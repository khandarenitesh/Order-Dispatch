﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CNF.Business.Model.Context
{
    /// <summary>
    /// Used ContextManager to configure context class
    /// </summary>
    //public class ContextManager:IDisposable
    //{
    //    public static SDSDBEntities _Context;

    //    public ContextManager()
    //    {

    //        SDSDBEntities context = new SDSDBEntities();

    //        _Context = context;

    //    }

    //    #region Dispose 

    //    private bool disposed = false;
    //    //Implement IDisposable.
    //    public void Dispose()
    //    {
    //        Dispose(true);
    //        GC.SuppressFinalize(this);
    //    }

    //    protected virtual void Dispose(bool disposing)
    //    {
    //        if (!disposed)
    //        {
    //            if (disposing)
    //            {
    //                // TO DO: clean up managed objects
    //            }
    //            // TO DO: clean up unmanaged objects
    //            disposed = true;
    //        }
    //    }

    //    #endregion 
    //}
}
