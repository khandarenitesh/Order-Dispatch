﻿using CNF.API.Controllers;
using CNF.Business.BusinessConstant;
using CNF.Business.Model.ChequeAccounting;
using CNF.Business.Model.Context;
using CNF.Business.Repositories;
using Quartz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;

namespace CNF.API.Classes
{
    public class SendAlertToSalesTeamForChqSmmry : BaseApiController, IJob
    {
        EmailNotification emailNotification = new EmailNotification();
        //List<CCEmailDtls> CCEmailList = new List<CCEmailDtls>();

        public void Execute(IJobExecutionContext context)
        {
            string Subject = string.Empty, CCEmail = string.Empty, Date = string.Empty, MailFilePath = string.Empty, BCCEmail = string.Empty, msgHTMLOutput = string.Empty;
            bool RetValue = false;
            List<ChqSummaryForSalesTeamModel> modelList = new List<ChqSummaryForSalesTeamModel>();
            List<ChqDepositDetails> chqDepositDetails = new List<ChqDepositDetails>();
            try
            {
                BusinessCont.SaveLog(0, 0, 0, "SendAlertToSalesTeamForChqSmmrySchedular", "Execute", "Scheduler Execution Start", BusinessCont.SuccessStatus);
                Date = DateTime.Today.Date.ToString("dd-MM-yyyy");
                Subject = ConfigurationManager.AppSettings["ChqSmmryAlertEmailSub"] + Date + " ";
                MailFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\SendAlertToSalesTeamForChqSmmry.html");
                CCEmail = ConfigurationManager.AppSettings["CCEmail"];
                BCCEmail = ConfigurationManager.AppSettings["BCCEmail"];

                //CCEmailList = _unitOfWork.chequeAccountingRepository.GetCCEmailDtlsPvt(1, 1, 7);
                //if (CCEmailList.Count > 0)
                //{
                //    for (int i = 0; i < CCEmailList.Count; i++)
                //    {
                //        CCEmail += ";" + CCEmailList[i].Email;
                //    }
                //    EmailCC = CCEmail.TrimStart(';');
                //}

                modelList = _unitOfWork.chequeAccountingRepository.GetRptChqSummaryForSalesTeamList(0, 0);
                if (modelList.Count > 0)
                {
                    msgHTMLOutput = _unitOfWork.chequeAccountingRepository.GetChequeSummaryForSalesTeamForReport(modelList, MailFilePath);
                    
                    //var result = _unitOfWork.chequeAccountingRepository.GetSalesTeamEmailList().ToList();
                    //if (result.Count > 0)
                    //{
                    //    foreach (var item in result)
                    //    {
                    //        RetValue = emailNotification.SendAlertToSalesTeamForChqSmmry(item.Email, CCEmail, BCCEmail, Subject, msgHTMLOutput);
                    //    }
                    //}

                    foreach (var item in modelList)
                    {
                        RetValue = emailNotification.SendAlertToSalesTeamForChqSmmry(item.Emailid, CCEmail, BCCEmail, Subject, msgHTMLOutput);
                    }
                }
                BusinessCont.SaveLog(0, 0, 0, "SendAlertToSalesTeamForChqSmmrySchedular", "Execute", "Scheduler Execution End", BusinessCont.SuccessStatus);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, "Send Alert To Sales Team For Chq Smmry Schedular", "", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
        }
    }
}