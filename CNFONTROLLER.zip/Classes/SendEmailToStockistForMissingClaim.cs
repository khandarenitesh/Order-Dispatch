﻿using CNF.API.Controllers;
using CNF.Business.BusinessConstant;
using CNF.Business.Model.ChequeAccounting;
using CNF.Business.Model.Login;
using Quartz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;

namespace CNF.API.Classes
{
    public class SendEmailToStockistForMissingClaim : BaseApiController, IJob
    {
        EmailNotification emailNotification = new EmailNotification();
        EmailSend Email = new EmailSend();
        //List<CCEmailDtls> CCEmailList = new List<CCEmailDtls>();

        public void Execute(IJobExecutionContext context)
        {
            string Date = string.Empty, Subject = string.Empty, MailFilePath = string.Empty, CCEmail = string.Empty, ClaimBodyText = string.Empty, BCCEmail = string.Empty;
            bool bResult = false;
            CCEmailDtls CCEmailModel = new CCEmailDtls();
            int emailSend = 0;
            try
            {
                Date = DateTime.Today.Date.ToString("dd-MM-yyyy");
                Subject = ConfigurationManager.AppSettings["ClaimSubj"] + Date + " ";
                ClaimBodyText = ConfigurationManager.AppSettings["ClaimBodyText"];
                MailFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\SendEmailForMissingClaimForm.html");
                CCEmail = ConfigurationManager.AppSettings["CCEmail"];
                BCCEmail = ConfigurationManager.AppSettings["BCCEmail"];

                //CCEmailList = _unitOfWork.chequeAccountingRepository.GetCCEmailDtlsPvt(1, 1, 10);
                //if (CCEmailList.Count > 0)
                //{
                //    for (int i = 0; i < CCEmailList.Count; i++)
                //    {
                //        CCEmail += ";" + CCEmailList[i].Email;
                //    }
                //    EmailCC = CCEmail.TrimStart(';');
                //}

                var result = _unitOfWork.OrderReturnRepository.GetStockistDtlsForMissingClaim(0, 0, 0);
                foreach (var item in result)
                {
                    bResult = emailNotification.SendEmailMissingClaimForm(item.Emailid, CCEmail, BCCEmail, Subject, item.StockistName, item.TransCourName, item.LRNumber, item.LRDate, MailFilePath);
                    if (bResult == true)
                    {
                        emailSend = _unitOfWork.OrderReturnRepository.AddSendEmailFlag(item.BranchId, item.CompId, item.LREntryId, 1);
                    }
                }
                BusinessCont.SaveLog(0, 0, 0, "SendEmailForMissingClaimFormSchedular", "Execute", "Scheduler Execution End", BusinessCont.SuccessStatus);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, "SendEmailForMissingClaimForm", "Send Email For Missing Claim Form", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
        }
    }
}