﻿using CNF.API.Controllers;
using CNF.Business.BusinessConstant;
using CNF.Business.Model.ChequeAccounting;
using Quartz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;

namespace CNF.API.Classes
{
    public class SendLRDetailsEmailToStockist : BaseApiController, IJob
    {
        EmailNotification emailNotification = new EmailNotification();
        //List<CCEmailDtls> CCEmailList = new List<CCEmailDtls>();

        public void Execute(IJobExecutionContext context)
        {
            string Subject = string.Empty, CCEmail = string.Empty, Date = string.Empty, MailFilePath = string.Empty, BCCEmail = string.Empty;
            bool RetValue = false;
            try
            {
                BusinessCont.SaveLog(0, 0, 0, "SendLRDetailsEmailToStockistSchedular", "Execute", "Scheduler Execution Start", BusinessCont.SuccessStatus);
                Date = DateTime.Today.Date.ToString("dd-MM-yyyy");
                Subject = ConfigurationManager.AppSettings["LREmailSubject"] + Date + " ";
                MailFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\SendLRDetailsEmailToStockist.html");
                CCEmail = ConfigurationManager.AppSettings["CCEmail"];
                BCCEmail = ConfigurationManager.AppSettings["BCCEmail"];

                //CCEmailList = _unitOfWork.chequeAccountingRepository.GetCCEmailDtlsPvt(1, 1, 6);
                //if (CCEmailList.Count > 0)
                //{
                //    for (int i = 0; i < CCEmailList.Count; i++)
                //    {
                //        CCEmail += ";" + CCEmailList[i].Email;
                //    }
                //    EmailCC = CCEmail.TrimStart(';');
                //}

                var result = _unitOfWork.chequeAccountingRepository.GetLRImportDetailsList(0, 0);
                foreach (var item in result)
                {
                    RetValue = emailNotification.SendLRImportEmailToStockist(item.Emailid, CCEmail, BCCEmail, Subject, item.StockistName, item.TransporterName, item.LRNo, MailFilePath);
                }
                BusinessCont.SaveLog(0, 0, 0, "SendLRDetailsEmailToStockistSchedular", "Execute", "Scheduler Execution End", BusinessCont.SuccessStatus);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, "Send LR Details Email To Stockist Schedular", "", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
        }

    }
}