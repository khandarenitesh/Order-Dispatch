﻿using CNF.Business.Model.Login;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CNF.API.Controllers
{   
    //[RoutePrefix("Logger")]    
    //public class LoggerController : BaseApiController
    //{
    //    [Route("GetLogDetails")]
    //    [HttpPost]      
    //    public IHttpActionResult GetLogDetails()
    //    {
    //        var result = _unitOfWork.GetLoggerRepositoryInstance.GetLoggerDetails();
    //        if(result !=null)
    //        {
    //            return Ok(result);
    //        }
    //        return BadRequest();
    //    }
    //}
}
