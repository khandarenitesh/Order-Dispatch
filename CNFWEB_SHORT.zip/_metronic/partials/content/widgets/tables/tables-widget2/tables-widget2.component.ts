import { Component } from '@angular/core';

@Component({
  selector: 'app-tables-widget2',
  templateUrl: './tables-widget2.component.html',
})
export class TablesWidget2Component {
  constructor() {}
}
