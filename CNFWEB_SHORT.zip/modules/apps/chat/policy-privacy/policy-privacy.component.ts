import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policy-privacy',
  templateUrl: './policy-privacy.component.html',
  styleUrls: ['./policy-privacy.component.scss']
})
export class PolicyPrivacyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
