export class UserLogin {
    DisplayName: string;
    MobileNo: string;
    UserAddress: string;
    UserName: string;
    UserId: number;
    RoleId: number;
    RoleName: string;
    BranchId: number = 0;
    CompanyId: number = 0;
    EmpId: number = 0;
    IsActive: string;
    BranchCode: string = '';
    BranchName: string = '';
    City: string = '';
    roleName: string = '';
    EmpNo: string = '';
    EmpName: string = '';
    EmpMob: string = ''
    CompanyCode: string = '';
    CompanyName: string = '';
    CompCityName: string = '';
    Password: string = '';
}
