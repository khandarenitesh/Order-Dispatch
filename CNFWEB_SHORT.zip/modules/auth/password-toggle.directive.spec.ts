import { PasswordToggleDirective } from './password-toggle.directive';

describe('PasswordToggleDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordToggleDirective();
    expect(directive).toBeTruthy();
  });
});
