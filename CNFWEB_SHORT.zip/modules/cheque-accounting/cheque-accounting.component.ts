import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cheque-accounting',
  templateUrl: './cheque-accounting.component.html',
  styleUrls: ['./cheque-accounting.component.scss']
})
export class ChequeAccountingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
