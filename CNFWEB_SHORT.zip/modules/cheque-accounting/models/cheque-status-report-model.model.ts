export class ChequeStatusReportModel {
    CompId: number = 0;
    BranchId: number = 0;
    FromDate : Date = new Date();
    ToDate : Date = new Date();
}
