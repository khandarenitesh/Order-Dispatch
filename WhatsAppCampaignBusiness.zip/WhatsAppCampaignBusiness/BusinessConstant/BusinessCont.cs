using HPGASNCEnquiryBusiness.Models.Entity;
using HPGASNCEnquiryBusiness.Models.Masters;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Web.Script.Serialization;
using System.IO;
using WhatsAppCampaignBusiness.Models.Entity;

namespace HPGASNCEnquiryBusiness.BusinessConstant
{
	public class BusinessCont
	{
		public static string SuccessStatus = "Success";
		public static string FailStatus = "Fail";

		public static string ActiveStatus = "ACTIVE";
		public static string InActiveStatus = "INACTIVE";
		public static string DateFormat = "dd-MM-yyyy";

		public static string MobSource = "MOBILE";
		public static string WebSource = "WEB";

		public static string DateTime24HrFormat = "yyyy-MM-dd hh:mm:ss";

		public static string DateFormatUpdate = "yyyy-MM-dd";

		public static string ExceptionMsg(Exception exception)
		{
			return "Exception= " + exception.ToString() + ",  Inner Exception= " + exception.InnerException?.ToString() ?? string.Empty;
		}

		public static DateTime StrConvertIntoDatetime(string Datetime)
		{
			return DateTime.ParseExact(Datetime, new string[] { "dd.MM.yyyy", "dd-MM-yyyy", "dd/MM/yyyy", "yyyy-MM-dd", "yyyy/MM/dd", "yyyy-MM-dd HH:mm:ss.fff", "yyyy/MM/dd HH:mm:ss.fff", "dd-MM-yyyy HH:mm", "dd-MM-yyyy HH:mm:ss.fff", "dd/MM/yyyy HH:mm:ss.fff", "yyyy-MM-dd HH:mm tt", "yyyy/MM/dd hh:mm tt", "dd-MM-yyyy hh:mm tt", "dd/MM/yyyy hh:mm tt", "dd/MM/yyyy hh:mm:ss tt", "dd-MM-yyyy HH:mm tt", "dd/MM/yyyy HH:mm tt", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss tt", "dd/MM/yyyy h:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt" }, CultureInfo.InvariantCulture, DateTimeStyles.None);
		}

		public static string CheckNullandConvertDateTime(DateTime? DT)
		{
			return DT ? .ToString(DateFormat) ?? string.Empty;
		}

		public static decimal SaveLog(decimal logID, int distributorId, string logFor, string logData, string logStatus, string logException)
		{
			decimal LogId = 0;
			string SaveLog = ConfigurationManager.AppSettings["SaveLog"];
			if (SaveLog == "Yes")
			{
				using (HPGASNCEnquiryEntities contextManager = new HPGASNCEnquiryEntities())
				{
					var ID = contextManager.sp_AddEditAuditLog(logID,  distributorId, logFor, logData, logStatus, DateTime.Now, logException).FirstOrDefault();
					if (ID != null)
						LogId = ID.Value;
				}
			}
			return LogId;
		}

		public static string CheckNullandConvertDateWithTime(DateTime? DT)
		{
			return DT?.ToString(DateTime24HrFormat) ?? string.Empty;
		}

		// To Convert Xml To Json
		public static string XmlToJson(string xml)
		{
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(xml);
			string jsonText = JsonConvert.SerializeXmlNode(doc);
			return jsonText;
		}

        public static decimal SaveAPILog(decimal logID, int distributorId, string logFor, string logData, string logStatus, string logException)
        {
            decimal LogId = 0;
            using (HPGASNCEnquiryEntities contextManager = new HPGASNCEnquiryEntities())
            {
               // var ID = contextManager.sp_AddEditAPIHitLog(logID, distributorId, logFor, logData, logStatus, DateTime.Now, logException).FirstOrDefault();
                //if (ID != null)
                //    LogId = ID.Value;
            }
            return LogId;
        }

        // WhatsAppMsg - pickyassist
        public static async Task<string> WhatsAppMsg(string WhatsappMsg, string MobileNos, string FilePath)
		{
			List<MobNoInfo> Msglist = null;
			PickyJSON dtlsModel = null;
			MobNoInfo MobmsgInfo = null;
			string result = string.Empty, token = string.Empty, MobileNo = string.Empty;
			try
			{
				token = ConfigurationManager.AppSettings["Token"];
				if (MobileNos != null && token != null)
				{
					Msglist = new List<MobNoInfo>();
					if (MobileNos.Contains(","))
					{
						string[] MobNos = MobileNos.Trim().Split(',');
						foreach (var MobNo in MobNos)
						{
							if (MobNo.Length == 10)
							{
								MobileNo = "91" + MobNo;
							}
							else
							{
								MobileNo = MobNo;
							}

							MobmsgInfo = new MobNoInfo
							{
								number = MobileNo,
								message = WhatsappMsg
							};
							Msglist.Add(MobmsgInfo);
						}
					}
					else
					{
						if (MobileNos.Length == 10)
						{
							MobileNo = "91" + MobileNos;
						}
						else
						{
							MobileNo = MobileNos;
						}

						MobmsgInfo = new MobNoInfo
						{
							number = MobileNo,
							message = WhatsappMsg
						};
						Msglist.Add(MobmsgInfo);
					}

					using (var client = new HttpClient())
					{
						dtlsModel = new PickyJSON
						{
							token = token,
							priority = "0",
							application = "2",
							sleep = "0",
							globalmessage = "",
							globalmedia = FilePath,
							data = Msglist
						};
						var data = JsonConvert.SerializeObject(dtlsModel);
						var stringContent = new StringContent(data, Encoding.UTF8, "application/json");
						var response = await client.PostAsync("https://pickyassist.com/app/api/v1/push", stringContent);
						result = await response.Content.ReadAsStringAsync();
					}
				}
				return result;
			}
			catch (Exception ex)
			{
				//SaveAPILog(0, 0, "WhatsAppMsg", "MobileNos = " + MobileNos, FailStatus, ExceptionMsg(ex.InnerException));
				throw ex;
			}
		}

		/// <summary>
		/// public method for send notification to android user
		/// </summary>
		/// <param name="Token">send notification to Mobile token using FCM</param>
		/// <param name="NotiTitle">Notification title</param>
		/// <param name="NotificationMsg">Notification message</param>
		/// <returns></returns>
		public static string AndroidNotification(string Token, string NotiTitle, string NotificationMsg)
		{
			string ResponseStr = string.Empty;
			try
			{
				string ApplicationKey = "AAAABPb3xok:APA91bGw6ohY5BphAyQyciNgsiSJQBpC4KR1zOQIKVvBA57EQP6FXueMRukwGXk7E3hpNs-hxC6Z69gxHysXt6MO7i4rYemZrdTz161MYvf9aYAdmS8Ua39k88KPEvtyMTdeGqbQi8R3";

				string senderId = "21323302537"; // senderId is sender key of web project in fcm

				WebRequest tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send") as HttpWebRequest;

				tRequest.Method = "Post";
				tRequest.ContentType = "application/json";
				tRequest.UseDefaultCredentials = true;
				tRequest.Credentials = CredentialCache.DefaultNetworkCredentials;
				var data = new
				{
					to = Token,
					notification = new
					{
						title = NotiTitle,
						body = NotificationMsg
					}
				};
				var serializer = new JavaScriptSerializer();
				var json = serializer.Serialize(data);
				Byte[] byteArray = Encoding.UTF8.GetBytes(json);
				tRequest.Headers.Add(string.Format("Authorization: key={0}", ApplicationKey));
				tRequest.Headers.Add(string.Format("Sender: id={0}", senderId));
				tRequest.ContentLength = byteArray.Length;
				using (Stream dataStream = tRequest.GetRequestStream())
				{
					dataStream.Write(byteArray, 0, byteArray.Length);
					using (HttpWebResponse tResponse = tRequest.GetResponse() as HttpWebResponse)
					{
						using (Stream dataStreamResponse = tResponse.GetResponseStream())
						{
							using (StreamReader tReader = new StreamReader(dataStreamResponse))
							{
								String sResponseFromServer = tReader.ReadToEnd();
								ResponseStr = sResponseFromServer;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return ResponseStr;
		}

	}
}
