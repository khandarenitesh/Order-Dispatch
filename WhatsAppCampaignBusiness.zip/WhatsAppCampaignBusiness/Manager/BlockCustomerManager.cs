﻿using HPGASNCEnquiryBusiness.BusinessConstant;
using HPGASNCEnquiryBusiness.Models.Customer;
using HPGASNCEnquiryBusiness.Models.Entity;
using PagedList;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class BlockCustomerManager : IDisposable
    {
        decimal LogId = 0;
        ContextManager contextManager = new ContextManager();
        #region Dispose 

        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }

        #endregion

        #region Block Consumer Details 

        /// <summary>
        /// Get Consumer Feedback count
        /// </summary>
        /// <param name="DistributorId"></param>
        /// <returns></returns>
        public IEnumerable<BlockCustomer> GetBlockConsumerlist(int DistributorId, string callStatusCall,string uniSearch, string flag, int pageNo, int pageSize)
        {
            return GetBlockConsumerlistPR(DistributorId, callStatusCall, uniSearch, flag, pageNo, pageSize);
        }

        /// <summary>
        /// Get Consumer Feedback count
        /// </summary>
        /// <param name="DistributorId"></param>
        /// <returns></returns>
        private IEnumerable<BlockCustomer> GetBlockConsumerlistPR(int DistributorId, string callStatusCall, string uniSearch, string flag, int pageNo, int pageSize)
        {
            long Srno = 1;
            pageNo = pageNo == 0 ? 1 : pageNo;
            pageSize = pageSize == 0 ? 1 : pageSize;
            try
            {
                return ContextManager._Context.Bcf_sp_GetBlockConsumersLst(DistributorId, callStatusCall, flag, uniSearch).Select(x => new BlockCustomer
                {
                    Srno = Srno++,
                    IVRSMobNo = x.IVRSMobNo,
                    //DistributorCode = x.DistributorCode,
                    Address = x.Address,
                    AreaName = x.AreaName,
                    BlockDate = x.BlockDate == null ? "" : Convert.ToDateTime(x.BlockDate).ToString("dd-MM-yyyy"),
                    CDCMSMobNo = x.CDCMSMobNo,
                    ConsumerName = x.ConsumerName,
                    ConsumerNo = x.ConsumerNo,
                    Feedback = x.Feedback,
                    FeedbackDT = x.FeedbackDT == null ? "" : Convert.ToDateTime(x.FeedbackDT).ToString("dd-MM-yyyy"),
                    UniqueConsumerId = x.UniqueConsumerId == null ? "0" : Convert.ToString(x.UniqueConsumerId),
                    CallStatusId = x.CallStatusId,
                    CallStatusName = x.CallStatusName,
                    IsCylinderBook = x.IsCylinderBook,
                    Blockedby = x.Blockedby,
                    FeedbackType = x.FeedbackType,
                    NoOfCall = x.NoOfCall,
                    ActualMobCallStatus = x.ActualMobCallStatus
                }).ToList().ToPagedList(pageNo, pageSize);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #endregion

        #region Get Call Status Mst

        /// <summary>
        /// Get Call Status Mst
        /// </summary>
        /// <returns></returns>
        public List<CallStatusMst> GetCallStatusMst()
        {
            return GetCallStatusMstPR();
        }

        /// <summary>
        /// Get Call Status Mst
        /// </summary>
        /// <returns></returns>
        private List<CallStatusMst> GetCallStatusMstPR()
        {
            try
            {
                return ContextManager._Context.Bcf_sp_GetCallStatusMaster().Select(x => new CallStatusMst
                {
                    Id = x.Id,
                    CallStatusName = x.CallStatusName,
                    Colour = x.Colour,
                    IsActive = x.IsActive
                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion Get Call Status Mst

        #region Save Consumer Feedback

        public long SaveConsumerFeedback(SaveFeedBack saveFeedBack)
        {
            return SaveConsumerFeedbackPvt(saveFeedBack);
        }

        private long SaveConsumerFeedbackPvt(SaveFeedBack saveFeedBack)
        {
            long Id = 0;
            ObjectParameter obj=new ObjectParameter("Result",typeof(long));

            try
            {
                 ContextManager._Context.Bcf_sp_AddEditBlkConsAgainstCallStatus(saveFeedBack.Id, saveFeedBack.StaffRefNo, Convert.ToDecimal(saveFeedBack.UniqueConsumerId), saveFeedBack.DistributorId, saveFeedBack.DistributorCode,
                        saveFeedBack.Feedback, saveFeedBack.CallStatusId, saveFeedBack.CallStatusName, saveFeedBack.FeedbackType,saveFeedBack.ActualMobCallStatus, saveFeedBack.Operation, obj);

                if (obj != null)
                {
                    Id = Convert.ToInt64(obj.Value);
                }
            }
            catch (Exception Ex)
            {
                throw Ex;
            }

            return Id;
        }

        #endregion 

        #region Get block Consumer  Call Status list

        /// <summary>
        ///  Get Block Consumer Status
        /// </summary>
        /// <param name="DistributorId"></param>
        /// <param name="UniqueConsumerId"></param>
        /// <returns></returns>
        public List<SaveFeedBack> GetBlockConsumerCallStatus(int DistributorId, decimal UniqueConsumerId)
        {
            return GetBlockConsumerCallStatusPR(DistributorId, UniqueConsumerId);
        }

        /// <summary>
        ///  Get Block Consumer Status
        /// </summary>
        /// <param name="DistributorId"></param>
        /// <param name="UniqueConsumerId"></param>
        /// <returns></returns>
        private List<SaveFeedBack> GetBlockConsumerCallStatusPR(int DistributorId, decimal UniqueConsumerId)
        {
            try
            {
                return ContextManager._Context.Bcf_sp_GetBlockConsumerCallStatusLst(DistributorId, UniqueConsumerId).Select(x => new SaveFeedBack
                {
                  Id=x.Id,
                  FeedbackType=x.FeedbackType,
                  UniqueConsumerId=x.UniqueConsumerId.ToString(),
                  CallStatusId=x.CallStatusId,
                  StaffRefNo=x.StaffRefNo,
                  CallStatusName=x.CallStatusName,
                  DistributorCode=x.DistributorCode,
                  DistributorId=x.DistributorId,
                  Feedback=x.Feedback,
                  FeedbackDate=x.FeedbackDate,
                  FeedbackDateSt= BusinessCont.CheckNullandConvertDateTime(x.FeedbackDate),
                  ActualMobCallStatus=x.ActualMobCallStatus
                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion Get Call Status Mst

        #region Get Consumer Feedback Count

        /// <summary>
        /// Get Consumer Feedback count
        /// </summary>
        /// <param name="DistributorId"></param>
        /// <returns></returns>
        public List<CltFeedbackCount> GetConsumerFeedbackCount(int DistributorId, string SACode)
        {
            return GetConsumerFeedbackCountPR(DistributorId, SACode);
        }

        /// <summary>
        /// Get Consumer Feedback count
        /// </summary>
        /// <param name="DistributorId"></param>
        /// <returns></returns>
        private List<CltFeedbackCount> GetConsumerFeedbackCountPR(int DistributorId, string SACode)
        {
            try
            {
                return ContextManager._Context.Bcf_sp_GetCallStatuswiseCnt(DistributorId, SACode).Select(x => new CltFeedbackCount
                {
                    CallStatusColour = x.CallStatusColour,
                    ConsCnt = x.ConsCnt
                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion Get Consumer Feedback Count

        #region Get Block Consumer count

        /// <summary>
        /// Get Block Consumer count
        /// </summary>
        /// <param name="DistributorId"></param>
        /// <returns></returns>
        public BlkcltCnt GetBlockConsumersCnt(int DistributorId)
        {
            return GetBlockConsumersCntPR(DistributorId);
        }

        /// <summary>
        /// Get Block Consumer count
        /// </summary>
        /// <param name="DistributorId"></param>
        /// <returns></returns>
        private BlkcltCnt GetBlockConsumersCntPR(int DistributorId)
        {
            try
            {
                return ContextManager._Context.Bcf_sp_GetBlockConsumersCnt(DistributorId).Select(x => new BlkcltCnt
                {
                    CalledCnt = x.CalledCnt,
                    ConsWithNo = x.ConsWithNo,
                    PendingCnt = x.PendingCnt,
                    TotalConsCnt = x.TotalConsCnt
                }).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion Get Block Consumer count

        #region Update Consumer Booking details

        public int UpdateCylinderBook(int DistributorId, decimal UniqueConsumerId)
        {
            return UpdateCylinderBookPvt(DistributorId, UniqueConsumerId);
        }

        private int UpdateCylinderBookPvt(int DistributorId, decimal UniqueConsumerId)
        {
            int RtnValue = 0;
            ObjectParameter temp = new ObjectParameter("RowCnt", typeof(Int16));
            try
            {
                ContextManager._Context.Bcf_sp_UpdateCylinderBookFlag(DistributorId, UniqueConsumerId, temp);
                if (temp != null)
                {
                    RtnValue = Convert.ToInt16(temp.Value);
                }
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
            return RtnValue;
        }

        #endregion
        #region Get Area wise Count block consumer

        /// <summary>
        /// Get Area wise Count 
        /// </summary>
        /// <param name="DistCode"></param>
        /// <returns></returns>
        public List<AreaWiseCount> GetAreaWiseBkCnt(int DistributorId)
        {
            return GetAreaWiseBkCntPR(DistributorId);
        }

        /// <summary>
        /// Get Area wise Count 
        /// </summary>
        /// <param name="DistCode"></param>
        /// <returns></returns>
        private List<AreaWiseCount> GetAreaWiseBkCntPR(int DistributorId)
        {
            try
            {
                return ContextManager._Context.BCF_sp_GetAreawisePendingConsCnt(DistributorId).Select(x => new AreaWiseCount
                {
                    CalledCnt = x.CalledCnt,
                    AreaName = x.AreaName,
                    DistributorCode=x.DistributorCode,
                    PendingCnt = x.PendingCnt,
                    TotalConsCnt = x.TotalConsCnt
                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion Get Area wise Count block consumer

        #region Get Block Consumers SA Wise Cnt

        /// <summary>
        /// Get Block Consumers SA Wise Cnt
        /// </summary>
        /// <param name="code"></param>
        /// <param name="Flag"></param>
        /// <returns></returns>
        public List<SAwiseBkConCount> GetBlockConsumersSAWiseCnt(string  code, string Flag)
        {
            return GetBlockConsumersSAWiseCntPR(code, Flag);
        }

        /// <summary>
        /// Get Block Consumers SA Wise Cnt
        /// </summary>
        /// <param name="code"></param>
        /// <param name="Flag"></param>
        /// <returns></returns>
        private List<SAwiseBkConCount> GetBlockConsumersSAWiseCntPR(string code, string Flag)
        {
            try
            {
                return ContextManager._Context.Bcf_sp_SchGetBlockConsumersSAWiseCnt(code, Flag).Select(x => new SAwiseBkConCount
                {
                    SACode=x.SACode,
                    SAName=x.SAName,
                    CompCnt=x.CompCnt,
                    ConsWithNo=x.ConsWithNo,
                    DistributorCode=x.DistributorCode,
                    DistributorName=x.DistributorName,
                    PendingConsCnt=x.PendingConsCnt,
                    TodCompCnt=x.TodCompCnt,
                    TotalConsCnt=x.TotalConsCnt
                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion Get Block Consumers SA Wise Cnt


    }
}
