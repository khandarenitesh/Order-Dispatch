using HPGASNCEnquiryBusiness.BusinessConstant;
using HPGASNCEnquiryBusiness.Models.ConfiguratoinDetails;
using HPGASNCEnquiryBusiness.Models.Entity;
using HPGASNCEnquiryBusiness.Models.WhatApp;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using WhatsAppCampaignBusiness.Models.Entity;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class ConfiguratoinDetailsManager : IDisposable
    {
        ContextManager contextManager = new ContextManager();

        #region Dispose 
        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }
        #endregion


        // Common Method----------

        #region Get All Template List
        public List<TemplateDetails> GetAllTemplateList(string TemplateFor)
        {
            return GetAllTemplateListPvt(TemplateFor);
        }
        private List<TemplateDetails> GetAllTemplateListPvt(string TemplateFor)
        {
            List<TemplateDetails> templateList = new List<TemplateDetails>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    templateList = _Context.usp_GetSBCMsgTemplateList(TemplateFor).Select(x => new TemplateDetails()
                    {
                        TemplateId = x.TemplateId,
                        TemplateName = x.TemplateName,
                        IsActive = x.IsActive
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " GetAllTemplateListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return templateList;
        }
        #endregion

        #region Get Distributor Details
        public List<DistributorDtlCD> GetDistributorDetails(int DistributorId, string SACode)
        {
            return GetDistributorDetailsCDPvt(DistributorId, SACode);
        }
        private List<DistributorDtlCD> GetDistributorDetailsCDPvt(int DistributorId, string SACode)
        {
            List<DistributorDtlCD> List = new List<DistributorDtlCD>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    List = _Context.sp_GetDistributorMasterNew(DistributorId, SACode).Select(x => new DistributorDtlCD
                    {
                        DistributorId = x.DistributorId,
                        DistributorName = x.DistributorName,
                        Email = x.Email,
                        IsDistributorLive = x.IsDistributorLive,
                        JDEDistributorCode = x.JDEDistributorCode,
                        MobileNo = x.MobileNo,
                        OwnerName = x.OwnerName,
                        SACode = x.SACode,
                        selected = x.selected
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "GetDistributorDetailsCDPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return List;
        }
        #endregion

        #region Update Webhook Data To Main Table-  After Send messages
        public long UpdateWebhookDataToMainTable(string SACode, int DistributorId)
        {
            return UpdateWebhookDataToMainTablePvt(SACode, DistributorId);
        }
        private long UpdateWebhookDataToMainTablePvt(string SACode, int DistributorId)
        {
            long Retvalue = 0;
            try
            {
                ObjectParameter obj = new ObjectParameter("RetVal", typeof(string));
                using (HPGASNCEnquiryEntities Context = new HPGASNCEnquiryEntities())
                {
                    Retvalue = Context.usp_UpdateWebhookdata_Bridge(SACode, Convert.ToString(DistributorId), obj);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " UpdateWebhookDataToMainTable", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        //DBC Campaign New---------

        #region Get SBC Distributor Group Mapping List
        public List<SBCDistributorGroupMappingList> GetSBCDistributorGroupMappingList(string SACode)
        {
            return GetSBCDistributorGroupMappingListPvt(SACode);
        }
        private List<SBCDistributorGroupMappingList> GetSBCDistributorGroupMappingListPvt(string SACode)
        {
            List<SBCDistributorGroupMappingList> model = new List<SBCDistributorGroupMappingList>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    model = _Context.usp_SBCDistributorGroupMappingList(SACode).Select(x => new SBCDistributorGroupMappingList()
                    {
                        GroupId = x.GroupId,
                        GroupName = x.GroupName,
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " GetSBCDistributorGroupMappingListPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return model;
        }
        #endregion

        //#region Get SBC Configuration Details Distributor By List
        //public List<SBCConfigDetailsDistributorByList> GetSBCConfigDetailsDistributorByList(int DistributorId)
        //{
        //    return GetSBCConfigDetailsDistributorByListPvt(DistributorId);
        //}
        //private List<SBCConfigDetailsDistributorByList> GetSBCConfigDetailsDistributorByListPvt(int DistributorId)
        //{
        //    List<SBCConfigDetailsDistributorByList> sBCConfigDetailsDistributorByList = new List<SBCConfigDetailsDistributorByList>();
        //    try
        //    {
        //        using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
        //        {
        //            sBCConfigDetailsDistributorByList =_Context.usp_GetSBCConfigDetailsDistributorByList(DistributorId).Select(x => new SBCConfigDetailsDistributorByList()
        //            {
        //                DistributorId = x.DistributorId,
        //                JDEDistributorCode = x.JDEDistributorCode,
        //                DistributorName = x.DistributorName,
        //                DistributorMobile = Convert.ToString(x.DistributorMobile),
        //                EmergencyContactNo = x.EmergencyContactNo,
        //                RSPAmount = x.RSPAmount
        //            }).ToList();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, DistributorId, " GetSBCConfigDetailsDistributorByListPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //    }
        //    return sBCConfigDetailsDistributorByList;
        //}
        //#endregion

        #region Get Distributor List By Group
        public List<SBCDistributorListByGroupList> GetDistributorListByGroup(string SACode, string GroupName)
        {
            return GetDistributorListByGroupPvt(SACode, GroupName);
        }
        private List<SBCDistributorListByGroupList> GetDistributorListByGroupPvt(string SACode, string GroupName)
        {
            List<SBCDistributorListByGroupList> model = new List<SBCDistributorListByGroupList>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    model = _Context.sp_GetDistributorListByGroup(SACode, GroupName).Select(x => new SBCDistributorListByGroupList()
                    {
                        DistributorId = x.DistributorId,
                        JDEDistributorCode = x.JDEDistributorCode,
                        DistributorName = x.DistributorName,
                        OwnerName = x.OwnerName,
                        IsDistributorLive = x.IsDistributorLive,
                        MobileNo = Convert.ToDecimal(x.MobileNo),
                        Email = x.Email,
                        SACode = x.SACode,
                        GroupName = x.GroupName,
                        selected = x.selected,
                        TemplateId = x.TemplateId,
                        TemplateName = x.TemplateName
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " GetDistributorListByGroupPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return model;
        }
        #endregion

        #region SBC Distributor Group Mapping -> Add/Update
        public long SBCDistributorGroupMappingAddEdit(SBCDistributorGroupMappingAddEdit model)
        {
            return SBCDistributorGroupMappingAddEditPvt(model);
        }
        private long SBCDistributorGroupMappingAddEditPvt(SBCDistributorGroupMappingAddEdit model)
        {
            long Retvalue = 0;
            try
            {
                ObjectParameter obj = new ObjectParameter("RetValue", typeof(string));
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    Retvalue = _Context.usp_SBCDistributorGroupMappingAddEdit(model.GroupId, model.GroupName, model.SACode, model.DistributorIdArray, model.TemplateId, model.IsActive, model.Action, obj);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " SBCDistributorGroupMappingAddEditPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region Add Update SBC Config Details
        public long SBCConfigDetailsAddUpdate(SBCConfigDetails configdetails)
        {
            return SBCConfigDetailsAddUpdatePvt(configdetails);
        }
        private long SBCConfigDetailsAddUpdatePvt(SBCConfigDetails configdetails)
        {
            long Retvalue = 0;
            try
            {
                // Mutlitple Distributor
                string DistributorIdarrayValue = configdetails.DistributorIdarray;
                DistributorIdarrayValue = DistributorIdarrayValue.Remove(DistributorIdarrayValue.Length - 1, 1);
                int[] DistributorNums = Array.ConvertAll(DistributorIdarrayValue.Split(','), int.Parse);

                foreach (var i in DistributorNums)
                {
                    using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                    {
                        Retvalue = _Context.usp_SBCConfigDetailsAddUpdate(
                            configdetails.DBCConfId, configdetails.SACode, configdetails.ScheduleDate, configdetails.GroupName, i,
                            configdetails.DistributorMobNo, configdetails.EmergencyNo, configdetails.IsWithRefillCost, configdetails.RSP,
                            configdetails.TemplateId, configdetails.MsgQty, configdetails.CurrentStatus, configdetails.Action, configdetails.Retvalue, configdetails.ScheduleDaily);
                    }
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " SBCConfigDetailsAddUpdatePvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region Update SBC Config Details
        public long SBCConfigDetailsUpdate(int DBCConfId, int DistributorId, string CurrentStatus)
        {
            return SBCConfigDetailsUpdatePvt(DBCConfId, DistributorId, CurrentStatus);
        }
        private long SBCConfigDetailsUpdatePvt(int DBCConfId, int DistributorId, string CurrentStatus)
        {
            long Retvalue = 0;
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    Retvalue = _Context.usp_SBCConfigDetailsAddUpdate(DBCConfId, "", null, "", DistributorId, "", "", "", "", "", 0, CurrentStatus, "STATUS", "", "");
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " GetSBCMsgTemplateListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region Get All SBC Users With Config
        public List<ConsumerDtlsModel> GetAllSBCUsersWithConfig(string SACode, int DistributorId, int Qty)
        {
            return GetAllSBCUsersWithConfigPvt(SACode, DistributorId, Qty);
        }
        private List<ConsumerDtlsModel> GetAllSBCUsersWithConfigPvt(string SACode, int DistributorId, int Qty)
        {
            List<ConsumerDtlsModel> SBCWhatsAppList = new List<ConsumerDtlsModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    SBCWhatsAppList = _Context.usp_GetAllSBCUsersWithConfig(SACode, DistributorId, Qty).Select(a => new ConsumerDtlsModel
                    {
                        SACode = Convert.ToInt32(a.SACode),
                        DistributorIdint = Convert.ToInt32(a.DistributorIdint),
                        DistributorCode = a.DistributorCode,
                        DistributorName = a.DistributorName,
                        UniqueConsumerId = Convert.ToDecimal(a.UniqueConsumerId),
                        ConsumerNo = Convert.ToString(a.ConsumerNo),
                        MobileNo = a.MobileNo,
                        ConsumerName = a.ConsumerName,
                        DistributorEmergencyContactNo = a.DistributorEmergencyContactNo,
                        DistributorMobileNo = a.DistributorMobileNo,
                        RSPAmount = a.RSPAmount,
                        DPhoneNo = a.DPhoneNo
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, " GetAllSBCUsersWithConfigPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return SBCWhatsAppList;
        }
        #endregion

        #region Get SBC Config Details List
        public List<SBCConfigDetailsList> GetSBCConfigDetailsList(string SACode)
        {
            return GetSBCConfigDetailsListPvt(SACode);
        }
        private List<SBCConfigDetailsList> GetSBCConfigDetailsListPvt(string SACode)
        {
            List<SBCConfigDetailsList> sBCConfigDetailsList = new List<SBCConfigDetailsList>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    sBCConfigDetailsList = _Context.usp_SBCConfigDetailsList(SACode).Select(x => new SBCConfigDetailsList()
                    {
                        DBCConfId = Convert.ToInt32(x.DBCConfId),
                        SACode = x.SACode,
                        GroupName = x.GroupName,
                        DistributorId = Convert.ToInt32(x.DistributorId),
                        JDEDistributorCode = x.JDEDistributorCode,
                        DistributorName = x.DistributorName,
                        TemplateId = x.TemplateId,
                        TemplateName = x.TemplateName,
                        ScheduleDate = Convert.ToDateTime(x.ScheduleDate),
                        MsgQty = Convert.ToInt32(x.ScheduledQty),
                        CurrentStatus = x.CurrentStatus,
                        TotalConsumer = Convert.ToInt32(x.TotalConsumer),
                        NonWhatsAppNo = Convert.ToInt32(x.NonWhatsAppNo),
                        TotalMsgSend = Convert.ToInt32(x.TotalMsgSend),
                        Balanced = Convert.ToInt32(x.Balanced),
                        TodaySend = Convert.ToInt32(x.TodaySend)
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " GetSBCConfigDetailsListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return sBCConfigDetailsList;
        }
        #endregion

        #region Get SBC Config Details List For Schedular
        public List<SBCConfigDetailsList> GetAllSASBCConfigDetailsList(string SACode)
        {
            return GetAllSASBCConfigDetailsListPvt(SACode);
        }
        private List<SBCConfigDetailsList> GetAllSASBCConfigDetailsListPvt(string SACode)
        {
            List<SBCConfigDetailsList> sBCConfigDetailsList = new List<SBCConfigDetailsList>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    sBCConfigDetailsList = _Context.usp_SBCConfigDetailsListScheduler(SACode).Select(x => new SBCConfigDetailsList()
                    {
                        DBCConfId = Convert.ToInt32(x.DBCConfId),
                        SACode = x.SACode,
                        ScheduleDate = Convert.ToDateTime(x.ScheduleDate),
                        DistributorId = Convert.ToInt32(x.DistributorId),
                        JDEDistributorCode = x.JDEDistributorCode,
                        DistributorName = x.DistributorName,
                        DistributorMobNo = x.DistributorMobNo,
                        EmergencyNo = x.EmergencyNo,
                        IsWithRefillCost = x.IsWithRefillCost,
                        RSP = x.RSP,
                        TemplateId = x.TemplateId,
                        TemplateName = x.TemplateName,
                        MsgQty = Convert.ToInt32(x.MsgQty),
                        EntryDate = Convert.ToDateTime(x.EntryDate),
                        CurrentStatus = x.CurrentStatus
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetAllSASBCConfigDetailsListPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return sBCConfigDetailsList;
        }
        #endregion

        //Suraksha Campaign New---------

        #region Get Suraksha Distributor Group Mapping List
        public List<SurakshaDistributorGroupMappingList> GetSurakshaDistributorGroupMappingList(string SACode)
        {
            return GetSurakshaDistributorGroupMappingListPvt(SACode);
        }
        private List<SurakshaDistributorGroupMappingList> GetSurakshaDistributorGroupMappingListPvt(string SACode)
        {
            List<SurakshaDistributorGroupMappingList> model = new List<SurakshaDistributorGroupMappingList>();
            try
            {
                model = ContextManager._Context.usp_SurakshaDistributorGroupMappingList(SACode).Select(x => new SurakshaDistributorGroupMappingList()
                {
                    GroupId = x.GroupId,
                    GroupName = x.GroupName,
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetSurakshaDistributorGroupMappingListPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return model;
        }
        #endregion

        #region Get Suraksha Distributor List By Group
        public List<SurakshaDistributorListByGroupList> GetSurakshaDistributorListByGroup(string SACode, string GroupName)
        {
            return GetSurakshaDistributorListByGroupPvt(SACode, GroupName);
        }
        private List<SurakshaDistributorListByGroupList> GetSurakshaDistributorListByGroupPvt(string SACode, string GroupName)
        {
            List<SurakshaDistributorListByGroupList> model = new List<SurakshaDistributorListByGroupList>();
            try
            {
                model = ContextManager._Context.sp_GetSurakshaDistributorListByGroup(SACode, GroupName).Select(x => new SurakshaDistributorListByGroupList()
                {
                    DistributorId = x.DistributorId,
                    JDEDistributorCode = x.JDEDistributorCode,
                    DistributorName = x.DistributorName,
                    OwnerName = x.OwnerName,
                    IsDistributorLive = x.IsDistributorLive,
                    MobileNo = Convert.ToDecimal(x.MobileNo),
                    Email = x.Email,
                    SACode = x.SACode,
                    GroupName = x.GroupName,
                    selected = x.selected,
                    TemplateId = x.TemplateId,
                    TemplateName = x.TemplateName
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetSurakshaDistributorListByGroupPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return model;
        }
        #endregion

        #region Suraksha Distributor Group Mapping -> Add/Update
        public long SurakshaDistributorGroupMappingAddEdit(SurakshaDistributorGroupMappingAddEdit model)
        {
            return SurakshaDistributorGroupMappingAddEditPvt(model);
        }
        private long SurakshaDistributorGroupMappingAddEditPvt(SurakshaDistributorGroupMappingAddEdit model)
        {
            long Retvalue = 0;
            try
            {
                ObjectParameter obj = new ObjectParameter("RetValue", typeof(string));
                Retvalue = ContextManager._Context.usp_SurakshaDistributorGroupMappingAddEdit(model.GroupId, model.GroupName, model.SACode, model.DistributorIdArray, model.TemplateId,
                    model.IsActive, model.Action, obj);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " SurakshaDistributorGroupMappingAddEditPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region Add Update Suraksha Config Details
        public long SurakshaConfigDetailsAddUpdate(SurakshaConfigDetails configdetails)
        {
            return SurakshaConfigDetailsAddUpdatePvt(configdetails);
        }
        private long SurakshaConfigDetailsAddUpdatePvt(SurakshaConfigDetails configdetails)
        {
            long Retvalue = 0;
            try
            {
                // Mutlitple Distributor
                string DistributorIdarrayValue = configdetails.DistributorIdarray;
                DistributorIdarrayValue = DistributorIdarrayValue.Remove(DistributorIdarrayValue.Length - 1, 1);
                int[] DistributorNums = Array.ConvertAll(DistributorIdarrayValue.Split(','), int.Parse);

                foreach (var i in DistributorNums)
                {
                    Retvalue = ContextManager._Context.usp_SurakshaConfigDetailsAddUpdate(
                            configdetails.ConfgId, configdetails.SACode, configdetails.ScheduleDate, configdetails.GroupName, i,
                            configdetails.DistributorMobNo, configdetails.EmergencyNo, configdetails.IsWithRefillCost, configdetails.RSP,
                            configdetails.TemplateId, configdetails.MsgQty, configdetails.CurrentStatus, configdetails.Action, configdetails.Retvalue, configdetails.ScheduleDaily);
                }

            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "SurakshaConfigDetailsAddUpdatePvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region Update Suraksha Config Details 
        public long SurakshaConfigDetailsUpdate(int ConfgId, int DistributorId, string CurrentStatus)
        {
            return SurakshaConfigDetailsUpdatePvt(ConfgId, DistributorId, CurrentStatus);
        }
        private long SurakshaConfigDetailsUpdatePvt(int ConfgId, int DistributorId, string CurrentStatus)
        {
            long Retvalue = 0;
            try
            {
                Retvalue = ContextManager._Context.usp_SurakshaConfigDetailsAddUpdate(ConfgId, "", null, "", DistributorId, "", "", "", "", "", 0, CurrentStatus, "STATUS", "", "");
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " SurakshaConfigDetailsUpdatePvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region Get All Suraksha Users With Config
        public List<ConsumerDtlsModel> GetAllSurakshaUsersWithConfig(string SACode, int DistributorId, int Qty)
        {
            return GetAllSurakshaUsersWithConfigPvt(SACode, DistributorId, Qty);
        }
        private List<ConsumerDtlsModel> GetAllSurakshaUsersWithConfigPvt(string SACode, int DistributorId, int Qty)
        {
            List<ConsumerDtlsModel> consumerList = new List<ConsumerDtlsModel>();
            try
            {
                consumerList = ContextManager._Context.usp_GetAllSurakshaUsersWithConfig(SACode, DistributorId, Qty).Select(a => new ConsumerDtlsModel
                {
                    SACode = Convert.ToInt32(a.SACode),
                    DistributorIdint = Convert.ToInt32(a.DistributorIdint),
                    DistributorCode = a.DistributorCode,
                    DistributorName = a.DistributorName,
                    UniqueConsumerId = Convert.ToDecimal(a.UniqueConsumerId),
                    ConsumerNo = Convert.ToString(a.ConsumerNo),
                    MobileNo = a.MobileNo,
                    ConsumerName = a.ConsumerName,
                    DistributorEmergencyContactNo = a.DistributorEmergencyContactNo,
                    DistributorMobileNo = a.DistributorMobileNo,
                    DistributorAddress = a.DistrAddress,
                    RSPAmount = a.RSPAmount
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "GetAllSurakshaUsersWithConfigPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return consumerList;
        }
        #endregion

        #region Get Suraksha Config Details List
        public List<SurakshaConfigDetailsList> GetSurkshaConfigDetailsList(string SACode)
        {
            return GetSurkshaConfigDetailsListPvt(SACode);
        }
        private List<SurakshaConfigDetailsList> GetSurkshaConfigDetailsListPvt(string SACode)
        {
            List<SurakshaConfigDetailsList> surakshaConfigDetailsList = new List<SurakshaConfigDetailsList>();
            try
            {
                surakshaConfigDetailsList = ContextManager._Context.usp_SurakshaConfigDetailsList(SACode).Select(x => new SurakshaConfigDetailsList()
                {
                    ConfgId = Convert.ToInt32(x.ConfgId),
                    SACode = x.SACode,
                    GroupName = x.GroupName,
                    DistributorId = Convert.ToInt32(x.DistributorId),
                    JDEDistributorCode = x.JDEDistributorCode,
                    DistributorName = x.DistributorName,
                    TemplateId = x.TemplateId,
                    TemplateName = x.TemplateName,
                    ScheduleDate = Convert.ToDateTime(x.ScheduleDate),
                    MsgQty = Convert.ToInt32(x.ScheduledQty),
                    CurrentStatus = x.CurrentStatus,
                    TotalConsumer = Convert.ToInt32(x.TotalConsumer),
                    NonWhatsAppNo = Convert.ToInt32(x.NonWhatsAppNo),
                    TotalMsgSend = Convert.ToInt32(x.TotalMsgSend),
                    Balanced = Convert.ToInt32(x.Balanced),
                    TodaySend = Convert.ToInt32(x.TodaySend)
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetSurkshaConfigDetailsListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return surakshaConfigDetailsList;
        }
        #endregion

        #region Get Suraksha Config Details List For Schedular
        public List<SurakshaConfigDetailsList> GetSurakshaConfigDetailsListNew(string SACode)
        {
            return GetSurakshaConfigDetailsListNewPvt(SACode);
        }
        private List<SurakshaConfigDetailsList> GetSurakshaConfigDetailsListNewPvt(string SACode)
        {
            List<SurakshaConfigDetailsList> surakshaConfigDtlsList = new List<SurakshaConfigDetailsList>();
            try
            {
                surakshaConfigDtlsList = ContextManager._Context.usp_SurakshaConfigDetailsListScheduler(SACode).Select(x => new SurakshaConfigDetailsList()
                {
                    ConfgId = Convert.ToInt32(x.ConfgId),
                    SACode = x.SACode,
                    ScheduleDate = Convert.ToDateTime(x.ScheduleDate),
                    DistributorId = Convert.ToInt32(x.DistributorId),
                    JDEDistributorCode = x.JDEDistributorCode,
                    DistributorName = x.DistributorName,
                    DistributorMobNo = x.DistributorMobNo,
                    EmergencyNo = x.EmergencyNo,
                    IsWithRefillCost = x.IsWithRefillCost,
                    RSP = x.RSP,
                    TemplateId = x.TemplateId,
                    TemplateName = x.TemplateName,
                    MsgQty = Convert.ToInt32(x.MsgQty),
                    EntryDate = Convert.ToDateTime(x.EntryDate),
                    CurrentStatus = x.CurrentStatus
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetSurakshaConfigDetailsListNewPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return surakshaConfigDtlsList;
        }
        #endregion

        #region Get Area Sequence List
        public List<SurakshaUsersByAreaSeqModel> GetSurakshaUsersByAreaSeqList(string JDEDistributorCode)
        {
            return GetSurakshaUsersByAreaSeqListPvt(JDEDistributorCode);
        }
        private List<SurakshaUsersByAreaSeqModel> GetSurakshaUsersByAreaSeqListPvt(string JDEDistributorCode)
        {
            List<SurakshaUsersByAreaSeqModel> AreaSeqList = new List<SurakshaUsersByAreaSeqModel>();
            try
            {
                AreaSeqList = ContextManager._Context.usp_GetSurakshaUsersByAreaSeq(JDEDistributorCode).Select(x => new SurakshaUsersByAreaSeqModel()
                {
                    JDEDistributorCode = x.JDEDistributorCode,
                    AreaRefNo = Convert.ToString(x.AreaRefNo),
                    AreaName = x.AreaName,
                    AreaSeqNo = Convert.ToInt32(x.AreaSeqNo),
                    ConsCnt = Convert.ToDecimal(x.ConsCnt)
                }).OrderBy(x => x.AreaName).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetSurakshaUsersByAreaSeqListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return AreaSeqList;
        }
        #endregion

        #region Suraksha Users Update Area Sequence
        public long SurakshaUsersUpdateAreaSeq(SurakshaUsersByAreaSeqModel model)
        {
            return SurakshaUsersUpdateAreaSeqPvt(model);
        }
        private long SurakshaUsersUpdateAreaSeqPvt(SurakshaUsersByAreaSeqModel model)
        {
            long Retvalue = 0;
            try
            {
                ObjectParameter obj = new ObjectParameter("RetValue", typeof(string));
                Retvalue = ContextManager._Context.usp_SurakshaUsersUpdateAreaSeq(model.JDEDistributorCode, model.AreaRefNoStr, model.SeqNoStr, obj);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " ARBDistributorGroupMappingAddEditPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        //ARB Campaign New---------

        #region Get ARB Distributor Group Mapping List
        public List<ARBDistributorGroupMappingList> GetARBDistributorGroupMappingList(string SACode)
        {
            return GetARBDistributorGroupMappingListPvt(SACode);
        }
        private List<ARBDistributorGroupMappingList> GetARBDistributorGroupMappingListPvt(string SACode)
        {
            List<ARBDistributorGroupMappingList> model = new List<ARBDistributorGroupMappingList>();
            try
            {
                model = ContextManager._Context.usp_ARBDistributorGroupMappingList(SACode).Select(x => new ARBDistributorGroupMappingList()
                {
                    GroupId = x.GroupId,
                    GroupName = x.GroupName,
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetARBDistributorGroupMappingListPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return model;
        }
        #endregion

        #region Get ARB Distributor List By Group
        public List<ARBDistributorListByGroupList> GetARBDistributorListByGroup(string SACode, string GroupName)
        {
            return GetARBDistributorListByGroupPvt(SACode, GroupName);
        }
        private List<ARBDistributorListByGroupList> GetARBDistributorListByGroupPvt(string SACode, string GroupName)
        {
            List<ARBDistributorListByGroupList> model = new List<ARBDistributorListByGroupList>();
            try
            {
                model = ContextManager._Context.usp_GetARBDistributorListByGroup(SACode, GroupName).Select(x => new ARBDistributorListByGroupList()
                {
                    DistributorId = x.DistributorId,
                    JDEDistributorCode = x.JDEDistributorCode,
                    DistributorName = x.DistributorName,
                    OwnerName = x.OwnerName,
                    IsDistributorLive = x.IsDistributorLive,
                    MobileNo = Convert.ToDecimal(x.MobileNo),
                    Email = x.Email,
                    SACode = x.SACode,
                    GroupName = x.GroupName,
                    selected = x.selected,
                    TemplateId = x.TemplateId,
                    TemplateName = x.TemplateName
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetARBDistributorListByGroupPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return model;
        }
        #endregion

        #region ARB Distributor Group Mapping -> Add/Update
        public long ARBDistributorGroupMappingAddEdit(ARBDistributorGroupMappingAddEdit model)
        {
            return ARBDistributorGroupMappingAddEditPvt(model);
        }
        private long ARBDistributorGroupMappingAddEditPvt(ARBDistributorGroupMappingAddEdit model)
        {
            long Retvalue = 0;
            try
            {
                ObjectParameter obj = new ObjectParameter("RetValue", typeof(string));
                Retvalue = ContextManager._Context.usp_ARBDistributorGroupMappingAddEdit(model.GroupId, model.GroupName, model.SACode, model.DistributorIdArray, model.TemplateId,
                    model.IsActive, model.Action, obj);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " ARBDistributorGroupMappingAddEditPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region Add Update ARB Config Details
        public long ARBConfigDetailsAddUpdate(ARBConfigDetails configdetails)
        {
            return ARBConfigDetailsAddUpdatePvt(configdetails);
        }
        private long ARBConfigDetailsAddUpdatePvt(ARBConfigDetails configdetails)
        {
            long Retvalue = 0;
            try
            {
                // Mutlitple Distributor
                string DistributorIdarrayValue = configdetails.DistributorIdarray;
                DistributorIdarrayValue = DistributorIdarrayValue.Remove(DistributorIdarrayValue.Length - 1, 1);
                int[] DistributorNums = Array.ConvertAll(DistributorIdarrayValue.Split(','), int.Parse);

                foreach (var i in DistributorNums)
                {
                    Retvalue = ContextManager._Context.usp_ARBConfigDetailsAddUpdate(
                            configdetails.DBCConfId, configdetails.SACode, configdetails.ScheduleDate, configdetails.GroupName, i,
                            configdetails.DistributorMobNo, configdetails.EmergencyNo, configdetails.IsWithRefillCost, configdetails.RSP,
                            configdetails.TemplateId, configdetails.MsgQty, configdetails.CurrentStatus, configdetails.Action, configdetails.Retvalue, configdetails.ScheduleDaily);
                }

            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "ARBConfigDetailsAddUpdatePvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region Update ARB Config Details
        public long ARBConfigDetailsUpdate(int DBCConfId, int DistributorId, string CurrentStatus)
        {
            return ARBConfigDetailsUpdatePvt(DBCConfId, DistributorId, CurrentStatus);
        }
        private long ARBConfigDetailsUpdatePvt(int DBCConfId, int DistributorId, string CurrentStatus)
        {
            long Retvalue = 0;
            try
            {
                using (HPGASNCEnquiryEntities Context = new HPGASNCEnquiryEntities())
                {
                    Retvalue = Context.usp_ARBConfigDetailsAddUpdate(DBCConfId, "", null, "", DistributorId, "", "", "", "", "", 0, CurrentStatus, "STATUS", "", "");
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " ARBConfigDetailsUpdatePvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region Get All ARB Users With Config
        public List<ConsumerDtlsModel> GetAllARBUsersWithConfig(string SACode, int DistributorId, int Qty)
        {
            return GetAllARBUsersWithConfigPvt(SACode,DistributorId, Qty);
        }
        private List<ConsumerDtlsModel> GetAllARBUsersWithConfigPvt(string SACode,int DistributorId, int Qty)
        {
            List<ConsumerDtlsModel> ARBWhatsAppList = new List<ConsumerDtlsModel>();
            try
            {
                using (HPGASNCEnquiryEntities Context = new HPGASNCEnquiryEntities())
                {
                    ARBWhatsAppList = Context.usp_GetAllARBUsersWithConfig(SACode,DistributorId, Qty).Select(a => new ConsumerDtlsModel
                    {
                        SACode = Convert.ToInt32(a.SACode),
                        DistributorIdint = Convert.ToInt32(a.DistributorIdint),
                        DistributorCode = a.DistributorCode,
                        DistributorName = a.DistributorName,
                        UniqueConsumerId = Convert.ToDecimal(a.UniqueConsumerId),
                        ConsumerNo = Convert.ToString(a.ConsumerNo),
                        MobileNo = a.MobileNo,
                        ConsumerName = a.ConsumerName,
                        DistributorEmergencyContactNo = a.DistributorEmergencyContactNo,
                        DistributorMobileNo = a.DistributorMobileNo,
                        DistributorAddress = a.DistrAddress,
                        RSPAmount = a.RSPAmount,
                        DPhoneNo = a.DPhoneNo,
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "GetAllSurakshaUsersWithConfigPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return ARBWhatsAppList;
        }
        #endregion

        #region Get ARB Config Details List
        public List<ARBConfigDetailsList> GetARBConfigDetailsList(string SACode)
        {
            return GetARBConfigDetailsListPvt(SACode);
        }
        private List<ARBConfigDetailsList> GetARBConfigDetailsListPvt(string SACode)
        {
            List<ARBConfigDetailsList> arbConfigDetailsList = new List<ARBConfigDetailsList>();
            try
            {
                arbConfigDetailsList = ContextManager._Context.usp_ARBConfigDetailsList(SACode).Select(x => new ARBConfigDetailsList()
                {
                    DBCConfId = Convert.ToInt32(x.ConfgId),
                    SACode = x.SACode,
                    GroupName = x.GroupName,
                    DistributorId = Convert.ToInt32(x.DistributorId),
                    JDEDistributorCode = x.JDEDistributorCode,
                    DistributorName = x.DistributorName,
                    TemplateId = x.TemplateId,
                    TemplateName = x.TemplateName,
                    ScheduleDate = Convert.ToDateTime(x.ScheduleDate),
                    MsgQty = Convert.ToInt32(x.ScheduledQty),
                    CurrentStatus = Convert.ToString(x.CurrentStatus),
                    TotalConsumer = Convert.ToInt32(x.TotalConsumer),
                    NonWhatsAppNo = Convert.ToInt32(x.NonWhatsAppNo),
                    TotalMsgSend = Convert.ToInt32(x.TotalMsgSend),
                    Balanced = Convert.ToInt32(x.Balanced),
                    TodaySend = Convert.ToInt32(x.TodaySend)
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetARBConfigDetailsListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return arbConfigDetailsList;
        }
        #endregion

        #region Get ARB Config Details List For Schedular
        public List<ARBConfigDetailsList> GetARBConfigDetailsListNew(string SACode)
        {
            return GetARBConfigDetailsListNewPvt(SACode);
        }
        private List<ARBConfigDetailsList> GetARBConfigDetailsListNewPvt(string SACode)
        {
            List<ARBConfigDetailsList> arbConfigDetailsList = new List<ARBConfigDetailsList>();
            try
            {
                arbConfigDetailsList = ContextManager._Context.usp_ARBConfigDetailsListScheduler(SACode).Select(x => new ARBConfigDetailsList()
                {
                    DBCConfId = Convert.ToInt32(x.ConfgId),
                    SACode = x.SACode,
                    ScheduleDate = Convert.ToDateTime(x.ScheduleDate),
                    DistributorId = Convert.ToInt32(x.DistributorId),
                    JDEDistributorCode = x.JDEDistributorCode,
                    DistributorName = x.DistributorName,
                    DistributorMobNo = x.DistributorMobNo,
                    EmergencyNo = x.EmergencyNo,
                    IsWithRefillCost = x.IsWithRefillCost,
                    RSP = x.RSP,
                    TemplateId = x.TemplateId,
                    TemplateName = x.TemplateName,
                    MsgQty = Convert.ToInt32(x.MsgQty),
                    EntryDate = Convert.ToDateTime(x.EntryDate),
                    CurrentStatus = x.CurrentStatus
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Get ARB ConfigDetails List New", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return arbConfigDetailsList;
        }
        #endregion

        #region Get List for Reset Passeword
        public List<Resetpassmodel> GetListForResetPass()
        {
            return GetListForResetPassPvt();
        }
        private List<Resetpassmodel> GetListForResetPassPvt()
        {
            List<Resetpassmodel> resetpassList = new List<Resetpassmodel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    resetpassList = _Context.sp_GetListForResetPass().Select(x => new Resetpassmodel()
                    {
                        Distributor_Code = x.Distributor_Code,
                        Distributor_Name = x.Distributor_Name,
                        CDCMS_Password = x.CDCMS_Password,
                        CDCMS_ID_Email = x.CDCMS_ID_Email,
                        Updated_Date = Convert.ToDateTime(x.Updated_Date),
                    }).OrderBy(x => x.Distributor_Code).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetListForResetPassPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return resetpassList;
        }
        #endregion

        #region Update Reset password
        public long UpdateResetPass(Resetpassmodel model)
        {
            return UpdateResetPassPvt(model);
        }
        private long UpdateResetPassPvt(Resetpassmodel model)
        {
            long Retvalue = 0;
            try
            {
                ObjectParameter obj = new ObjectParameter("RetValue", typeof(int));
                Retvalue = ContextManager._Context.sp_UpdateResetPass(model.Distributor_Code, model.CDCMS_Password, model.CDCMS_ID_Email, obj);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " UpdateResetPassPvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion
    }
}
