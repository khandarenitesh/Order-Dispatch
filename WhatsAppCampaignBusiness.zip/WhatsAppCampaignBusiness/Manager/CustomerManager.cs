using HPGASNCEnquiryBusiness.BusinessConstant;
using HPGASNCEnquiryBusiness.Models.Customer;
using HPGASNCEnquiryBusiness.Models.Entity;
using HPGASNCEnquiryBusiness.Models.Masters;
using HPGASNCEnquiryBusiness.Models.WhatApp;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.Core.Objects;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web.Configuration;
using WhatsAppCampaignBusiness.Models.Entity;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class CustomerManager : IDisposable
    {
        decimal LogId = 0;
        ContextManager contextManager = new ContextManager();

        #region Dispose 

        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }

        #endregion

        /// <summary>
        /// Save customer details and question and answers in DB
        /// </summary>
        /// <param name="customerDetails"></param>
        /// <returns></returns>
        //public DocumentsDetails SaveCustomerDetails(CustomerDetails customerDetails)
        //{
        //    return SaveCustomerDetailsPvt(customerDetails);
        //}

        /// <summary>
        /// Save customer details and question and answers in DB
        /// </summary>
        /// <param name="customerDetails"></param>
        /// <returns></returns>
        //private DocumentsDetails SaveCustomerDetailsPvt(CustomerDetails customerDetails)
        //{
        //    DocumentsDetails documentsDetails = new DocumentsDetails();
        //    try
        //    {
        //        if (customerDetails != null)
        //        {
        //            int QueTypeId = 0, StoveSubType = 0, StoveType = 0;
        //            LogId = BusinessCont.SaveLog(0, 0, "SaveCustomerDetails", "customerDetails- " + customerDetails.CustPersonalDtls + ", CustEnquiryDtls - " + customerDetails.CustEnquiryDtls, null, null);
        //            if (!string.IsNullOrEmpty(customerDetails.CustPersonalDtls) && !string.IsNullOrEmpty(customerDetails.CustEnquiryDtls))
        //            {
        //                CustomerDetails CustDtls = JsonConvert.DeserializeObject<CustomerDetails>(customerDetails.CustPersonalDtls);
        //                long ConsId = 0, QueCnt = 0;

        //                ObjectParameter ObjParamConsId = new ObjectParameter("result", typeof(Int64));
        //                ContextManager._Context.sp_AddEditConsumerDetails(0, CustDtls.DistributorId, CustDtls.StaffRefNo, CustDtls.ConsName, CustDtls.Address, CustDtls.ResidentiaArea, CustDtls.MobileNo, CustDtls.EmailId, CustDtls.CompanyName, CustDtls.ConsumerNo, CustDtls.SourceType, ObjParamConsId);

        //                //using (ContextManager contextManager = new ContextManager())
        //                //{
        //                //    ContextManager._Context.sp_AddEditConsumerDetails(0, CustDtls.DistributorId, CustDtls.StaffRefNo, CustDtls.ConsName, CustDtls.Address, CustDtls.ResidentiaArea, CustDtls.MobileNo, CustDtls.EmailId, CustDtls.CompanyName, CustDtls.ConsumerNo, CustDtls.SourceType, ObjParamConsId);
        //                //}
        //                if (ObjParamConsId != null)
        //                    ConsId = Convert.ToInt64(ObjParamConsId.Value);
        //                if (ConsId > 0)
        //                {
        //                    var CustEnquiryDtls = JsonConvert.DeserializeObject<List<CustomerDetails>>(customerDetails.CustEnquiryDtls);
        //                    ObjectParameter ObjParamConsEnqryId = new ObjectParameter("CEId", typeof(Int64));
        //                    var DocumentsList = GetDocuments();
        //                    documentsDetails.Documents = new List<Documents>();
        //                    foreach (var item in CustEnquiryDtls.ToList())
        //                    {
        //                        ContextManager._Context.sp_AddEditConsumerEnquiryDetails(ConsId, item.QId, item.Ans, item.AnsId, ObjParamConsEnqryId);

        //                        //using (ContextManager contextManager = new ContextManager())
        //                        //{
        //                        //    ContextManager._Context.sp_AddEditConsumerEnquiryDetails(ConsId, item.QId, item.Ans,item.AnsId, ObjParamConsEnqryId);
        //                        //}
        //                        if (ObjParamConsEnqryId != null)
        //                        {
        //                            if (Convert.ToInt64(ObjParamConsId.Value) > 0)
        //                            {
        //                                if (item.QId == 1)
        //                                {
        //                                    QueTypeId = item.AnsId;
        //                                    documentsDetails.Documents.AddRange(DocumentsList.Where(a => a.EQueId == item.AnsId).ToList());
        //                                }
        //                                QueCnt++;
        //                            }
        //                        }
        //                        if (item.QId == 5)
        //                        {
        //                            StoveSubType = item.AnsId;
        //                        }
        //                        if (item.QId == 3)
        //                        {
        //                            StoveType = item.AnsId;
        //                        }
        //                    }
        //                    if (QueCnt == CustEnquiryDtls.Count())
        //                    {
        //                        Task<string> result = Task.Run(() => CheckNoUsingWhatsAppOrNot(CustDtls.MobileNo.Trim()));
        //                        SendWhatsappMsg(CustDtls.MobileNo.Trim());
        //                        BusinessCont.SaveLog(0, 0, "MsgSent", "Mobile No = " + CustDtls.MobileNo.Trim(), BusinessCont.SuccessStatus, null);
        //                        documentsDetails.Status = BusinessCont.SuccessStatus;
        //                        documentsDetails.EnquiryId = CustDtls.EnquiryId;
        //                        BusinessCont.SaveLog(LogId, CustDtls.DistributorId, null, null, BusinessCont.SuccessStatus, null);
        //                    }
        //                }
        //                else if (ConsId == -1)
        //                {
        //                    documentsDetails.Status = BusinessCont.FailStatus;
        //                    documentsDetails.ExMsg = "You have already done Enquiry against this mobile number.";
        //                    documentsDetails.EnquiryId = CustDtls.EnquiryId;
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        documentsDetails.Status = BusinessCont.FailStatus;
        //        //documentsDetails.ExMsg = BusinessCont.ExceptionMsg(ex);
        //        BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        //throw;
        //    }
        //    return documentsDetails;
        //}

        //public Task<string> SendTestWhatsappMsg()
        //{
            ////string MobileNo = "9404298780";
            //string MobileNo = "8007007006";

            //if (!string.IsNullOrEmpty(MobileNo))
            //{
            //    Task<string> result = null;
            //    if (!string.IsNullOrWhiteSpace(MobileNo))
            //        result = Task.Run(() => GetAsync("Test", MobileNo, "Testing", "9529517051"));
            //}

        //    Task<string> result = null;
        //    string WhatsappMsg = "hii testing of whatapps msg from NC Enquiry!!";
        //    try
        //    {
        //        //string MobileNos = "9529517051" + "," + "9763482204" + "," + ConfigurationManager.AppSettings["MobileNos"];
        //        //string MobileNos = "9529517051" + "," + "7302126413" + "," + "918007007006";
        //        string MobileNos = "9529517051" + "," + "7302126413";

        //        result = Task.Run(() => GetAsync1(WhatsappMsg, MobileNos));
        //        Task.WaitAll(result);
        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}



        
        //            {
        //                string CustomerName = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(CustomerDetails.CustomerName.Trim());
        //                if (EventId == 1)public DocumentsDetails SaveCustomerDetailsFromWeb(CustomerDetails customerDetails)
        //{
        //    return SaveCustomerDetailsFromWebPvt(customerDetails);
        //}
        //private DocumentsDetails SaveCustomerDetailsFromWebPvt(CustomerDetails customerDetails)
        //{
        //    DocumentsDetails documentsDetails = new DocumentsDetails();
        //    try
        //    {
        //        if (customerDetails != null)
        //        {
        //            string jsonStaff = customerDetails == null ? "" : JsonConvert.SerializeObject(customerDetails);
        //            int QueTypeId = 0, StoveSubType = 0, StoveType = 0;
        //            LogId = BusinessCont.SaveLog(0, 0, "SaveCustomerDetailsFromWebPvt", "customerDetails- " + jsonStaff + ", CustEnquiryDtls - " + customerDetails.CustEnquiryDtls, null, null);


        //            long ConsId = 0, QueCnt = 0;

        //            ObjectParameter ObjParamConsId = new ObjectParameter("result", typeof(Int64));
        //            using (ContextManager contextManager = new ContextManager())
        //            {
        //                ContextManager._Context.sp_AddEditConsumerDetails(customerDetails.CId, customerDetails.DistributorId, customerDetails.StaffRefNo, customerDetails.ConsName, customerDetails.Address, customerDetails.ResidentiaArea, customerDetails.MobileNo, customerDetails.EmailId, customerDetails.CompanyName, customerDetails.ConsumerNo, customerDetails.SourceType, ObjParamConsId);
        //            }
        //            if (ObjParamConsId != null)
        //                ConsId = Convert.ToInt64(ObjParamConsId.Value);
        //            if (ConsId > 0)
        //            {
        //                var CustEnquiryDtls = JsonConvert.DeserializeObject<List<CustomerQueAnsDetails>>(customerDetails.CustEnquiryDtls);
        //                ObjectParameter ObjParamConsEnqryId = new ObjectParameter("CEId", typeof(Int64));
        //                var DocumentsList = GetDocuments();
        //                documentsDetails.Documents = new List<Documents>();
        //                foreach (var item in CustEnquiryDtls)
        //                {
        //                    using (ContextManager contextManager = new ContextManager())
        //                    {
        //                        ContextManager._Context.sp_AddEditConsumerEnquiryDetails(ConsId, item.QId, item.Ans, item.AnsId, ObjParamConsEnqryId);
        //                    }
        //                    if (ObjParamConsEnqryId != null)
        //                    {
        //                        if (Convert.ToInt64(ObjParamConsId.Value) > 0)
        //                        {
        //                            if (item.QId == 1)
        //                            {
        //                                QueTypeId = item.AnsId;
        //                                documentsDetails.Documents.AddRange(DocumentsList.Where(a => a.EQueId == item.AnsId).ToList());
        //                            }
        //                            QueCnt++;
        //                        }
        //                    }
        //                    if (item.QId == 5)
        //                    {
        //                        StoveSubType = item.AnsId;
        //                    }
        //                    if (item.QId == 3)
        //                    {
        //                        StoveType = item.AnsId;
        //                    }
        //                }
        //                if (QueCnt == CustEnquiryDtls.Count())
        //                {
        //                    //SendWhatsappMsg(customerDetails.DistributorId, QueTypeId, StoveSubType, customerDetails.MobileNo.Trim(), StoveType);
        //                    if (customerDetails.DistributorId > 0)
        //                    {
        //                        //sendEmailToDistributor(customerDetails);
        //                        Task<string> result = Task.Run(() => sendEmailToDistributor(customerDetails));

        //                    }
        //                    //sendEmailToCustomer(customerDetails);
        //                    // sendEmailToAadyamStaff(customerDetails);

        //                    Task<string> result1 = Task.Run(() => sendEmailToCustomer(customerDetails));
        //                    Task<string> result2 = Task.Run(() => sendEmailToAadyamStaff(customerDetails));


        //                    documentsDetails.Status = BusinessCont.SuccessStatus;
        //                    documentsDetails.EnquiryId = customerDetails.EnquiryId;
        //                    BusinessCont.SaveLog(LogId, customerDetails.DistributorId, null, null, BusinessCont.SuccessStatus, null);
        //                }
        //            }
        //            else if (ConsId == -1)
        //            {
        //                documentsDetails.Status = BusinessCont.FailStatus;
        //                documentsDetails.ExMsg = "You have already done Enquiry against this mobile number.";
        //                documentsDetails.EnquiryId = customerDetails.EnquiryId;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        documentsDetails.Status = BusinessCont.FailStatus;
        //        documentsDetails.ExMsg = BusinessCont.ExceptionMsg(ex);
        //        BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        //throw;
        //    }
        //    return documentsDetails;
        //}

        //public async Task<string> sendEmailToDistributor(CustomerDetails customerDetails)
        //{
        //    string result = "";
        //    string body = "";
        //    try
        //    {
        //        DistributorDtls distributorDtls = new DistributorDtls();
        //        string userName = WebConfigurationManager.AppSettings["PFUserName"];
        //        string password = WebConfigurationManager.AppSettings["PFPassWord"];
        //        string AadyamStaff = WebConfigurationManager.AppSettings["AadyamStaff"];
        //        string subject = "New Enquiry";
        //        //string body = "Thank you for contact us.Please Click below link to proceed further.";

        //        using (MastersManager mastersManager = new MastersManager())
        //        {
        //            distributorDtls = mastersManager.GetDistributorDetails(customerDetails.DistributorId).FirstOrDefault();
        //            //distributorDtls.DistributorName = "Testing";
        //            //distributorDtls.Email = "prasanna@aadyamconsultant.com";
        //        }
        //        if (distributorDtls != null && !String.IsNullOrEmpty(distributorDtls.Email))
        //        {
        //            //string body = "Dear " + distributorDtls.DistributorName + ",<br /><br />New Connection Enquiry<br /> Following are the Consumer Details:-<br />" +
        //            //" Consumer Name : " + customerDetails.ConsName + ",<br /> Consumer Address : " + customerDetails.Address +
        //            // ",<br /> Consumer Mobile No : " + customerDetails.MobileNo + ",<br />Consumer Email_Id : " + customerDetails.EmailId +
        //            // ",<br /> Consumer Type : " + customerDetails.ConnectionType + "<br /><br /> thank you";
        //            body = "Dear " + distributorDtls.DistributorName +
        //                        ",<br />Following enquiry received from a customer for " + customerDetails.ConnectionType + " " +
        //                        "<br /> Please contact the customer and fulfil his/her requirement.<br /> <br /> <b>  New Connection Enquiry </b> <br /> Following are the Consumer Details:- <br />" +
        //           "  Name : " + customerDetails.ConsName + ",<br /> Address : " + customerDetails.Address +
        //            ",<br />  Mobile No : " + customerDetails.MobileNo + ",<br /> Email Id : " + customerDetails.EmailId +
        //            ",<br /> Connection Type : " + customerDetails.ConnectionType + "<br /><br /> Thank You";

        //            body = body + "<div><p style = 'font-family: Verdana, Geneva, sans-serif; font-size: 12px; color: #0055f2; line-height: 22px; padding-bottom: 10px;'>***This is an automatically generated email, please do not reply ***</p></div>";

        //            string FromMail = userName;
        //            MailMessage mail = new MailMessage();
        //            mail.IsBodyHtml = true;
        //            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
        //            mail.From = new MailAddress(FromMail);
        //            mail.To.Add(distributorDtls.Email);
        //            mail.Subject = subject;
        //            mail.Body = body;
        //            SmtpServer.Port = 587;
        //            SmtpServer.Credentials = new System.Net.NetworkCredential(userName, password);
        //            SmtpServer.EnableSsl = true;
        //            SmtpServer.Send(mail);


        //        }
        //        //return "Fail";
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, 0, null, "sendEmailToDistributor = " + body, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        //throw ex;
        //    }
        //    return result;
        //}

        //public async Task<string> sendEmailToAadyamStaff(CustomerDetails customerDetails)
        //{
        //    string result = "";
        //    DistributorDtls distributorDtls = new DistributorDtls();
        //    string userName = WebConfigurationManager.AppSettings["PFUserName"];
        //    string password = WebConfigurationManager.AppSettings["PFPassWord"];
        //    string AadyamStaff = WebConfigurationManager.AppSettings["AadyamStaff"];
        //    // AadyamStaff = "prasanna@aadyamconsultant.com";
        //    string subject = "New Enquiry";
        //    string bodyForAadyamStaff = "";
        //    try
        //    {
        //        //string bodyForAadyamStaff = "Hello ,<br /><br />New Connection Enquiry<br /> Following are the Consumer Details:-<br />" +
        //        // " Consumer Name : " + customerDetails.ConsName + ",<br /> Consumer Address : " + customerDetails.Address +
        //        //  ",<br /> Consumer Mobile No : " + customerDetails.MobileNo + ",<br />Consumer Email_Id : " + customerDetails.EmailId +
        //        //  ",<br /> Consumer Type : " + customerDetails.ConnectionType + "<br /><br /> thank you";

        //        bodyForAadyamStaff = "Dear Sir/Ma'am,<br />Following enquiry received from a customer for " + customerDetails.ConnectionType + " " +
        //                        "<br /> Please contact the customer and fulfil his/her requirement.<br /> <br /> <b>  New Connection Enquiry </b> <br /> Following are the Consumer Details:- <br />" +
        //           "  Name : " + customerDetails.ConsName + ",<br /> Address : " + customerDetails.Address +
        //            ",<br />  Mobile No : " + customerDetails.MobileNo + ",<br /> Email Id : " + customerDetails.EmailId +
        //            ",<br /> Connection Type : " + customerDetails.ConnectionType + "<br /><br /> Thank You";

        //        bodyForAadyamStaff = bodyForAadyamStaff + "<div><p style = 'font-family: Verdana, Geneva, sans-serif; font-size: 12px; color: #0055f2; line-height: 22px; padding-bottom: 10px;'>***This is an automatically generated email, please do not reply ***</p></div>";

        //        string FromMail = userName;
        //        MailMessage mailAS = new MailMessage();
        //        mailAS.IsBodyHtml = true;
        //        SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
        //        mailAS.From = new MailAddress(FromMail);
        //        mailAS.To.Add(AadyamStaff);
        //        mailAS.Subject = subject;
        //        mailAS.Body = bodyForAadyamStaff;
        //        SmtpServer.Port = 587;
        //        SmtpServer.Credentials = new System.Net.NetworkCredential(userName, password);
        //        SmtpServer.EnableSsl = true;
        //        SmtpServer.Send(mailAS);

        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, 0, null, "sendEmailToAadyamStaff = " + bodyForAadyamStaff, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        //throw ex;
        //    }
        //    return result;
        //}
        //public async Task<string> sendEmailToCustomer(CustomerDetails customerDetails)
        //{
        //    string result = "";
        //    DistributorDtls distributorDtls = new DistributorDtls();
        //    string userName = WebConfigurationManager.AppSettings["PFUserName"];
        //    string password = WebConfigurationManager.AppSettings["PFPassWord"];
        //    string subject = "NCE- New Connection Enquiry";
        //    string bodyForCustomer = "";
        //    try
        //    {
        //        if (customerDetails.DistributorId > 0)
        //        {
        //            bodyForCustomer = " Dear Valued Customer,<br /><br />Your following details have been received.<br /><br />" +
        //        " Consumer Name : " + customerDetails.ConsName + ",<br /> Consumer Address : " + customerDetails.Address +
        //         ",<br /> Consumer Mobile No : " + customerDetails.MobileNo + ",<br />Consumer Email Id : " + customerDetails.EmailId +
        //         ",<br /> Connection Type : " + customerDetails.ConnectionType + "<br /><br /> Soon, our distributor " + customerDetails.DistributorName + " will get in touch with you for registration of New Connection <br /><br />  Thank You";
        //        }
        //        else
        //        {
        //            bodyForCustomer = " Dear Valued Customer,<br /><br />Your following details have been received.<br /><br />" +
        //       " Consumer Name : " + customerDetails.ConsName + ",<br /> Consumer Address : " + customerDetails.Address +
        //        ",<br /> Consumer Mobile No : " + customerDetails.MobileNo + ",<br />Consumer Email Id : " + customerDetails.EmailId +
        //        ",<br /> Connection Type : " + customerDetails.ConnectionType + "<br /><br />  Thank You";
        //        }

        //        bodyForCustomer = bodyForCustomer + "<div><p style = 'font-family: Verdana, Geneva, sans-serif; font-size: 12px; color: #0055f2; line-height: 22px; padding-bottom: 10px;'>***This is an automatically generated email, please do not reply ***</p></div>";

        //        string FromMail = userName;
        //        MailMessage mailAS = new MailMessage();
        //        mailAS.IsBodyHtml = true;
        //        SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
        //        mailAS.From = new MailAddress(FromMail);
        //        mailAS.To.Add(customerDetails.EmailId);
        //        mailAS.Subject = subject;
        //        mailAS.Body = bodyForCustomer;
        //        SmtpServer.Port = 587;
        //        SmtpServer.Credentials = new System.Net.NetworkCredential(userName, password);
        //        SmtpServer.EnableSsl = true;
        //        SmtpServer.Send(mailAS);
        //        //return "Success";
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, 0, null, "sendEmailToAadyamStaff = " + bodyForCustomer, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        //return "Fail";
        //        //throw ex;
        //    }
        //    return result;
        //}

        //public EmailSend sendEmailViaWebApi(EmailSend emailTo, Nullable<int> Id)
        //{
        //    EmailSend Email = new EmailSend();
        //    string userName = WebConfigurationManager.AppSettings["PFUserName"];
        //    string password = WebConfigurationManager.AppSettings["PFPassWord"];
        //    string URL = WebConfigurationManager.AppSettings["NCEnquiry"];
        //    string subject = "NCE- New Connection Enquiry";
        //    //string body = "Thank you for contact us.Please Click below link to proceed further.";
        //    string body = "Dear Valued Customer,<br />Thank you for your interest in New Connection.<br /> " +
        //                     "Please click the below link and input the essential details to complete the activation process <br />" + URL + "" + Id + "<br /><br /> A notification email will be sent to you once this has been completed. <br /><br />Thank You";
        //    string FromMail = userName;

        //    body = body + "<div><p style = 'font-family: Verdana, Geneva, sans-serif; font-size: 12px; color: #0055f2; line-height: 22px; padding-bottom: 10px;'>***This is an automatically generated email, please do not reply ***</p></div>";


        //    MailMessage mail = new MailMessage();
        //    mail.IsBodyHtml = true;
        //    SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
        //    mail.From = new MailAddress(FromMail);
        //    mail.To.Add(emailTo.Email);
        //    mail.Subject = subject;
        //    mail.Body = body;
        //    SmtpServer.Port = 587;
        //    SmtpServer.Credentials = new System.Net.NetworkCredential(userName, password);
        //    SmtpServer.EnableSsl = true;
        //    SmtpServer.Send(mail);
        //    return Email;
        //}

        //public EmailSend sendResetPasswordEmail(DistributorDtls distributorDtls)
        //{
        //    EmailSend Email = new EmailSend();
        //    string userName = WebConfigurationManager.AppSettings["PFUserName"];
        //    string password = WebConfigurationManager.AppSettings["PFPassWord"];
        //    string URL = WebConfigurationManager.AppSettings["EmailReset"];
        //    string subject = "Reset Password - HPCL Campaign";
        //    //string encryDistributorCode= Clsencrypt.EncryptData(distributorDtls.JDEDistributorCode);
        //    ////string encryDistributorId = Clsencrypt.EncryptM(distributorDtls.DistributorId.ToString());
        //    //string encryUserId = Clsencrypt.EncryptData("0");
        //    //string encryRoleId = Clsencrypt.EncryptData("3");
        //    //string encryrefNo = Clsencrypt.EncryptData(distributorDtls.DistributorId.ToString());
        //    //string body = "Thank you for contact us.Please Click below link to proceed further.";

        //    //string body = "Dear Distributor,<br /><br />Please click the below link to reset your password.<br /> " +
        //    //                "<br />" + URL + "" + encryDistributorCode + "&UserId=" + encryUserId + "&RoleId=" + encryRoleId + "&refNo=" + encryrefNo + "<br /><br /> " + "<br /><br />Thank You";

        //    string body = "Dear Distributor,<br /><br />Please click the below link to reset your password.<br /> " +
        //                      "<br />" + URL + "" + distributorDtls.JDEDistributorCode + "&UserId=" + "0" + "&RoleId=" + "3" + "&refNo=" + distributorDtls.DistributorId + "<br /><br /> " +
        //                      "<br /><br />Thank You";


        //    string FromMail = userName;

        //    body = body + "<div><p style = 'font-family: Verdana, Geneva, sans-serif; font-size: 12px; color: #0055f2; line-height: 22px; padding-bottom: 10px;'>***This is an automatically generated email, please do not reply ***</p></div>";

        //    MailMessage mail = new MailMessage();
        //    mail.IsBodyHtml = true;
        //    SmtpClient SmtpServer = new SmtpClient("smtp.office365.com");
        //    mail.From = new MailAddress(FromMail);
        //    mail.To.Add(distributorDtls.Email);//distributorDtls.Email
        //    mail.Subject = subject;
        //    mail.Body = body;
        //    SmtpServer.Port = 587;
        //    SmtpServer.Credentials = new System.Net.NetworkCredential(userName, password);
        //    SmtpServer.EnableSsl = true;
        //    SmtpServer.Send(mail);
        //    Email.Status = "Success";
        //    return Email;
        //}

        //public EmailSend SaveEmailViaWebApi(EmailSend emailTo)
        //{
        //    EmailSend email = new EmailSend();
        //    try
        //    {
        //        if (email != null)
        //        {
        //            using (ContextManager contextManager = new ContextManager())
        //            {
        //                email.Id = (ContextManager._Context.sp_AddEmailLog(emailTo.Email).FirstOrDefault<Nullable<int>>());
        //                if (email.Id == -1)
        //                {
        //                    email.Status = "Exist";
        //                }
        //                else
        //                {
        //                    email.Status = "Success";
        //                }

        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        email.Status = BusinessCont.FailStatus;
        //        BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //    }
        //    return email;
        //}

        ////public void SendTestWhatsappMsg()
        ////{
        ////    //string MobileNo = "9404298780";
        ////    string MobileNo = "8007007006";

        ////    if (!string.IsNullOrEmpty(MobileNo))
        ////    {
        ////        Task<string> result = null;
        ////        if (!string.IsNullOrWhiteSpace(MobileNo))
        ////            result = Task.Run(() => GetAsync("Test", MobileNo, "Testing", "9529517051"));
        ////    }

        ////}

        //public void SendWhatsappMsg(string MobileNo)
        //{
        //    ConsumerDetailsForSendMsg ConsQueDtls = null;
        //    try
        //    {
        //        MastersManager mastersManager = new MastersManager();
        //        ConsQueDtls = mastersManager.GetConsumerDetailsForSendMsg(MobileNo);
        //        if (ConsQueDtls != null)
        //        {
        //            var QuestionMasterData = mastersManager.GetMaster(ConsQueDtls.DistributorId, "ALL").Where(a => a.EQueId == ConsQueDtls.QueTypeId).FirstOrDefault();
        //            if (QuestionMasterData != null)
        //            {
        //                StoveItemDtls StoveSubItem = null; StoveItemDtls stoveItemDtls = null;
        //                List<PriceDetails> priceDetails = mastersManager.GetPriceDetails(ConsQueDtls.DistributorId).Where(a => a.EQueId == ConsQueDtls.QueTypeId).ToList();
        //                //PriceDetails price = priceDetails.Where(a => a.ID == 5).FirstOrDefault();

        //                if (ConsQueDtls.StoveSubType > 0)
        //                    StoveSubItem = mastersManager.GetStoveItemDtls(0, 0, ConsQueDtls.DistributorId, "MASTER").Where(a => a.Id == ConsQueDtls.StoveSubType).FirstOrDefault();
        //                if (ConsQueDtls.StoveSubType == 0 && ConsQueDtls.StoveType > 0)
        //                    stoveItemDtls = mastersManager.GetStoveTypeDtls().Where(a => a.StoveId == ConsQueDtls.StoveType).FirstOrDefault();
        //                string WhatsappFirstMsg = string.Empty;
        //                string DistributorWhatsappMsg = string.Empty;
        //                var MsgSendLanguage = QuestionMasterData.LanguageId;

        //                if (MsgSendLanguage == 3)//Send whatsapp msg in Marathi
        //                {
        //                    WhatsappFirstMsg = CustomerMarathiMsg(StoveSubItem, stoveItemDtls, priceDetails, QuestionMasterData, ConsQueDtls.QueTypeId, ConsQueDtls.StoveSubType, MobileNo, ConsQueDtls.StoveType);
        //                    //WhatsappSecondMsg = "*हा सिस्टम जनरेट संदेश आहे या क्रमांकावर प्रत्युत्तर देऊ नका आपल्याला पुढील तपशीलांची आवश्यकता असल्यास कृपया "+ QuestionMasterData.ContactNo + " संपर्क साधा*";
        //                }
        //                else if (MsgSendLanguage == 2)//Send whatsapp msg in Hindi
        //                {
        //                    WhatsappFirstMsg = CustomerHindiMsg(StoveSubItem, stoveItemDtls, priceDetails, QuestionMasterData, ConsQueDtls.QueTypeId, ConsQueDtls.StoveSubType, MobileNo, ConsQueDtls.StoveType);
        //                    //WhatsappSecondMsg = "*यह सिस्टम जनरेटेड मैसेज है इस नंबर पर रिप्लाई ना करें। यदि आपको और अधिक जानकारी चाहिए तो कृपया "+ QuestionMasterData.ContactNo + " पर संपर्क करें।*";
        //                }
        //                else //if (MsgSendLanguage == 3)//Send whatsapp msg in Marathi
        //                {
        //                    WhatsappFirstMsg = CustomerEngMsg(StoveSubItem, stoveItemDtls, priceDetails, QuestionMasterData, ConsQueDtls.QueTypeId, ConsQueDtls.StoveSubType, MobileNo, ConsQueDtls.StoveType);
        //                    //WhatsappSecondMsg = "*This is system generated message do not reply on this number. If you need further details please contact on*" + QuestionMasterData.ContactNo;
        //                }

        //                // Send whatsapp message to distributor if enquiry is created by Vendor
        //                if (!string.IsNullOrEmpty(ConsQueDtls.ConsumerName) && !string.IsNullOrEmpty(ConsQueDtls.DistWhatsappNo) && !string.IsNullOrEmpty(ConsQueDtls.VendorName))
        //                {
        //                    DistributorWhatsappMsg = "*NC Enquiry Update*,\n\n*" + ConsQueDtls.VendorName.Trim() + "* Vendor has just registered a *" + QuestionMasterData.EnquiryQue.Trim() + "* connection request for name *" + ConsQueDtls.ConsumerName.Trim() + "*";
        //                    //"*NC Enquiry Update*,\n\n*ABC* Vendor has just registered a *New connection* connection request for name *Prasanna*";
        //                }

        //                if (!string.IsNullOrEmpty(WhatsappFirstMsg))
        //                {
        //                    Task<string> result = null;
        //                    if (!string.IsNullOrWhiteSpace(MobileNo))
        //                        result = Task.Run(() => GetAsync(WhatsappFirstMsg, MobileNo, DistributorWhatsappMsg, ConsQueDtls.DistWhatsappNo));
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, ConsQueDtls.DistributorId, "Send Whatsapp Msg", "QueTypeId- " + ConsQueDtls.QueTypeId + ", StoveSubType- " + ConsQueDtls.StoveSubType + ", MobileNo-" + MobileNo, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        throw ex;
        //    }
        //}

        //private string CustomerMarathiMsg(StoveItemDtls StoveSubItem, StoveItemDtls StoveItemDtls, List<PriceDetails> PriceDetails, QuestionMaster QuestionData, long QueTypeId, long StoveSubType, string MobileNo, long StoveType)
        //{
        //    string WhatsappMsg = string.Empty; decimal? Price = 0, NewWithAdtnalPrice = 0, NewCylPrice = 0;
        //    try
        //    {
        //        if (QueTypeId == 4)//New with Additional Cylinder
        //        {
        //            WhatsappMsg = "प्रिय ग्राहक,\n\n*" + QuestionData.DistributorName + "* यांचेकडुन हार्दिक शुभेच्छा...\nआपणाकडुन नुकत्याच *" + QuestionData.EnquiryQue.Trim() + "* जोडणी बाबत करणेत आलेल्या चौकशीसाठी आम्ही आपले आभारी आहोत.यास अनुसरुन आम्ही आपणास पुढील प्रमाणे एचपी गॅस कनेक्शनची किंमत कळवु इच्छीतो *रु. CONPRICE/-* विना गॅस स्टोव्ह किंमत. \n\nतपशिल पुढील प्रमाणे:\n";
        //            foreach (var item in PriceDetails)
        //            {
        //                NewWithAdtnalPrice = item.RSP;
        //                if (item.ID == 5)// Take double Deposit for cylinder 14.2kg
        //                {
        //                    WhatsappMsg += (item.TotalAmount) + " - " + item.ItemNameInMarathi + "\n";
        //                    Price += (item.TotalAmount);
        //                }
        //                else //Other Items in Invoice
        //                {
        //                    if (item.ID == 19) //Check Installation charges
        //                    {
        //                        if (StoveSubType == 0 && StoveType > 0) //check stove brand is not selected and Stove type is selected ie single burner. then give inspection charges otherwise give Installation charges.
        //                        {
        //                            WhatsappMsg += String.Format("{0:0.00}", StoveItemDtls.StoveTypePrice) + " - " + StoveItemDtls.StoveType.Trim() + " साठी तपासणी शुल्क (जीएसटी सह)\n";
        //                            Price += StoveItemDtls.StoveTypePrice;
        //                        }
        //                        else
        //                        {
        //                            WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInMarathi + " (जीएसटी सह)\n";
        //                            Price += item.TotalAmount;
        //                        }
        //                    }
        //                    else
        //                    {
        //                        WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInMarathi + "\n";
        //                        Price += item.TotalAmount;
        //                    }
        //                }
        //            }

        //            //New with Additional Cylinder
        //            WhatsappMsg += String.Format("{0:0.00}", (NewWithAdtnalPrice)) + " - गॅस सिलेंडर १४.२ कि.ग्रॅ. (जीएसटी सह)\n";
        //            Price += (NewWithAdtnalPrice);
        //        }
        //        else //New Connection and Additional Connection
        //        {
        //            WhatsappMsg = "प्रिय ग्राहक,\n\n*" + QuestionData.DistributorName + "* यांचेकडुन हार्दिक शुभेच्छा...\nआपणाकडुन नुकत्याच *" + QuestionData.EnquiryQue.Trim() + "* जोडणी बाबत करणेत आलेल्या चौकशीसाठी आम्ही आपले आभारी आहोत.यास अनुसरुन आम्ही आपणास पुढील प्रमाणे एचपी गॅस कनेक्शनची किंमत कळवु इच्छीतो *रु. CONPRICE/-* विना स्टोव्ह गॅस किंमत. \n\nतपशिल पुढील प्रमाणे:\n";
        //            foreach (var item in PriceDetails)
        //            {
        //                NewCylPrice = item.RSP;
        //                if (item.ID == 5)// Take Deposit for cylinder 14.2kg
        //                {
        //                    WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInMarathi + "\n";
        //                    Price += item.TotalAmount;
        //                }
        //                else //Other Items in Invoice
        //                {
        //                    if (item.ID == 18 || item.ID == 20)//Check Installation charges 
        //                    {
        //                        if (StoveSubType == 0 && StoveType > 0)//check stove brand is not selected and Stove type is selected ie single burner. then give inspection charges otherwise give Installation charges.
        //                        {
        //                            WhatsappMsg += String.Format("{0:0.00}", StoveItemDtls.StoveTypePrice) + " - " + StoveItemDtls.StoveType.Trim() + " साठी तपासणी शुल्क (जीएसटी सह)\n";
        //                            Price += StoveItemDtls.StoveTypePrice;
        //                        }
        //                        else
        //                        {
        //                            WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInMarathi + " (जीएसटी सह)\n";
        //                            Price += item.TotalAmount;
        //                        }
        //                    }
        //                    else
        //                    {
        //                        WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInMarathi + "\n";
        //                        Price += item.TotalAmount;
        //                    }
        //                }
        //            }
        //            //New connection and additional connection
        //            WhatsappMsg += String.Format("{0:0.00}", NewCylPrice) + " - गॅसची किंमत (जीएसटी सह)\n";
        //            Price += NewCylPrice;
        //        }
        //        if (StoveSubType == 0 && StoveSubItem == null)//with stove cost added
        //        {
        //            if (QueTypeId != 2)
        //            {
        //                WhatsappMsg += "236.00 - निरीक्षण शुल्क\n";
        //                Price += 236;
        //            }
        //        }
        //        if (QueTypeId == 2)//Additional Cylinder
        //            WhatsappMsg += "*" + String.Format("{0:0.00}", Price) + " - कनेक्शनची एकूण किंमत*\n";
        //        else//New Connection and New with Additional Cylinder
        //            WhatsappMsg += "*" + String.Format("{0:0.00}", Price) + " - विना स्टोव्ह गॅस कनेक्शनची किंमत (जीएसटी सह)*\n";

        //        WhatsappMsg = WhatsappMsg.Replace("CONPRICE", String.Format("{0:0.00}", Price));//Replace final price on top of msg
        //        if (StoveSubType > 0 && StoveSubItem != null)//with stove cost added
        //        {
        //            WhatsappMsg += "\nयाव्यतिरिक्त इतर ऐच्छीक गोष्टी\n";
        //            WhatsappMsg += String.Format("{0:0.00}", StoveSubItem.Price) + " - " + StoveSubItem.ItemName.Trim() + " गॅस शेगडी (अन्यप्रकारचे गॅस स्टोव्ह सुध्दा उपलब्ध)\n";
        //            Price += StoveSubItem.Price;
        //            WhatsappMsg += "*" + String.Format("{0:0.00}", Price) + " - एकुण गॅस स्टोव्हसह कनेक्शनची किंमत (जीएसटी सह)*\n";
        //        }
        //        WhatsappMsg += "\nकृपया कनेक्शन स्थापनेसाठी आपल्या योग्य दिनांक आणि वेळेचा सल्ला द्या आणि आम्ही त्वरीत आपली सेवा करण्यात आनंदित होऊ.\n";

        //        if (QueTypeId == 2)//Additional Cylinder
        //            WhatsappMsg += QuestionData.EnquiryQue.Trim() + " साठी आवश्यक कागदपत्रे:\n1.        ओरिनिगल एसव्ही पेपर\n2.        ओळख पुरावा\n3.        डीजीसीसी बुक\n";
        //        else//New Connection and New with Additional Cylinder
        //            WhatsappMsg += QuestionData.EnquiryQue.Trim() + " साठी आवश्यक कागदपत्रे:\n1.        1 फोटो ग्राफ\n2.        रहिवाशी पुरावा (वाहन चालक परवाना/ मतदान ओळखपत्र / विज अथवा दुरध्वनी बील/ पारपत्र)\n3.        आधार कार्ड\n4.        बॅंक खाते तपशील (अकौंट नंबर, बॅंकेचे नाव, आयएफएससी कोड इत्यादी)\n";

        //        WhatsappMsg += "\nअधीक माहीतीसाठी संपर्क,\n*" + QuestionData.DistributorName + "*\n";
        //        if (QuestionData.ContactNo != null)
        //            WhatsappMsg += "संपर्क नंबर: " + QuestionData.ContactNo;
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //    return WhatsappMsg;
        //}
        //private string CustomerHindiMsg(StoveItemDtls StoveSubItem, StoveItemDtls StoveItemDtls, List<PriceDetails> PriceDetails, QuestionMaster QuestionData, long QueTypeId, long StoveSubType, string MobileNo, long StoveType)
        //{
        //    string WhatsappMsg = string.Empty; decimal? Price = 0, NewWithAdtnalPrice = 0, NewCylPrice = 0;
        //    try
        //    {
        //        if (QueTypeId == 4)//New with Additional Cylinder
        //        {
        //            WhatsappMsg = "प्रिय ग्राहक,\n\n*" + QuestionData.DistributorName + "* की ओर से बधाई !!\n*" + QuestionData.EnquiryQue.Trim() + "* के बारे में हाल ही में की गई आपकी पूछताछ के लिए धन्यवाद। आपकी पूछताछ के जवाब में, एचपी गैस आपको स्टोव के बिना *रु. CONPRICE/-* का उत्तम मूल्य प्रदान करता है। \n\nमूल्य में शामिल हैं:\n";
        //            foreach (var item in PriceDetails)
        //            {
        //                NewWithAdtnalPrice = item.RSP;
        //                if (item.ID == 5)// Take double Deposit for cylinder 14.2kg
        //                {
        //                    WhatsappMsg += (item.TotalAmount) + " - " + item.ItemNameInHindi + "\n";
        //                    Price += (item.TotalAmount);
        //                }
        //                else //Other Items in Invoice
        //                {
        //                    if (item.ID == 19) //Check Installation charges
        //                    {
        //                        if (StoveSubType == 0 && StoveType > 0) //check stove brand is not selected and Stove type is selected ie single burner. then give inspection charges otherwise give Installation charges.
        //                        {
        //                            WhatsappMsg += String.Format("{0:0.00}", StoveItemDtls.StoveTypePrice) + " - " + StoveItemDtls.StoveType.Trim() + " के लिए निरीक्षण शुल्क (जीएसटी के साथ)\n";
        //                            Price += StoveItemDtls.StoveTypePrice;
        //                        }
        //                        else
        //                        {
        //                            WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInHindi + " (जीएसटी के साथ)\n";
        //                            Price += item.TotalAmount;
        //                        }
        //                    }
        //                    else
        //                    {
        //                        WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInHindi + "\n";
        //                        Price += item.TotalAmount;
        //                    }
        //                }
        //            }

        //            //New with Additional Cylinder
        //            WhatsappMsg += String.Format("{0:0.00}", (NewWithAdtnalPrice)) + " - गैस की लागत (RSP, जीएसटी के साथ)\n";
        //            Price += (NewWithAdtnalPrice);
        //        }
        //        else //New Connection and Additional Connection
        //        {
        //            WhatsappMsg = "प्रिय ग्राहक,\n\n*" + QuestionData.DistributorName + "* की ओर से बधाई !!\n*" + QuestionData.EnquiryQue.Trim() + "* के बारे में हाल ही में की गई आपकी पूछताछ के लिए धन्यवाद। आपकी पूछताछ के जवाब में, एचपी गैस आपको स्टोव के बिना *रु. CONPRICE/-* का उत्तम मूल्य प्रदान करता है। \n\nमूल्य में शामिल हैं:\n";
        //            foreach (var item in PriceDetails)
        //            {
        //                NewCylPrice = item.RSP;
        //                if (item.ID == 5)// Take Deposit for cylinder 14.2kg
        //                {
        //                    WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInHindi + "\n";
        //                    Price += item.TotalAmount;
        //                }
        //                else //Other Items in Invoice
        //                {
        //                    if (item.ID == 18 || item.ID == 20)//Check Installation charges 
        //                    {
        //                        if (StoveSubType == 0 && StoveType > 0)//check stove brand is not selected and Stove type is selected ie single burner. then give inspection charges otherwise give Installation charges.
        //                        {
        //                            WhatsappMsg += String.Format("{0:0.00}", StoveItemDtls.StoveTypePrice) + " - " + StoveItemDtls.StoveType.Trim() + " के लिए निरीक्षण शुल्क (जीएसटी के साथ)\n";
        //                            Price += StoveItemDtls.StoveTypePrice;
        //                        }
        //                        else
        //                        {
        //                            WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInHindi + " (जीएसटी के साथ)\n";
        //                            Price += item.TotalAmount;
        //                        }
        //                    }
        //                    else
        //                    {
        //                        WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInHindi + "\n";
        //                        Price += item.TotalAmount;
        //                    }
        //                }
        //            }

        //            //New connection and additional connection
        //            WhatsappMsg += String.Format("{0:0.00}", NewCylPrice) + " - गैस की लागत (RSP, जीएसटी के साथ)\n";
        //            Price += NewCylPrice;
        //        }
        //        if (StoveSubType == 0 && StoveSubItem == null)//with stove cost added
        //        {
        //            if (QueTypeId != 2)
        //            {
        //                WhatsappMsg += "236.00 - तपासणी शुल्क\n";
        //                Price += 236;
        //            }
        //        }
        //        if (QueTypeId == 2)//Additional Cylinder
        //            WhatsappMsg += "*" + String.Format("{0:0.00}", Price) + " - कनेक्शन की कुल लागत*\n";
        //        else//New Connection and New with Additional Cylinder
        //            WhatsappMsg += "*" + String.Format("{0:0.00}", Price) + " - कनेक्शन पर स्टोव की लागत के बिना*\n";

        //        WhatsappMsg = WhatsappMsg.Replace("CONPRICE", String.Format("{0:0.00}", Price));//Replace final price on top of msg
        //        if (StoveSubType > 0 && StoveSubItem != null)//with stove cost added
        //        {
        //            WhatsappMsg += "\nअतिरिक्त आइटम - स्टोव\n";
        //            WhatsappMsg += String.Format("{0:0.00}", StoveSubItem.Price) + " - " + StoveSubItem.ItemName.Trim() + " गॅस शेगडी (अन्य प्रकार के गैस स्टोव भी उपलब्ध हैं)\n";
        //            Price += StoveSubItem.Price;
        //            WhatsappMsg += "*" + String.Format("{0:0.00}", Price) + " - स्टोव सहित कनेक्शन की कुल लागत*\n";
        //        }

        //        WhatsappMsg += "\nकनेक्शन स्थापना के लिए कृपया अपनी उचित तिथि और समय की जानकारी दें ताकि हमें जल्दी से सेवा देने में खुशी होगी।\n";

        //        if (QueTypeId == 2)//Additional Cylinder
        //            WhatsappMsg += QuestionData.EnquiryQue.Trim() + " के लिए आवश्यक दस्तावेज:\n1.        ओरिगनल एसवी पेपर\n2.        पहचान प्रमाण\n3.        डीजीसीसी बुक\n";
        //        else//New Connection and New with Additional Cylinder
        //            WhatsappMsg += QuestionData.EnquiryQue.Trim() + " के लिए आवश्यक दस्तावेज:\n1.        1 फोटो ग्राफ\n2.        पते का प्रमाण (ड्राइविंग लाइसेंस / वोटर आईडी / बिजली या टेलीफोन का बिल / पासपोर्ट)\n3.        आधार कार्ड\n4.        बैंक विवरण (खाता संख्या, बैंक का नाम, आईएफएससी कोड)\n";

        //        WhatsappMsg += "\nशुभकामनाओ सहित,\n*" + QuestionData.DistributorName + "*\n";
        //        if (QuestionData.ContactNo != null)
        //            WhatsappMsg += "संपर्क नंबर: " + QuestionData.ContactNo;
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //    return WhatsappMsg;
        //}
        //private string CustomerEngMsg(StoveItemDtls StoveSubItem, StoveItemDtls StoveItemDtls, List<PriceDetails> PriceDetails, QuestionMaster QuestionData, long QueTypeId, long StoveSubType, string MobileNo, long StoveType)
        //{
        //    string WhatsappMsg = string.Empty; decimal? Price = 0, NewWithAdtnalPrice = 0, NewCylPrice = 0;
        //    try
        //    {
        //        if (QueTypeId == 4)//New with Additional Cylinder
        //        {
        //            WhatsappMsg = "Dear Valued Customer,\n\nGreetings from *" + QuestionData.DistributorName + " !!*\nThanks for your recent enquiry about HP GAS *" + QuestionData.EnquiryQue.Trim() + "*. In response to your query, HP GAS offers you Best price of *Rs. CONPRICE/-*  without Stove. \n\nPrice includes:\n";
        //            foreach (var item in PriceDetails)
        //            {
        //                NewWithAdtnalPrice = item.RSP;
        //                if (item.ID == 5)// Take double Deposit for cylinder 14.2kg
        //                {
        //                    WhatsappMsg += (item.TotalAmount) + " - " + item.ItemNameInEnglish + "\n";
        //                    Price += (item.TotalAmount);
        //                }
        //                else //Other Items in Invoice
        //                {
        //                    if (item.ID == 19) //Check Installation charges
        //                    {
        //                        if (StoveSubType == 0 && StoveType > 0) //check stove brand is not selected and Stove type is selected ie single burner. then give inspection charges otherwise give Installation charges.
        //                        {
        //                            WhatsappMsg += String.Format("{0:0.00}", StoveItemDtls.StoveTypePrice) + " - Inspection Charges for " + StoveItemDtls.StoveType.Trim() + " (Inc. GST)\n";
        //                            Price += StoveItemDtls.StoveTypePrice;
        //                        }
        //                        else
        //                        {
        //                            WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInEnglish + "(Inc. GST)\n";
        //                            Price += item.TotalAmount;
        //                        }
        //                    }
        //                    else
        //                    {
        //                        WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInEnglish + "(Inc. GST)\n";
        //                        Price += item.TotalAmount;
        //                    }
        //                }
        //            }

        //            //New with Additional Cylinder
        //            WhatsappMsg += String.Format("{0:0.00}", (NewWithAdtnalPrice)) + " - Cost of Gas (RSP, Inc. GST)\n";
        //            Price += (NewWithAdtnalPrice);
        //        }
        //        else //New Connection and Additional Connection
        //        {
        //            WhatsappMsg = "Dear Valued Customer,\n\nGreetings from *" + QuestionData.DistributorName + "* !!\nThanks for your recent enquiry about HP GAS *" + QuestionData.EnquiryQue.Trim() + "*. In response to your query, HP GAS offers you Best price of *Rs. CONPRICE/-*  without Stove. \n\nPrice includes:\n";
        //            foreach (var item in PriceDetails)
        //            {
        //                NewCylPrice = item.RSP;
        //                if (item.ID == 5)// Take Deposit for cylinder 14.2kg
        //                {
        //                    WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInEnglish + "\n";
        //                    Price += item.TotalAmount;
        //                }
        //                else //Other Items in Invoice
        //                {
        //                    if (item.ID == 18 || item.ID == 20)//Check Installation charges 
        //                    {
        //                        if (StoveSubType == 0 && StoveType > 0)//check stove brand is not selected and Stove type is selected ie single burner. then give inspection charges otherwise give Installation charges.
        //                        {
        //                            WhatsappMsg += String.Format("{0:0.00}", StoveItemDtls.StoveTypePrice) + " - Inspection Charges for " + StoveItemDtls.StoveType.Trim() + " (Inc. GST)\n";
        //                            Price += StoveItemDtls.StoveTypePrice;
        //                        }
        //                        else
        //                        {
        //                            WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInEnglish + "(Inc. GST)\n";
        //                            Price += item.TotalAmount;
        //                        }
        //                    }
        //                    else
        //                    {
        //                        WhatsappMsg += item.TotalAmount + " - " + item.ItemNameInEnglish + "(Inc. GST)\n";
        //                        Price += item.TotalAmount;
        //                    }
        //                }
        //            }
        //            //New connection and additional connection
        //            WhatsappMsg += String.Format("{0:0.00}", NewCylPrice) + " - Cost of Gas (RSP, Inc. GST)\n";
        //            Price += NewCylPrice;
        //        }
        //        if (StoveSubType == 0 && StoveSubItem == null)//with stove cost added
        //        {
        //            if (QueTypeId != 2)
        //            {
        //                WhatsappMsg += "236.00 - Inspection Charges\n";
        //                Price += 236;
        //            }
        //        }
        //        if (QueTypeId == 2)//Additional Cylinder
        //            WhatsappMsg += "*" + String.Format("{0:0.00}", Price) + " - Total Cost of Connection*\n";
        //        else//New Connection and New with Additional Cylinder
        //            WhatsappMsg += "*" + String.Format("{0:0.00}", Price) + " - Without Stove Cost on Connection*\n";

        //        WhatsappMsg = WhatsappMsg.Replace("CONPRICE", String.Format("{0:0.00}", Price));//Replace final price on top of msg
        //        if (StoveSubType > 0 && StoveSubItem != null)//with stove cost added
        //        {
        //            WhatsappMsg += "\nAdditional item - Stove\n";
        //            WhatsappMsg += String.Format("{0:0.00}", StoveSubItem.Price) + " - " + StoveSubItem.ItemName.Trim() + "\n";
        //            Price += StoveSubItem.Price;
        //            WhatsappMsg += "*" + String.Format("{0:0.00}", Price) + " - Total Cost of Connection Including Stove*\n";
        //        }
        //        //else
        //        //{
        //        //    WhatsappMsg += "\nInspection Charges - 236.00\n";
        //        //}

        //        WhatsappMsg += "\nKindly advise your suitable date and time for Connection installation and we will be delighted to serve you quickly.\n";

        //        if (QueTypeId == 2)//Additional Cylinder
        //            WhatsappMsg += "Documents required for " + QuestionData.EnquiryQue.Trim() + ":\n1.        Orignal SV Paper\n2.        Identity Proof\n3.        DGCC Book\n";
        //        else//New Connection and New with Additional Cylinder
        //            WhatsappMsg += "Documents required for " + QuestionData.EnquiryQue.Trim() + ":\n1.        1 Photo graphs\n2.        Proof of Address (Driving Licence/ Voter ID/ Electricity or Telephone Bill/ Passport)\n3.        Aadhar Card\n4.        Bank Details(Account No., Bank Name, IFSC Code)\n";

        //        WhatsappMsg += "\nBest wishes,\n*" + QuestionData.DistributorName + "*\n";
        //        if (QuestionData.ContactNo != null)
        //            WhatsappMsg += "Contact No: " + QuestionData.ContactNo;
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //    return WhatsappMsg;
        //}

        //public async Task<string> CheckNoUsingWhatsAppOrNot(string MobileNos)
        //{
        //    try
        //    {
        //        List<MobNoInfo> Msglist = null;
        //        PickyJSON dtlsModel = null;
        //        MobNoInfo MobmsgInfo = null;
        //        string result = string.Empty;
        //        string token = ConfigurationManager.AppSettings["Token"];

        //        if (MobileNos != null && token != null)
        //        {
        //            string MobileNo = string.Empty;
        //            Msglist = new List<MobNoInfo>();

        //            if (MobileNos.Length == 10)
        //                MobileNo = "91" + MobileNos;
        //            else
        //                MobileNo = MobileNos;
        //            MobmsgInfo = new MobNoInfo
        //            {
        //                number = MobileNo
        //            };
        //            Msglist.Add(MobmsgInfo);
        //            dtlsModel = new PickyJSON
        //            {
        //                token = token,
        //                application = "2",
        //                action = "1",
        //                data = Msglist
        //            };

        //            var data = JsonConvert.SerializeObject(dtlsModel);
        //            using (var client = new HttpClient())
        //            {
        //                var stringContent = new StringContent(data, System.Text.Encoding.UTF8, "application/json");
        //                var response = await client.PostAsync("https://pickyassist.com/app/api/v2/push", stringContent);
        //                result = await response.Content.ReadAsStringAsync();
        //            }
        //        }
        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}


        ///// <summary>
        ///// Return documents list.
        ///// </summary>
        ///// <returns></returns>
        //public List<Documents> GetDocuments()
        //{
        //    return GetDocumentsPvt();
        //}

        ///// <summary>
        ///// Return documents list.
        ///// </summary>
        ///// <returns></returns>
        //private List<Documents> GetDocumentsPvt()
        //{
        //    return ContextManager._Context.sp_GetDocuments().Select(a => new Documents
        //    {
        //        EQueId = a.EQueId,
        //        DocumentName = a.DocumentName
        //    }).ToList();
        //}

        ///// <summary>
        ///// return customer details from mobile no
        ///// </summary>
        ///// <param name="customerDetails"></param>
        ///// <returns></returns>
        //public ConsumerDetails GetCustomerDetails(CustomerDetails customerDetails)
        //{
        //    return GetCustomerDetailsPvt(customerDetails);
        //}

        ///// <summary>
        ///// return customer details from mobile no
        ///// </summary>
        ///// <param name="customerDetails"></param>
        ///// <returns></returns>
        //private ConsumerDetails GetCustomerDetailsPvt(CustomerDetails customerDetails)
        //{
        //    ConsumerDetails consumerDetails = new ConsumerDetails();
        //    try
        //    {
        //        //LogId = BusinessCont.SaveLog(0, 0, "GetCustomerDetails", "MobileNo- " + customerDetails.MobileNo, null, null);
        //        consumerDetails.ConsDtls = new List<ConsDtls>();
        //        DateTime FromDate = DateTime.Now, ToDate = DateTime.Now;
        //        if (customerDetails.FromDate != null)
        //            FromDate = Convert.ToDateTime(customerDetails.FromDate);
        //        if (customerDetails.ToDate != null)
        //            ToDate = Convert.ToDateTime(customerDetails.ToDate);
        //        ContextManager contextManager = new ContextManager();
        //        consumerDetails.ConsDtls = ContextManager._Context.sp_GetConsumerDetails(customerDetails.DistributorId, customerDetails.MobileNo, FromDate, ToDate).Select(a => new ConsDtls
        //        {
        //            ConsumerName = a.ConsumerName,
        //            ConsAddress = a.Address,
        //            MobileNo = a.MobileNo,
        //            DistributorId = a.DistributorId,
        //            DistributorCode = a.DistributorCode,
        //            DistAddress = a.DistAddress,
        //            DistributorName = a.DistributorName,
        //            CId = a.CId,
        //            IsPurchase = a.IsPurchase,
        //            PurchaseDate = BusinessCont.CheckNullandConvertDateTime(a.PurchaseDate),
        //            EnquiryDate = BusinessCont.CheckNullandConvertDateTime(a.EnquiryDate),
        //            StaffType = a.StaffType,
        //            StaffName = a.StaffName,
        //            ConsumerNo = a.ConsumerNo,
        //            EnquiryType = a.EnquiryType,
        //            Reason = String.IsNullOrEmpty(a.Reason) ? "" : "(" + a.Reason + ")",
        //            CompanyName = a.CompanyName,
        //            EmailId = a.EmailId,
        //            ResidentiaArea = a.ResidentiaArea,
        //            SourceType = a.SourceType
        //        }).ToList();
        //        consumerDetails.Status = BusinessCont.SuccessStatus;
        //    }
        //    catch (Exception ex)
        //    {
        //        consumerDetails.Status = BusinessCont.FailStatus;
        //        consumerDetails.ExMsg = BusinessCont.ExceptionMsg(ex);
        //        BusinessCont.SaveLog(0, 0, "GetCustomerDetails", "DistributorId- " + customerDetails.DistributorId + ", MobileNo- " + customerDetails.MobileNo, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        //throw;
        //    }
        //    return consumerDetails;
        //}

        ///// <summary>
        ///// Call picky assist service for send msg
        ///// </summary>
        ///// <param name="WhatsappMsg">Message</param>
        ///// <param name="MobileNos">mobile nos</param>
        ///// <returns></returns>
        //public async Task<string> GetAsync(string WhatsappFirstMsg, string MobileNos, string DistributorWhatsappMsg, string DistContactNo)
        //{
        //    try
        //    {
        //        List<MobNoInfo> Msglist = null;
        //        PickyJSON dtlsModel = null;
        //        MobNoInfo MobmsgInfo = null;
        //        string result = string.Empty;
        //        string token = ConfigurationManager.AppSettings["Token"];

        //        if (MobileNos != null && token != null)
        //        {
        //            string MobileNo = string.Empty;
        //            Msglist = new List<MobNoInfo>();

        //            if (MobileNos.Length == 10)
        //                MobileNo = "91" + MobileNos;
        //            else
        //                MobileNo = MobileNos;
        //            MobmsgInfo = new MobNoInfo
        //            {
        //                number = MobileNo,
        //                message = WhatsappFirstMsg
        //            };
        //            Msglist.Add(MobmsgInfo);


        //            if (!string.IsNullOrEmpty(DistContactNo) && !string.IsNullOrEmpty(DistributorWhatsappMsg))
        //            {
        //                if (DistContactNo.Contains(","))
        //                {
        //                    string[] MobNos = DistContactNo.Trim().Split(',');
        //                    foreach (var MobNo in MobNos)
        //                    {
        //                        if (MobNo.Length == 10)
        //                            MobileNo = "91" + MobNo;
        //                        else
        //                            MobileNo = MobNo;
        //                        MobmsgInfo = new MobNoInfo
        //                        {
        //                            number = MobileNo,
        //                            message = DistributorWhatsappMsg
        //                        };
        //                        Msglist.Add(MobmsgInfo);
        //                    }
        //                }
        //                else
        //                {
        //                    if (MobileNos.Length == 10)
        //                        //  MobileNo = "91" + MobileNos;
        //                        MobileNo = "91" + DistContactNo;
        //                    else
        //                        MobileNo = MobileNos;
        //                    MobmsgInfo = new MobNoInfo
        //                    {
        //                        number = MobileNo,
        //                        message = DistributorWhatsappMsg
        //                    };
        //                    Msglist.Add(MobmsgInfo);
        //                }
        //                BusinessCont.SaveLog(LogId, 0, "DistributorWhatsappUser", "Mobile No = " + DistContactNo, BusinessCont.SuccessStatus, null);
        //            }

        //            dtlsModel = new PickyJSON
        //            {
        //                token = token,
        //                priority = "0",
        //                application = "2",
        //                sleep = "0",
        //                globalmessage = "",
        //                globalmedia = "",
        //                data = Msglist
        //            };



        //            var data = JsonConvert.SerializeObject(dtlsModel);

        //            using (var client = new HttpClient())
        //            {
        //                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls
        //                            | SecurityProtocolType.Tls11
        //                            | SecurityProtocolType.Tls12;
        //                var stringContent = new StringContent(data, System.Text.Encoding.UTF8, "application/json");

        //                var response = await client.PostAsync("https://pickyassist.com/app/api/v1/push", stringContent);
        //                result = await response.Content.ReadAsStringAsync();
        //            }
        //        }
        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}


        //public async Task<string> GetAsync1(string WhatsappMsg, string MobileNos)
        //{
        //    //distManager = new DistributorManager();
        //    try
        //    {
        //        List<MobNoInfo> Msglist = null;
        //        PickyJSON dtlsModel = null;
        //        MobNoInfo MobmsgInfo = null;
        //        string result = string.Empty;
        //        string token = ConfigurationManager.AppSettings["Token"];
        //        if (MobileNos != null && token != null)
        //        {
        //            string MobileNo = string.Empty;
        //            Msglist = new List<MobNoInfo>();
        //            if (MobileNos.Contains(","))
        //            {
        //                string[] MobNos = MobileNos.Trim().Split(',');
        //                foreach (var MobNo in MobNos.ToList())
        //                {
        //                    if (MobNo.Length == 10)
        //                        MobileNo = "91" + MobNo;
        //                    else
        //                        MobileNo = MobNo;
        //                    MobmsgInfo = new MobNoInfo
        //                    {
        //                        number = MobileNo,
        //                        message = WhatsappMsg
        //                    };
        //                    Msglist.Add(MobmsgInfo);
        //                }
        //            }
        //            else
        //            {
        //                if (MobileNos.Length == 10)
        //                    MobileNo = "91" + MobileNos;
        //                else
        //                    MobileNo = MobileNos;
        //                MobmsgInfo = new MobNoInfo
        //                {
        //                    number = MobileNo,
        //                    message = WhatsappMsg
        //                };
        //                Msglist.Add(MobmsgInfo);
        //            }

        //            //if (MobileNos.Length == 10)
        //            //    MobileNo = "91" + MobileNos;
        //            //else
        //            //    MobileNo = MobileNos;
        //            //MobmsgInfo = new MobNoInfo();
        //            //MobmsgInfo.number = MobileNo;
        //            //MobmsgInfo.message = WhatsappMsg;
        //            //Msglist.Add(MobmsgInfo);

        //            dtlsModel = new PickyJSON
        //            {
        //                token = token,
        //                priority = "0",
        //                application = "2",
        //                sleep = "0",
        //                globalmessage = "",
        //                globalmedia = "",
        //                data = Msglist
        //            };

        //            var data = JsonConvert.SerializeObject(dtlsModel);
        //            using (var client = new HttpClient())
        //            {
        //                var stringContent = new StringContent(data, System.Text.Encoding.UTF8, "application/json");
        //                var response = await client.PostAsync("https://pickyassist.com/app/api/v1/push", stringContent);
        //                result = await response.Content.ReadAsStringAsync();
        //            }
        //        }
        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}



        //public string Sendwhatsappmsg()
        //{
        //    Task<string> result = null;
        //    try
        //    {
        //        string WhatsappFirstMsg = "*NC Enquiry Update*,\n\n*ABC* Vendor has just registered a *New connection* connection request for name *Prasanna*";
        //        result = Task.Run(() => GetAsync(WhatsappFirstMsg, "9404298780", null, null));//Async("919404298780"));
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return result.ToString();
        //}

        //public async Task<string> Async(string MobileNos)
        //{
        //    try
        //    {
        //        List<MobNoInfo> Msglist = null;
        //        PickyJSON dtlsModel = null;
        //        MobNoInfo MobmsgInfo = null;
        //        string result = string.Empty;
        //        string token = ConfigurationManager.AppSettings["Token"];

        //        if (MobileNos != null && token != null)
        //        {
        //            string MobileNo = string.Empty;
        //            Msglist = new List<MobNoInfo>();
        //            if (MobileNos.Contains(","))
        //            {
        //                string[] MobNos = MobileNos.Trim().Split(',');
        //                foreach (var MobNo in MobNos)
        //                {
        //                    if (MobNo.Length == 10)
        //                        MobileNo = "91" + MobNo;
        //                    else
        //                        MobileNo = MobNo;
        //                    MobmsgInfo = new MobNoInfo
        //                    {
        //                        number = MobileNo
        //                    };
        //                    Msglist.Add(MobmsgInfo);
        //                }
        //            }
        //            else
        //            {
        //                if (MobileNos.Length == 10)
        //                    MobileNo = "91" + MobileNos;
        //                else
        //                    MobileNo = MobileNos;
        //                MobmsgInfo = new MobNoInfo
        //                {
        //                    number = MobileNo
        //                };
        //                Msglist.Add(MobmsgInfo);
        //            }
        //            dtlsModel = new PickyJSON
        //            {
        //                token = token,
        //                application = "2",
        //                action = "1",
        //                data = Msglist
        //            };

        //            var data = JsonConvert.SerializeObject(dtlsModel);
        //            using (var client = new HttpClient())
        //            {
        //                var stringContent = new StringContent(data, System.Text.Encoding.UTF8, "application/json");
        //                var response = await client.PostAsync("https://pickyassist.com/app/api/v2/push", stringContent);
        //                result = await response.Content.ReadAsStringAsync();
        //            }
        //        }
        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        //public async Task<string> DeliveryReportAsync()
        //{
        //    try
        //    {
        //        PickyJSON dtlsModel = null;
        //        string result = string.Empty;
        //        string token = ConfigurationManager.AppSettings["Token"];

        //        dtlsModel = new PickyJSON
        //        {
        //            token = token,
        //            push_id = 842983
        //        };

        //        var data = JsonConvert.SerializeObject(dtlsModel);
        //        using (var client = new HttpClient())
        //        {
        //            var stringContent = new StringContent(data, System.Text.Encoding.UTF8, "application/json");
        //            var response = await client.PostAsync("https://pickyassist.com/app/api/v2/delivery-report", stringContent);
        //            result = await response.Content.ReadAsStringAsync();
        //        }
        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        //#region update Customer Details 
        ///// <summary>
        ///// Update Customer Purchase Date 
        ///// </summary>
        ///// <param name="consDtls"></param>
        ///// <returns></returns>
        //public long UpdateCustomerDtls(ConsDtls consDtls)
        //{
        //    return UpdateCustomerDtlsPR(consDtls);
        //}
        ///// <summary>
        ///// Update Customer Purchase Date 
        ///// </summary>
        ///// <param name="consDtls"></param>
        ///// <returns></returns>
        //private long UpdateCustomerDtlsPR(ConsDtls consDtls)
        //{
        //    ContextManager contextManager = new ContextManager();
        //    long StaffRefNo = 0;
        //    ObjectParameter objParam = new ObjectParameter("Result", typeof(long));
        //    try
        //    {
        //        DateTime? PurchaseDate = DateTime.Now;
        //        if (consDtls.PurchaseDate != null && consDtls.PurchaseDate.Length > 0)
        //            PurchaseDate = Convert.ToDateTime(consDtls.PurchaseDate);
        //        ContextManager._Context.sp_UpdateConsumerDetails(consDtls.CId, consDtls.DistributorId, consDtls.StaffRefNo, consDtls.IsPurchase, consDtls.Reason, PurchaseDate, consDtls.Operation, objParam);
        //        if (objParam != null)
        //        {
        //            StaffRefNo = Convert.ToInt64(objParam.Value);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return StaffRefNo;
        //}
        //#endregion

        //#region Get Unassign Consumer

        //public ConsumerDetails GetUnassignConsumerDetails(CustomerDetails customerDetails)
        //{
        //    return GetUnassignConsumerDetailsPR(customerDetails);
        //}
        //private ConsumerDetails GetUnassignConsumerDetailsPR(CustomerDetails customerDetails)
        //{
        //    ConsumerDetails consumerDetails = new ConsumerDetails();
        //    consumerDetails.unassginConsumersDtls = new UnassginConsumer();
        //    try
        //    {
        //        //LogId = BusinessCont.SaveLog(0, 0, "GetUnassignConsumerDetails", "MobileNo- " + customerDetails.MobileNo, null, null);
        //        consumerDetails.ConsDtls = new List<ConsDtls>();
        //        DateTime? FromDate = null;
        //        DateTime? ToDate = null;
        //        if (!String.IsNullOrEmpty(customerDetails.FromDate))
        //            FromDate = Convert.ToDateTime(customerDetails.FromDate);
        //        if (!String.IsNullOrEmpty(customerDetails.ToDate))
        //            ToDate = Convert.ToDateTime(customerDetails.ToDate);
        //        ContextManager contextManager = new ContextManager();
        //        consumerDetails.unassginConsumers = ContextManager._Context.sp_GetUnassignConsumerDetails(customerDetails.CId, FromDate, ToDate).Select(a => new UnassginConsumer
        //        {
        //            ConsumerName = a.ConsumerName,
        //            Address = a.Address,
        //            MobileNo = a.MobileNo,
        //            DistributorId = a.DistributorId,
        //            CId = a.CId,
        //            IsPurchase = a.IsPurchase,
        //            PurchaseDate = BusinessCont.CheckNullandConvertDateTime(a.PurchaseDate),
        //            EnquiryDate = BusinessCont.CheckNullandConvertDateTime(a.EnquiryDate),
        //            ConsumerNo = a.ConsumerNo,
        //            Reason = String.IsNullOrEmpty(a.Reason) ? "" : a.Reason,
        //            CompanyName = a.CompanyName,
        //            EmailId = a.EmailId,
        //            ResidentiaArea = a.ResidentiaArea,
        //            SourceType = a.SourceType,
        //            StaffRefNo = a.StaffRefNo,
        //            DistributorName = a.DistributorName,
        //            ConnectionType = a.ConnectionType,
        //            Brand = a.Brand,
        //            burnerType = a.burnerType,
        //            ExpectedDate = a.ExpectedDate,
        //            Stove = a.Stove
        //        }).ToList();
        //        if (customerDetails.CId != 0)
        //            consumerDetails.unassginConsumersDtls = consumerDetails.unassginConsumers.FirstOrDefault();
        //        consumerDetails.Status = BusinessCont.SuccessStatus;
        //    }
        //    catch (Exception ex)
        //    {
        //        consumerDetails.Status = BusinessCont.FailStatus;
        //        consumerDetails.ExMsg = BusinessCont.ExceptionMsg(ex);
        //        BusinessCont.SaveLog(0, 0, "GetUnassignConsumerDetails", "DistributorId- " + customerDetails.DistributorId + ", MobileNo- " + customerDetails.MobileNo, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        //throw;
        //    }
        //    return consumerDetails;
        //}


        //#endregion

        //public List<EmailSend> GetEmailViaWebApi(int EmailId)
        //{
        //    return GetEmailPvt(EmailId);
        //}

        //private List<EmailSend> GetEmailPvt(int EmailId)
        //{
        //    ContextManager contextManager = new ContextManager();
        //    return ContextManager._Context.sp_GetEmailLog(EmailId).Select(a => new EmailSend
        //    {
        //        Id = a.Id,
        //        Email = a.Email,
        //        Status = a.Status
        //    }).ToList();
        //}

        //public decimal SaveAPILog(decimal logID, int distributorId, string logFor, string logData, string logStatus, string logException)
        //{
        //    decimal LogId = 0;
        //    using (HPGASNCEnquiryEntities contextManager = new HPGASNCEnquiryEntities())
        //    {
        //        var ID = contextManager.sp_AddEditAPIHitLog(logID, distributorId, logFor, logData, logStatus, DateTime.Now, logException).FirstOrDefault();
        //        if (ID != null)
        //            LogId = ID.Value;
        //    }
        //    return LogId;
        //}

        //public MessageSend SendWhatsappMessage(string Token, string RequiredData, int EventId)
        //{
        //    MessageSend messageSendStatus = new MessageSend();
        //    messageSendStatus.Status = BusinessCont.FailStatus;
        //    try
        //    {
        //        string ValidToken = ConfigurationManager.AppSettings["WhatsappAPIToken"];
        //        string SendWhatsappMsg = ConfigurationManager.AppSettings["SendWhatsappMsg"];
        //        if (!string.IsNullOrEmpty(RequiredData) && ValidToken == Token && SendWhatsappMsg == "Y")
        //        {
        //            SaveAPILog(0, 0, "SendWhatsappMessage", "SendWhatsappMsg = " + SendWhatsappMsg + ", Token =" + Token + ", EventId=" + EventId + ", RequiredData = " + RequiredData, BusinessCont.SuccessStatus, null);
        //            GenerateWhatsappMsg(RequiredData, EventId);
        //            messageSendStatus.Status = BusinessCont.SuccessStatus;
        //        }
        //        else
        //            SaveAPILog(0, 0, "SendWhatsappMessage", "SendWhatsappMsg = " + SendWhatsappMsg + ", Token =" + Token + ", EventId=" + EventId + ", RequiredData = " + RequiredData, BusinessCont.FailStatus, null);
        //    }
        //    catch (Exception ex)
        //    {
        //        SaveAPILog(0, 0, "SendWhatsappMessage", "Token =" + Token + ", EventId=" + EventId + ", RequiredData = " + RequiredData, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        messageSendStatus.Status = BusinessCont.FailStatus;
        //    }
        //    return messageSendStatus;
        //}

        //public void GenerateWhatsappMsg(string RequiredData, int EventId)
        //{
        //    try
        //    {
        //        string FinalWhatsappMsg = string.Empty; Task<string> result = null;
        //        var CustomerDetails = JsonConvert.DeserializeObject<LPGDetails>(RequiredData);
        //        if (CustomerDetails != null)
        //        {
        //            DateTime? ActiveDate = null, ReadingDate = null, DueDate = null;
        //            if (!string.IsNullOrEmpty(CustomerDetails.ActiveDate))
        //                ActiveDate = BusinessCont.StrConvertIntoDatetime(CustomerDetails.ActiveDate);
        //            if (!string.IsNullOrEmpty(CustomerDetails.ReadingDate))
        //                ReadingDate = BusinessCont.StrConvertIntoDatetime(CustomerDetails.ReadingDate);
        //            if (!string.IsNullOrEmpty(CustomerDetails.DueDate))
        //                DueDate = BusinessCont.StrConvertIntoDatetime(CustomerDetails.DueDate);

        //            if (!string.IsNullOrEmpty(CustomerDetails.CustomerName))
        //                    FinalWhatsappMsg = "Dear " + CustomerName + ",\nThanks for choosing Shree Renuka LPG services. Your reticulated LPG connection has been activated on " + ActiveDate.Value.ToString(BusinessCont.DateFormat) + " by Shree Renuka LPG services. *Your CRN No. is " + CustomerDetails.CRN.Trim() + "*";
        //                if (EventId == 2)
        //                    FinalWhatsappMsg = "Dear " + CustomerName + ",\nCRN No - " + CustomerDetails.CRN + ". Your LPG meter reading has been captured *" + CustomerDetails.MeterReading + "* as on " + ReadingDate.Value.ToString(BusinessCont.DateFormat) + ". For any discrepancies please get in touch with our office at " + CustomerDetails.OfficeNumbers + ". \n\n*Thank you.*\n*Shree Renuka LPG services team.*";
        //                if (EventId == 3)
        //                    FinalWhatsappMsg = "Dear " + CustomerName + ",\nCRN No - " + CustomerDetails.CRN + ". Your LPG consumption bill for month of *" + CultureInfo.CurrentCulture.TextInfo.ToTitleCase(CustomerDetails.BillingMonth.Trim()) + "* is generated successfully. Itemized bill has been sent to your registered email ID.\nTotal Amount Due - *" + CustomerDetails.TotalAmountDue + "*\nDue Date - *" + DueDate.Value.ToString(BusinessCont.DateFormat) + "*\nClick to Pay - *" + CustomerDetails.PaymentLink + "*\nView Bill - *" + CustomerDetails.Billurl + "*\n\n*Thank you.*\n*Shree Renuka LPG services team.*";
        //                if (EventId == 4)
        //                    FinalWhatsappMsg = "Dear " + CustomerName + ",\nCRN No - " + CustomerDetails.CRN + ". Your LPG consumption bill due date is approaching on *" + DueDate.Value.ToString(BusinessCont.DateFormat) + "*.\nAmount Due - *" + CustomerDetails.TotalAmountDue + "*\nClick to Pay - *" + CustomerDetails.PaymentLink + "*\nKindly pay before due date to avoid late payment charges.\n\n*Thank you.*\n*Shree Renuka LPG services team.*";
        //                if (EventId == 5)
        //                    FinalWhatsappMsg = "Dear " + CustomerName + ",\nCRN No - " + CustomerDetails.CRN + ". Your LPG consumption Bill payment of *Rs." + CustomerDetails.AmountPaid + "* is successful.\n\n*Thank you for using Shree Renuka LPG services*";
        //                if (EventId == 6)
        //                    FinalWhatsappMsg = "Dear " + CustomerName + ",\nCRN No - " + CustomerDetails.CRN + ". Your LPG connection has been suspended. To reactivate it, please get in touch with us on " + CustomerDetails.OfficeNumbers + "\n\n*Thank you for using Shree Renuka LPG service*";
        //            }
        //        }
        //        if (!string.IsNullOrEmpty(FinalWhatsappMsg) && !string.IsNullOrEmpty(CustomerDetails.MobileNo))
        //        {
        //            result = Task.Run(() => WhatsappMsg(FinalWhatsappMsg, CustomerDetails.MobileNo, EventId));
        //            SaveAPILog(0, 0, "MsgSend", "Mobile No = " + CustomerDetails.MobileNo + ", EventId = " + EventId, BusinessCont.SuccessStatus, null);
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //}

        //public async Task<string> WhatsappMsg(string WhatsappMsg, string MobileNos, int EventId)
        //{
        //    try
        //    {
        //        List<MobNoInfo> Msglist = null;
        //        PickyJSON dtlsModel = null;
        //        MobNoInfo MobmsgInfo = null;
        //        string result = string.Empty;
        //        string token = ConfigurationManager.AppSettings["Token"];

        //        if (MobileNos != null && token != null)
        //        {
        //            string MobileNo = string.Empty;
        //            Msglist = new List<MobNoInfo>();

        //            if (MobileNos.Contains(","))
        //            {
        //                string[] MobNos = MobileNos.Trim().Split(',');
        //                foreach (var MobNo in MobNos)
        //                {
        //                    if (MobNo.Length == 10)
        //                        MobileNo = "91" + MobNo;
        //                    else
        //                        MobileNo = MobNo;
        //                    MobmsgInfo = new MobNoInfo
        //                    {
        //                        number = MobileNo,
        //                        message = WhatsappMsg
        //                    };
        //                    Msglist.Add(MobmsgInfo);
        //                }
        //            }
        //            else
        //            {
        //                if (MobileNos.Length == 10)
        //                    MobileNo = "91" + MobileNos;
        //                else
        //                    MobileNo = MobileNos;
        //                MobmsgInfo = new MobNoInfo
        //                {
        //                    number = MobileNo,
        //                    message = WhatsappMsg
        //                };
        //                Msglist.Add(MobmsgInfo);
        //            }

        //            dtlsModel = new PickyJSON
        //            {
        //                token = token,
        //                priority = "0",
        //                application = "2",
        //                sleep = "0",
        //                globalmessage = "",
        //                globalmedia = "",
        //                data = Msglist
        //            };

        //            var data = JsonConvert.SerializeObject(dtlsModel);
        //            using (var client = new HttpClient())
        //            {
        //                var stringContent = new StringContent(data, System.Text.Encoding.UTF8, "application/json");
        //                var response = await client.PostAsync("https://pickyassist.com/app/api/v1/push", stringContent);
        //                result = await response.Content.ReadAsStringAsync();
        //            }
        //        }
        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        //public SBCWhatsApp UpdateReplayReceivedFlag(SBCWhatsApp model)
        //{
        //    return UpdateReplayReceivedFlagPvt(model);
        //}

        //private SBCWhatsApp UpdateReplayReceivedFlagPvt(SBCWhatsApp model)
        //{

        //    SBCWhatsApp Model = new SBCWhatsApp();
        //    try
        //    {
        //        Model = ContextManager._Context.sp_UpdateReplayReceivedflag(model.MobileNo, model.ConsumerNo.ToString(), 0).Select(a => new SBCWhatsApp
        //        {
        //            SACode = a.SACode,
        //            DistributorIdint = a.DistributorIdint,
        //            DistributorCode = a.DistributorCode,
        //            DistributorName = a.DistributorName,
        //            UniqueConsumerId = a.UniqueConsumerId,
        //            ConsumerNo = a.ConsumerNo,
        //            MobileNo = a.MobileNo,
        //            ConsumerName = a.ConsumerName,
        //            DistributorEmergencyContactNo = a.DistributorEmergencyContactNo,
        //            DistributorMobileNo = a.DistributorMobileNo,
        //            IsReplayReceived = a.IsReplayReceived,
        //            IsReplayReceivedDate = a.IsReplayReceivedDate?.ToString("dd mmm yyyy"),
        //            AutoReplyDate = a.AutoReplyDate?.ToString("dd mmm yyyy"),
        //            AutoReplySent = a.AutoReplySent,
        //            ConnectionReleased = a.ConnectionReleased,
        //            ConnectionReleasedDate = a.ConnectionReleasedDate?.ToString("dd mmm yyyy")
        //        }).FirstOrDefault();
        //        return Model;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}



        //public int checkReplyPresentOrNot(SBCWhatsApp model)
        //{
        //    return checkReplyPresentOrNotPvt(model);
        //}
        //private int checkReplyPresentOrNotPvt(SBCWhatsApp model)
        //{
        //    int a = 0;
        //    try
        //    {
        //        ObjectParameter ObjParamConsId = new ObjectParameter("result", typeof(Int64));
        //        ContextManager._Context.sp_CheckReplyPresentOrNot(model.MobileNo, model.ConsumerNo.ToString(), ObjParamConsId);
        //        if (ObjParamConsId != null)
        //        {
        //            a = Convert.ToUInt16(ObjParamConsId.Value);
        //        }
        //        return a;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}


        //public int UpdateLinkVisited(SBCWhatsApp model)
        //{
        //    return updateLinkVisitedPvt(model);
        //}
        //private int updateLinkVisitedPvt(SBCWhatsApp model)
        //{
        //    int a = 0;
        //    try
        //    {
        //        ObjectParameter ObjParamConsId = new ObjectParameter("result", typeof(Int64));
        //        ContextManager._Context.sp_SBC_UpdateLinkVisitedFlag(model.MobileNo, model.ConsumerNo.ToString(), ObjParamConsId);
        //        if (ObjParamConsId != null)
        //        {
        //            a = Convert.ToUInt16(ObjParamConsId.Value);
        //        }
        //        return a;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
    }
}
