﻿using HPGASNCEnquiryBusiness.BusinessConstant;
using HPGASNCEnquiryBusiness.Models.Distributor;
using HPGASNCEnquiryBusiness.Models.Entity;
using HPGASNCEnquiryBusiness.Models.Login;
using HPGASNCEnquiryBusiness.Models.WhatApp;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using WhatsAppCampaignBusiness.Models.Entity;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class DistributorManager : IDisposable
    {
        ContextManager contextManager = new ContextManager();

        #region Dispose 

        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }

        #endregion

        #region Get SurakshaConsumers Count
        public MessageSentConsumerCount GetSurakshaConsumersCount(int DistributorId)
        {
            return GetSurakshaConsumersCountPvt(DistributorId);
        }
        private MessageSentConsumerCount GetSurakshaConsumersCountPvt(int DistributorId)
        {
            MessageSentConsumerCount messageSentConsumerCount = new MessageSentConsumerCount();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    messageSentConsumerCount = _Context.usp_GetSurakshaConsumersCount(DistributorId).Select(a => new MessageSentConsumerCount
                    {
                        SurkshaCount = Convert.ToInt32(a.SurkshaCount),
                        DuplicateMobCount = a.DuplicateMobCount,
                        Messagesentcount = a.Messagesentcount,
                        Interestedcount = a.Interestedcount,
                        ReadCount = a.ReadCount,
                        ConsumerContactedCount = a.ConsumerContactedCount,
                        NotIntrestedCount = a.NotIntrestedCount,
                        ReadContactedCount = a.ReadContactedCount,
                        CheckMsgSent = a.CheckMsgSent,
                        ConnectionReleasedCount = a.ConnectionReleasedCount,
                        MIDoneCount = a.MIDoneCount,
                        SurakshaHostChangedCount = a.SurakshaHostChangedCount,
                        Both = a.Both
                    }).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "GetSurakshaConsumersCountPvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return messageSentConsumerCount;
        }
        #endregion

        #region Get All Consumers by Distributor for Surksha Campaign
        public List<SBCWhatsApp> GetAllSurakshausersByDistributor(int DistributorId, string FromDate, string ToDate)
        {
            return GetAllSurakshausersByDistributorPvt(DistributorId, FromDate, ToDate);
        }
        private List<SBCWhatsApp> GetAllSurakshausersByDistributorPvt(int DistributorId, string FromDate, string ToDate)
        {
            List<SBCWhatsApp> sBCWhatsApps = new List<SBCWhatsApp>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    sBCWhatsApps = _Context.usp_GetAllSurakshausersByDistributor(DistributorId, FromDate, ToDate).Select(a => new SBCWhatsApp
                    {
                        DistributorIdint = Convert.ToInt32(a.DistributorIdint),
                        DistributorCode = a.DistributorCode,
                        DistributorName = a.DistributorName,
                        DistributorMobileNo = Convert.ToInt64(a.DistributorMobileNo),
                        DistributorEmergencyContactNo = a.DistributorEmergencyContactNo,
                        UniqueConsumerid = a.UniqueConsumerId.ToString(),
                        ConsumerNo = Convert.ToInt32(a.ConsumerNo),
                        ConsumerName = a.ConsumerName,
                        MobileNo = a.MobileNo,
                        MessageStatus = a.MessageStatus,
                        IsMessageSent = a.IsMessageSent,
                        IsReplayReceivedDate = BusinessCont.CheckNullandConvertDateTime(a.IsReplayReceivedDate),
                        MessageSentDate = BusinessCont.CheckNullandConvertDateTime(a.MessageSentDate),
                        StatusName = a.StatusName,
                        AutoReplySent = a.AutoReplySent,
                        ConsumerFeedback = a.ConsumerFeedback,
                        AutoReplyDate = BusinessCont.CheckNullandConvertDateTime(a.AutoReplyDate),
                        ConnectionReleasedDate = BusinessCont.CheckNullandConvertDateTime(a.ConnectionReleasedDate),
                        ConnectionReleased = a.ConnectionReleased,
                        IsReplayReceived = a.IsReplayReceived,
                        UserReply = a.UserReply,
                        LinkVisited = Convert.ToInt32(a.LinkVisited),
                        NotIntrested = a.NotIntrested,
                        MIDone = a.MIDone,
                        HoseChanged = a.HoseChanged,
                        MI_Suraksha = a.MI_Suraksha
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "GetAllSurakshausersByDistributorPvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return sBCWhatsApps;
        }
        #endregion

        #region Get InterestedCnt Details For Surksha
        public List<InterestedCountsModel> GetInterestedCntDetailsForSurksha(int DistributorId)
        {
            return GetInterestedCntDetailsForSurkshaPvt(DistributorId);
        }
        private List<InterestedCountsModel> GetInterestedCntDetailsForSurkshaPvt(int DistributorId)
        {
            List<InterestedCountsModel> interestedctn = null;
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    interestedctn = new List<InterestedCountsModel>();
                    interestedctn = _Context.usp_GetInterestedCntForSurksha(DistributorId).Select(a => new InterestedCountsModel
                    {
                        StatusName = a.StatusName,
                        ReadCnt = a.ReadCnt ?? 0,
                        InterestedCnt = a.InterestedCnt ?? 0
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetInterestedCntDetailsForSurkshaPvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return interestedctn;
        }
        #endregion

        #region Update Connection Flag
        public long UpdateConnectionFlagForSuraksha(int DistributorId, int ConsumerNo, string StatusName, string ConsumerFeedback, string ConnectionReleased)
        {
            return UpdateConnectionFlagForSurakshaPvt(DistributorId, ConsumerNo, StatusName, ConsumerFeedback, ConnectionReleased);
        }
        private long UpdateConnectionFlagForSurakshaPvt(int DistributorId, int ConsumerNo, string StatusName, string ConsumerFeedback, string ConnectionReleased)
        {
            long ConsId = 0;
            try
            {
                ObjectParameter ObjParamConsId = new ObjectParameter("result", typeof(Int64));
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    ConsId = context.usp_UpdateConReleasedStatusForSuraksha(DistributorId, ConsumerNo, StatusName, ConsumerFeedback, ConnectionReleased, ObjParamConsId);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "UpdateConnectionFlagForSurakshaPvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return ConsId;
        }

        #endregion

        #region Get All SA by RO code
        public List<SAModel> GetAllSAbyROcode(string Id)
        {
            return GetAllSAbyROcodepvt(Id);
        }
        private List<SAModel> GetAllSAbyROcodepvt(string Id)
        {
            List<SAModel> SAList = new List<SAModel>();
            try
            {
                SAList = ContextManager._Context.sp_GetAllSAByROcode(Id).Select(a => new SAModel
                {
                    SACode = a.SACode,
                    SAName = a.SAName,
                    ROCode = a.ROCode,
                    ZOCode = a.ZOCode
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, Convert.ToInt32(Id), "GetARBItemSoldCountPvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return SAList;
        }
        #endregion

        #region Get All DBC Users By Distributor
        public List<SBCWhatsApp> GetAllDBCusersByDistributor(int DistributorId, string FromDate, string ToDate)
        {
            return GetAllDBCusersByDistributorPvt(DistributorId, FromDate, ToDate);
        }
        private List<SBCWhatsApp> GetAllDBCusersByDistributorPvt(int DistributorId, string FromDate, string ToDate)
        {
            List<SBCWhatsApp> sBCWhatsApps = new List<SBCWhatsApp>();
            try
            {
                sBCWhatsApps = ContextManager._Context.usp_GetAllConsumersbyDistributor(DistributorId, FromDate, ToDate).Select(a => new SBCWhatsApp
                {
                    pkId = Convert.ToInt32(a.pkId),
                    DistributorIdint = Convert.ToInt32(a.DistributorIdint),
                    DistributorCode = a.DistributorCode,
                    DistributorName = a.DistributorName,
                    DistributorMobileNo = Convert.ToInt64(a.DistributorMobileNo),
                    DistributorEmergencyContactNo = a.DistributorEmergencyContactNo,
                    UniqueConsumerId = Convert.ToInt64(a.UniqueConsumerId),
                    ConsumerNo = Convert.ToInt32(a.ConsumerNo),
                    ConsumerName = a.ConsumerName,
                    MobileNo = a.MobileNo,
                    MessageStatus = a.MessageStatus,
                    IsMessageSent = a.IsMessageSent,
                    IsReplayReceivedDate = BusinessCont.CheckNullandConvertDateTime(a.IsReplayReceivedDate),
                    MessageSentDate = BusinessCont.CheckNullandConvertDateTime(a.MessageSentDate),
                    StatusName = a.StatusName,
                    AutoReplySent = a.AutoReplySent,
                    ConsumerFeedback = a.ConsumerFeedback,
                    AutoReplyDate = BusinessCont.CheckNullandConvertDateTime(a.AutoReplyDate),
                    ConnectionReleasedDate = BusinessCont.CheckNullandConvertDateTime(a.ConnectionReleasedDate),
                    ConnectionReleased = a.ConnectionReleased,
                    IsReplayReceived = a.IsReplayReceived,
                    UserReply = a.UserReply,
                    LinkVisited = Convert.ToInt32(a.LinkVisited),
                    NotIntrested = a.NotIntrested
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "GetAllDBCusersByDistributorPvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return sBCWhatsApps;
        }
        #endregion

        #region Update status 
        public int UpdateStatus(SBCWhatsApp model)
        {
            return UpdateStatusPvt(model);
        }
        private int UpdateStatusPvt(SBCWhatsApp model)
        {
            int ConsId = 0;
            try
            {
                ObjectParameter ObjParamConsId = new ObjectParameter("result", typeof(long));
                ConsId = ContextManager._Context.sp_UpdateConnectionReleasedStatus(model.DistributorIdint, model.ConsumerNo, model.StatusName, model.ConsumerFeedback, model.ConnectionReleased, ObjParamConsId);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, model.DistributorIdint, "UpdateStatusPvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return ConsId;
        }
        #endregion

        #region Get Dbc Consumers Count
        public MessageSentConsumerCount GetDbcConsumersCount(int DistributorId)
        {
            return GetDbcConsumersCountPvt(DistributorId);
        }
        private MessageSentConsumerCount GetDbcConsumersCountPvt(int DistributorId)
        {
            MessageSentConsumerCount messageSentConsumerCount = new MessageSentConsumerCount();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    messageSentConsumerCount = _Context.usp_GetDbcConsumersCount(DistributorId).Select(a => new MessageSentConsumerCount
                    {
                        SBCCount = a.SBCCount,
                        DuplicateMobCount = a.DuplicateMobCount,
                        Messagesentcount = a.Messagesentcount,
                        Interestedcount = a.Interestedcount,
                        ReadCount = a.ReadCount,
                        ConsumerContactedCount = a.ConsumerContactedCount,
                        NotIntrestedCount = a.NotIntrestedCount,
                        ReadContactedCount = a.ReadContactedCount,
                        CheckMsgSent = a.CheckMsgSent,
                        ConnectionReleasedCount = a.ConnectionReleasedCount
                    }).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "GetDbcConsumersCountPvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return messageSentConsumerCount;
        }
        #endregion

        #region Get Admin Dbc Information
        public List<AdminDBC> GetAdminDbcInformation(string Id, string flag)
        {
            return GetAdminDbcInformationpvt(Id, flag);
        }
        private List<AdminDBC> GetAdminDbcInformationpvt(string Id, string flag)
        {
            List<AdminDBC> admins = null;
            try
            {
                admins = new List<AdminDBC>();
                admins = ContextManager._Context.usp_SBCMessageSendSummaryData(Id, "0", flag).Select(a => new AdminDBC
                {
                    SACode = a.SACode,
                    SAName = a.SAName,
                    DistributorId = a.DistributorIdint,
                    JDEDistributorCode = a.JDEDistributorCode,
                    DistributorName = a.DistributorName,
                    TotalConsumer = a.TotalConsumer,
                    ConsumerProcessed = a.ConsumerProcessed,
                    ConsumerBalance = a.ConsumerBalance,
                    MessageSend = a.MessageSend,
                    Interested = a.Interested,
                    InterestedPercent = a.InterestedPercent,
                    NotInterestedCount = a.NotInterestedCount,
                    ConnectionReleased = a.ConnectionReleased,
                    MessageRead = a.MessageRead,
                    Contacted = a.Contacted,
                    PendingForContact = a.PendingForContact
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetAdminDbcInformationpvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return admins;
        }
        #endregion

        #region Get Interested Cnt Details
        public List<InterestedCountsModel> GetInterestedCntDetails(int DistributorId)
        {
            return GetInterestedCntDetailspvt(DistributorId);
        }
        private List<InterestedCountsModel> GetInterestedCntDetailspvt(int DistributorId)
        {
            List<InterestedCountsModel> interestedctn = null;
            try
            {
                interestedctn = new List<InterestedCountsModel>();
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    interestedctn = _Context.usp_GetStatuswiseReadInterestedCounts(DistributorId).Select(a => new InterestedCountsModel
                    {
                        StatusName = a.StatusName,
                        ReadCnt = a.ReadCnt ?? 0,
                        InterestedCnt = a.InterestedCnt ?? 0
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetInterestedCntDetailspvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return interestedctn;
        }
        #endregion

        #region Get All ARB Users By Distributor
        public List<SBCWhatsApp> GetAllARBUsersByDistributor(int DistributorId, string FromDate, string ToDate)
        {
            return GetAllARBUsersByDistributorPvt(DistributorId, FromDate, ToDate);
        }

        private List<SBCWhatsApp> GetAllARBUsersByDistributorPvt(int DistributorId, string FromDate, string ToDate)
        {
            List<SBCWhatsApp> sBCWhatsApps = new List<SBCWhatsApp>();
            try
            {
                using (HPGASNCEnquiryEntities _contextManager = new HPGASNCEnquiryEntities())
                {
                    sBCWhatsApps = _contextManager.usp_GetAllARBusersByDistributor(DistributorId, FromDate, ToDate).Select(a => new SBCWhatsApp
                    {
                        pkId = Convert.ToInt32(a.pkId),
                        DistributorIdint = Convert.ToInt32(a.DistributorIdint),
                        DistributorCode = a.DistributorCode,
                        DistributorName = a.DistributorName,
                        DistributorMobileNo = Convert.ToInt64(a.DistributorMobileNo),
                        DistributorEmergencyContactNo = a.DistributorEmergencyContactNo,
                        UniqueConsumerid = a.UniqueConsumerId.ToString(),
                        ConsumerNo = Convert.ToInt32(a.ConsumerNo),
                        ConsumerName = a.ConsumerName,
                        MobileNo = a.MobileNo,
                        MessageStatus = a.MessageStatus,
                        IsMessageSent = a.IsMessageSent,
                        IsReplayReceivedDate = BusinessCont.CheckNullandConvertDateTime(a.IsReplayReceivedDate),
                        MessageSentDate = BusinessCont.CheckNullandConvertDateTime(a.MessageSentDate),
                        StatusName = a.StatusName,
                        AutoReplySent = a.AutoReplySent,
                        ConsumerFeedback = a.ConsumerFeedback,
                        AutoReplyDate = BusinessCont.CheckNullandConvertDateTime(a.AutoReplyDate),
                        ConnectionReleasedDate = BusinessCont.CheckNullandConvertDateTime(a.ConnectionReleasedDate),
                        ConnectionReleased = a.ConnectionReleased,
                        IsReplayReceived = a.IsReplayReceived,
                        UserReply = a.UserReply,
                        //LinkVisited = a.LinkVisited,
                        NotIntrested = a.NotIntrested,
                        ARBDone = a.ARBDone,
                        //HoseChanged = a.HoseChanged,
                        //MI_Suraksha = a.MI_Suraksha,
                    }).ToList();
                }

            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "GetAllARBUsersByDistributorPvt", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            return sBCWhatsApps;
        }
        #endregion

        #region Get ARB Consumers Count
        public MessageSentConsumerCount GetARBConsumersCount(int DistributorId)
        {
            return GetARBConsumersCountPvt(DistributorId);
        }

        private MessageSentConsumerCount GetARBConsumersCountPvt(int DistributorId)
        {
            MessageSentConsumerCount messageSentConsumerCount = new MessageSentConsumerCount();
            try
            {
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    messageSentConsumerCount = context.usp_GetARBConsumersCount(DistributorId).Select(a => new MessageSentConsumerCount
                    {
                        ARBCount = Convert.ToInt32(a.ARBCount),
                        DuplicateMobCount = a.DuplicateMobCount,
                        Messagesentcount = a.Messagesentcount,
                        Interestedcount = a.Interestedcount,
                        ReadCount = a.ReadCount,
                        ConsumerContactedCount = a.ConsumerContactedCount,
                        NotIntrestedCount = a.NotIntrestedCount,
                        ReadContactedCount = a.ReadContactedCount,
                        CheckMsgSent = a.CheckMsgSent,
                        ConnectionReleasedCount = a.ConnectionReleasedCount,
                        ARBDoneCount = Convert.ToInt32(a.ARBDoneCount),
                        //MIDoneCount = a.MIDoneCount,s
                        //SurakshaHostChangedCount = a.SurakshaHostChangedCount,
                        //Both = a.Both,
                    }).FirstOrDefault();
                }
                return messageSentConsumerCount;
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "GetARBConsumersCountPvt", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
        }
        #endregion

        #region Get Interested Cnt Details For ARB
        public List<InterestedCountsModel> GetInterestedCntDetailsForARB(int DistributorId)
        {
            return GetInterestedCntDetailsForARBPvt(DistributorId);
        }
        private List<InterestedCountsModel> GetInterestedCntDetailsForARBPvt(int DistributorId)
        {
            List<InterestedCountsModel> interestedctn = null;
            try
            {
                interestedctn = new List<InterestedCountsModel>();
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    interestedctn = ContextManager._Context.usp_GetInterestedCntDetailsForARB(DistributorId).Select(a => new InterestedCountsModel
                    {
                        StatusName = a.StatusName,
                        ReadCnt = a.ReadCnt ?? 0,
                        InterestedCnt = a.InterestedCnt ?? 0
                    }).ToList();
                }
                return interestedctn;
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetInterestedCntDetailsForARBPvt", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
        }
        #endregion

        #region Get ARB Item Sold Count
        public List<ARBItemSoldCountsModel> GetARBItemSoldCount(string JDEDistributorCode)
        {
            return GetARBItemSoldCountPvt(JDEDistributorCode);
        }
        private List<ARBItemSoldCountsModel> GetARBItemSoldCountPvt(string JDEDistributorCode)
        {
            List<ARBItemSoldCountsModel> soldQtycnt = new List<ARBItemSoldCountsModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    soldQtycnt = _Context.usp_ARBUserItemSoldCounts(JDEDistributorCode).Select(a => new ARBItemSoldCountsModel
                    {
                        itemId = a.itemId,
                        ItemName = a.ItemName,
                        ItemSoldCnt = Convert.ToDecimal(a.ItemSoldCnt)
                    }).ToList();
                }
                return soldQtycnt;
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetARBItemSoldCountPvt", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
        }
        #endregion

        #region Update Status Flag For ARB
        public int UpdateConnectionFlagForARB(int DistributorId, string DistributorCode, int ConsumerNo, string UniqueConsumerId, string ItemIdstr, string StatusName, string ConsumerFeedback, string ConnectionReleased)
        {
            return UpdateConnectionFlagForARBPvt(DistributorId, DistributorCode, ConsumerNo, UniqueConsumerId, ItemIdstr, StatusName, ConsumerFeedback, ConnectionReleased);
        }
        private int UpdateConnectionFlagForARBPvt(int DistributorId, string DistributorCode, int ConsumerNo, string UniqueConsumerId, string ItemIdstr, string StatusName, string ConsumerFeedback, string ConnectionReleased)
        {
            int res = 0;
            try
            {
                ObjectParameter ObjParamConsId = new ObjectParameter("result", typeof(Int64));
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    res = context.usp_UpdateConReleasedStatusForARB(DistributorId, DistributorCode, ConsumerNo, UniqueConsumerId, ItemIdstr, StatusName, ConsumerFeedback, ConnectionReleased, ObjParamConsId);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "UpdateConnectionFlagForARBPvt", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            return res;
        }
        #endregion

        #region Get ARB Item List
        public List<ARBItemModel> GetARBItemList(int Flag)
        {
            return GetARBItemListpvt(Flag);
        }

        private List<ARBItemModel> GetARBItemListpvt(int Flag)
        {
            List<ARBItemModel> ARBList = new List<ARBItemModel>();
            try
            {
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    ARBList = context.usp_ARBItemMasterList(Flag).Select(a => new ARBItemModel
                    {
                        itemId = a.itemId,
                        ItemName = a.ItemName,
                        ItemPrice = Convert.ToInt32(a.ItemPrice),
                        IsActive = Convert.ToInt16(a.IsActive)
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, Flag, "GetARBItemList", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            return ARBList;
        }
        #endregion
    }
}
