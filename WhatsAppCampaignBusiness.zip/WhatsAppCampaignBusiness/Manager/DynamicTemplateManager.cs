﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using HPGASNCEnquiryBusiness.BusinessConstant;
using WhatsAppCampaignBusiness.Models.DynamicTemplate;
using WhatsAppCampaignBusiness.Models.Entity;
using System.Data;
using System.Data.SqlClient;
namespace WhatsAppCampaignBusiness.Manager
{
    public class DynamicTemplateManager : IDisposable
    {
        #region Dispose 
        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }
        #endregion

        #region Add Dynamic Template Values
        public int AddDynamicTemplateValue(DynamicTemplateModel model)
        {
            return AddDynamicTemplateValuePvt(model);
        }
        private int AddDynamicTemplateValuePvt(DynamicTemplateModel model)
        {
            int RetValue = 0;
            List<TemplateModel> modelList = new List<TemplateModel>();
            try
            {
                if (model != null)
                {
                    for (int i = 0; i < model.TemplateData.Count; i++)
                    {
                        TemplateModel modelAppend = new TemplateModel();
                        modelAppend.Value = model.TemplateData[i].Value;
                        modelAppend.FieldType = model.TemplateData[i].FieldType;
                        modelAppend.IsBold = model.TemplateData[i].IsBold;
                        modelList.Add(modelAppend);
                    }

                    DataTable dt = new DataTable();
                    dt.Columns.Add("Value");
                    dt.Columns.Add("FieldType");
                    dt.Columns.Add("IsBold");
                    foreach (var item in modelList)
                    {
                        dt.Rows.Add(item.Value, item.FieldType, item.IsBold);
                    }

                    using (var db = new HPGASNCEnquiryEntities())
                    {
                        {
                            SqlConnection connection = (SqlConnection)db.Database.Connection;
                            SqlCommand cmd = new SqlCommand("WC.usp_AddTemplateDataDynamic", connection);
                            cmd.CommandType = CommandType.StoredProcedure;
                            SqlParameter CampaignIdParameter = cmd.Parameters.AddWithValue("@CampaignId", model.CampaignId);
                            CampaignIdParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter CampaignNameParameter = cmd.Parameters.AddWithValue("@CampaignName", model.CampaignName);
                            CampaignNameParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter TemplateIdParameter = cmd.Parameters.AddWithValue("@TemplateId ", model.TemplateId);
                            TemplateIdParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter TemplateNameParameter = cmd.Parameters.AddWithValue("@TemplateName ", model.TemplateName);
                            TemplateNameParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter TemplateForParameter = cmd.Parameters.AddWithValue("@TemplateFor ", model.TemplateFor);
                            TemplateForParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter TemplateTypeParameter = cmd.Parameters.AddWithValue("@TemplateType ", model.TemplateType);
                            TemplateTypeParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter IsActiveParameter = cmd.Parameters.AddWithValue("@IsActive ", model.IsActive);
                            IsActiveParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter MediaTypeParameter = cmd.Parameters.AddWithValue("@MediaType ", model.MediaType);
                            MediaTypeParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter FileNameParameter = cmd.Parameters.AddWithValue("@FileName ", model.FileName);
                            FileNameParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter DCampRightsParameter = cmd.Parameters.AddWithValue("@TemplateData", dt);
                            DCampRightsParameter.SqlDbType = SqlDbType.Structured;
                            SqlParameter retvalueParameter = cmd.Parameters.AddWithValue("@RetValue", 0);
                            retvalueParameter.Direction = ParameterDirection.Output;
                            if (connection.State == ConnectionState.Closed)
                                connection.Open();
                            RetValue = cmd.ExecuteNonQuery();
                            if (connection.State == ConnectionState.Open)
                                connection.Close();
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Add Dynamic Template Value", "AddDynamicTemplateValue", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            return RetValue;
        }
        #endregion

        #region Get list for Dynamic Template Values
        public List<DynamicTemplateModel> GetDynamicTemplateValuesList()
        {
            return GetDynamicTemplateValuesListPvt();
        }
        private List<DynamicTemplateModel> GetDynamicTemplateValuesListPvt()
        {
            List<DynamicTemplateModel> TmpList = new List<DynamicTemplateModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    //TmpList = _Context.usp_GetTemplateDataDynamic().Select(a => new DynamicTemplateModel
                    //{
                    //    Pkid = a.Pkid,
                    //    TemplateId = a.TemplateId,
                    //    Keystr = a.Keys,
                    //    Valuestr = a.Value,
                    //    TemplateName = a.TemplateName,
                    //    IsActive = a.IsActive
                    //}).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetDynamicTemplateValuesListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return TmpList;
        }

        #endregion

        #region Get Temaplate Value List By Id
        public List<TemplateModel> GetTemaplateValueListById(string TemplateId)
        {
            return GetTemaplateValueListByIdPvt(TemplateId);
        }
        private List<TemplateModel> GetTemaplateValueListByIdPvt(string TemplateId)
        {
            List<TemplateModel> TmpList = new List<TemplateModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    TmpList = _Context.usp_GetTemaplateValuesListById(TemplateId).Select(a => new TemplateModel
                    {
                        pkId = a.pkId,
                        TemplateId = a.TemplateId,
                        Value = a.Value,
                        FieldType = a.FieldType,
                        IsBold = a.IsBold,
                        IsActive = a.IsActive
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetTemaplateValueListByIdPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return TmpList;
        }
        #endregion

        #region Get Temaplate Master Value List By Id
        public TemplateMasterModel GetTemaplateMasterValueListById(string TemplateId)
        {
            return GetTemaplateMasterValueListByIdPvt(TemplateId);
        }
        private TemplateMasterModel GetTemaplateMasterValueListByIdPvt(string TemplateId)
        {
            TemplateMasterModel MasterList = new TemplateMasterModel();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    MasterList = _Context.usp_GetTemaplateMasterListById(TemplateId).Select(a => new TemplateMasterModel
                    {
                        pkId = a.pkId,
                        CampaignId = a.CampaignId,
                        CampaignName = a.CampaignName,
                        TemplateId = a.TemplateId,
                        TemplateName = a.TemplateName,
                        TemplateFor = a.TemplateFor,
                        TemplateType = a.TemplateType,
                        IsActive = a.IsActive,
                        MediaType = a.MediaType,
                        FileName = a.FileName
                    }).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetTemaplateMasterValueListByIdPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return MasterList;
        }
        #endregion

        #region Add Send Template Message
        public int AddSendTemplateMessage(AddSendTemplateMessageModel model)
        {
            return AddSendTemplateMessagePvt(model);
        }
        private int AddSendTemplateMessagePvt(AddSendTemplateMessageModel model)
        {
            int RetValue = 0;
            ObjectParameter obj = new ObjectParameter("RetValue", typeof(long));
            try
            {
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                     RetValue = context.usp_AddSendSampleWhatsAppMessage(model.pkId, model.DistributorId, model.ConsumerNo, model.ConsumerName,
                        model.MobileNo, model.TemplateId, model.CurrentStatus, model.Action, obj);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "AddSendTemplateMessagePvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return RetValue;
        }
        #endregion

        #region Get Send Sample Message List
        public List<AddSendTemplateMessageModel> GetSendSampleMessageList()
        {
            return GetSendSampleMessageListPvt();
        }
        private List<AddSendTemplateMessageModel> GetSendSampleMessageListPvt()
        {
            List<AddSendTemplateMessageModel> modelList = new List<AddSendTemplateMessageModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    modelList = _Context.usp_GetSendSampleWhatsAppMessageList().Select(a => new AddSendTemplateMessageModel
                    {
                        pkId = Convert.ToInt32(a.pkId),
                        SACode = Convert.ToString(a.SACode),
                        ConsumerNo = Convert.ToInt32(a.ConsumerNo),
                        MobileNo = Convert.ToString(a.MobileNo),
                        ConsumerName = Convert.ToString(a.ConsumerName),
                        TemplateId = Convert.ToString(a.TemplateId),
                        DistributorName = Convert.ToString(a.DistributorName),
                        TemplateName = Convert.ToString(a.TemplateName),
                        DistributorId = Convert.ToInt32(a.DistributorId),
                        CurrentStatus = Convert.ToString(a.CurrentStatus)
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetSendSampleMessageListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return modelList;
        }
        #endregion

        #region Send Sample Message
        public int SendSampleMessage(AddSendTemplateMessageModel model)
        {
            return SendSampleMessagePvt(model);
        }
        private int SendSampleMessagePvt(AddSendTemplateMessageModel model)
        {
            int RetValue = 0;
            ObjectParameter obj = new ObjectParameter("RetValue", typeof(long));
            try
            {
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    RetValue = context.usp_AddSendSampleWhatsAppMessage(model.pkId, 0, 0, "", "", "", "In-Progress", "EDIT", obj);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "SendSampleMessagePvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return RetValue;
        }
        #endregion

        #region Sample WhatsApp Message Sent
        public List<SampleWhatsAppMessageSentModel> SampleWhatsAppMessageSent(int pkId, string Did, string MobNo)
        {
            return SampleWhatsAppMessageSentPvt(pkId, Did, MobNo);
        }
        private List<SampleWhatsAppMessageSentModel> SampleWhatsAppMessageSentPvt(int pkId, string Did, string MobNo)
        {
            List<SampleWhatsAppMessageSentModel> modelList = new List<SampleWhatsAppMessageSentModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    modelList = _Context.usp_SampleWhatsAppMessageSent(pkId, Did, MobNo).Select(s => new SampleWhatsAppMessageSentModel
                    {
                        pkId = Convert.ToInt32(s.pkId),
                        SACode = Convert.ToString(s.SACode),
                        DistributorId = Convert.ToInt32(s.DistributorId),
                        DistributorName = Convert.ToString(s.DistributorName),
                        DistributorMobileNo = Convert.ToString(s.DistributorMobileNo),
                        PhoneNo = Convert.ToString(s.PhoneNo),
                        DistributorEmergencyContactNo = Convert.ToString(s.DistributorEmergencyContactNo),
                        ConsumerNo = Convert.ToInt32(s.ConsumerNo),
                        MobileNo = Convert.ToString(s.MobileNo),
                        TemplateId = Convert.ToString(s.TemplateId),
                        ConsumerName = Convert.ToString(s.ConsumerName),
                        RSPAmount = Convert.ToString(s.RSPAmount),
                        DistrAddress = Convert.ToString(s.DistrAddress)
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " SampleWhatsAppMessageSentPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return modelList;
        }
        #endregion

        #region Update Send Sample Message
        public int UpdateSendSampleMessage(int pkId, int DistributorId, string CurrentStatus, string MobileNo)
        {
            return UpdateSendSampleMessagePvt(pkId, DistributorId, CurrentStatus, MobileNo);
        }
        private int UpdateSendSampleMessagePvt(int pkId, int DistributorId, string CurrentStatus, string MobileNo)
        {
            int RetValue = 0;
            ObjectParameter obj = new ObjectParameter("RetValue", typeof(string));
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    RetValue = _Context.usp_UpdateSendSampleMessage(pkId, DistributorId, CurrentStatus, MobileNo, obj);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, " UpdateSendSampleMessagePvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return RetValue;
        }
        #endregion

        #region Get All Template List
        public List<DynamicTemplateModel> GetAllTemplateList()
        {
            return GetAllTemplateListPvt();
        }
        private List<DynamicTemplateModel> GetAllTemplateListPvt()
        {
            List<DynamicTemplateModel> TmpList = new List<DynamicTemplateModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    TmpList = _Context.usp_GetAllTemplateList().Select(a => new DynamicTemplateModel
                    {
                        pkId = a.pkId,
                        CampaignId = a.CampaignId,
                        CampaignName = a.CampaignName,
                        TemplateId = a.TemplateId,
                        TemplateName = a.TemplateName,
                        TemplateFor = a.TemplateFor,
                        TemplateType = a.TemplateType,
                        IsActive = a.IsActive,
                        MediaType = a.MediaType,
                        FileName = a.FileName,                       
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetAllTemplateListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return TmpList;
        }
        #endregion

        #region Get All Template List
        public List<TemplateModel> GetAllTemplateValuesList(string TemplpateId)
        {
            return GetAllTemplateValuesListPvt(TemplpateId);
        }
        private List<TemplateModel> GetAllTemplateValuesListPvt(string TemplpateId)
        {
            List<TemplateModel> TmpList = new List<TemplateModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    TmpList = _Context.usp_GetAllTemplateValuesList(TemplpateId).Select(a => new TemplateModel
                    {
                        pkId = a.pkId,                      
                        Value = a.Value,
                        IsBold = a.IsBold,
                        FieldType = a.FieldType,
                        AddedOn = Convert.ToDateTime(a.AddedOn),
                        IsActive = a.IsActive,
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetAllTemplateListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return TmpList;
        }
        #endregion

        #region Get Template
        public DynamicTemplateModel GetTemplate(int Id)
        {
            return GetTemplatePvt(Id);
        }
        private DynamicTemplateModel GetTemplatePvt(int pkId)
        {
            DynamicTemplateModel Tmpmodel = new DynamicTemplateModel();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    Tmpmodel = _Context.usp_GetTemplate(pkId).Select(a => new DynamicTemplateModel
                    {
                        pkId = a.pkId,
                        CampaignId = a.CampaignId,
                        CampaignName = a.CampaignName,
                        TemplateId = a.TemplateId,
                        TemplateName = a.TemplateName,
                        TemplateFor = a.TemplateFor,
                        TemplateType = a.TemplateType,
                        IsActive = a.IsActive,
                        MediaType = a.MediaType,
                        FileName = a.FileName,
                    }).FirstOrDefault();

                    Tmpmodel.TemplateData = _Context.usp_GetAllTemplateValuesList(Tmpmodel.TemplateId).Select(a => new TemplateModel
                    {
                        pkId = a.pkId,
                        Value = a.Value,
                        IsBold = a.IsBold,
                        FieldType = a.FieldType,
                        AddedOn = Convert.ToDateTime(a.AddedOn),
                        IsActive = a.IsActive,
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetAllTemplateListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return Tmpmodel;
        }
        #endregion

        #region Edit Template Values
        public int EditTemplateValue(DynamicTemplateModel model)
        {
            return EditTemplateValuePvt(model);
        }
        private int EditTemplateValuePvt(DynamicTemplateModel model)
        {
            int RetValue = 0;
            List<TemplateModel> modelList = new List<TemplateModel>();
            try
            {
                if (model != null)
                {
                    for (int i = 0; i < model.TemplateData.Count; i++)
                    {
                        TemplateModel modelAppend = new TemplateModel();
                        modelAppend.Value = model.TemplateData[i].Value;
                        modelAppend.FieldType = model.TemplateData[i].FieldType;
                        modelAppend.IsBold = model.TemplateData[i].IsBold;
                        modelList.Add(modelAppend);
                    }

                    DataTable dt = new DataTable();
                    dt.Columns.Add("Value");
                    dt.Columns.Add("FieldType");
                    dt.Columns.Add("IsBold");
                    foreach (var item in modelList)
                    {
                        dt.Rows.Add(item.Value, item.FieldType, item.IsBold);
                    }

                    using (var db = new HPGASNCEnquiryEntities())
                    {
                        {
                            SqlConnection connection = (SqlConnection)db.Database.Connection;
                            SqlCommand cmd = new SqlCommand("WC.usp_EditTemplateData", connection);
                            cmd.CommandType = CommandType.StoredProcedure;
                            SqlParameter CampaignIdParameter = cmd.Parameters.AddWithValue("@CampaignId", model.CampaignId);
                            CampaignIdParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter CampaignNameParameter = cmd.Parameters.AddWithValue("@CampaignName", model.CampaignName);
                            CampaignNameParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter TemplateIdParameter = cmd.Parameters.AddWithValue("@TemplateId ", model.TemplateId);
                            TemplateIdParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter TemplateNameParameter = cmd.Parameters.AddWithValue("@TemplateName ", model.TemplateName);
                            TemplateNameParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter TemplateForParameter = cmd.Parameters.AddWithValue("@TemplateFor ", model.TemplateFor);
                            TemplateForParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter TemplateTypeParameter = cmd.Parameters.AddWithValue("@TemplateType ", model.TemplateType);
                            TemplateTypeParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter IsActiveParameter = cmd.Parameters.AddWithValue("@IsActive ", model.IsActive);
                            IsActiveParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter MediaTypeParameter = cmd.Parameters.AddWithValue("@MediaType ", model.MediaType);
                            MediaTypeParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter FileNameParameter = cmd.Parameters.AddWithValue("@FileName ", model.FileName);
                            FileNameParameter.SqlDbType = SqlDbType.NVarChar;
                            SqlParameter DCampRightsParameter = cmd.Parameters.AddWithValue("@TemplateData", dt);
                            DCampRightsParameter.SqlDbType = SqlDbType.Structured;
                            SqlParameter retvalueParameter = cmd.Parameters.AddWithValue("@RetValue", 0);
                            retvalueParameter.Direction = ParameterDirection.Output;
                            if (connection.State == ConnectionState.Closed)
                                connection.Open();
                            RetValue = cmd.ExecuteNonQuery();
                            if (connection.State == ConnectionState.Open)
                                connection.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Add Dynamic Template Value", "AddDynamicTemplateValue", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            return RetValue;
        }
        #endregion

    }
}
