using ClosedXML.Excel;
using HPGASNCEnquiryBusiness.BusinessConstant;
using HPGASNCEnquiryBusiness.Models.EmailScheduler;
using HPGASNCEnquiryBusiness.Models.Entity;
using HPGASNCEnquiryBusiness.Models.RO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Web.Hosting;
using WhatsAppCampaignBusiness.Models.Entity;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class EmailSchedulerManager : IDisposable
    {
#pragma warning disable CS0414 // The field 'EmailSchedulerManager.LogId' is assigned but its value is never used
        decimal LogId = 0;
#pragma warning restore CS0414 // The field 'EmailSchedulerManager.LogId' is assigned but its value is never used
        ContextManager contextManager = new ContextManager();
        bool SendMail;

        #region Dispose 

        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }

        #endregion

        //#region Get Distwise Enquiry for Rpt
        ///// <summary>
        /////  Get Distwise Enquiry for Rpt
        ///// </summary>
        ///// <param name="Id"></param>
        ///// <param name="type"></param>
        ///// <returns></returns>
        //public List<EmailSchedulerModel> GetDistwiseEnquiryDtls(string Id,string type)
        //{
        //    return GetDistwiseEnquiryDtlsPR(Id, type);
        //}

        ///// <summary>
        /////  Get Distwise Enquiry for Rpt
        ///// </summary>
        ///// <param name="Id"></param>
        ///// <param name="type"></param>
        ///// <returns></returns>
        //private List<EmailSchedulerModel> GetDistwiseEnquiryDtlsPR(string Id, string type)
        //{
        //    List<EmailSchedulerModel> model = new List<EmailSchedulerModel>(); 

        //    try
        //    {
        //        int srno = 1;
        //        LogId = BusinessCont.SaveLog(0, 0, "Get Distwise Enquiry for Rpt", "Id- " + Id+ ",type- "+ type, null, null);
        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            model = ContextManager._Context.rpt_GetDistwiseEnquiryRpt(Id, type).Select(x=> new EmailSchedulerModel() {
        //                srno= srno++,
        //                Id = x.Id,
        //                UserName = x.UserName,
        //                SourceType = x.SourceType,
        //                JDEDistributorCode=x.JDEDistributorCode,
        //                YesterdayEnquiry = x.YesterdayEnquiry,
        //                ThisMonthEnquiry = x.ThisMonthEnquiry,
        //                TotalEnquiry = x.TotalEnquiry,
        //                YesterdayPurchase = x.YesterdayPurchase,
        //                ThisMonthPurchase = x.ThisMonthPurchase,
        //                TotalPurchase = x.TotalPurchase,
        //                ROCode=x.ROCode,
        //                ROName=x.ROName,
        //                SACode=x.SACode,
        //                SAName=x.SAName,
        //                ZOCode=x.ZOCode,
        //                ZOName=x.ZOName
        //            }).ToList();
        //            BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.SuccessStatus, null);
        //        }

        //    }
        //    catch(Exception ex)
        //    {
        //        BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        throw ex;
        //    }
        //    return model;
        //}

        //#endregion
        //public List<EmailSchedulerModel> GetDBCDistwiseEnquiryDtls(string Id, string type)
        //{
        //    return GetDBCDistwiseEnquiryDtlsPR(Id, type);
        //}

        ///// <summary>
        /////  Get Distwise Enquiry for Rpt
        ///// </summary>
        ///// <param name="Id"></param>
        ///// <param name="type"></param>
        ///// <returns></returns>
        //private List<EmailSchedulerModel> GetDBCDistwiseEnquiryDtlsPR(string Id, string type)
        //{
        //    List<EmailSchedulerModel> model = new List<EmailSchedulerModel>();

        //    try
        //    {
        //        int srno = 1;
        //        LogId = BusinessCont.SaveLog(0, 0, "Get Distwise Enquiry for Rpt", "Id- " + Id + ",type- " + type, null, null);
        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            model = ContextManager._Context.rpt_GetDBCConsumerInformationForEmail(Id, type).Select(x => new EmailSchedulerModel()
        //            {
        //                srno = srno++,
        //                Id = x.Id,
        //                UserName = x.UserName,
        //                //SourceType = x.SourceType,
        //                JDEDistributorCode = x.JDEDistributorCode,
        //                YesterdayEnquiry = x.YesterdayEnquiry,
        //                ThisMonthEnquiry = x.ThisMonthEnquiry,
        //                TotalEnquiry = x.TotalEnquiry,
        //                YesterdayPurchase = x.YesterdayPurchase,
        //                ThisMonthPurchase = x.ThisMonthPurchase,
        //                TotalPurchase = x.TotalPurchase,
        //                ROCode = x.ROCode,
        //                ROName = x.ROName,
        //                SACode = x.SACode,
        //                SAName = x.SAName,
        //                ZOCode = x.ZOCode,
        //                ZOName = x.ZOName
        //            }).ToList();
        //            BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.SuccessStatus, null);
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        throw ex;
        //    }
        //    return model;
        //}

        //#region
        //public List<Master> GetMasterdetails(string Id, string type)
        //{
        //    return GetMasterdetailsPR(Id, type);
        //}
        //private List<Master> GetMasterdetailsPR(string Id, string type)
        //{
        //    List<Master> model = new List<Master>();

        //    try
        //    {
        //        LogId = BusinessCont.SaveLog(0, 0, "GetMasterdetails", "Id- " + Id + ",type- " + type, null, null);
        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            model = ContextManager._Context.sp_GetMaster(Id, type).Select(x => new Master()
        //            {
        //                Id = x.Id,
        //                Name = x.Name,
        //                Email=x.Email,
        //                ParentId=x.ParentId,
        //                ActiveFlag=x.ActiveFlag
        //            }).ToList();
        //            BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.SuccessStatus, null);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        throw ex;
        //    }
        //    return model;
        //}

        //#endregion

        //public List<Master> GetMasterdetailsDBC(string Id, string type)
        //{
        //    return GetMasterdetailsDBCPR(Id, type);
        //}
        //private List<Master> GetMasterdetailsDBCPR(string Id, string type)
        //{
        //    List<Master> model = new List<Master>();

        //    try
        //    {
        //        LogId = BusinessCont.SaveLog(0, 0, "GetMasterdetails", "Id- " + Id + ",type- " + type, null, null);
        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            model = ContextManager._Context.sp_GetMasterForDBC(Id, type).Select(x => new Master()
        //            {
        //                Id = x.Id,
        //                Name = x.Name,
        //                Email = x.Email,
        //                ParentId = x.ParentId,
        //                ActiveFlag = x.ActiveFlag
        //            }).ToList();
        //            BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.SuccessStatus, null);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        throw ex;
        //    }
        //    return model;
        //}

        //#region
        //public SchedulerSettings GetSchedulerSettings( string type)
        //{
        //    return GetSchedulerSettingsPR(type);
        //}
        //private SchedulerSettings GetSchedulerSettingsPR(string type)
        //{
        //    SchedulerSettings model = new SchedulerSettings();

        //    try
        //    {
        //        LogId = BusinessCont.SaveLog(0, 0, "GetMasterdetails", "type- " + type, null, null);
        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            model = ContextManager._Context.sp_GetSchedulerSettings(type).Select(x=> new SchedulerSettings() {
        //                SettingId = x.SettingId,
        //                SchedulerName = x.SchedulerName,
        //                WithIntervalInHours = x.WithIntervalInHours,
        //                Hours = x.Hours,
        //                Minutes = x.Minutes,
        //                IsActive = x.IsActive,
        //                LastUpdatedDate = x.LastUpdatedDate
        //            }).FirstOrDefault();
        //            BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.SuccessStatus, null);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(LogId, 0, null, null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        throw ex;
        //    }
        //    return model;
        //}
        //#endregion


        //#region MIS DBC 
        //public int GetDailySchedulerCheck()
        //{
        //    return GetDailySchedulerCheckPvt();
        //}

        //private int GetDailySchedulerCheckPvt()
        //{
        //    int ReturnValue = 0;
        //    try
        //    {
        //        string ToEmail = Convert.ToString(ConfigurationManager.AppSettings["ToEmail"]);
        //        string CCEmail = Convert.ToString(ConfigurationManager.AppSettings["CCEmail"]);

        //        bool SendMail;
        //        EmailSending model = new EmailSending();
        //        string InsertedtablesDetails = "";
        //        string InsertedtablesDetailsSA = "";
        //        string MainEmailBody = string.Empty;
        //        string Table = string.Empty;
        //        string TableDist = string.Empty;
        //        string [] attachment1 = null;

        //        string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\");
        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            var data = ContextManager._Context.usp_SBCMessageSendSummaryData("0", "0", "sawise").ToList();

        //            if (data.Count > 0)
        //            {
        //                Table = "";
        //                InsertedtablesDetailsSA = "";

        //                Table += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse; width:100 %;white-space:nowrap;'>";
        //                Table += "<thead><tr style='font-size:14px;'>";
        //                Table += "<th style='border: 1px solid grey;padding: 5px;'>Sr.No</th>";
        //                Table += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area</th>";
        //                Table += "<th style='border: 1px solid grey;padding: 5px;'>Sum of Msg sent as of Date</th>";
        //                Table += "<th style='border: 1px solid grey;padding: 5px;'> Sum of Interested </th>";
        //                Table += "<th style='border: 1px solid grey;padding: 5px;'> Average of % Interested </th>";
        //                Table += "<th style='border: 1px solid grey;padding: 5px;'> Sum of Connection Released </th>";
        //                Table += "</tr></thead><tbody>";

        //                int Count = 1;
        //                InsertedtablesDetailsSA += Table;
        //                for (int i = 0; i < data.Count; i++)
        //                {
        //                    InsertedtablesDetailsSA += "<tr style='font-size:14px;'>";
        //                    InsertedtablesDetailsSA += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + Count +
        //                             "</td>";
        //                    InsertedtablesDetailsSA += "<td style='border: 1px solid grey;padding: 5px;'>" + data[i].SAName + "</td>";
        //                    InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].ConsumerProcessed +
        //                             "</td>";
        //                    InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].Interested +
        //                             "</td>";
        //                    InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].InterestedPercent +
        //                             "</td>";
        //                    InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].ConnectionReleased +
        //                             "</td>";
        //                    InsertedtablesDetailsSA += "</tr>";

        //                    Count++;
        //                }

        //                InsertedtablesDetailsSA += "</tbody></table>";

        //                var datadist = ContextManager._Context.usp_SBCMessageSendSummaryData("0", "0", "distwise").ToList();

        //                if (datadist.Count > 0)
        //                {
        //                    TableDist = "";
        //                    InsertedtablesDetails = "";

        //                    TableDist += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse; width:100 %;white-space:nowrap;'>";
        //                    TableDist += "<thead><tr style='font-size:14px;'>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'>Sr.No</th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area</th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'>Distributor Code</th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Distributor Name </th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Total Consumer </th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Msg sent as of Date </th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Balance Consumer</th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Interested </th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> % Interested </th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Not Interested </th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Connection Released </th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Message Read </th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Contacted</th>";
        //                    TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Pending For Contact</th>";

        //                    TableDist += "</tr></thead><tbody>";

        //                    Count = 1;
        //                    InsertedtablesDetails += TableDist;


        //                    for (int i = 0; i < datadist.Count; i++)
        //                    {
        //                        InsertedtablesDetails += "<tr style='font-size:14px;'>";
        //                        InsertedtablesDetails += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + Count +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + datadist[i].SAName + "</td>";
        //                        InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + datadist[i].JDEDistributorCode +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + datadist[i].DistributorName +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].TotalConsumer +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].ConsumerProcessed +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].ConsumerBalance +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].Interested +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].InterestedPercent +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].NotInterestedCount +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].ConnectionReleased +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].MessageRead +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].Contacted +
        //                                 "</td>";
        //                        InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].PendingForContact +
        //                                 "</td>";
        //                        InsertedtablesDetails += "</tr>";

        //                        Count++;
        //                    }

        //                    InsertedtablesDetails += "</tbody></table>";
        //                }

        //                if (InsertedtablesDetailsSA != "" && InsertedtablesDetailsSA != null && InsertedtablesDetails != "" && InsertedtablesDetails != null)
        //                {
        //                    DBCSOCreateSentSMSAttachment("0", "MIS Daily Report status :");

        //                    string[] AttachmentPaths = new string[1];
        //                    AttachmentPaths[0] = filePath + "\\" + "DBCSADailyReport.xlsx";

        //                    BusinessCont.SaveLog(0, 100, "DBCSADailyReport File Path", null, BusinessCont.SuccessStatus, AttachmentPaths[0]);

        //                    SendMail = model.DailySchedulerEmail(ToEmail, CCEmail,"", "MIS DBC Summary Data : " + DateTime.Now.ToString("dd/MM/yyyy"),"", InsertedtablesDetailsSA, InsertedtablesDetails, attachment1, AttachmentPaths);

        //                    if (SendMail == true)
        //                        ReturnValue = 1;
        //                    else
        //                        ReturnValue = 0;
        //                }
        //            }
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, 100, "GetDailySchedulerCheckPvt", null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        throw ex;
        //    }
        //    return ReturnValue;
        //}

        //private void DBCSOCreateSentSMSAttachment(string SACode, string SAName)
        //{
        //    int srno = 1;
        //    int srno1 = 1;
        //    try
        //    {
        //        var workbook = new XLWorkbook();

        //        List<DBCExcelAdminModelSA> listSA = null;
        //        listSA = new List<DBCExcelAdminModelSA>();
        //        listSA = ContextManager._Context.usp_SBCMessageSendSummaryData("0","0","sawise").Select(x => new DBCExcelAdminModelSA()
        //        {
        //            srno = srno++,
        //            //SACode = x.SACode,
        //            SAName = x.SAName,
        //            //JDEDistributorCode = x.JDEDistributorCode,
        //            //DistributorName = x.DistributorName,
        //            //TotalConsumer = x.TotalConsumer,
        //            ConsumerProcessed = x.ConsumerProcessed,
        //            //ConsumerBalance = x.ConsumerBalance,
        //            //MessageSend = x.MessageSend,
        //            Interested = x.Interested,
        //            InterestedPercent = x.InterestedPercent,
        //            //NotInterestedCount = x.NotInterestedCount,
        //            ConnectionReleased = x.ConnectionReleased
        //            //MessageRead = x.MessageRead,
        //            //Contacted = x.Contacted,
        //            //PendingForContact = x.PendingForContact
        //        }).ToList();
        //        var wsDetailedDataSA = workbook.AddWorksheet("SalesAreaWise");

        //        wsDetailedDataSA.Cell(1, 1).InsertTable(listSA);
        //        wsDetailedDataSA.Tables.FirstOrDefault().ShowAutoFilter = false;
        //        wsDetailedDataSA.ColumnWidth = 20;
        //        wsDetailedDataSA.Column(3).AdjustToContents();
        //        //wsDetailedDataSA.Column(3).Width = 20;
        //        wsDetailedDataSA.Cell(1, 1).Value = "Sr. No";
        //        //wsDetailedDataSA.Cell(1, 2).Value = "SA Code";
        //        wsDetailedDataSA.Cell(1, 2).Value = "SA Name";
        //        //wsDetailedDataSA.Cell(1, 4).Value = "Distributor Code";
        //        //wsDetailedDataSA.Cell(1, 5).Value = "Distributor Name";
        //        //wsDetailedDataSA.Cell(1, 6).Value = "Total Consumer";
        //        wsDetailedDataSA.Cell(1, 3).Value = "Msg sent as of Date";
        //        //wsDetailedDataSA.Cell(1, 8).Value = "Balance Consumer";
        //        //wsDetailedDataSA.Cell(1, 9).Value = "Message Send";
        //        wsDetailedDataSA.Cell(1, 4).Value = "Interested";
        //        wsDetailedDataSA.Cell(1, 5).Value = "% Interested";
        //        //wsDetailedDataSA.Cell(1, 11).Value = "Not Interested";
        //        wsDetailedDataSA.Cell(1, 6).Value = "Connection Released";
        //        //wsDetailedDataSA.Cell(1, 13).Value = "Message Read";
        //        //wsDetailedDataSA.Cell(1, 14).Value = "Contacted";
        //        //wsDetailedDataSA.Cell(1, 15).Value = "Pending For Contact";


        //        List<DBCExcelAdminModel> list = null;
        //        list = new List<DBCExcelAdminModel>();
        //        list = ContextManager._Context.usp_SBCMessageSendSummaryData("0","0","distwise").Select(x => new DBCExcelAdminModel()
        //        {
        //            srno = srno1++,
        //            SACode = x.SACode,
        //            SAName = x.SAName,
        //            JDEDistributorCode = x.JDEDistributorCode,
        //            DistributorName = x.DistributorName,
        //            TotalConsumer = x.TotalConsumer,
        //            ConsumerProcessed = x.ConsumerProcessed,
        //            ConsumerBalance = x.ConsumerBalance,
        //            //MessageSend = x.MessageSend,
        //            Interested = x.Interested,
        //            InterestedPercent = x.InterestedPercent,
        //            NotInterestedCount = x.NotInterestedCount,
        //            ConnectionReleased = x.ConnectionReleased,
        //            MessageRead = x.MessageRead,
        //            Contacted = x.Contacted,
        //            PendingForContact = x.PendingForContact
        //        }).ToList();

        //        var wsDetailedData = workbook.AddWorksheet("Distributorwise");
        //        wsDetailedData.Cell(1, 1).InsertTable(list);
        //        wsDetailedData.Tables.FirstOrDefault().ShowAutoFilter = false;
        //        wsDetailedData.ColumnWidth = 20;
        //        wsDetailedData.Column(3).AdjustToContents();
        //        //wsDetailedData.Column(3).Width = 20;
        //        wsDetailedData.Cell(1, 1).Value = "Sr. No"; 
        //        wsDetailedData.Cell(1, 2).Value = "SA Code";
        //        wsDetailedData.Cell(1, 3).Value = "SA Name";
        //        wsDetailedData.Cell(1, 4).Value = "Distributor Code";
        //        wsDetailedData.Cell(1, 5).Value = "Distributor Name";
        //        wsDetailedData.Cell(1, 6).Value = "Total Consumer";
        //        wsDetailedData.Cell(1, 7).Value = "Msg sent as of Date";
        //        wsDetailedData.Cell(1, 8).Value = "Balance Consumer";
        //        //wsDetailedData.Cell(1, 9).Value = "Message Send";
        //        wsDetailedData.Cell(1, 9).Value = "Interested";
        //        wsDetailedData.Cell(1, 10).Value = "% Interested";
        //        wsDetailedData.Cell(1, 11).Value = "Not Interested";
        //        wsDetailedData.Cell(1, 12).Value = "Connection Released";
        //        wsDetailedData.Cell(1, 13).Value = "Message Read";
        //        wsDetailedData.Cell(1, 14).Value = "Contacted";
        //        wsDetailedData.Cell(1, 15).Value = "Pending For Contact";

        //        wsDetailedData.Column(16).Hide();
        //        wsDetailedData.Column(17).Hide();
        //        wsDetailedData.Column(18).Hide();
        //        wsDetailedData.Column(19).Hide();
        //        wsDetailedData.Column(20).Hide();
        //        wsDetailedData.Column(21).Hide();
        //        wsDetailedData.Column(22).Hide();
        //        wsDetailedData.Column(23).Hide();
        //        wsDetailedData.Column(24).Hide();
        //        wsDetailedData.Column(25).Hide();



        //        string ExcelName = "DBCSADailyReport.xlsx";

        //        string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\");
        //        //string[] FolderPath = Directory.GetDirectories(HostingEnvironment.MapPath("~/MailFile/"));
        //        string FinalPath = filePath  + "\\" + ExcelName;

        //        BusinessCont.SaveLog(0, 100, "DBCSADailyReport Save File Path", null, BusinessCont.SuccessStatus, FinalPath);

        //        workbook.SaveAs(FinalPath);
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, 0, "SO Excel ", "", "Fail", BusinessCont.ExceptionMsg(ex));
        //    }
        //}
        //private string GetHtmlFileForPremise()
        //{
        //    string[] Mappedpath = Directory.GetFiles(HostingEnvironment.MapPath("~/MailFile/"));
        //    string MappedFilePath = Mappedpath[1];
        //    string message = File.OpenText(MappedFilePath).ReadToEnd().ToString();
        //    return message;
        //}

        //#endregion

        //#region VAS MIS Report
        //public int GetVASReport()
        //{
        //    return GetVASReportPvt();
        //}
        //private int GetVASReportPvt()
        //{
        //    int ReturnValue = 0;
        //    try
        //    {
        //        int TotalRegConsumer = 0, PendingBooking = 0, YestDelivery = 0, DelDelay = 0, S1 = 0, S2 = 0;


        //        //string ToEmail = Convert.ToString(ConfigurationManager.AppSettings["ToEmail"]);
        //        string CCEmail = Convert.ToString(ConfigurationManager.AppSettings["CCEmail"]);

        //        //bool SendMail;
        //        EmailSending model = new EmailSending();
        //        string InsertedtablesDetails = "";
        //        string InsertedtablesDetailsSA = "";
        //        string MainEmailBody = string.Empty;
        //        string Table = string.Empty;
        //        string TableDist = string.Empty;
        //        List<tblROMaster> ROList = null;

        //        string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\");
        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            ROList = ContextManager._Context.tblROMasters.Where(r => r.ActiveFlag == "Y").ToList();

        //            //ROList = ContextManager._Context.tblROMasters.Where(r => r.ActiveFlag == "Y" && r.ROCode == "12352").ToList();

        //            if (ROList != null && ROList.Any())
        //            {
        //                foreach (tblROMaster Ro in ROList)
        //                {
        //                    ContextManager._Context.Database.CommandTimeout = 600;
        //                    string ROEmail = ContextManager._Context.tbl_SchedulerEmail.Where(r => r.Code == Ro.ROCode && r.Role == "RO" && r.IsActive == true).Select(r => r.Email).FirstOrDefault();
        //                    if (String.IsNullOrWhiteSpace(ROEmail))
        //                        continue;   //Dont process RO if email not available

        //                    var data = ContextManager._Context.usp_VASMISReportData("0", Ro.ROCode, "sawise").ToList();

        //                    if (data.Count > 0)
        //                    {
        //                        Table = "";
        //                        InsertedtablesDetailsSA = "";
        //                        TotalRegConsumer = 0; PendingBooking = 0; YestDelivery = 0; DelDelay = 0; S1 = 0; S2 = 0;

        //                        Table += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse; width:100 %;white-space:nowrap;'>";
        //                        Table += "<thead><tr style='font-size:14px;'>";
        //                        Table += "<th style='border: 1px solid grey;padding: 5px;'>Sr.No</th>";
        //                        Table += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area</th>";
        //                        Table += "<th style='border: 1px solid grey;padding: 5px;'>Total Register Consumer</th>";
        //                        Table += "<th style='border: 1px solid grey;padding: 5px;'> Pending Booking </th>";
        //                        Table += "<th style='border: 1px solid grey;padding: 5px;'> Yesterday Delivery </th>";
        //                        Table += "<th style='border: 1px solid grey;padding: 5px;'> Delivery Delay </th>";
        //                        Table += "<th style='border: 1px solid grey;padding: 5px;'> 1st Service Due </th>";
        //                        Table += "<th style='border: 1px solid grey;padding: 5px;'> 2nd Service Due </th>";
        //                        Table += "</tr></thead><tbody>";

        //                        int Count = 1;
        //                        InsertedtablesDetailsSA += Table;
        //                        for (int i = 0; i < data.Count; i++)
        //                        {

        //                            InsertedtablesDetailsSA += "<tr style='font-size:14px;'>";
        //                            InsertedtablesDetailsSA += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + Count +
        //                                     "</td>";
        //                            InsertedtablesDetailsSA += "<td style='border: 1px solid grey;padding: 5px;'>" + data[i].SAName + "</td>";
        //                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].TotalRegConsumer +
        //                                     "</td>";
        //                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].PendingBooking +
        //                                     "</td>";
        //                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].YestDelivery +
        //                                     "</td>";
        //                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].DelDelay +
        //                                     "</td>";
        //                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].S1 +
        //                                     "</td>";
        //                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].S2 +
        //                                     "</td>";
        //                            InsertedtablesDetailsSA += "</tr>";

        //                            TotalRegConsumer += Convert.ToInt32(data[i].TotalRegConsumer);
        //                            PendingBooking += Convert.ToInt32(data[i].PendingBooking);
        //                            YestDelivery += Convert.ToInt32(data[i].YestDelivery);
        //                            DelDelay += Convert.ToInt32(data[i].DelDelay);
        //                            S1 += Convert.ToInt32(data[i].S1);
        //                            S2 += Convert.ToInt32(data[i].S2);

        //                            Count++;
        //                        }

        //                        InsertedtablesDetailsSA += "</tbody></table>";

        //                        var datadist = ContextManager._Context.usp_VASMISReportData("0", Ro.ROCode, "distwise").ToList();

        //                        var datalistnew = datadist.GroupBy(x => x.SACode).ToList();

        //                        var groupedCustomerList = datadist
        //                                .GroupBy(u => u.SACode)
        //                                .Select(grp => grp.ToList())
        //                                .ToList();
        //                        InsertedtablesDetails = "";
        //                        int ik = 0;
        //                        foreach (var items in datalistnew)
        //                        {
        //                            TableDist = "";

        //                            TableDist += "<h4 style='font-family: Calibri (Body);font-size: 12pt;color: #000000; background-color: #ffffff'>" + groupedCustomerList[ik][0].SAName + "</h4>";
        //                            TableDist += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse; width:100 %;white-space:nowrap;'>";
        //                            TableDist += "<thead><tr style='font-size:14px;'>";
        //                            TableDist += "<th style='border: 1px solid grey;padding: 5px;'>Sr.No</th>";
        //                            TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area</th>";
        //                            TableDist += "<th style='border: 1px solid grey;padding: 5px;'>Distributor Code</th>";
        //                            TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Distributor Name </th>";
        //                            TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Total Register Consumer </th>";
        //                            TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Pending Booking </th>";
        //                            TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Yesterday Delivery</th>";
        //                            TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Delivery Delay </th>";
        //                            TableDist += "<th style='border: 1px solid grey;padding: 5px;'> 1st Service Due </th>";
        //                            TableDist += "<th style='border: 1px solid grey;padding: 5px;'> 2nd Service Due </th>";

        //                            TableDist += "</tr></thead><tbody>";


        //                            Count = 1;
        //                            InsertedtablesDetails += TableDist;

        //                            foreach (var item in items)
        //                            {
        //                                if (items.Count() > 0)
        //                                {
        //                                    if (item.SAName == "Total :")
        //                                    {
        //                                        Count = 0;
        //                                    }

        //                                    InsertedtablesDetails += "<tr style='font-size:14px;'>";
        //                                    InsertedtablesDetails += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + Count +
        //                                             "</td>";
        //                                    InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + item.SAName + "</td>";

        //                                    InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + item.JDEDistributorCode +
        //                                             "</td>";
        //                                    InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + item.DistributorName +
        //                                             "</td>";
        //                                    InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.TotalRegConsumer +
        //                                             "</td>";
        //                                    InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.PendingBooking +
        //                                             "</td>";
        //                                    InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.YestDelivery +
        //                                             "</td>";
        //                                    InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.DelDelay +
        //                                             "</td>";
        //                                    InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.S1 +
        //                                             "</td>";
        //                                    InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.S2 +
        //                                             "</td>";

        //                                    InsertedtablesDetails += "</tr>";

        //                                    TotalRegConsumer += Convert.ToInt32(item.TotalRegConsumer);
        //                                    PendingBooking += Convert.ToInt32(item.PendingBooking);
        //                                    YestDelivery += Convert.ToInt32(item.YestDelivery);
        //                                    DelDelay += Convert.ToInt32(item.DelDelay);
        //                                    S1 += Convert.ToInt32(item.S1);
        //                                    S2 += Convert.ToInt32(item.S2);

        //                                    Count++;
        //                                }
        //                            }
        //                            InsertedtablesDetails += "</tbody></table></br></br>";
        //                            ik++;
        //                        }

        //                        if (InsertedtablesDetailsSA != "" && InsertedtablesDetailsSA != null && InsertedtablesDetails != "" && InsertedtablesDetails != null)
        //                        {

        //                            //Create ARB attachment file
        //                            VASSOCreateSentSMSAttachmentForRO("", Ro.ROCode, "VAS MIS Daily Report status :" + Ro.ROName);

        //                            string[] AttachmentPaths = new string[1];
        //                            AttachmentPaths[0] = filePath + "\\" + "VASSADailyReport.xlsx";

        //                            BusinessCont.SaveLog(0, 100, "VASSADailyReport File Path", null, BusinessCont.SuccessStatus, AttachmentPaths[0]);

        //                            // VAS MIS Report For Pune LPG RO
        //                            if (Ro.ROCode == "12352")
        //                            {
        //                                BusinessCont.SaveLog(0, 0, "VAS MIS Report", DateTime.Now.ToLongTimeString(), "Start", "");

        //                                SendMail = model.VASDailySchedulerEmail(ROEmail, CCEmail, "sancheet@gmail.com;aadyamconsultant@gmail.com;rajendra@aadyamconsultant.com;nayankakade@aadyamconsultant.com", "VAS MIS Summary Data : " + Ro.ROName + " - " + DateTime.Now.ToString("dd/MM/yyyy"), InsertedtablesDetailsSA, InsertedtablesDetails, AttachmentPaths);

        //                                BusinessCont.SaveLog(0, 0, "VAS MIS Report", DateTime.Now.ToLongTimeString(), "End", "");
        //                            }

        //                            if (SendMail == true)
        //                                ReturnValue = 1;
        //                            else
        //                                ReturnValue = 0;
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, 100, "GetVASReportPvt", null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        //        throw ex;
        //    }
        //    return ReturnValue;
        //}

        //// VAS Attachment 
        //private void VASSOCreateSentSMSAttachmentForRO(string SACode, string ROCode, string SAName)
        //{
        //    int srno = 1;
        //    int srno1 = 1;
        //    try
        //    {
        //        var workbook = new XLWorkbook();
        //        List<VASExcelAdminModelSA> listSA = null;
        //        listSA = new List<VASExcelAdminModelSA>();
        //        listSA = ContextManager._Context.usp_VASMISReportData("0", ROCode, "sawise").Select(x => new VASExcelAdminModelSA()
        //        {
        //            srno = srno++,
        //            //SACode = x.SACode,
        //            SAName = x.SAName,
        //            TotalRegConsumer = x.TotalRegConsumer,
        //            PendingBooking = x.PendingBooking,
        //            YestDelivery = x.YestDelivery,
        //            DelDelay= x.DelDelay,
        //            S1= x.S1,
        //            S2 = x.S2
        //        }).ToList();

        //        var wsDetailedDataSA = workbook.AddWorksheet("SalesAreaWise");
        //        wsDetailedDataSA.Cell(1, 1).InsertTable(listSA);
        //        wsDetailedDataSA.Tables.FirstOrDefault().ShowAutoFilter = false;
        //        wsDetailedDataSA.ColumnWidth = 20;
        //        wsDetailedDataSA.Column(3).AdjustToContents();
        //        //wsDetailedDataSA.Column(3).Width = 20;
        //        wsDetailedDataSA.Cell(1, 1).Value = "Sr. No";
        //        wsDetailedDataSA.Cell(1, 2).Value = "SA Name";
        //        wsDetailedDataSA.Cell(1, 3).Value = "Total Register Consumer";
        //        wsDetailedDataSA.Cell(1, 4).Value = "Pending Booking"; 
        //        wsDetailedDataSA.Cell(1, 5).Value = "Yesterday Delivery"; 
        //        wsDetailedDataSA.Cell(1, 6).Value = "Delivery Delay";
        //        wsDetailedDataSA.Cell(1, 7).Value = "1st Service Due";
        //        wsDetailedDataSA.Cell(1, 8).Value = "2nd Service Due";

        //        List<VAS_ExcelAdminModel> list = null;
        //        list = new List<VAS_ExcelAdminModel>();
        //        list = ContextManager._Context.usp_VASMISReportData("0", ROCode, "distwise").Select(x => new VAS_ExcelAdminModel()
        //        {
        //            srno = x.SAName == "Total :" ? srno1 = 1 : srno1++,
        //            SACode = x.SACode,
        //            SAName = x.SAName,
        //            JDEDistributorCode = x.JDEDistributorCode,
        //            DistributorName = x.DistributorName,
        //            TotalRegConsumer = x.TotalRegConsumer,
        //            PendingBooking = x.PendingBooking,
        //            YestDelivery = x.YestDelivery,
        //            DelDelay = x.DelDelay,
        //            S_1 = x.S1,
        //            S_2 = x.S2,
        //        }).ToList();

        //        var datalistnew = list.GroupBy(x => x.SACode).ToList();

        //        var groupedCustomerList = list
        //               .GroupBy(u => u.SACode)
        //               .Select(grp => grp.ToList())
        //               .ToList();
        //        int ik = 0;

        //        foreach (var items in datalistnew)
        //        {
        //            var wsDetailedData = workbook.AddWorksheet(groupedCustomerList[ik][0].SAName);
        //            wsDetailedData.Cell(1, 1).InsertTable(items.ToList());
        //            wsDetailedData.Tables.FirstOrDefault().ShowAutoFilter = false;
        //            wsDetailedData.ColumnWidth = 20;
        //            wsDetailedData.Column(3).AdjustToContents();
        //            //wsDetailedData.Column(3).Width = 20;
        //            wsDetailedData.Cell(1, 1).Value = "Sr. No";
        //            wsDetailedData.Cell(1, 2).Value = "SA Code";
        //            wsDetailedData.Cell(1, 3).Value = "SA Name";
        //            wsDetailedData.Cell(1, 4).Value = "Distributor Code";
        //            wsDetailedData.Cell(1, 5).Value = "Distributor Name";
        //            wsDetailedData.Cell(1, 6).Value = "Total Register Consumer";
        //            wsDetailedData.Cell(1, 7).Value = "Pending Booking";
        //            wsDetailedData.Cell(1, 8).Value = "Yesterday Delivery";
        //            wsDetailedData.Cell(1, 9).Value = "Delivery Delay";
        //            wsDetailedData.Cell(1, 10).Value = "1st Service Due";
        //            wsDetailedData.Cell(1, 11).Value = "2nd Service Due";

        //            wsDetailedData.Column(12).Hide();
        //            wsDetailedData.Column(13).Hide();
        //            wsDetailedData.Column(14).Hide();
        //            wsDetailedData.Column(15).Hide();
        //            wsDetailedData.Column(16).Hide();
        //            wsDetailedData.Column(17).Hide();
        //            wsDetailedData.Column(18).Hide();
        //            wsDetailedData.Column(19).Hide();
        //            wsDetailedData.Column(20).Hide();
        //            ik++;
        //        }

        //        string ExcelName = "VASSADailyReport.xlsx";

        //        string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\");

        //        string FinalPath = filePath + "\\" + ExcelName;

        //        BusinessCont.SaveLog(0, 100, "VASSADailyReport Save File Path", null, BusinessCont.SuccessStatus, FinalPath);

        //        workbook.SaveAs(FinalPath);
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, 0, "VASSOCreateSentSMSAttachmentForRO ", "", "Fail", BusinessCont.ExceptionMsg(ex));
        //    }
        //}
        //#endregion

        #region DBC MIS Report
        public int GetDBCCampaignReport()
        {
            return GetDBCCampaignReportPvt();
        }

        private int GetDBCCampaignReportPvt()
        {
            int ReturnValue = 0, TotalConsumers = 0, TotalConsumerProcessed = 0, TotalConsumerBalance = 0, TotalMessageSend = 0, TotalInterested = 0, TotalNotInterestedCount = 0, TotalConnectionReleased = 0, TotalMesageRead = 0, TotalContacted = 0, TotalPendingForContacted = 0;
#pragma warning disable CS0219 // The variable 'MessageReadPercent' is assigned but its value is never used
#pragma warning disable CS0219 // The variable 'ConnectionReleasedPercent' is assigned but its value is never used
#pragma warning disable CS0219 // The variable 'IntPerPercentage' is assigned but its value is never used
            decimal IntPerPercentage = 0, ConnectionReleasedPercent = 0, MessageReadPercent = 0;
#pragma warning restore CS0219 // The variable 'IntPerPercentage' is assigned but its value is never used
#pragma warning restore CS0219 // The variable 'ConnectionReleasedPercent' is assigned but its value is never used
#pragma warning restore CS0219 // The variable 'MessageReadPercent' is assigned but its value is never used

            string ToEmail = string.Empty, CCEmail = string.Empty, BCCEmail = string.Empty, InsertedtablesDetails = string.Empty,
                   InsertedtablesDetailsSA = string.Empty, MainEmailBody = string.Empty, Table = string.Empty,
                   TableDist = string.Empty, InsertedtablesDetailsSASuraksha = string.Empty, filePath = string.Empty,
                   ROEmail = string.Empty;

            EmailSending model = new EmailSending();
            List<ROMasterModel> ROList = new List<ROMasterModel>();
            ROMasterModel ROMasterModel = new ROMasterModel();
            MastersManager mastersManager = new MastersManager();
            string[] AttachmentPaths = new string[1];
            string[] AttachmentPaths1 = new string[1];
            try
            {
                ToEmail = Convert.ToString(ConfigurationManager.AppSettings["ToEmail"]);
                CCEmail = Convert.ToString(ConfigurationManager.AppSettings["CCEmail"]);
                BCCEmail = Convert.ToString(ConfigurationManager.AppSettings["BCCEmail"]);
                filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\");

                ROList = mastersManager.GetROMasterList();

                if (ROList != null && ROList.Any())
                {
                    #region Start - ROList
                    foreach (var RO in ROList)
                    {
                        using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                        {
                            // Role and RoCode wise MIS Send
                            ROMasterModel = mastersManager.GetROMasterListByCode(RO.ROCode).FirstOrDefault();
                            if (ROMasterModel != null)
                            {
                                ROEmail = ROMasterModel.Email;

                                if (string.IsNullOrWhiteSpace(ROEmail))
                                    continue;   // Dont process RO if email not available

                                var data = _Context.usp_SBCMessageSendSummaryData("0", RO.ROCode, "sawise").ToList();
                                if (data.Count > 0)
                                {
                                    #region Start - sawise
                                    Table = "";
                                    InsertedtablesDetailsSA = "";
                                    TotalConsumerProcessed = 0; TotalMessageSend = 0; TotalInterested = 0; TotalNotInterestedCount = 0; TotalConnectionReleased = 0; IntPerPercentage = 0;

                                    Table += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse; width:100 %;white-space:nowrap;'>";
                                    Table += "<thead><tr style='font-size:14px;'>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'>Sr.No</th>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area</th>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'>Sum of Msg sent as of Date</th>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'> Sum of Interested </th>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'> Average of % Interested </th>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'> Sum of Connection Released </th>";
                                    Table += "</tr></thead><tbody>";

                                    int Count = 1;
                                    InsertedtablesDetailsSA += Table;
                                    for (int i = 0; i < data.Count; i++)
                                    {

                                        InsertedtablesDetailsSA += "<tr style='font-size:14px;'>";
                                        InsertedtablesDetailsSA += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + Count +
                                                 "</td>";
                                        InsertedtablesDetailsSA += "<td style='border: 1px solid grey;padding: 5px;'>" + data[i].SAName + "</td>";
                                        InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].MessageSend +
                                                 "</td>";
                                        InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].Interested +
                                                 "</td>";
                                        InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].InterestedPercent +
                                                 "</td>";
                                        InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].ConnectionReleased +
                                                 "</td>";
                                        InsertedtablesDetailsSA += "</tr>";

                                        //TotalConsumerProcessed += Convert.ToInt32(data[i].ConsumerProcessed);
                                        TotalMessageSend += Convert.ToInt32(data[i].MessageSend);
                                        TotalInterested += Convert.ToInt32(data[i].Interested);
                                        TotalNotInterestedCount += Convert.ToInt32(data[i].InterestedPercent);
                                        TotalConnectionReleased += Convert.ToInt32(data[i].ConnectionReleased);
                                        Count++;
                                    }

                                    InsertedtablesDetailsSA += "</tbody></table>";
                                    #endregion End - sawise

                                    #region Start - distwise
                                    var datadist = _Context.usp_SBCMessageSendSummaryData("0", RO.ROCode, "distwise").ToList();
                                    var datalistnew = datadist.GroupBy(x => x.SACode).ToList();
                                    var groupedCustomerList = datadist
                                            .GroupBy(u => u.SACode)
                                            .Select(grp => grp.ToList())
                                            .ToList();
                                    InsertedtablesDetails = "";
                                    int ik = 0;
                                    foreach (var items in datalistnew)
                                    {
                                        TableDist = "";
                                        TotalConsumers = 0; TotalConsumerProcessed = 0;
                                        TotalConsumerBalance = 0; TotalMessageSend = 0;
                                        TotalInterested = 0;
                                        TotalNotInterestedCount = 0;
                                        TotalConnectionReleased = 0;
                                        TotalMesageRead = 0;
                                        TotalContacted = 0;
                                        TotalPendingForContacted = 0; IntPerPercentage = 0;
                                        TableDist += "<h4 style='font-family: Calibri (Body);font-size: 12pt;color: #000000; background-color: #ffffff'>" + groupedCustomerList[ik][0].SAName + "</h4>";
                                        TableDist += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse; width:100 %;white-space:nowrap;'>";
                                        TableDist += "<thead><tr style='font-size:14px;'>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'>Sr.No</th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area</th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'>Distributor Code</th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Distributor Name </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Total Consumer </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Msg sent as of Date </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Balance Consumer</th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Interested </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> % Interested </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Not Interested </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Connection Released </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Message Read </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Contacted</th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Pending For Contact</th>";
                                        TableDist += "</tr></thead><tbody>";

                                        Count = 1;
                                        InsertedtablesDetails += TableDist;

                                        foreach (var item in items)
                                        {
                                            if (items.Count() > 0)
                                            {

                                                //for (int i = 0; i < datadist.Count; i++)
                                                //{
                                                if (item.SAName == "Total :")
                                                {
                                                    Count = 0;
                                                }

                                                InsertedtablesDetails += "<tr style='font-size:14px;'>";
                                                InsertedtablesDetails += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + Count +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + item.SAName + "</td>";

                                                InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + item.JDEDistributorCode +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + item.DistributorName +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.TotalConsumer +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.MessageSend +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.ConsumerBalance +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.Interested +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.InterestedPercent +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.NotInterestedCount +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.ConnectionReleased +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.MessageRead +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.Contacted +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.PendingForContact +
                                                         "</td>";
                                                InsertedtablesDetails += "</tr>";

                                                TotalConsumers += Convert.ToInt32(item.TotalConsumer);
                                                TotalConsumerProcessed += Convert.ToInt32(item.ConsumerProcessed);
                                                TotalConsumerBalance += Convert.ToInt32(item.ConsumerBalance);
                                                TotalMessageSend += Convert.ToInt32(item.MessageSend);
                                                TotalInterested += Convert.ToInt32(item.Interested);
                                                TotalNotInterestedCount += Convert.ToInt32(item.NotInterestedCount);
                                                TotalConnectionReleased += Convert.ToInt32(item.ConnectionReleased);
                                                TotalMesageRead += Convert.ToInt32(item.MessageRead);
                                                TotalContacted += Convert.ToInt32(item.Contacted);
                                                TotalPendingForContacted += Convert.ToInt32(item.PendingForContact);

                                                Count++;
                                            }
                                        }
                                        InsertedtablesDetails += "</tbody></table></br></br>";
                                        ik++;
                                    }
                                    #endregion End - distwise

                                    #region Start - InsertedtablesDetailsSA & InsertedtablesDetails
                                    if (InsertedtablesDetailsSA != "" && InsertedtablesDetailsSA != null && InsertedtablesDetails != "" && InsertedtablesDetails != null)
                                    {
                                        // DBC
                                        if (ROMasterModel.IsDBC == "Y")
                                        {
                                            #region Start - Create DBC attachment file
                                            DBCSOCreateSentSMSAttachmentForRO("", ROMasterModel.ROCode, "MIS Daily Report status :" + RO.ROName);

                                            AttachmentPaths[0] = filePath + "\\" + "DBCSADailyReport.xlsx";

                                            BusinessCont.SaveLog(0, 100, "DBCSADailyReport File Path", null, BusinessCont.SuccessStatus, AttachmentPaths[0]);
                                            #endregion End - Create DBC attachment file
                                        }

                                        // Suraksha
                                        if (ROMasterModel.IsSuraksha == "Y")
                                        {
                                            #region Start - Create suraksha attachment file
                                            SurakshaSOCreateSentAttachmentForRO("", ROMasterModel.ROCode, "MIS Daily Report status :" + RO.ROName);

                                            AttachmentPaths1[0] = filePath + "\\" + "SurakshaSADailyReport.xlsx";

                                            BusinessCont.SaveLog(0, 100, "SurakshaSADailyReport File Path", null, BusinessCont.SuccessStatus, AttachmentPaths1[0]);
                                            #endregion End - Create suraksha attachment file

                                            #region Start - InsertedtablesDetailsSASuraksha
                                            InsertedtablesDetailsSASuraksha = GetSurakshaCampaignReport(ROMasterModel.ROCode);
                                            #endregion End - InsertedtablesDetailsSASuraksha
                                        }

                                        if (ROMasterModel.IsDBC == "Y" || ROMasterModel.IsSuraksha == "Y")
                                        {
                                            BusinessCont.SaveLog(0, 0, "DBC/Suraksha RO Email:  " + ROEmail, DateTime.Now.ToLongTimeString(), "Start", "");

                                            SendMail = model.DailySchedulerEmail(ROEmail, CCEmail, BCCEmail, "MIS DBC/Suraksha Summary Data : " + RO.ROName + " - " + DateTime.Now.ToString("dd/MM/yyyy"), InsertedtablesDetailsSA, InsertedtablesDetails, InsertedtablesDetailsSASuraksha, AttachmentPaths1, AttachmentPaths);

                                            BusinessCont.SaveLog(0, 0, "DBC/Suraksha RO Email:  " + ROEmail, DateTime.Now.ToLongTimeString(), "End", "");

                                            //SendMail = model.DailySchedulerEmail(ROEmail, CCEmail, "sancheet@gmail.com;nayankakade@aadyamconsultant.com;rajendra@aadyamconsultant.com", "MIS DBC/Suraksha Summary Data : " + RO.ROName + " - " + DateTime.Now.ToString("dd/MM/yyyy"), InsertedtablesDetailsSA, InsertedtablesDetails, "", null, AttachmentPaths);
                                        }

                                        #region Start - SendMail
                                        if (SendMail == true)
                                            ReturnValue = 1;
                                        else
                                            ReturnValue = 0;
                                        #endregion End - SendMail
                                    }
                                    #endregion End - InsertedtablesDetailsSA & InsertedtablesDetails
                                }
                            }
                        }
                    }
                    #endregion End - ROList
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "GetDBCCampaignReportPvt", null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return ReturnValue;
        }
        #endregion

        private void DBCSOCreateSentSMSAttachmentForRO(string SACode, string ROCode, string SAName)
        {
            int srno = 1, srno1 = 1;
            string ExcelName = string.Empty, filePath = string.Empty, FinalPath = string.Empty;
            List<DBCExcelAdminModelSA> listSA = new List<DBCExcelAdminModelSA>(); // sawise
            List<DBCExcelAdminModel> listDist = new List<DBCExcelAdminModel>(); // distwise
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    var workbook = new XLWorkbook();

                    #region Start - sawise
                    listSA = _Context.usp_SBCMessageSendSummaryData("0", ROCode, "sawise").Select(x => new DBCExcelAdminModelSA()
                    {
                        srno = srno++,
                        //SACode = x.SACode,
                        SAName = x.SAName,
                        //JDEDistributorCode = x.JDEDistributorCode,
                        //DistributorName = x.DistributorName,
                        //TotalConsumer = x.TotalConsumer,
                        //ConsumerProcessed = x.ConsumerProcessed,
                        MessageSend = x.MessageSend,
                        //ConsumerBalance = x.ConsumerBalance,
                        Interested = x.Interested,
                        InterestedPercent = x.InterestedPercent,
                        //NotInterestedCount = x.NotInterestedCount,
                        ConnectionReleased = x.ConnectionReleased
                        //MessageRead = x.MessageRead,
                        //Contacted = x.Contacted,
                        //PendingForContact = x.PendingForContact
                    }).ToList();

                    if (listSA.Count > 0)
                    {
                        var wsDetailedDataSA = workbook.AddWorksheet("SalesAreaWise");
                        wsDetailedDataSA.Cell(1, 1).InsertTable(listSA);
                        wsDetailedDataSA.Tables.FirstOrDefault().ShowAutoFilter = false;
                        wsDetailedDataSA.ColumnWidth = 20;
                        wsDetailedDataSA.Column(3).AdjustToContents();
                        //wsDetailedDataSA.Column(3).Width = 20;
                        wsDetailedDataSA.Cell(1, 1).Value = "Sr. No";
                        //wsDetailedDataSA.Cell(1, 2).Value = "SA Code";
                        wsDetailedDataSA.Cell(1, 2).Value = "SA Name";
                        //wsDetailedDataSA.Cell(1, 4).Value = "Distributor Code";
                        //wsDetailedDataSA.Cell(1, 5).Value = "Distributor Name";
                        //wsDetailedDataSA.Cell(1, 6).Value = "Total Consumer";
                        wsDetailedDataSA.Cell(1, 3).Value = "Msg sent as of Date";
                        //wsDetailedDataSA.Cell(1, 8).Value = "Balance Consumer";
                        //wsDetailedDataSA.Cell(1, 9).Value = "Message Send";
                        wsDetailedDataSA.Cell(1, 4).Value = "Interested";
                        wsDetailedDataSA.Cell(1, 5).Value = "% Interested";
                        //wsDetailedDataSA.Cell(1, 11).Value = "Not Interested";
                        wsDetailedDataSA.Cell(1, 6).Value = "Connection Released";
                        //wsDetailedDataSA.Cell(1, 13).Value = "Message Read";
                        //wsDetailedDataSA.Cell(1, 14).Value = "Contacted";
                        //wsDetailedDataSA.Cell(1, 15).Value = "Pending For Contact";
                    }
                    #endregion End - sawise

                    #region Start - distwise
                    listDist = _Context.usp_SBCMessageSendSummaryData("0", ROCode, "distwise").Select(x => new DBCExcelAdminModel()
                    {
                        srno = x.SAName == "Total :" ? srno1 = 1 : srno1++,
                        SACode = x.SACode,
                        SAName = x.SAName,
                        JDEDistributorCode = x.JDEDistributorCode,
                        DistributorName = x.DistributorName,
                        TotalConsumer = x.TotalConsumer,
                        //ConsumerProcessed = x.ConsumerProcessed,
                        MessageSend = x.MessageSend,
                        ConsumerBalance = x.ConsumerBalance,
                        Interested = x.Interested,
                        InterestedPercent = x.InterestedPercent,
                        NotInterestedCount = x.NotInterestedCount,
                        ConnectionReleased = x.ConnectionReleased,
                        MessageRead = x.MessageRead,
                        Contacted = x.Contacted,
                        PendingForContact = x.PendingForContact
                    }).ToList();

                    if (listDist.Count > 0)
                    {
                        var datalistnew = listDist.GroupBy(x => x.SACode).ToList();
                        var groupedCustomerList = listDist
                                .GroupBy(u => u.SACode)
                                .Select(grp => grp.ToList())
                                .ToList();
                        int ik = 0;
                        foreach (var items in datalistnew)
                        {
                            var wsDetailedData = workbook.AddWorksheet(groupedCustomerList[ik][0].SAName);
                            wsDetailedData.Cell(1, 1).InsertTable(items.ToList());
                            wsDetailedData.Tables.FirstOrDefault().ShowAutoFilter = false;
                            wsDetailedData.ColumnWidth = 20;
                            wsDetailedData.Column(3).AdjustToContents();
                            //wsDetailedData.Column(3).Width = 20;
                            wsDetailedData.Cell(1, 1).Value = "Sr. No";
                            wsDetailedData.Cell(1, 2).Value = "SA Code";
                            wsDetailedData.Cell(1, 3).Value = "SA Name";
                            wsDetailedData.Cell(1, 4).Value = "Distributor Code";
                            wsDetailedData.Cell(1, 5).Value = "Distributor Name";
                            wsDetailedData.Cell(1, 6).Value = "Total Consumer";
                            wsDetailedData.Cell(1, 7).Value = "Msg sent as of Date";
                            wsDetailedData.Cell(1, 8).Value = "Balance Consumer";
                            //wsDetailedData.Cell(1, 9).Value = "Message Send";
                            wsDetailedData.Cell(1, 9).Value = "Interested";
                            wsDetailedData.Cell(1, 10).Value = "% Interested";
                            wsDetailedData.Cell(1, 11).Value = "Not Interested";
                            wsDetailedData.Cell(1, 12).Value = "Connection Released";
                            wsDetailedData.Cell(1, 13).Value = "Message Read";
                            wsDetailedData.Cell(1, 14).Value = "Contacted";
                            wsDetailedData.Cell(1, 15).Value = "Pending For Contact";

                            wsDetailedData.Column(16).Hide();
                            wsDetailedData.Column(17).Hide();
                            wsDetailedData.Column(18).Hide();
                            wsDetailedData.Column(19).Hide();
                            wsDetailedData.Column(20).Hide();
                            wsDetailedData.Column(21).Hide();
                            wsDetailedData.Column(22).Hide();
                            wsDetailedData.Column(23).Hide();
                            wsDetailedData.Column(24).Hide();
                            wsDetailedData.Column(25).Hide();
                            ik++;
                        }
                    }
                    #endregion End - distwise

                    #region Start - workbook.SaveAs
                    ExcelName = "DBCSADailyReport.xlsx";
                    filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\");
                    FinalPath = filePath + "\\" + ExcelName;
                    BusinessCont.SaveLog(0, 100, "DBCSADailyReport Save File Path", null, BusinessCont.SuccessStatus, FinalPath);
                    workbook.SaveAs(FinalPath);
                    #endregion End - workbook.SaveAs
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "SO Excel ", "", "Fail", BusinessCont.ExceptionMsg(ex));
            }
        }

        #region Start - SurakshaSOCreateSentAttachmentForRO
        private void SurakshaSOCreateSentAttachmentForRO(string SACode, string ROCode, string SAName)
        {
            int srno = 1, srno1 = 1;
            string ExcelName = string.Empty, filePath = string.Empty, FinalPath = string.Empty;
            List<SurakshaExcelAdminModelSA> listSA = new List<SurakshaExcelAdminModelSA>(); // sawise
            List<SurakshaExcelAdminModel> listDist = new List<SurakshaExcelAdminModel>(); // distwise
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    var workbook = new XLWorkbook();

                    #region Start - sawise
                    listSA = _Context.usp_SurakshaMessageSendSummaryData("0", ROCode, "sawise").Select(x => new SurakshaExcelAdminModelSA()
                    {
                        srno = srno++,
                        SAName = x.SAName,
                        MessageSend = x.MessageSend,
                        Interested = x.Interested,
                        InterestedPercent = x.InterestedPercent,
                        MIDone = x.MIDone,
                        SurakshaChanged = x.SurakshaChanged,
                        Both = x.Both
                    }).ToList();

                    if (listSA.Count > 0)
                    {
                        var wsDetailedDataSA = workbook.AddWorksheet("SalesAreaWise");
                        wsDetailedDataSA.Cell(1, 1).InsertTable(listSA);
                        wsDetailedDataSA.Tables.FirstOrDefault().ShowAutoFilter = false;
                        wsDetailedDataSA.ColumnWidth = 20;
                        wsDetailedDataSA.Column(3).AdjustToContents();
                        wsDetailedDataSA.Cell(1, 1).Value = "Sr. No";
                        wsDetailedDataSA.Cell(1, 2).Value = "SA Name";
                        wsDetailedDataSA.Cell(1, 3).Value = "Msg sent as of Date";
                        wsDetailedDataSA.Cell(1, 4).Value = "Interested";
                        wsDetailedDataSA.Cell(1, 5).Value = "% Interested";
                        wsDetailedDataSA.Cell(1, 6).Value = "MI Done";
                        wsDetailedDataSA.Cell(1, 7).Value = "Suraksha Changed";
                        wsDetailedDataSA.Cell(1, 8).Value = "MI + Suraksha";
                    }
                    #endregion End - sawise

                    #region Start - distwise
                    listDist = _Context.usp_SurakshaMessageSendSummaryData("0", ROCode, "distwise").Select(x => new
                      SurakshaExcelAdminModel()
                    {
                        srno = x.SAName == "Total :" ? srno1 = 1 : srno1++,
                        SACode = x.SACode,
                        SAName = x.SAName,
                        JDEDistributorCode = x.JDEDistributorCode,
                        DistributorName = x.DistributorName,
                        TotalConsumer = x.TotalConsumer,
                        MessageSend = x.MessageSend,
                        ConsumerBalance = x.ConsumerBalance,
                        Interested = x.Interested,
                        InterestedPercent = x.InterestedPercent,
                        NotInterestedCount = x.NotInterestedCount,
                        MessageRead = x.MessageRead,
                        Contacted = x.Contacted,
                        PendingForContact = x.PendingForContact,
                        MIDone = x.MIDone,
                        SurakshaChanged = x.SurakshaChanged,
                        Both = x.Both
                    }).ToList();

                    if (listDist.Count > 0)
                    {
                        var datalistnew = listDist.GroupBy(x => x.SACode).ToList();
                        var groupedCustomerList = listDist
                               .GroupBy(u => u.SACode)
                               .Select(grp => grp.ToList())
                               .ToList();
                        int ik = 0;
                        foreach (var items in datalistnew)
                        {
                            var wsDetailedData = workbook.AddWorksheet(groupedCustomerList[ik][0].SAName);
                            wsDetailedData.Cell(1, 1).InsertTable(items.ToList());
                            wsDetailedData.Tables.FirstOrDefault().ShowAutoFilter = false;
                            wsDetailedData.ColumnWidth = 20;
                            wsDetailedData.Column(3).AdjustToContents();
                            wsDetailedData.Cell(1, 1).Value = "Sr. No";
                            wsDetailedData.Cell(1, 2).Value = "SA Code";
                            wsDetailedData.Cell(1, 3).Value = "SA Name";
                            wsDetailedData.Cell(1, 4).Value = "Distributor Code";
                            wsDetailedData.Cell(1, 5).Value = "Distributor Name";
                            wsDetailedData.Cell(1, 6).Value = "Total Consumer";
                            wsDetailedData.Cell(1, 7).Value = "Msg sent as of Date";
                            wsDetailedData.Cell(1, 8).Value = "Balance Consumer";
                            wsDetailedData.Cell(1, 9).Value = "Interested";
                            wsDetailedData.Cell(1, 10).Value = "% InterestedPercent";
                            wsDetailedData.Cell(1, 11).Value = "Not Interested";
                            wsDetailedData.Cell(1, 12).Value = "Message Read";
                            wsDetailedData.Cell(1, 13).Value = "Contacted";
                            wsDetailedData.Cell(1, 14).Value = "Pending For Contact";
                            wsDetailedData.Cell(1, 15).Value = "MI Done";
                            wsDetailedData.Cell(1, 16).Value = "Suraksha Changed";
                            wsDetailedData.Cell(1, 17).Value = "MI + Suraksha";

                            wsDetailedData.Column(18).Hide();
                            wsDetailedData.Column(19).Hide();
                            wsDetailedData.Column(20).Hide();
                            wsDetailedData.Column(21).Hide();
                            wsDetailedData.Column(22).Hide();
                            wsDetailedData.Column(23).Hide();
                            wsDetailedData.Column(24).Hide();
                            wsDetailedData.Column(25).Hide();
                            wsDetailedData.Column(26).Hide();
                            wsDetailedData.Column(27).Hide();
                            ik++;
                        }
                    }
                    #endregion End - distwise

                    #region Start - workbook.SaveAs
                    ExcelName = "SurakshaSADailyReport.xlsx";
                    filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\");
                    FinalPath = filePath + "\\" + ExcelName;
                    BusinessCont.SaveLog(0, 100, "SurakshaSADailyReport Save File Path", null, BusinessCont.SuccessStatus, FinalPath);
                    workbook.SaveAs(FinalPath);
                    #endregion End - workbook.SaveAs
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "SurakshaSOCreateSentAttachmentForRO", "", "Fail", BusinessCont.ExceptionMsg(ex));
            }
        }
        #endregion End - SurakshaSOCreateSentAttachmentForRO

        #region Start - Get Suraksha Campaign Report
        public string GetSurakshaCampaignReport(string ROCode)
        {
            return GetSurakshaCampaignReportPvt(ROCode);
        }
        private string GetSurakshaCampaignReportPvt(string ROCode)
        {
            string InsertedtablesDetailsSASuraksha = string.Empty, InsertedtablesDetailsSA = string.Empty, Table = string.Empty;
            int TotalMessageSend = 0, TotalInterested = 0, TotalNotInterestedCount = 0, TotalMIDone = 0, TotalSurakshaChanged = 0, TotalBoth = 0;
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    var data = _Context.usp_SurakshaMessageSendSummaryData("0", ROCode, "sawise").ToList();
                    if (data.Count > 0)
                    {
                        Table = "";
                        InsertedtablesDetailsSA = "";
                        TotalMessageSend = 0; TotalInterested = 0; TotalNotInterestedCount = 0;
                        TotalMIDone = 0; TotalSurakshaChanged = 0; TotalBoth = 0;

                        Table += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse; width:100 %;white-space:nowrap;'>";
                        Table += "<thead><tr style='font-size:14px;'>";
                        Table += "<th style='border: 1px solid grey;padding: 5px;'> Sr.No </th>";
                        Table += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area </th>";
                        Table += "<th style='border: 1px solid grey;padding: 5px;'> Sum of Msg sent as of Date </th>";
                        Table += "<th style='border: 1px solid grey;padding: 5px;'> Sum of Interested </th>";
                        Table += "<th style='border: 1px solid grey;padding: 5px;'> Average of % Interested </th>";
                        Table += "<th style='border: 1px solid grey;padding: 5px;'> MI Done </th>";
                        Table += "<th style='border: 1px solid grey;padding: 5px;'> Suraksha Hose Changed </th>";
                        Table += "<th style='border: 1px solid grey;padding: 5px;'> MI + Suraksha </th>";
                        Table += "</tr></thead><tbody>";

                        int Count = 1;
                        InsertedtablesDetailsSA += Table;
                        for (int i = 0; i < data.Count; i++)
                        {
                            InsertedtablesDetailsSA += "<tr style='font-size:14px;'>";
                            InsertedtablesDetailsSA += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + Count +
                                     "</td>";
                            InsertedtablesDetailsSA += "<td style='border: 1px solid grey;padding: 5px;'>" + data[i].SAName + "</td>";
                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].MessageSend + "</td>";
                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].Interested +
                                     "</td>";
                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].InterestedPercent +
                                     "</td>";
                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].MIDone +
                                     "</td>";
                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].SurakshaChanged +
                                 "</td>";
                            InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].Both +
                                 "</td>";
                            InsertedtablesDetailsSA += "</tr>";

                            TotalMessageSend += Convert.ToInt32(data[i].MessageSend);
                            TotalInterested += Convert.ToInt32(data[i].Interested);
                            TotalNotInterestedCount += Convert.ToInt32(data[i].InterestedPercent);
                            TotalMIDone += Convert.ToInt32(data[i].MIDone);
                            TotalSurakshaChanged += Convert.ToInt32(data[i].SurakshaChanged);
                            TotalBoth += Convert.ToInt32(data[i].Both);

                            Count++;
                        }
                        InsertedtablesDetailsSA += "</tbody></table>";
                    }
                }
                if (InsertedtablesDetailsSA != "" && InsertedtablesDetailsSA != null)
                {
                    InsertedtablesDetailsSASuraksha = InsertedtablesDetailsSA;
                }
                else
                {
                    BusinessCont.SaveLog(0, 0, "InsertedtablesDetailsSA", "", "Fail", "");
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "GetSurakshaCampaignReportPvt", null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return InsertedtablesDetailsSASuraksha;
        }
        #endregion End - Get Suraksha Campaign Report

        #region ARB Campaign Report
        public int GetARBmpaignReport()
        {
            return GetARBmpaignReportPvt();
        }
        private int GetARBmpaignReportPvt()
        {
            int ReturnValue = 0;
            try
            {
#pragma warning disable CS0219 // The variable 'TotalConsumerProcessed' is assigned but its value is never used
                int TotalConsumers = 0, TotalConsumerProcessed = 0, TotalConsumerBalance = 0, TotalMessageSend = 0, Count = 1,
#pragma warning restore CS0219 // The variable 'TotalConsumerProcessed' is assigned but its value is never used
                    TotalInterested = 0, TotalNotInterestedCount = 0, TotalConnectionReleased = 0, TotalMesageRead = 0,
                    TotalContacted = 0, TotalPendingForContacted = 0, srno = 1, srno1 = 1;

#pragma warning disable CS0219 // The variable 'MessageReadPercent' is assigned but its value is never used
#pragma warning disable CS0219 // The variable 'ConnectionReleasedPercent' is assigned but its value is never used
#pragma warning disable CS0219 // The variable 'IntPerPercentage' is assigned but its value is never used
                decimal IntPerPercentage = 0, ConnectionReleasedPercent = 0, MessageReadPercent = 0;
#pragma warning restore CS0219 // The variable 'IntPerPercentage' is assigned but its value is never used
#pragma warning restore CS0219 // The variable 'ConnectionReleasedPercent' is assigned but its value is never used
#pragma warning restore CS0219 // The variable 'MessageReadPercent' is assigned but its value is never used

                string CCEmail = Convert.ToString(ConfigurationManager.AppSettings["CCEmail"]);
                string BCCEmail = Convert.ToString(ConfigurationManager.AppSettings["BCCEmail"]);
                
                EmailSending model = new EmailSending();
                List<ROMasterModel> ROList = new List<ROMasterModel>();
                ROMasterModel ROMasterModel = new ROMasterModel();
                MastersManager mastersManager = new MastersManager();
                List<ARBExcelAdminModelSA> listSA = new List<ARBExcelAdminModelSA>();
                List<ARBExcelAdminModel> list = new List<ARBExcelAdminModel>();
                string InsertedtablesDetails = "", InsertedtablesDetailsSA = "", MainEmailBody = string.Empty, Table = string.Empty,
                TableDist = string.Empty, ROEmail = string.Empty;

                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\");

                ROList = mastersManager.GetROMasterList();

                if (ROList != null && ROList.Any())
                {
                    foreach (var RO in ROList)
                    {
                        using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                        {
                            // Role and RoCode wise MIS Send
                            ROMasterModel = mastersManager.GetROMasterListByCode(RO.ROCode).FirstOrDefault();

                            if (ROMasterModel != null)
                            {
                                ROEmail = ROMasterModel.Email;

                                if (string.IsNullOrWhiteSpace(ROEmail))
                                    continue;   //Dont process RO if email not available

                                listSA = _Context.usp_ARBMessageSendSummaryData("0", RO.ROCode, "sawise").Select(x => new ARBExcelAdminModelSA()
                                {
                                    srno = srno++,
                                    SAName = x.SAName,
                                    //ConsumerProcessed = x.ConsumerProcessed,
                                    MessageSend = x.MessageSend,
                                    Interested = x.Interested,
                                    InterestedPercent = x.InterestedPercent,
                                    ARBDone = x.ARBDone
                                }).ToList();

                                if (listSA.Count > 0)
                                {
                                    Table = "";
                                    InsertedtablesDetailsSA = "";
                                    TotalConsumerProcessed = 0; TotalMessageSend = 0; TotalInterested = 0; TotalNotInterestedCount = 0; TotalConnectionReleased = 0; IntPerPercentage = 0;

                                    Table += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse; width:100 %;white-space:nowrap;'>";
                                    Table += "<thead><tr style='font-size:14px;'>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'>Sr.No</th>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area</th>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'>Sum of Msg sent as of Date</th>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'> Sum of Interested </th>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'> Average of % Interested </th>";
                                    Table += "<th style='border: 1px solid grey;padding: 5px;'> ARB Done </th>";
                                    Table += "</tr></thead><tbody>";

                                    InsertedtablesDetailsSA += Table;
                                    for (int i = 0; i < listSA.Count; i++)
                                    {

                                        InsertedtablesDetailsSA += "<tr style='font-size:14px;'>";
                                        InsertedtablesDetailsSA += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + Count +
                                                 "</td>";
                                        InsertedtablesDetailsSA += "<td style='border: 1px solid grey;padding: 5px;'>" + listSA[i].SAName + "</td>";
                                        InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + listSA[i].MessageSend +
                                                 "</td>";
                                        InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + listSA[i].Interested +
                                                 "</td>";
                                        InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + listSA[i].InterestedPercent +
                                                 "</td>";
                                        InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + listSA[i].ARBDone +
                                                 "</td>";
                                        InsertedtablesDetailsSA += "</tr>";

                                        //TotalConsumerProcessed += Convert.ToInt32(listSA[i].ConsumerProcessed);
                                        TotalMessageSend += Convert.ToInt32(listSA[i].MessageSend);
                                        TotalInterested += Convert.ToInt32(listSA[i].Interested);
                                        TotalNotInterestedCount += Convert.ToInt32(listSA[i].InterestedPercent);
                                        TotalConnectionReleased += Convert.ToInt32(listSA[i].ARBDone);
                                        Count++;
                                    }
                                    InsertedtablesDetailsSA += "</tbody></table>";
                                }

                                list = ContextManager._Context.usp_ARBMessageSendSummaryData("0", RO.ROCode, "distwise").Select(x => new ARBExcelAdminModel()
                                {
                                    srno = x.SAName == "Total :" ? srno1 = 1 : srno1++,
                                    SACode = x.SACode,
                                    SAName = x.SAName,
                                    JDEDistributorCode = x.JDEDistributorCode,
                                    DistributorName = x.DistributorName,
                                    TotalConsumer = x.TotalConsumer,
                                    //ConsumerProcessed = x.ConsumerProcessed,
                                    MessageSend = x.MessageSend,
                                    ConsumerBalance = x.ConsumerBalance,
                                    Interested = x.Interested,
                                    InterestedPercent = x.InterestedPercent,
                                    NotInterestedCount = x.NotInterestedCount,
                                    //ConnectionReleased = x.ConnectionReleased,
                                    MessageRead = x.MessageRead,
                                    Contacted = x.Contacted,
                                    PendingForContact = x.PendingForContact,
                                    ARBDone = x.ARBDone
                                }).ToList();

                                if (list.Count > 0)
                                {
                                    var datalistnew = list.GroupBy(x => x.SACode).ToList();

                                    var groupedCustomerList = list
                                            .GroupBy(u => u.SACode)
                                            .Select(grp => grp.ToList())
                                            .ToList();
                                    InsertedtablesDetails = "";
                                    int ik = 0;
                                    foreach (var items in datalistnew)
                                    {
                                        TableDist = "";
                                        TotalConsumers = 0; TotalConsumerProcessed = 0;
                                        TotalConsumerBalance = 0; TotalMessageSend = 0;
                                        TotalInterested = 0;
                                        TotalNotInterestedCount = 0;
                                        TotalConnectionReleased = 0;
                                        TotalMesageRead = 0;
                                        TotalContacted = 0;
                                        TotalPendingForContacted = 0; IntPerPercentage = 0;
                                        TableDist += "<h4 style='font-family: Calibri (Body);font-size: 12pt;color: #000000; background-color: #ffffff'>" + groupedCustomerList[ik][0].SAName + "</h4>";
                                        TableDist += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse; width:100 %;white-space:nowrap;'>";
                                        TableDist += "<thead><tr style='font-size:14px;'>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'>Sr.No</th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area</th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'>Distributor Code</th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Distributor Name </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Total Consumer </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Msg sent as of Date </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Balance Consumer</th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Interested </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> % Interested </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Not Interested </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> ARB Done </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Message Read </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Contacted</th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Pending For Contact</th>";
                                        TableDist += "</tr></thead><tbody>";

                                        Count = 1;
                                        InsertedtablesDetails += TableDist;

                                        foreach (var item in items)
                                        {
                                            if (items.Count() > 0)
                                            {
                                                if (item.SAName == "Total :")
                                                {
                                                    Count = 0;
                                                }

                                                InsertedtablesDetails += "<tr style='font-size:14px;'>";
                                                InsertedtablesDetails += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + Count +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + item.SAName + "</td>";

                                                InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + item.JDEDistributorCode +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + item.DistributorName +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.TotalConsumer +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.MessageSend +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.ConsumerBalance +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.Interested +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.InterestedPercent +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.NotInterestedCount +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.ARBDone +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.MessageRead +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.Contacted +
                                                         "</td>";
                                                InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + item.PendingForContact +
                                                         "</td>";
                                                InsertedtablesDetails += "</tr>";

                                                TotalConsumers += Convert.ToInt32(item.TotalConsumer);
                                                //TotalConsumerProcessed += Convert.ToInt32(item.ConsumerProcessed);
                                                TotalMessageSend += Convert.ToInt32(item.MessageSend);
                                                TotalConsumerBalance += Convert.ToInt32(item.ConsumerBalance);
                                                TotalInterested += Convert.ToInt32(item.Interested);
                                                TotalNotInterestedCount += Convert.ToInt32(item.NotInterestedCount);
                                                TotalConnectionReleased += Convert.ToInt32(item.ARBDone);
                                                TotalMesageRead += Convert.ToInt32(item.MessageRead);
                                                TotalContacted += Convert.ToInt32(item.Contacted);
                                                TotalPendingForContacted += Convert.ToInt32(item.PendingForContact);

                                                Count++;
                                            }
                                        }
                                        InsertedtablesDetails += "</tbody></table></br></br>";
                                        ik++;


                                        if (InsertedtablesDetailsSA != "" && InsertedtablesDetailsSA != null && InsertedtablesDetails != "" && InsertedtablesDetails != null)
                                        {

                                            //Create ARB attachment file
                                            ARBSOCreateSentSMSAttachmentForRO(listSA, list);

                                            //MainEmailBody = GetHtmlFileForPremise();

                                            string[] AttachmentPaths = new string[1];
                                            AttachmentPaths[0] = filePath + "\\" + "ARBSADailyReport.xlsx";

                                            BusinessCont.SaveLog(0, 100, "ARBSADailyReport File Path", null, BusinessCont.SuccessStatus, AttachmentPaths[0]);

                                            // ARB MIS Report For RAIPUR LPG RO
                                            if (ROMasterModel.IsARB == "Y")
                                            {
                                                BusinessCont.SaveLog(0, 0, "ARB MIS Report For " + ROMasterModel.ROName, DateTime.Now.ToLongTimeString(), "Start", "");

                                                SendMail = model.ARBDailySchedulerEmail(ROEmail, CCEmail, BCCEmail, "MIS ARB Summary Data : " + RO.ROName + " - " + DateTime.Now.ToString("dd/MM/yyyy"), InsertedtablesDetailsSA, InsertedtablesDetails, AttachmentPaths);

                                                BusinessCont.SaveLog(0, 0, "ARB MIS Report For " + ROMasterModel.ROName, DateTime.Now.ToLongTimeString(), "End", "");
                                            }

                                            if (SendMail == true)
                                                ReturnValue = 1;
                                            else
                                                ReturnValue = 0;
                                        }
                                    }
                                }
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "GetARBmpaignReportPvt", null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            return ReturnValue;
        }
        #endregion

        #region ARB Attachment
        private void ARBSOCreateSentSMSAttachmentForRO(List<ARBExcelAdminModelSA> listSA, List<ARBExcelAdminModel> list)
        {
#pragma warning disable CS0219 // The variable 'srno' is assigned but its value is never used
            int srno = 1;
#pragma warning restore CS0219 // The variable 'srno' is assigned but its value is never used
#pragma warning disable CS0219 // The variable 'srno1' is assigned but its value is never used
            int srno1 = 1;
#pragma warning restore CS0219 // The variable 'srno1' is assigned but its value is never used
            try
            {
                var workbook = new XLWorkbook();

                var wsDetailedDataSA = workbook.AddWorksheet("SalesAreaWise");

                wsDetailedDataSA.Cell(1, 1).InsertTable(listSA);
                wsDetailedDataSA.Tables.FirstOrDefault().ShowAutoFilter = false;
                wsDetailedDataSA.ColumnWidth = 20;
                wsDetailedDataSA.Column(3).AdjustToContents();
                wsDetailedDataSA.Cell(1, 1).Value = "Sr. No";
                wsDetailedDataSA.Cell(1, 2).Value = "SA Name";
                wsDetailedDataSA.Cell(1, 3).Value = "Msg sent as of Date";
                wsDetailedDataSA.Cell(1, 4).Value = "Interested";
                wsDetailedDataSA.Cell(1, 5).Value = "% Interested";
                wsDetailedDataSA.Cell(1, 6).Value = "ARB Done";



                var datalistnew = list.GroupBy(x => x.SACode).ToList();

                var groupedCustomerList = list
                       .GroupBy(u => u.SACode)
                       .Select(grp => grp.ToList())
                       .ToList();
                int ik = 0;

                foreach (var items in datalistnew)
                {
                    var wsDetailedData = workbook.AddWorksheet(groupedCustomerList[ik][0].SAName);
                    wsDetailedData.Cell(1, 1).InsertTable(items.ToList());
                    wsDetailedData.Tables.FirstOrDefault().ShowAutoFilter = false;
                    wsDetailedData.ColumnWidth = 20;
                    wsDetailedData.Column(3).AdjustToContents();
                    //wsDetailedData.Column(3).Width = 20;
                    wsDetailedData.Cell(1, 1).Value = "Sr. No";
                    wsDetailedData.Cell(1, 2).Value = "SA Code";
                    wsDetailedData.Cell(1, 3).Value = "SA Name";
                    wsDetailedData.Cell(1, 4).Value = "Distributor Code";
                    wsDetailedData.Cell(1, 5).Value = "Distributor Name";
                    wsDetailedData.Cell(1, 6).Value = "Total Consumer";
                    wsDetailedData.Cell(1, 7).Value = "Msg sent as of Date";
                    wsDetailedData.Cell(1, 8).Value = "Balance Consumer";
                    //wsDetailedData.Cell(1, 9).Value = "Message Send";
                    wsDetailedData.Cell(1, 9).Value = "Interested";
                    wsDetailedData.Cell(1, 10).Value = "% InterestedPercent";
                    wsDetailedData.Cell(1, 11).Value = "Not Interested";
                    wsDetailedData.Cell(1, 12).Value = "Message Read";
                    wsDetailedData.Cell(1, 13).Value = "Contacted";
                    wsDetailedData.Cell(1, 14).Value = "Pending For Contact";
                    wsDetailedData.Cell(1, 15).Value = "ARB Done";
                    //wsDetailedData.Cell(1, 16).Value = "Suraksha Changed";
                    //wsDetailedData.Cell(1, 17).Value = "MI + Suraksha";

                    wsDetailedData.Column(16).Hide();
                    wsDetailedData.Column(17).Hide();
                    wsDetailedData.Column(18).Hide();
                    wsDetailedData.Column(19).Hide();
                    wsDetailedData.Column(20).Hide();
                    wsDetailedData.Column(21).Hide();
                    wsDetailedData.Column(22).Hide();
                    wsDetailedData.Column(23).Hide();
                    wsDetailedData.Column(24).Hide();
                    wsDetailedData.Column(25).Hide();
                    ik++;
                }

                string ExcelName = "ARBSADailyReport.xlsx";

                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\");

                string FinalPath = filePath + "\\" + ExcelName;

                BusinessCont.SaveLog(0, 100, "ARBSADailyReport Save File Path", null, BusinessCont.SuccessStatus, FinalPath);

                workbook.SaveAs(FinalPath);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "ARB SO Excel ", "", "Fail", BusinessCont.ExceptionMsg(ex));
            }
        }
        #endregion

    }
}
