﻿using HPGASNCEnquiryBusiness.BusinessConstant;
using HPGASNCEnquiryBusiness.Models.Entity;
using System;
using System.Data.Entity.Core.Objects;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class ImportWatiDataManager : IDisposable
    {
        ContextManager contextManager = new ContextManager();

        #region Dispose 
        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }
        #endregion

    }
}
