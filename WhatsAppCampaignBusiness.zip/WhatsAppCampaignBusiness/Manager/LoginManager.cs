﻿using HPGASNCEnquiryBusiness.BusinessConstant;
using HPGASNCEnquiryBusiness.Models.Entity;
using HPGASNCEnquiryBusiness.Models.Login;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class LoginManager:IDisposable
    {
        #region Dispose 

        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }

        #endregion

        /// <summary>
        /// Return user details if valid user.
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        //public List<LoginUser> LoginDetails(UserModel user)
        //{
        //    return LoginDetailsPvt(user);
        //}

        ///// <summary>
        ///// Return user details if valid user.
        ///// </summary>
        ///// <param name="user"></param>
        ///// <returns></returns>
        //private List<LoginUser> LoginDetailsPvt(UserModel user)
        //{
        //    ContextManager contextManager = new ContextManager();
        //    Random random = new Random();
        //    string OTP = (random.Next(1000, 5000)).ToString();
        //    return ContextManager._Context.sp_GetLoginDetails(user.MobileNo, OTP).Select(a => new LoginUser
        //    {
        //        DistributorCode = a.DistributorCode,
        //        DistributorId = a.DistributorId,
        //        StaffAddress = a.StaffAddress,
        //        DistributorName = a.DistributorName,
        //        StaffName = a.StaffName,
        //        StaffRefNo = a.StaffRefNo,
        //        Password = OTP
        //    }).ToList();
        //}

        /// <summary>
        /// Santosh - Check user login is valid or not
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public UserLoginDetails CheckUserLogin(string username, string password)
        {
            return CheckUserLoginPvt(username, password);
        }

        /// <summary>
        /// Santosh - Check user login is valid or not
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        private UserLoginDetails CheckUserLoginPvt(string username, string password)
        {
            UserLoginDetails userLoginDetails = new UserLoginDetails();
            userLoginDetails.Status = BusinessCont.FailStatus;
            ContextManager contextManager = new ContextManager();
            try
            {
                if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
                {
                    string EncryptPassword = Clsencrypt.EncryptM(password);
                    using (var context = new ContextManager())
                    {
                        userLoginDetails.userDetails = ContextManager._Context.sp_UserAuthentication(username, EncryptPassword).Select(u => new UserLogin()
                        {
                            UserId = u.UserId,
                            RoleId = u.RoleId,
                            RoleName = u.RoleName,
                            refNo = u.refNo,
                            DisplayName = u.DisplayName,
                            UserName = u.UserName,
                            Password = u.Password,
                            EncryptPassword = u.EncryptPassword,
                            ActiveStatus = u.ActiveStatus,
                            LastUpdatedDate = u.LastUpdatedDate,
                            IsLive = u.IsLive,
                            SBCLive = u.SBCLive,
                            SurakshaLive = u.SurakshaLive,
                            ARBLive = u.ARBLive,
                            VASLive = u.VASLive,
                            EncryptUserName = ConvertStringToHex(u.UserName.Trim(), System.Text.Encoding.Unicode)
                        }).FirstOrDefault();
                    }
                    if (userLoginDetails.userDetails == null)
                        userLoginDetails.LoginStatus = "Username or password is Incorrect";
                    else
                        userLoginDetails.LoginStatus = "Success";
                    userLoginDetails.Status = BusinessCont.SuccessStatus;
                }
                else
                {
                    userLoginDetails.LoginStatus = "Username or password is null";
                }
                userLoginDetails.Status = BusinessCont.SuccessStatus;
            }
            catch (Exception ex)
            {
                userLoginDetails.LoginStatus = "Username or password is null";
                throw ex; 
            }
            return userLoginDetails;
        }


        /// <summary>
        /// Santosh - Check user login is valid or not
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public UserLoginDetails CheckUserLoginUserLoginAnotherWeb(string username, string password)
        {
            return CheckUserLoginUserLoginAnotherWebPvt(username, password);
        }

        /// <summary>
        /// Santosh - Check user login is valid or not
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        private UserLoginDetails CheckUserLoginUserLoginAnotherWebPvt(string username, string password)
        {
            UserLoginDetails userLoginDetails = new UserLoginDetails();
            userLoginDetails.Status = BusinessCont.FailStatus;
            ContextManager contextManager = new ContextManager();
            try
            {

                if (!string.IsNullOrEmpty(username))
                {
                    username = ConvertHexToString(username, System.Text.Encoding.Unicode);
                    string EncryptPassword = "";// Clsencrypt.EncryptM(password);
                    using (var context = new ContextManager())
                    {
                        userLoginDetails.userDetails = ContextManager._Context.sp_UserAuthentication(username, EncryptPassword).Select(u => new UserLogin()
                        {
                            UserId = u.UserId,
                            RoleId = u.RoleId,
                            RoleName = u.RoleName,
                            refNo = u.refNo,
                            DisplayName = u.DisplayName,
                            UserName = u.UserName,
                            Password = u.Password,
                            EncryptPassword = u.EncryptPassword,
                            ActiveStatus = u.ActiveStatus,
                            LastUpdatedDate = u.LastUpdatedDate,
                            IsLive = u.IsLive,
                            SBCLive = u.SBCLive,
                            SurakshaLive = u.SurakshaLive,
                            ARBLive = u.ARBLive,
                            VASLive = u.VASLive,
                            EncryptUserName = ConvertStringToHex(u.UserName.Trim(), System.Text.Encoding.Unicode)
                        }).FirstOrDefault();
                    }
                    if (userLoginDetails.userDetails == null)
                        userLoginDetails.LoginStatus = "Username or password is Incorrect";
                    else
                        userLoginDetails.LoginStatus = "Success";
                    userLoginDetails.Status = BusinessCont.SuccessStatus;
                }
                else
                {
                    userLoginDetails.LoginStatus = "Username or password is null";
                }
                userLoginDetails.Status = BusinessCont.SuccessStatus;
            }
            catch (Exception ex)
            {
                userLoginDetails.LoginStatus = "Username or password is null";
                throw ex;
            }
            return userLoginDetails;
        }
        public static string ConvertHexToString(String hexInput, System.Text.Encoding encoding)
        {
            int numberChars = hexInput.Length;
            byte[] bytes = new byte[numberChars / 2];
            for (int i = 0; i < numberChars; i += 2)
            {
                bytes[i / 2] = Convert.ToByte(hexInput.Substring(i, 2), 16);
            }
            return encoding.GetString(bytes);
        }
        public static string ConvertStringToHex(String input, System.Text.Encoding encoding)
        {
            Byte[] stringBytes = encoding.GetBytes(input);
            StringBuilder sbBytes = new StringBuilder(stringBytes.Length * 2);
            foreach (byte b in stringBytes)
            {
                sbBytes.AppendFormat("{0:X2}", b);
            }
            return sbBytes.ToString();
        }

        #region Reset Password of User

        public PostBackModel ResetUserPassword(ResetPassword model)
        {
            return ResetUserPasswordPR(model);
        }

        private PostBackModel ResetUserPasswordPR(ResetPassword model)
        {
            PostBackModel userLogin = new PostBackModel();

            userLogin.ResultId = 0;
            userLogin.Status = BusinessCont.FailStatus;
            ContextManager contextManager = new ContextManager();
            string jsonStaff = string.Empty;
            try
            {
                model.EncryptPwd= Clsencrypt.EncryptM(model.NewPassword);

                jsonStaff = model == null ? "" : JsonConvert.SerializeObject(model);
                ObjectParameter obj = new ObjectParameter("ResultId", typeof(long));
                ContextManager._Context.sp_ResetUserPassword(model.UserId, model.RefId, model.OldPassword, model.NewPassword, model.EncryptPwd, obj);

                if (obj != null)
                {
                    userLogin.ResultId = Convert.ToInt64(obj.Value);
                }
                userLogin.Status = BusinessCont.SuccessStatus;
            }
            catch (Exception ex)
            {
                userLogin.Status = BusinessCont.FailStatus;
                userLogin.ExMsg = BusinessCont.ExceptionMsg(ex);
                BusinessCont.SaveLog(0, 0, "Reset User Password", jsonStaff, userLogin.Status, BusinessCont.ExceptionMsg(ex));
            }
            return userLogin;
        }
        #endregion

    }

}
