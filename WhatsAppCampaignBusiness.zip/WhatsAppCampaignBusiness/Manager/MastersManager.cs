﻿using HPGASNCEnquiryBusiness.BusinessConstant;
using HPGASNCEnquiryBusiness.Models.Entity;
using HPGASNCEnquiryBusiness.Models.Masters;
using HPGASNCEnquiryBusiness.Models.RO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Core.Objects;
using System.Data.SqlClient;
using System.Linq;
using WhatsAppCampaignBusiness.Models.Entity;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class MastersManager : IDisposable
    {
        ContextManager contextManager = new ContextManager();

        #region Dispose 
        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }
        #endregion

        ///// <summary>
        ///// Return Stove and question Masters
        ///// </summary>
        ///// <returns></returns>
        //public QuestionDetails GetMasters(DistributorStaff staffDtls)
        //{
        //    QuestionDetails questionDetails = null;
        //    try
        //    {
        //        questionDetails = new QuestionDetails();
        //        questionDetails.IsUserActive = BusinessCont.InActiveStatus;
        //        questionDetails.QuestionMaster = GetMastersPvt(staffDtls.DistributorId, "ALL");
        //        questionDetails.StoveMaster = GetMastersPvt(staffDtls.DistributorId, "STOVE");
        //        using (CustomerManager customerManager = new CustomerManager())
        //        {
        //            questionDetails.Documents = customerManager.GetDocuments();
        //        }
        //        questionDetails.PSVersion = GetVersionPvt();
        //        using (DistributorManager distributorManager = new DistributorManager())
        //        {
        //            questionDetails.DashboardCounts = distributorManager.GetDistStaffDashboardCount(staffDtls.DistributorId, staffDtls.StaffRefNo);

        //            if (questionDetails.DashboardCounts.Any())
        //            {
        //                questionDetails.IsUserActive = BusinessCont.ActiveStatus;
        //            }
        //        }
        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            ContextManager._Context.sp_ActiveUser(staffDtls.DistributorId, staffDtls.StaffRefNo, staffDtls.VersionNo);
        //        }
        //        questionDetails.Status = BusinessCont.SuccessStatus;
        //    }
        //    catch (Exception ex)
        //    {
        //        questionDetails.Status = BusinessCont.FailStatus;
        //        questionDetails.ExMsg = BusinessCont.ExceptionMsg(ex);
        //        // throw;
        //    }
        //    return questionDetails;
        //}

        //public List<QuestionMaster> GetMaster(int DistributorId, string Flag)
        //{
        //    return GetMastersPvt(DistributorId, Flag);
        //}

        ///// <summary>
        ///// Return Stove and question Masters
        ///// </summary>
        ///// <returns></returns>
        //private List<QuestionMaster> GetMastersPvt(int DistributorId, string Flag)
        //{
        //    using (ContextManager contextManager = new ContextManager())
        //    {
        //        return ContextManager._Context.sp_GetQuestionMaster(DistributorId, Flag).Select(a => new QuestionMaster
        //        {
        //            EQueId = a.EQueId,
        //            EnquiryQue = a.EnquiryQue,
        //            QuestionType = a.QuestionType,
        //            Id = a.Id,
        //            StoveType = a.StoveType,
        //            Price = a.Price,
        //            DistributorCode = a.DistributorCode,
        //            DistributorName = a.DistributorName.Trim(),
        //            ContactNo = a.ContactNo,
        //            LanguageId = a.LanguageId,
        //            LanguageName = a.LanguageName
        //        }).ToList();
        //    }
        //}

        //public ConsumerDetailsForSendMsg GetConsumerDetailsForSendMsg(string MobileNo)
        //{
        //    return GetConsumerDetailsForSendMsgPvt(MobileNo);
        //}

        ///// <summary>
        ///// Return Consumer Details for send msg
        ///// </summary>
        ///// <returns></returns>
        //private ConsumerDetailsForSendMsg GetConsumerDetailsForSendMsgPvt(string MobileNo)
        //{
        //    using (ContextManager contextManager = new ContextManager())
        //    {
        //        return ContextManager._Context.sp_GetConsumerDetailsForSendMsg(MobileNo).Select(a => new ConsumerDetailsForSendMsg
        //        {
        //            DistributorId = Convert.ToInt32(a.DistributorId),
        //            QueTypeId = a.QueTypeId,
        //            StoveSubType = a.StoveSubType,
        //            StoveType = a.StoveType,
        //            ConsumerName = a.ConsumerName,
        //            DistWhatsappNo = a.DistWhatsappNo,
        //            VendorName = a.VendorName
        //        }).FirstOrDefault();
        //    }
        //}

        ///// <summary>
        ///// Return Price Masters
        ///// </summary>
        ///// <returns></returns>
        //public List<PriceDetails> GetPriceDetails(int DistributorId)
        //{
        //    return GetPriceDetailsPvt(DistributorId);
        //}

        ///// <summary>
        ///// Return Price Masters
        ///// </summary>
        ///// <returns></returns>
        //private List<PriceDetails> GetPriceDetailsPvt(int DistributorId)
        //{
        //    ContextManager contextManager = new ContextManager();
        //    try
        //    {
        //        return ContextManager._Context.sp_GetPriceDetails(DistributorId).Select(a => new PriceDetails()
        //        {
        //            ID = a.ID,
        //            EQueId = a.EQueId,
        //            EnquiryQue = a.EnquiryQue,
        //            ItemName = String.IsNullOrEmpty(a.ItemName) ? "" : a.ItemName.Trim(),
        //            ItemNameInEnglish = String.IsNullOrEmpty(a.ItemName) ? "" : a.ItemName.Trim(),
        //            ItemNameInHindi = String.IsNullOrEmpty(a.ItemNameInHindi) ? "" : a.ItemNameInHindi.Trim(),
        //            ItemNameInMarathi = String.IsNullOrEmpty(a.ItemNameInMarathi) ? "" : a.ItemNameInMarathi.Trim(),
        //            RSP = a.RSP,
        //            TotalAmount = a.TotalAmount,
        //            RSPMonthFlag = a.RSPMonthFlag
        //        }).ToList();
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //}

        ///// <summary>
        ///// Return Current play store version
        ///// </summary>
        ///// <returns></returns>
        //private string GetVersionPvt()
        //{
        //    return ContextManager._Context.sp_GetVersionDetails().FirstOrDefault();
        //}

        //#region Distributor
        //public List<DistributorDtls> GetDistributorDetails(int DistributorId)
        //{
        //    return GetDistributorDetailsPR(DistributorId);
        //}
        ///// <summary>
        ///// Get Ditributor  List 
        ///// </summary>
        ///// <returns></returns>
        //private List<DistributorDtls> GetDistributorDetailsPR(int DistributorId)
        //{
        //    try
        //    {
        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            return ContextManager._Context.sp_GetDistributorMaster(DistributorId).Select(x => new DistributorDtls
        //            {
        //                DistributorId = x.DistributorId,
        //                DistributorName = x.DistributorName,
        //                Email = x.Email,
        //                IsDistributorLive = x.IsDistributorLive,
        //                JDEDistributorCode = x.JDEDistributorCode,
        //                MobileNo = x.MobileNo,
        //                OwnerName = x.OwnerName,
        //                EmergencyContactNo = x.EmergencyContactNo,
        //                PhoneNo = x.PhoneNo
        //            }).ToList();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        //#endregion

        //#region Distributor Staff

        ///// <summary>
        ///// Get Ditributor Staff List 
        ///// </summary>
        ///// <param name="StaffRefNo"></param>
        ///// <param name="DistributorId"></param>
        ///// <param name="Status"></param>
        ///// <returns></returns>
        //public List<DistributorStaff> GetDistributorStaffDetails(long StaffRefNo, int DistributorId, string Status)
        //{
        //    return GetDistributorStaffDetailsPR(StaffRefNo, DistributorId, Status);
        //}

        ///// <summary>
        ///// Get Ditributor Staff List 
        ///// </summary>
        ///// <param name="StaffRefNo"></param>
        ///// <param name="DistributorId"></param>
        ///// <param name="Status"></param>
        ///// <returns></returns>
        //private List<DistributorStaff> GetDistributorStaffDetailsPR(long StaffRefNo, int DistributorId, string Status)
        //{
        //    try
        //    {
        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            return ContextManager._Context.sp_GetDistributorStaffMaster(StaffRefNo, DistributorId, Status).Select(x => new DistributorStaff
        //            {
        //                StaffRefNo = x.StaffRefNo,
        //                StaffType = x.StaffType,
        //                StaffName = x.StaffName,
        //                DistributorId = x.DistributorId,
        //                MobileNo = x.MobileNo,
        //                OTP = x.OTP,
        //                StaffAddress = x.StaffAddress,
        //                LastUpdateDateTime = BusinessCont.CheckNullandConvertDateTime(x.LastUpdateDateTime),
        //                ActiveStatus = x.ActiveStatus,
        //                ActiveFrom = BusinessCont.CheckNullandConvertDateTime(x.ActiveFrom),
        //                VersionNo = x.VersionNo,
        //                IsEnquiryActive = x.IsEnquiryActive,
        //                IsInactiveConsActive = x.IsInactiveConsActive,
        //            }).ToList();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        ///// <summary>
        ///// Add and Edit Distributor Staff Details
        ///// </summary>
        ///// <param name="distributorStaff"></param>
        ///// <returns></returns>
        //public long AddEditDistributorStaffDetails(DistributorStaff distributorStaff)
        //{
        //    return AddEditDistributorStaffDetailsPR(distributorStaff);
        //}
        ///// <summary>
        ///// Add and Edit Distributor Staff Details
        ///// </summary>
        ///// <param name="distributorStaff"></param>
        ///// <returns></returns>
        //private long AddEditDistributorStaffDetailsPR(DistributorStaff distributorStaff)
        //{
        //    long StaffRefNo = 0;
        //    ObjectParameter objParam = new ObjectParameter("Result", typeof(long));
        //    try
        //    {
        //        if (distributorStaff.IsInactiveConsActive == null)
        //            distributorStaff.IsInactiveConsActive = false;

        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            ContextManager._Context.sp_AddEditDistributorStaffMaster(distributorStaff.StaffRefNo, distributorStaff.StaffType, distributorStaff.DistributorId, distributorStaff.StaffName,
        //                                                                 distributorStaff.StaffAddress, distributorStaff.MobileNo, distributorStaff.OTP, distributorStaff.ActiveStatus, distributorStaff.UserId,
        //                                                                 distributorStaff.IsEnquiryActive, distributorStaff.IsInactiveConsActive, distributorStaff.Operation, objParam);
        //        }
        //        if (objParam != null)
        //        {
        //            StaffRefNo = Convert.ToInt64(objParam.Value);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return StaffRefNo;
        //}

        //#endregion

        //#region Distributor Connection Type Price nk

        ///// <summary>
        ///// Get distributor Connection Type Price List
        ///// </summary>
        ///// <param name="DistributorId"></param>
        ///// <returns></returns>
        //public DistConnType GetDistributorConnTypePrice(int DistributorId)
        //{
        //    return GetDistributorConnTypePricePR(DistributorId);
        //}

        ///// <summary>
        ///// Get distributor Connection Type Price List
        ///// </summary>
        ///// <param name="DistributorId"></param>
        ///// <returns></returns>
        //private DistConnType GetDistributorConnTypePricePR(int DistributorId)
        //{
        //    try
        //    {
        //        return ContextManager._Context.sp_GetDistributorConnTypePrice(DistributorId).Select(x => new DistConnType()
        //        {
        //            PId = x.PId,
        //            RSP = x.RSP,
        //            ActiveStatus = x.ActiveStatus,
        //            ContactNo = x.ContactNo,
        //        }).FirstOrDefault();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        ///// <summary>
        ///// Add Edit distributor Connection Type Price details
        ///// </summary>
        ///// <param name="distConnType"></param>
        ///// <returns></returns>
        //public long AddEditDistConnTypePriceDtls(DistConnType distConnType)
        //{
        //    return AddEditDistConnTypePriceDtlsPR(distConnType);
        //}

        ///// <summary>
        ///// Add Edit distributor Connection Type Price details
        ///// </summary>
        ///// <param name="distConnType"></param>
        ///// <returns></returns>
        //private long AddEditDistConnTypePriceDtlsPR(DistConnType distConnType)
        //{
        //    long CId = 0;
        //    ObjectParameter obj = new ObjectParameter("Result", typeof(long));
        //    try
        //    {
        //        ContextManager._Context.sp_AddEditDistributorConnTypePrice(distConnType.PId, distConnType.DistributorId, distConnType.RSP, distConnType.ContactNo, distConnType.ActiveStatus, distConnType.Flag, obj);
        //        if (obj != null)
        //        {
        //            CId = Convert.ToInt64(obj.Value);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return CId;
        //}

        //#endregion
        ///// <summary>
        ///// Add Edit distributor Connection Type Price details
        ///// </summary>
        ///// <param name="distConnType"></param>
        ///// <returns></returns>
        //public long AddEditDistConnTypePriceDtls(DistConnType distConnType)
        //{
        //    return AddEditDistConnTypePriceDtlsPR(distConnType);
        //}

        ///// <summary>
        ///// Add Edit distributor Connection Type Price details
        ///// </summary>
        ///// <param name="distConnType"></param>
        ///// <returns></returns>
        //private long AddEditDistConnTypePriceDtlsPR(DistConnType distConnType)
        //{
        //    long CId = 0;
        //    ObjectParameter obj = new ObjectParameter("Result", typeof(long));
        //    try
        //    {
        //        ContextManager._Context.sp_AddEditDistributorConnTypePrice(distConnType.PId, distConnType.DistributorId, distConnType.RSP, distConnType.ContactNo, distConnType.ActiveStatus, distConnType.Flag, obj);
        //        if (obj != null)
        //        {
        //            CId = Convert.ToInt64(obj.Value);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return CId;
        //}


        //#region Stove Item Master
        ///// <summary>
        /////  get stove Type
        ///// </summary>
        ///// <returns></returns>
        //public List<StoveItemDtls> GetStoveTypeDtls()
        //{
        //    return GetStoveTypeDtlsPR();
        //}
        ///// <summary>
        /////  get stove Type
        ///// </summary>
        ///// <returns></returns>
        //private List<StoveItemDtls> GetStoveTypeDtlsPR()
        //{
        //    try
        //    {
        //        return ContextManager._Context.sp_GetStoveMaster().Select(x => new StoveItemDtls()
        //        {
        //            StoveId = x.StoveId,
        //            StoveType = x.StoveType,
        //            ActiveStatus = x.ActiveStatus,
        //            StoveTypePrice = x.Price
        //        }).ToList();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        ///// <summary>
        /////  get stove item Details
        ///// </summary>
        ///// <param name="Id"></param>
        ///// <param name="StoveId"></param>
        ///// <param name="DistributorId"></param>
        ///// <param name="Status"></param>
        ///// <returns></returns>
        //public List<StoveItemDtls> GetStoveItemDtls(long Id, long StoveId, int DistributorId, string Status)
        //{
        //    return GetStoveItemDtlsPR(Id, StoveId, DistributorId, Status);
        //}

        ///// <summary>
        /////  get stove item Details
        ///// </summary>
        ///// <param name="Id"></param>
        ///// <param name="StoveId"></param>
        ///// <param name="DistributorId"></param>
        ///// <param name="Status"></param>
        ///// <returns></returns>
        //private List<StoveItemDtls> GetStoveItemDtlsPR(long Id, long StoveId, int DistributorId, string Status)
        //{
        //    try
        //    {
        //        return ContextManager._Context.sp_GetDistributorStoveItemMaster(Id, StoveId, DistributorId, Status).Select(x => new StoveItemDtls()
        //        {
        //            DistributorId = x.DistributorId,
        //            Price = x.Price,
        //            StoveId = x.StoveId,
        //            StoveType = x.StoveType,
        //            ItemName = x.ItemName,
        //            Id = x.Id,
        //            ActiveStatus = x.ActiveStatus,
        //            LastUpdateDateTime = BusinessCont.CheckNullandConvertDateTime(x.LastUpdateDateTime),
        //            StoveTypePrice = x.StoveTypePrice
        //        }).ToList();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        ///// <summary>
        ///// Add and Edit Distributor Stove Item Details
        ///// </summary>
        ///// <param name="stoveItemDtls"></param>
        ///// <returns></returns>
        //public long AddEditStoveItemDetails(StoveItemDtls stoveItemDtls)
        //{
        //    return AddEditStoveItemDetailsPR(stoveItemDtls);
        //}
        ///// <summary>
        ///// Add and Edit Distributor Stove Item Details
        ///// </summary>
        ///// <param name="stoveItemDtls"></param>
        ///// <returns></returns>
        //private long AddEditStoveItemDetailsPR(StoveItemDtls stoveItemDtls)
        //{
        //    long StoveItemId = 0;
        //    ObjectParameter objParam = new ObjectParameter("Result", typeof(long));
        //    try
        //    {
        //        ContextManager._Context.sp_AddEditStoveItemMaster(stoveItemDtls.Id, stoveItemDtls.DistributorId, stoveItemDtls.StoveId, stoveItemDtls.ItemName, stoveItemDtls.Price, stoveItemDtls.ActiveStatus, stoveItemDtls.Operation, objParam);
        //        if (objParam != null)
        //        {
        //            StoveItemId = Convert.ToInt64(objParam.Value);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return StoveItemId;
        //}




        //#endregion

        //#region Get Language Master 

        //public LanguageModel GetLanguageMaster(int LanguageId)
        //{
        //    return GetLanguageMasterPR(LanguageId);
        //}
        //private LanguageModel GetLanguageMasterPR(int LanguageId)
        //{
        //    LanguageModel languageModel = new LanguageModel();
        //    languageModel.Status = BusinessCont.FailStatus;

        //    try
        //    {
        //        languageModel.LangList = ContextManager._Context.sp_GetLanguageMaster(LanguageId).Select(x => new LanguageMaster()
        //        {
        //            LanguageId = x.LanguageId,
        //            LanguageName = x.LanguageName,
        //            ActiveStatus = x.ActiveStatus
        //        }).ToList();

        //    }
        //    catch (Exception ex)
        //    {
        //        languageModel.ExMsg = BusinessCont.ExceptionMsg(ex);
        //        languageModel.Status = BusinessCont.FailStatus;
        //        throw ex;
        //    }
        //    return languageModel;
        //}
        //#endregion

        ///// <summary>
        /////  Delete contact details
        ///// </summary>
        ///// <returns>number of rows affected</returns>

        //public int DeleteContact(ContactDetails contactDetails)
        //{
        //    return DeleteContactPvt(contactDetails.MobileNo);
        //}
        //private int DeleteContactPvt(string MobileNo)
        //{
        //    int ConsId = 0;
        //    try
        //    {
        //        ObjectParameter ObjParamConsId = new ObjectParameter("result", typeof(Int64));

        //        using (ContextManager contextManager = new ContextManager())
        //        {
        //            ContextManager._Context.sp_DeleteContactDetails(MobileNo, ObjParamConsId);
        //        }
        //        if (ObjParamConsId != null)
        //        {
        //            ConsId = Convert.ToInt32(ObjParamConsId.Value);
        //        }
        //        return ConsId;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        ////#region Update Distributor Contact Details
        /////// <summary>
        /////// Update Distributor Contact Details
        /////// </summary>
        /////// <param name="model"></param>
        /////// <returns></returns>
        ////public int UpdateDistributorContactDetails(UpdateDistContact updateDistContact)
        ////{
        ////    return UpdateDistributorContactDetailsPvt(updateDistContact);
        ////}

        /////// <summary>
        /////// Update Distributor Contact Details
        /////// </summary>
        /////// <param name="model"></param>
        /////// <returns></returns>
        ////private int UpdateDistributorContactDetailsPvt(UpdateDistContact updateDistContact)
        ////{
        ////    int InsertedCount = 0;
        ////    try
        ////    {
        ////        ObjectParameter obj = new ObjectParameter("RetVal", typeof(long));
        ////       InsertedCount = ContextManager._Context.sp_UpdateDistibutorContactDetails(updateDistContact.DistributorId, updateDistContact.MobileNo, updateDistContact.EmergencyContactNo,updateDistContact.Email, updateDistContact.PhoneNo, obj);
        ////    }
        ////    catch (Exception ex)
        ////    {
        ////        BusinessCont.SaveLog(0, 0, "Update Distributor Contact Details", "", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
        ////    }
        ////    return InsertedCount;
        ////}
        ////#endregion

        //#region ADD Activate Campaign
        //public int ADDActivateCampaign(ActivateCampaignModel model)
        //{
        //    return ADDActivateCampaignPvt(model);
        //}
        //private int ADDActivateCampaignPvt(ActivateCampaignModel model)
        //{
        //    int RetValue = 0;
        //    string message = "";
        //    try
        //    {
        //        List<ChecklistDtlsModel> modelList = new List<ChecklistDtlsModel>();
        //        if (model.AllFlag.Count > 0) // All List 
        //        {
        //            for (int i = 0; i < model.AllFlag.Count; i++)
        //            {
        //                ChecklistDtlsModel checklistModel = new ChecklistDtlsModel();
        //                checklistModel.DistributorId = model.AllFlag[i].DistributorId;
        //                checklistModel.IsLive = model.AllFlag[i].IsLive;
        //                checklistModel.SBCLive = model.AllFlag[i].SBCLive;
        //                checklistModel.SurakshaLive = model.AllFlag[i].SurakshaLive;
        //                checklistModel.ARBLive = model.AllFlag[i].ARBLive;
        //                checklistModel.VASLive = model.AllFlag[i].VASLive;
        //                modelList.Add(checklistModel);
        //            }

        //            DataTable dt = new DataTable();
        //            dt.Columns.Add("DistributorId");
        //            dt.Columns.Add("IsLive");
        //            dt.Columns.Add("SBCLive");
        //            dt.Columns.Add("SurakshaLive");
        //            dt.Columns.Add("ARBLive");
        //            dt.Columns.Add("VASLive");

        //            foreach (var item in modelList)
        //            {
        //                dt.Rows.Add(item.DistributorId, item.IsLive, item.SBCLive, item.SurakshaLive, item.ARBLive, item.VASLive);
        //            }

        //            using (var db = new HPGASNCEnquiryEntities())
        //            {
        //                {

        //                    SqlConnection connection = (SqlConnection)db.Database.Connection;
        //                    SqlCommand cmd = new SqlCommand("NCE.USP_DistriCampRightsAdd", connection);
        //                    cmd.CommandType = CommandType.StoredProcedure;
        //                    SqlParameter DCampRightsParameter = cmd.Parameters.AddWithValue("@DCampRights", dt);
        //                    DCampRightsParameter.SqlDbType = SqlDbType.Structured;
        //                    SqlParameter retvalueParameter = cmd.Parameters.AddWithValue("@retvalue", 0);
        //                    retvalueParameter.Direction = ParameterDirection.Output;
        //                    if (connection.State == ConnectionState.Closed)
        //                        connection.Open();
        //                    RetValue = cmd.ExecuteNonQuery();
        //                    if (connection.State == ConnectionState.Open)
        //                        connection.Close();
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, 0, "ADD Activate Campaign", "ADDActivateCampaign", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
        //    }
        //    return RetValue;
        //}
        //#endregion

        //#region Distri Camp Rights List
        //public List<DistriCampRightsList> DistriCampRightsList(string SACode)
        //{
        //    return DistriCampRightsListPvt(SACode);
        //}
        //private List<DistriCampRightsList> DistriCampRightsListPvt(string SACode)
        //{
        //    List<DistriCampRightsList> TransitDataLst = new List<DistriCampRightsList>();
        //    ContextManager contextManager = new ContextManager();
        //    try
        //    {
        //        TransitDataLst = ContextManager._Context.USP_DistriCampRightsList(SACode).Select(a => new DistriCampRightsList()
        //        {
        //            Sacode = a.Sacode,
        //            DistributorId = a.DistributorId,
        //            JDEDistributorCode = a.JDEDistributorCode,
        //            DistributorName = a.DistributorName,
        //            IsLive = a.IsLive,
        //            SBCLive = a.SBCLive,
        //            SBCCount = Convert.ToInt32(a.SBCCount),
        //            SurakshaLive = a.SurakshaLive,
        //            ARBLive = a.ARBLive,
        //            ARBCount = Convert.ToInt32(a.ARBCount),
        //            VASLive = a.VASLive,
        //            VASActiveCount = Convert.ToInt32(a.VASActiveCount),
        //            UpdatedOn = Convert.ToDateTime(a.UpdatedOn),
        //        }).ToList();
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, 0, "Distri Camp Rights List", "DistriCampRightsList", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
        //    }
        //    return TransitDataLst;
        //}

        //#endregion\

        // New 

        #region Get Distributor Details
        public List<DistributorDtls> GetDistributorDetailsList(int DistributorId)
        {
            return GetDistributorDetailsPvt(DistributorId);
        }
        private List<DistributorDtls> GetDistributorDetailsPvt(int DistributorId)
        {
            List<DistributorDtls> DistList = new List<DistributorDtls>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    DistList =_Context.sp_GetDistributorMaster(DistributorId).Select(x => new DistributorDtls
                    {
                        DistributorId = x.DistributorId,
                        DistributorName = x.DistributorName,
                        Email = x.Email,
                        IsDistributorLive = x.IsDistributorLive,
                        JDEDistributorCode = x.JDEDistributorCode,
                        MobileNo = x.MobileNo,
                        OwnerName = x.OwnerName,
                        EmergencyContactNo = x.EmergencyContactNo,
                        PhoneNo = x.PhoneNo
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Get Distributor Contact Details", "", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return DistList;
        }
        #endregion

        #region Update Distributor Contact Details
        public int UpdateDistributorContactDetails(UpdateDistContact updateDistContact)
        {
            return UpdateDistributorContactDetailsPvt(updateDistContact);
        }
        private int UpdateDistributorContactDetailsPvt(UpdateDistContact updateDistContact)
        {
            int InsertedCount = 0;
            try
            {
                ObjectParameter obj = new ObjectParameter("RetVal", typeof(long));
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    InsertedCount =_Context.sp_UpdateDistibutorContactDetails(updateDistContact.DistributorId, updateDistContact.MobileNo, updateDistContact.EmergencyContactNo, updateDistContact.Email, updateDistContact.PhoneNo, obj);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Update Distributor Contact Details", "", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return InsertedCount;
        }
        #endregion

        #region Distributor Connection Type Price
        public DistConnType GetDistributorConnTypePrice(int DistributorId)
        {
            return GetDistributorConnTypePricePR(DistributorId);
        }
        private DistConnType GetDistributorConnTypePricePR(int DistributorId)
        {
            DistConnType model = new DistConnType();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    model =_Context.sp_GetDistributorConnTypePrice(DistributorId).Select(x => new DistConnType()
                    {
                        PId = x.PId,
                        RSP = x.RSP,
                        ActiveStatus = x.ActiveStatus,
                        ContactNo = x.ContactNo
                    }).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Update Distributor Contact Details", "", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return model;
        }
        #endregion

        #region Get Call Status List
        public CallStatusList GetCallStatus(string StatusFor)
        {
            return GetCallStatusPvt(StatusFor);
        }
        private CallStatusList GetCallStatusPvt(string StatusFor)
        {
            CallStatusList callstatusModel = new CallStatusList();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    callstatusModel.CallStatusParameter =_Context.usp_GetCallStatus(StatusFor).Select(x => new CallStatusDetails()
                    {
                        Id = Convert.ToInt32(x.Id),
                        StatusName = x.StatusName,
                        Colour = x.Colour,
                        IsActive = x.IsActive,
                        LastUpdatedDatetime = (x.LastUpdatedDatetime).ToString()
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetCallStatusPvt", "", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return callstatusModel;
        }
        #endregion

        #region Start - GetROMasterList
        public List<ROMasterModel> GetROMasterList()
        {
            return GetROMasterListPvt();
        }
        private List<ROMasterModel> GetROMasterListPvt()
        {
            List<ROMasterModel> modelList = new List<ROMasterModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    modelList = _Context.usp_GetROMasterList().Select(r => new ROMasterModel()
                    {
                        ROCode = r.ROCode,
                        ROName = r.ROName,
                        ZOCode = r.ZOCode,
                        ActiveFlag = r.ActiveFlag,
                        LastUpdateBy = r.LastUpdateBy
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "GetROMasterListPvt", null, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return modelList;
        }
        #endregion End - GetROMasterList

        #region ADD Activate Campaign
        public int ADDActivateROMIS(ActivateROMISModel model)
        {
            return ADDActivateROMISPvt(model);
        }
        private int ADDActivateROMISPvt(ActivateROMISModel model)
        {
            int RetValue = 0;
            List<ChecklistDtlsROMISModel> modelList = new List<ChecklistDtlsROMISModel>();
            try
            {
                if (model.ActivateROMISFlag.Count > 0) // All List 
                {
                    for (int i = 0; i < model.ActivateROMISFlag.Count; i++)
                    {
                        ChecklistDtlsROMISModel checklistModel = new ChecklistDtlsROMISModel();
                        checklistModel.ROCode = model.ActivateROMISFlag[i].ROCode;
                        checklistModel.IsDBC = model.ActivateROMISFlag[i].IsDBC;
                        checklistModel.IsSuraksha = model.ActivateROMISFlag[i].IsSuraksha;
                        checklistModel.IsARB = model.ActivateROMISFlag[i].IsARB;
                        checklistModel.IsVAS = model.ActivateROMISFlag[i].IsVAS;
                        modelList.Add(checklistModel);
                    }

                    DataTable dt = new DataTable();
                    dt.Columns.Add("ROCode");
                    dt.Columns.Add("IsDBC");
                    dt.Columns.Add("IsSuraksha");
                    dt.Columns.Add("IsARB");
                    dt.Columns.Add("IsVAS");

                    foreach (var item in modelList)
                    {
                        dt.Rows.Add(item.ROCode, item.IsDBC, item.IsSuraksha, item.IsARB, item.IsVAS);
                    }

                    if (dt.Rows.Count > 0)
                    {
                        using (var db = new HPGASNCEnquiryEntities())
                        {
                            {
                                SqlConnection connection = (SqlConnection)db.Database.Connection;
                                SqlCommand cmd = new SqlCommand("WC.usp_ROMISRightsAdd", connection);
                                cmd.CommandType = CommandType.StoredProcedure;
                                //SqlParameter rocodeParameter = cmd.Parameters.AddWithValue("@rocode", model.ROCode);
                                //rocodeParameter.SqlDbType = SqlDbType.VarChar;
                                SqlParameter romisParameter = cmd.Parameters.AddWithValue("@romis", dt);
                                romisParameter.SqlDbType = SqlDbType.Structured;
                                SqlParameter retvalueParameter = cmd.Parameters.AddWithValue("@retvalue", 0);
                                retvalueParameter.Direction = ParameterDirection.Output;
                                if (connection.State == ConnectionState.Closed)
                                    connection.Open();
                                RetValue = cmd.ExecuteNonQuery();
                                if (connection.State == ConnectionState.Open)
                                    connection.Close();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "ADD Activate RO MIS", "ADDActivateROMISPvt", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            finally { Dispose(); }

            return RetValue;
        }
        #endregion

        #region Start - Get RO Master List By Code
        public List<ROMasterModel> GetROMasterListByCode(string ROCode)
        {
            return GetROMasterListByCodePvt(ROCode);
        }
        private List<ROMasterModel> GetROMasterListByCodePvt(string ROCode)
        {
            List<ROMasterModel> modelList = new List<ROMasterModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    modelList = _Context.usp_GetROMasterListByCode(ROCode).Select(r => new ROMasterModel()
                    {
                        ROCode = r.ROCode,
                        ROName = r.ROName,
                        ZOCode = r.ZOCode,
                        ActiveFlag = r.ActiveFlag,
                        Email = r.Email,
                        Role = r.Role,
                        IsDBC = r.IsDBC,
                        IsSuraksha = r.IsSuraksha,
                        IsARB = r.IsARB,
                        IsVAS = r.IsVAS
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "GetROMasterListByCodePvt", "RO Code:  " + ROCode, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return modelList;
        }
        #endregion End - Get RO Master List By Code

    }
}
