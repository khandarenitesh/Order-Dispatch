﻿using HPGASNCEnquiryBusiness.Models.Entity;
using HPGASNCEnquiryBusiness.Models.RO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class ROManager:IDisposable
    {
        ContextManager contextManager = new ContextManager();

        #region Dispose 

        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }

        #endregion

        /// <summary>
        /// Return SA wise count
        /// </summary>
        /// <returns></returns>
        public List<RODashboardCount> GetRODashboardCount(string ROCode)
        {
            return GetRODashboardCountPvt(ROCode);
        }

        /// <summary>
        /// Return SA wise count
        /// </summary>
        /// <returns></returns>
        private List<RODashboardCount> GetRODashboardCountPvt(string ROCode)
        {
            try
            {                
                return ContextManager._Context.sp_GetRODashboardCount(ROCode).Select(a => new RODashboardCount
                {
                    SACode = a.SACode,
                    SAName = a.SAName,
                    ActiveDist = a.ActiveDist,
                    ConnectionRels = a.ConnectionRels,
                    Enquiry = a.Enquiry,
                    YestEnquiry = a.YestEnquiry,
                    InActiveDist = a.InActiveDist,
                    TotalDist = a.TotalDist,
                    ROCode = ROCode
                }).ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        /// <summary>
        /// Return Distributor wise count
        /// </summary>
        /// <returns></returns>
        public List<RODashboardCount> GetRODashboardDistwiseCount(string ROCode)
        {
            return GetRODashboardDistwiseCountPvt(ROCode);
        }

        /// <summary>
        /// Return Distributor wise count
        /// </summary>
        /// <returns></returns>
        private List<RODashboardCount> GetRODashboardDistwiseCountPvt(string ROCode)
        {
            try
            {
                return ContextManager._Context.sp_GetRODashboardDistwiseCnt(ROCode).Select(a => new RODashboardCount
                {
                    SACode = a.SACode,
                    SAName = a.SAName,
                    DistributorId = a.DistributorId,
                    ConnectionRels = a.ConnectionRels,
                    Enquiry = a.Enquiry,
                    YestEnquiry =a.YestEnquiry,
                    DistributorName = a.DistributorName,
                    DistributorCode = a.DistributorCode,
                    ROCode = ROCode,
                    ActiveUsers=a.ActiveUsers
                }).ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public string GetROWiseTableString(string ROCode)
        {
            List<RODashboardCount> SAWiseCnt = null;
            string Table = string.Empty;            
            try
            {
                SAWiseCnt = new List<RODashboardCount>();
                SAWiseCnt = GetRODashboardCount(ROCode);

                Table += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse;width: 60%; white-space:nowrap;'>";
                Table += "<thead><tr style='font-size:14px;'>";
                Table += "<th style='border: 1px solid grey;padding: 5px;'>#</th>";
                Table += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area</th>";
                Table += "<th style='border: 1px solid grey;padding: 5px;'> Unsafe Insp </th>";
                Table += "<th style='border: 1px solid grey;padding: 5px;'> Unsafe Reallot </th>";
                Table += "<th style='border: 1px solid grey;padding: 5px;'> Realloted Completed </th>";
                Table += "</tr> </thead>";
                Table += "<tbody>";

                int TotalDist = 0;
                int TotalActiveDist = 0;
                int TotalYestEnquiry = 0;
                int TotalEnquiry = 0;
                int TotalConnectionRels = 0;
                int TotalInActiveDist = 0;

                int isrNo = 1;
                if (SAWiseCnt.Any())
                {
                    foreach (var data in SAWiseCnt)
                    {
                        Table += "<tr style='font-size:14px;'>";

                        Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + isrNo + "</td>";

                        Table += "<td style='border: 1px solid grey;padding: 5px;'>" + data.SAName + "</td>";
                        
                        Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + data.TotalDist + "</td>";
                        TotalDist += data.TotalDist;
                       
                        Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + data.ActiveDist + "</td>";
                        TotalActiveDist += data.ActiveDist;
                       
                        Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + data.YestEnquiry + "</td>";
                        TotalYestEnquiry += data.YestEnquiry;

                        Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + data.Enquiry + "</td>";
                        TotalEnquiry += data.Enquiry;

                        Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + data.ConnectionRels + "</td>";
                        TotalConnectionRels += data.ConnectionRels;

                        Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + data.InActiveDist + "</td>";
                        TotalInActiveDist += data.InActiveDist;

                        Table += "</tr>";
                        isrNo++;
                    }

                    Table += "<tr style='font-size:14px;'>";
                    Table += "<td colspan='2' style='text-align:center;border: 1px solid grey;padding: 5px;'> Total </td>";
                    Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + TotalDist + "</td>";
                    Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + TotalActiveDist + "</td>";
                    Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + TotalYestEnquiry + "</td>";
                    Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + TotalEnquiry + "</td>";
                    Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + TotalConnectionRels + "</td>";
                    Table += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + TotalInActiveDist + "</td>";
                    Table += "</tr>";
                }
                else
                {
                    Table += "<tr style='text-align:center;border: 1px solid grey;padding: 5px;'>";                    
                    Table += "<td colspan='10' style='font:italic;border: 1px solid grey;padding: 5px;'> No Records Found </td>";
                    Table += "</tr>";
                }
                Table += "</tbody></table>";
            }
            catch (Exception ex)
            {
                //log.Info(ex.Message);
                //log.Info(ex.InnerException);
            }
            finally
            {
                if (SAWiseCnt != null)
                    SAWiseCnt = null;
            }

            return Table;
        }
    }
}
