using HPGASNCEnquiryBusiness.BusinessConstant;
using HPGASNCEnquiryBusiness.Models.Entity;
using HPGASNCEnquiryBusiness.Models.RequestCatcherCall;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Text.RegularExpressions;
using RestSharp;
using RestSharp.Authenticators;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class RequestCatcherCallManager : IDisposable
    {
        ContextManager contextManager = new ContextManager();
		string exotelUserName = string.Empty, exotelPassword = string.Empty, exotelTokenKey = string.Empty, SendSMSBody = string.Empty;

		#region Dispose 
		private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }
        #endregion

        #region To Add Request Catcher Call
        public int AddRequestCatcherCall(string CallSid, string CallFrom, string CallTo, string Direction, DateTime Created, string DialCallDuration,
                                         DateTime StartTime, DateTime EndTime, string CallType, string DialWhomNumber, string flow_id, string tenant_id,
                                         DateTime CurrentTime, string digits)
        {
            return AddRequestCatcherCallPvt(CallSid, CallFrom, CallTo, Direction, Created, DialCallDuration,
                                            StartTime, EndTime, CallType, DialWhomNumber, flow_id, tenant_id, CurrentTime, digits);
        }

        private int AddRequestCatcherCallPvt(string CallSid, string CallFrom, string CallTo, string Direction, DateTime Created, string DialCallDuration,
                                             DateTime StartTime, DateTime EndTime, string CallType, string DialWhomNumber, string flow_id, string tenant_id,
                                             DateTime CurrentTime, string digits)
        {
            int InsertedCount = 0;

			try
            {
				exotelUserName = ConfigurationManager.AppSettings["ExotelUserName"];
				exotelPassword = ConfigurationManager.AppSettings["ExotelPassword"];
				exotelTokenKey = ConfigurationManager.AppSettings["ExotelTokenKey"];

				//InsertedCount = ContextManager._Context.usp_AddRequestCatcherCall(CallSid, CallFrom, CallTo, Direction, Created, DialCallDuration,
    //                            StartTime, EndTime, CallType, DialWhomNumber, flow_id, tenant_id, CurrentTime, digits);

				var result = ContextManager._Context.usp_AddRequestCatcherCall(CallSid, CallFrom, CallTo, Direction, Created, DialCallDuration,
	                            StartTime, EndTime, CallType, DialWhomNumber, flow_id, tenant_id, CurrentTime, digits).ToList();
				InsertedCount = 1;
				if (InsertedCount > 0)
				{
					var enuiryNo = result[0];
					// Hindi - Text (At the time of generation of enquiry (when a call is successfully completed))
					SendSMSBody = "प्रिय HPGas ग्राहक," + "<br />"
								+ "हैलो अप्पू में संपर्क करने के लिए धन्यवाद." + "<br />"
								+ "आपका टोकन नं  " + enuiryNo + " है. <br />"
								+ "हमारे LPG वितरक आपसे जल्द ही संपर्क करेंगे. HPRGAS";

					RestClient client = new RestClient("https://api.exotel.com/v1/Accounts/aadyamconsultant1/Sms/send");
					client.Authenticator = new HttpBasicAuthenticator(exotelUserName, exotelPassword);
					RestRequest request = new RestRequest(Method.POST);
					request.AddHeader("Authorization", "Basic " + exotelTokenKey);
					request.AddParameter("From", "HPRGAS");
					request.AddParameter("To", CallFrom);
					request.AddParameter("Body", ConvertHTMLToString(SendSMSBody));
					request.AddHeader("accept", "application/json");
					var response = client.Execute(request);
					string getResponse = response.Content;
				}
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Add Request Catcher Call", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return InsertedCount;
        }
        #endregion

        #region To Get Request Catcher Call
        public List<RequestCatcherCallModel> GetRequestCatcherCall(DateTime FromDate, DateTime ToDate)
        {
            return GetRequestCatcherCallPvt(FromDate, ToDate);
        }

        private List<RequestCatcherCallModel> GetRequestCatcherCallPvt(DateTime FromDate, DateTime ToDate)
        {
            List<RequestCatcherCallModel> data = new List<RequestCatcherCallModel>();
            RequestCatcherCallModel model = new RequestCatcherCallModel();

            try
            {
                var list = ContextManager._Context.usp_GetRequestCatcherCall(FromDate, ToDate).ToList();
                var groupList = list.ToList();
                for (int i = 0; i < groupList.Count(); i++)
                {
                    var a = groupList[i];
                    if (a.gflag == 1)
                    {
                        model = list.Where(x => x.gflag == 1).Select(x => new RequestCatcherCallModel()
                        {
                            EnquiryNo = x.EnquiryNo,
                            pkId = a.pkId,
                            CallSid = a.CallSid,
                            CallFrom = a.CallFrom,
                            CallTo = a.CallTo,
                            Direction = a.Direction,
                            Created = Convert.ToDateTime(a.Created),
                            DialCallDuration = a.DialCallDuration,
                            StartTime = Convert.ToDateTime(a.StartTime),
                            EndTime = Convert.ToDateTime(a.EndTime),
                            CallType = a.CallType,
                            DialWhomNumber = a.DialWhomNumber,
                            flow_id = a.flow_id,
                            tenant_id = a.tenant_id,
                            CurrentTime = Convert.ToDateTime(a.CurrentTime),
                            digits = a.digits,
                            IsValidPincode = a.IsValidPincode,
                            Status = a.Status,
                            DistributorName = a.DistributorName,
                            PincodeArea = a.PincodeArea,
                            DistributorId = a.DistributorId,
                            Remark = a.Remark,
                            AOHRemark = a.AOHRemark,
                            IsCallByAdmin = a.IsCallByAdmin,
                            IsCallNotAttended = a.IsCallNotAttended,
                            gflag = a.gflag.ToString()
                        }).FirstOrDefault();

                        // - Call From Group List
                        model.requestCatcherCallModelList = list.Where(y => y.CallFrom == a.CallFrom).Select(x => new RequestCatcherCallModel()
                        {
                            EnquiryNo = x.EnquiryNo,
                            pkId = x.pkId,
                            CallSid = x.CallSid,
                            CallFrom = x.CallFrom,
                            CallTo = x.CallTo,
                            Direction = x.Direction,
                            Created = Convert.ToDateTime(x.Created),
                            DialCallDuration = x.DialCallDuration,
                            StartTime = Convert.ToDateTime(x.StartTime),
                            EndTime = Convert.ToDateTime(x.EndTime),
                            CallType = x.CallType,
                            DialWhomNumber = x.DialWhomNumber,
                            flow_id = x.flow_id,
                            tenant_id = x.tenant_id,
                            CurrentTime = Convert.ToDateTime(x.CurrentTime),
                            digits = x.digits,
                            IsValidPincode = x.IsValidPincode,
                            Status = x.Status,
                            DistributorName = x.DistributorName,
                            PincodeArea = x.PincodeArea,
                            DistributorId = x.DistributorId,
                            Remark = x.Remark,
                            AOHRemark = x.AOHRemark,
                            IsCallByAdmin = x.IsCallByAdmin,
                            IsCallNotAttended = x.IsCallNotAttended
                        }).ToList();
                        data.Add(model);
                    }
                }
                return data;
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "To Get Request Catcher Call", "GetRequestCatcherCallPvt", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            return data;
        }
        #endregion

        #region To Get 5KG Appu Campaign By Distributor
        public List<RequestCatcherCallModel> Get5KGAppuCampaignByDistributor(int DistributorId, DateTime FromDate, DateTime ToDate)
        {
            return Get5KGAppuCampaignByDistributorPvt(DistributorId, FromDate, ToDate);
        }

        private List<RequestCatcherCallModel> Get5KGAppuCampaignByDistributorPvt(int DistributorId,DateTime FromDate, DateTime ToDate)
        {
            try
            {
                return ContextManager._Context.usp_Get5KGAppuCampaignByDistributor(DistributorId, FromDate, ToDate).Select(a => new RequestCatcherCallModel
                {
                    CallSid = a.CallSid,
                    CallFrom = a.CallFrom,
                    CallTo = a.CallTo,
                    Direction = a.Direction,
                    Created = Convert.ToDateTime(a.Created),
                    DialCallDuration = a.DialCallDuration,
                    StartTime = Convert.ToDateTime(a.StartTime),
                    EndTime = Convert.ToDateTime(a.EndTime),
                    CallType = a.CallType,
                    DialWhomNumber = a.DialWhomNumber,
                    flow_id = a.flow_id,
                    tenant_id = a.tenant_id,
                    CurrentTime = Convert.ToDateTime(a.CurrentTime),
                    digits = a.digits,
                    IsValidPincode = a.IsValidPincode,
                    Status = a.Status,
                    DistributorId=a.DistributorId 
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Get5KGAppuCampaignByDistributorPvt", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
        }
        #endregion

        #region Assign Distributor 

        public int AssignDistributor(RequestCatcherCallModel requestCatcherCallModel)
        {
            return AssignDistributorPvt(requestCatcherCallModel);
        }

        private int AssignDistributorPvt(RequestCatcherCallModel requestCatcherCallModel)
        {
            int a = 0;
            try
            {
                ObjectParameter ObjParamConsId = new ObjectParameter("result", typeof(Int64));
                ContextManager._Context.usp_Get5KGAppuCampaign_AcceptCustomer_byDistributor(requestCatcherCallModel.DistributorId, requestCatcherCallModel.CallFrom,
                requestCatcherCallModel.CallSid, ObjParamConsId);

                if (ObjParamConsId != null)
                    a = Convert.ToInt32(ObjParamConsId.Value);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "AssignDistributorPvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return a;
        }
        #endregion

        #region To Get 5 KG Appu Campaign By Admin Count
        public List<Get5KGAppuCampaignByAdminCountModel> Get5KGAppuCampaignByAdminCount()
        {
            return Get5KGAppuCampaignByAdminCountPvt();
        }

        private List<Get5KGAppuCampaignByAdminCountModel> Get5KGAppuCampaignByAdminCountPvt()
        {
            try
            {
                return ContextManager._Context.usp_Get5KGAppuCampaignByAdminCount().Select(a => new Get5KGAppuCampaignByAdminCountModel
                {
                    Today = a.Today,
                    AsOfDate = a.AsOfDate,
                    ValidPincode = a.ValidPincode,
                    InValidPincode = a.InValidPincode,
                    MissedCall = a.MissedCall,
                    AfterOfficeHrs = a.AfterOfficeHrs,
                    Forwarded = a.Forwarded
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Get5KGAppuCampaignByAdminCountPvt", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
        }
        #endregion

        #region To Get 5 KG Appu Campaign By Distributor Count
        public List<Get5KGAppuCampaignByDistributorCountModel> Get5KGAppuCampaignByDistributorCount(int DistributorId)
        {
            return Get5KGAppuCampaignByDistributorCountPvt(DistributorId);
        }

        private List<Get5KGAppuCampaignByDistributorCountModel> Get5KGAppuCampaignByDistributorCountPvt(int DistributorId)
        {
            try
            {
                return ContextManager._Context.usp_Get5KGAppuCampaignByDistributorCount(DistributorId).Select(a => new Get5KGAppuCampaignByDistributorCountModel
                {
                   Accepted = a.Accepted,
                   Pending = a.Pending
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Get5KGAppuCampaignByDistributorCountPvt", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
        }
        #endregion

        #region Update Admin Call Status
        public int UpdateCallStatusByAdmin(long pkId, string Number)
        {
            return UpdateCallStatusByAdminPvt(pkId, Number);
        }

        private int UpdateCallStatusByAdminPvt(long pkId, string Number)
        {
            int a;
            try
            {
                a = ContextManager._Context.usp_5KGAppuCampaign_UpdateCallStatusByAdmin(pkId, Number);
                
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "UpdateCallStatusByAdminPvt", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            return a;
        }
        #endregion

        #region To Get 5 KG Appu Campaign By Admin Count Summary
        public List<RequestCatcherCallModel> Get5KGAppuCampaignByAdminCountSummary(string type)
        {
            return Get5KGAppuCampaignByAdminCountSummaryPvt(type);
        }

        private List<RequestCatcherCallModel> Get5KGAppuCampaignByAdminCountSummaryPvt(string type)
        {
            List<RequestCatcherCallModel> data = new List<RequestCatcherCallModel>();
            RequestCatcherCallModel model = new RequestCatcherCallModel();

            try
            {
                var list = ContextManager._Context.usp_Get5KGAppuCampaignByAdminCountSummary(type).ToList();
                var groupList = list.ToList();
                for (int i = 0; i < groupList.Count(); i++)
                {
                    
                    var a = groupList[i];
                    if (a.gflag == 1)
                    {
                        model = list.Where(x => x.gflag == 1).Select(x => new RequestCatcherCallModel()
                        {
                            pkId = a.pkId,
							EnquiryNo = a.EnquiryNo,
                            CallSid = a.CallSid,
                            CallFrom = a.CallFrom,
                            CallTo = a.CallTo,
                            Direction = a.Direction,
                            Created = Convert.ToDateTime(a.Created),
                            DialCallDuration = a.DialCallDuration,
                            StartTime = Convert.ToDateTime(a.StartTime),
                            EndTime = Convert.ToDateTime(a.EndTime),
                            CallType = a.CallType,
                            DialWhomNumber = a.DialWhomNumber,
                            flow_id = a.flow_id,
                            tenant_id = a.tenant_id,
                            CurrentTime = Convert.ToDateTime(a.CurrentTime),
                            digits = a.digits,
                            IsValidPincode = a.IsValidPincode,
                            Status = a.Status,
                            DistributorName = a.DistributorName,
                            PincodeArea = a.PincodeArea,
                            DistributorId = a.DistributorId,
                            Remark = a.Remark,
                            AOHRemark = a.AOHRemark,
                            IsCallByAdmin = a.IsCallByAdmin,
                            IsCallNotAttended = a.IsCallNotAttended,
                            gflag = a.gflag.ToString()
                        }).FirstOrDefault();

                        // - Call From Group List
                        model.requestCatcherCallModelList = list.Where(y => y.CallFrom == a.CallFrom).Select(x => new RequestCatcherCallModel()
                        {
                            pkId = x.pkId,
							EnquiryNo = x.EnquiryNo,
							CallSid = x.CallSid,
                            CallFrom = x.CallFrom,
                            CallTo = x.CallTo,
                            Direction = x.Direction,
                            Created = Convert.ToDateTime(x.Created),
                            DialCallDuration = x.DialCallDuration,
                            StartTime = Convert.ToDateTime(x.StartTime),
                            EndTime = Convert.ToDateTime(x.EndTime),
                            CallType = x.CallType,
                            DialWhomNumber = x.DialWhomNumber,
                            flow_id = x.flow_id,
                            tenant_id = x.tenant_id,
                            CurrentTime = Convert.ToDateTime(x.CurrentTime),
                            digits = x.digits,
                            IsValidPincode = x.IsValidPincode,
                            Status = x.Status,
                            DistributorName = x.DistributorName,
                            PincodeArea = x.PincodeArea,
                            DistributorId = x.DistributorId,
                            Remark = x.Remark,
                            AOHRemark = x.AOHRemark,
                            IsCallByAdmin = x.IsCallByAdmin,
                            IsCallNotAttended = x.IsCallNotAttended
                        }).ToList();
                        data.Add(model);
                    }
                }
                return data;
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Get5KGAppuCampaignByAdminCountSummaryPvt", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
        }
        #endregion

        #region To Get 5 KG Appu Campaign By Pincode
        public List<Get5KGAppuCampaignByPincodeModel> Get5KGAppuCampaignByPincode()
        {
            return Get5KGAppuCampaignByPincodePvt();
        }

        private List<Get5KGAppuCampaignByPincodeModel> Get5KGAppuCampaignByPincodePvt()
        {
            try
            {
                return ContextManager._Context.usp_Get5KGAppuCampaignByPincode().Select(a => new Get5KGAppuCampaignByPincodeModel
                {
                    Id = a.Id,
                    Pincode = a.Pincode,
                    Area = a.Area
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Get5KGAppuCampaignByPincodePvt", "", "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
        }
        #endregion

        #region To Update 5 KG Appu Campaign By Pincode
        public List<Update5KGAppuCampaignByPincodeModel> Update5KGAppuCampaignByPincode(int Id, string Pincode, string IsCallNotAttended)
        {
            return Update5KGAppuCampaignByPincodePvt(Id, Pincode, IsCallNotAttended);
        }

        private List<Update5KGAppuCampaignByPincodeModel> Update5KGAppuCampaignByPincodePvt(int Id, string Pincode, string IsCallNotAttended)
        {
            Update5KGAppuCampaignByPincodeModel update5KGAppuCampaignByPincodeModel = new Update5KGAppuCampaignByPincodeModel();
            List<Update5KGAppuCampaignByPincodeModel> update5KGAppuCampaignByPincodeModelList = new List<Update5KGAppuCampaignByPincodeModel>();

            try
            {
                var result = ContextManager._Context.usp_Update5KGAppuCampaignByPincode(Id, Pincode, IsCallNotAttended).ToList();
                foreach(var item in result)
                {
                    update5KGAppuCampaignByPincodeModel.pkId = Convert.ToInt32(item.pkId);
                    update5KGAppuCampaignByPincodeModel.Pincode = item.Pincode;
                    update5KGAppuCampaignByPincodeModel.ResultMessage = item.ResultMessage;
                    update5KGAppuCampaignByPincodeModelList.Add(update5KGAppuCampaignByPincodeModel);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Update5KGAppuCampaignByPincodePvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return update5KGAppuCampaignByPincodeModelList;
        }
        #endregion

        #region To Get 5 KG Appu Campaign Enquiry Status
        public List<Get5KGAppuEnquiryStatusModel> Get5KGAppuEnquiryStatus()
        {
            return Get5KGAppuEnquiryStatusPvt();
        }

        private List<Get5KGAppuEnquiryStatusModel> Get5KGAppuEnquiryStatusPvt()
        {
            List<Get5KGAppuEnquiryStatusModel> model = new List<Get5KGAppuEnquiryStatusModel>();
            try
            {
                model = ContextManager._Context.usp_Get5KGAppuEnquiryStatus().Select(a => new Get5KGAppuEnquiryStatusModel
                {
                    pkid = a.pkid,
                    EnquiryStatusName = a.EnquiryStatusName,
                    IsActive = a.IsActive,
                    UpdatedDate = Convert.ToDateTime(a.UpdatedDate).ToString(BusinessCont.DateFormatUpdate)
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Get5KGAppuEnquiryStatusPvt", "", "", BusinessCont.ExceptionMsg(ex));
            }
            return model;
        }
        #endregion

        #region To Get 5 KG Appu Campaign Enquiry Action Taken
        public List<Get5KGAppuEnquiryActionTakenModel> Get5KGAppuEnquiryActionTaken()
        {
            return Get5KGAppuEnquiryActionTakenPvt();
        }

        private List<Get5KGAppuEnquiryActionTakenModel> Get5KGAppuEnquiryActionTakenPvt()
        {
            List<Get5KGAppuEnquiryActionTakenModel> model = new List<Get5KGAppuEnquiryActionTakenModel>();
            try
            {
                model = ContextManager._Context.usp_Get5KGAppuEnquiryActionTaken().Select(a => new Get5KGAppuEnquiryActionTakenModel
                {
                    pkid = a.pkid,
                    ActionTakenName = a.ActionTakenName,
                    IsActive = a.IsActive,
                    UpdatedDate = Convert.ToDateTime(a.UpdatedDate).ToString(BusinessCont.DateFormatUpdate)
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "To Get 5 KG Appu Campaign Enquiry Action Taken", "Get5KGAppuEnquiryActionTakenPvt", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            return model;
        }
        #endregion

        #region To Get 5KG Appu Enquiry Campaign By Distributor
        public List<Get5KGAppuEnquiryCampaignByDistributorModel> Get5KGAppuEnquiryCampaignByDistributor(int DistributorId, DateTime FromDate, DateTime ToDate)
        {
            return Get5KGAppuEnquiryCampaignByDistributorPvt(DistributorId, FromDate, ToDate);
        }

		private List<Get5KGAppuEnquiryCampaignByDistributorModel> Get5KGAppuEnquiryCampaignByDistributorPvt(int DistributorId, DateTime FromDate, DateTime ToDate)
		{
			List<Get5KGAppuEnquiryCampaignByDistributorModel> model = new List<Get5KGAppuEnquiryCampaignByDistributorModel>();
			try
			{
				model = ContextManager._Context.usp_Get5KGAppuEnquiryCampaignByDistributor(DistributorId, FromDate, ToDate).Select(a => new Get5KGAppuEnquiryCampaignByDistributorModel
				{
					gflag = a.gflag,
					maxpkId = Convert.ToInt64(a.maxPkId),
					pkid = a.pkId,
					DistributorId = Convert.ToInt32(a.DistributorId),
					EnquiryNo = a.EnquiryNo,
					MobileNumber = a.MobileNumber,
					CustomerName = a.CustomerName,
					Pincode = a.Pincode,
					AreaAddress = a.AreaAddress,
					StartTime = Convert.ToDateTime(a.StartTime).ToString("yyyy-MM-dd hh:mm"),
					EnquiryStatus = a.EnquiryStatus,
					ActionTaken = (a.ActionTaken != null) ? a.ActionTaken : "-",
					ActionTakenDateTime = (a.ActionTakenDateTime != null) ? Convert.ToDateTime(a.ActionTakenDateTime).ToString("yyyy-MM-dd hh:mm") : "-",
				}).ToList();
			}
			catch (Exception ex)
			{
				BusinessCont.SaveLog(0, DistributorId, "To Get 5KG Appu Enquiry Campaign By Distributor", "Get5KGAppuEnquiryCampaignByDistributorPvt", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
			}
			return model;
		}
		#endregion

		#region Update 5KG Appu Enquiry Status Distributor
		public int Update5KGAppuEnquiryStatusDistributor(long pkId, int DistributorId, string EnquiryStatusName, string EnquiryStatusFeedback)
        {
            return Update5KGAppuEnquiryStatusDistributorPvt(pkId, DistributorId, EnquiryStatusName, EnquiryStatusFeedback);
        }

        private int Update5KGAppuEnquiryStatusDistributorPvt(long pkId, int DistributorId, string EnquiryStatusName, string EnquiryStatusFeedback)
        {
            int InsertedCount = 0;
            try
            {
                ObjectParameter ObjRetVal = new ObjectParameter("RetVal", typeof(long));
                InsertedCount = ContextManager._Context.usp_Update5KGAppuEnquiryStatusDistributor(pkId, DistributorId, EnquiryStatusName, EnquiryStatusFeedback, ObjRetVal);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "Update 5KG Appu Enquiry Status Distributor", "Update5KGAppuEnquiryStatusDistributorPvt", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            return InsertedCount;
        }
        #endregion

        #region Update 5KG Appu Enquiry Action Distributor
        public int Update5KGAppuEnquiryActionDistributor(long pkId, int DistributorId, string ActionTakenName, string EnquiryActionTakenFeedback, string MobileNumber)
        {
            return Update5KGAppuEnquiryActionDistributorPvt(pkId, DistributorId, ActionTakenName, EnquiryActionTakenFeedback, MobileNumber);
        }

        private int Update5KGAppuEnquiryActionDistributorPvt(long pkId, int DistributorId, string ActionTakenName, string EnquiryActionTakenFeedback, string MobileNumber)
        {
            int InsertedCount = 0;
            try
            {
				exotelUserName = ConfigurationManager.AppSettings["ExotelUserName"];
				exotelPassword = ConfigurationManager.AppSettings["ExotelPassword"];
				exotelTokenKey = ConfigurationManager.AppSettings["ExotelTokenKey"];

				ObjectParameter ObjRetVal = new ObjectParameter("RetVal", typeof(long));
                InsertedCount = ContextManager._Context.usp_Update5KGAppuEnquiryActionDistributor(pkId, DistributorId, ActionTakenName, EnquiryActionTakenFeedback, ObjRetVal);

				if (InsertedCount > 0)
				{
					// Hindi - Text (At the time when the enquiry is attended by the distributor)
					SendSMSBody = "प्रिय HPGas ग्राहक, आशा है हैलो अप्पू का आपका अनुभव समाधानकारक रहा.";

					RestClient client = new RestClient("https://api.exotel.com/v1/Accounts/aadyamconsultant1/Sms/send");
					client.Authenticator = new HttpBasicAuthenticator(exotelUserName, exotelPassword);
					RestRequest request = new RestRequest(Method.POST);
					request.AddHeader("Authorization", "Basic " + exotelTokenKey);
					request.AddParameter("From", "HPRGAS");
					request.AddParameter("To", MobileNumber);
					request.AddParameter("Body", ConvertHTMLToString(SendSMSBody));
					request.AddHeader("accept", "application/json");
					var response = client.Execute(request);
					string getResponse = response.Content;
				}
			}
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "Update 5KG Appu Enquiry Action Distributor", "Update5KGAppuEnquiryActionDistributorPvt", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            return InsertedCount;
        }
        #endregion

        #region To Get 5 KG Appu Enquiry Campaign By Distributor Count
        public List<Get5KGAppuEnquiryCampaignByDistributorCountModel> Get5KGAppuEnquiryCampaignByDistributorCount(int DistributorId)
        {
            return Get5KGAppuEnquiryCampaignByDistributorPvt(DistributorId);
        }

        private List<Get5KGAppuEnquiryCampaignByDistributorCountModel> Get5KGAppuEnquiryCampaignByDistributorPvt(int DistributorId)
        {
            List<Get5KGAppuEnquiryCampaignByDistributorCountModel> model = new List<Get5KGAppuEnquiryCampaignByDistributorCountModel>();
            try
            {
                model = ContextManager._Context.usp_Get5KGAppuEnquiryCampaignByDistributorCount(DistributorId).Select(a => new Get5KGAppuEnquiryCampaignByDistributorCountModel
                {
                    CallNotAttendedEnquiryStatus = a.CallNotAttendedEnquiryStatus,
                    Attended = a.Attended,
                    Closed = a.Closed,
                    CallNotAttendedEnquiryActionTaken = a.CallNotAttendedEnquiryActionTaken,
                    RefillProvided = a.RefillProvided,
                    FTLProvided = a.FTLProvided,
                    Others = a.Others
                }).ToList();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "To Get 5 KG Appu Enquiry Campaign By Distributor Count", "Get5KGAppuEnquiryCampaignByDistributorPvt", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return model;
        }
        #endregion

        #region To Get 5KG Appu Enquiry Campaign By Distributor Count Summary
        public List<Get5KGAppuEnquiryCampaignByDistributorModel> Get5KGAppuEnquiryCampaignByDistributorCountSummary(int DistributorId, string type)
        {
            return Get5KGAppuEnquiryCampaignByDistributorCountSummaryPvt(DistributorId, type);
        }

		private List<Get5KGAppuEnquiryCampaignByDistributorModel> Get5KGAppuEnquiryCampaignByDistributorCountSummaryPvt(int DistributorId, string type)
		{
			List<Get5KGAppuEnquiryCampaignByDistributorModel> model = new List<Get5KGAppuEnquiryCampaignByDistributorModel>();
			try
			{
				model = ContextManager._Context.usp_Get5KGAppuEnquiryCampaignByDistributorCountSummary(DistributorId, type).Select(a => new Get5KGAppuEnquiryCampaignByDistributorModel
				{
					gflag = a.gflag,
					maxpkId = Convert.ToInt64(a.maxPkId),
					pkid = a.pkId,
					DistributorId = Convert.ToInt32(a.DistributorId),
					Status = a.Status,
					EnquiryNo = a.EnquiryNo,
					MobileNumber = a.MobileNumber,
					CustomerName = a.CustomerName,
					Pincode = a.Pincode,
					AreaAddress = a.AreaAddress,
					StartTime = Convert.ToDateTime(a.StartTime).ToString("yyyy-MM-dd hh:mm"),
					ActionTaken = (a.ActionTaken != null) ? a.ActionTaken : "-",
					ActionTakenDateTime = (a.ActionTakenDateTime != null) ? Convert.ToDateTime(a.ActionTakenDateTime).ToString("yyyy-MM-dd hh:mm") : "-",
				}).ToList();
			}
			catch (Exception ex)
			{
				BusinessCont.SaveLog(0, DistributorId, "To Get 5KG Appu Enquiry Campaign By Distributor Count Summary", "Get5KGAppuEnquiryCampaignByDistributorCountSummaryPvt", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
			}
			return model;
		}
		#endregion

		#region Start - To Convert HTML to String
		public static string ConvertHTMLToString(string input)
		{
			return Regex.Replace(input, "<.*?>", String.Empty);
		}
		#endregion End - To Convert HTML to String

	}
}
