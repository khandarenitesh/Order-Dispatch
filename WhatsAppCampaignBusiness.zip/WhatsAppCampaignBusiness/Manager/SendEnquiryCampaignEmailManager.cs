﻿using ClosedXML.Excel;
using HPGASNCEnquiryBusiness.BusinessConstant;
using HPGASNCEnquiryBusiness.Models.EmailScheduler;
using HPGASNCEnquiryBusiness.Models.Entity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WhatsAppCampaignBusiness.Models.Entity;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class SendEnquiryCampaignEmailManager : IDisposable
    {
        ContextManager contextManager = new ContextManager();

        #region Dispose 
        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }
        #endregion

        public int GetEnquiryCampaign()
        {
            return GetEnquiryCampaignReportPvt();
        }

        private int GetEnquiryCampaignReportPvt()
        {
            int ReturnValue = 0;
            try
            {
                string ToEmail = string.Empty, CCEmail = string.Empty, InsertedtablesDetails = string.Empty, InsertedtablesDetailsSA = string.Empty,
                       MainEmailBody = string.Empty, Table = string.Empty, TableDist = string.Empty, filePath = string.Empty, ROEmail = string.Empty;

                bool SendMail;
                EmailSending model = new EmailSending();
                List<tblROMaster> ROList = null;

                ToEmail = Convert.ToString(ConfigurationManager.AppSettings["ToEmail"]);
                CCEmail = Convert.ToString(ConfigurationManager.AppSettings["CCEmail"]);

                filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\");
                using (ContextManager contextManager = new ContextManager())
                {
                    ROList = ContextManager._Context.tblROMasters.Where(r => r.ActiveFlag == "Y").ToList();

                    if (ROList != null && ROList.Any())
                    {
                        foreach (tblROMaster Ro in ROList)
                        {
                            ContextManager._Context.Database.CommandTimeout = 600;
                            ROEmail = ContextManager._Context.tbl_SchedulerEmailForIVRS.Where(r => r.Code == Ro.ROCode && r.Role == "RO" && r.IsActive == true).Select(r => r.Email).FirstOrDefault();
                            if (string.IsNullOrWhiteSpace(ROEmail))
                                continue;   //Dont process RO if email not available

                             BusinessCont.SaveLog(0, 0, "SendEnquiryCampaignEmail", "Manager", "Start", BusinessCont.SuccessStatus);

                            // SA Wise
                            var data = ContextManager._Context.usp_SendEnquiryCampaignSummaryIVRSData("0", Ro.ROCode, "sawise").ToList();
                            if (data.Count > 0)
                            {
                                Table = "";
                                InsertedtablesDetailsSA = "";

                                Table += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse; width:100 %;white-space:nowrap;'>";
                                Table += "<thead><tr style='font-size:14px;'>";
                                Table += "<th style='border: 1px solid grey;padding: 5px;'> Sr.No. </th>";
                                Table += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area </th>";
                                Table += "<th style='border: 1px solid grey;padding: 5px;'> Total Not Attended </th>";
                                Table += "</tr></thead><tbody>";

                                int Count = 1;
                                InsertedtablesDetailsSA += Table;
                                for (int i = 0; i < data.Count; i++)
                                {
                                    if (i == data.Count - 1)
                                    {
                                        InsertedtablesDetailsSA += "<tr style='font-size:14px;'>";
                                        InsertedtablesDetailsSA += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + " " + "</td>";
                                        InsertedtablesDetailsSA += "<td style='border: 1px solid grey;padding: 5px;'>" + data[i].SAName + "</td>";
                                        InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].TotalNotAttended + "</td>";
                                        InsertedtablesDetailsSA += "</tr>";
                                        Count++;
                                    }
                                    else
                                    {
                                        InsertedtablesDetailsSA += "<tr style='font-size:14px;'>";
                                        InsertedtablesDetailsSA += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + Count + "</td>";
                                        InsertedtablesDetailsSA += "<td style='border: 1px solid grey;padding: 5px;'>" + data[i].SAName + "</td>";
                                        InsertedtablesDetailsSA += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + data[i].TotalNotAttended + "</td>";
                                        InsertedtablesDetailsSA += "</tr>";
                                        Count++;
                                    }
                                }
                                InsertedtablesDetailsSA += "</tbody></table>";

                                // Distributor Wise
                                var datadist = ContextManager._Context.usp_SendEnquiryCampaignSummaryIVRSData("0", Ro.ROCode, "distwise").ToList();
                                var datalistnew = datadist.GroupBy(x => x.SACode).ToList();
                                var groupedCustomerList = datadist.GroupBy(u => u.SACode).Select(grp => grp.ToList()).ToList();
                                int ik = 0;
                                if (datadist.Count > 0)
                                {
                                    foreach (var items in datalistnew)
                                    {
                                        TableDist = "";
                                        TableDist += "<h4 style='font-family: Calibri (Body);font-size: 12pt;color: #000000; background-color: #ffffff'>" + groupedCustomerList[ik][0].SAName + "</h4>";
                                        TableDist += "<table border='1' BORDERCOLOR=grey style='border-collapse: collapse; width:100 %;white-space:nowrap;'>";
                                        TableDist += "<thead><tr style='font-size:14px;'>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Sr.No. </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Sales Area </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Distributor Code </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Distributor Name </th>";
                                        TableDist += "<th style='border: 1px solid grey;padding: 5px;'> Total Not Attended </th>";
                                        TableDist += "</tr></thead><tbody>";
                                    }

                                    int CountD = 1;
                                    InsertedtablesDetails += TableDist;
                                    for (int i = 0; i < datadist.Count; i++)
                                    {
                                        if (i == datadist.Count - 1)
                                        {
                                            InsertedtablesDetails += "<tr style='font-size:14px;'>";
                                            InsertedtablesDetails += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + " " + "</td>";
                                            InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + datadist[i].SAName + "</td>";
                                            InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + datadist[i].JDEDistributorCode + "</td>";
                                            InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + datadist[i].DistributorName + "</td>";
                                            InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].TotalNotAttended + "</td>";
                                            InsertedtablesDetails += "</tr>";
                                            CountD++;
                                        }
                                        else
                                        {
                                            InsertedtablesDetails += "<tr style='font-size:14px;'>";
                                            InsertedtablesDetails += "<td style='text-align:center;border: 1px solid grey;padding: 5px;'>" + CountD + "</td>";
                                            InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + datadist[i].SAName + "</td>";
                                            InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + datadist[i].JDEDistributorCode + "</td>";
                                            InsertedtablesDetails += "<td style='border: 1px solid grey;padding: 5px;'>" + datadist[i].DistributorName + "</td>";
                                            InsertedtablesDetails += "<td style='text-align:right;border: 1px solid grey;padding: 5px;'>" + datadist[i].TotalNotAttended + "</td>";
                                            InsertedtablesDetails += "</tr>";
                                            CountD++;
                                        }
                                    }
                                    InsertedtablesDetails += "</tbody></table></br></br>";
                                }

                                if (InsertedtablesDetailsSA != "" && InsertedtablesDetailsSA != null && InsertedtablesDetails != "" && InsertedtablesDetails != null)
                                { 
                                    if (Ro.ROCode == "12352")
                                    {
                                        SendMail = model.EnquiryCampaignDailySchedulerEmail(ROEmail, CCEmail, "", "Enquiry Campaign For Email : " + Ro.ROName + " - " + DateTime.Now.ToString("dd/MM/yyyy"), InsertedtablesDetailsSA, InsertedtablesDetails);
                                        if (SendMail == true)
                                            ReturnValue = 1;
                                        else
                                            ReturnValue = 0;
                                    }
                                    BusinessCont.SaveLog(0, 0, "SendEnquiryCampaignEmail", "Manager", "End", BusinessCont.SuccessStatus);
                                }
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "Enquiry Campaign - Report", "GetEnquiryCampaignReportPvt", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return ReturnValue;
        }

    }
}
