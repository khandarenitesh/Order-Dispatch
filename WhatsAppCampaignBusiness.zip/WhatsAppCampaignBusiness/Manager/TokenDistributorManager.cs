﻿using HPGASNCEnquiryBusiness.Models.Entity;
using HPGASNCEnquiryBusiness.Models.Token;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class TokenDistributorManager : IDisposable
    {
        public List<DistributorModel> GetAllDistributor(SAModel sa)
        {
            return GetAllDistributorPvt(sa.SAId);
        }

        private List<DistributorModel> GetAllDistributorPvt(int SAId)
        {
            return ContextManager._Context.sp_GetDistributorBySAId(SAId).Select(x => new DistributorModel
            {
                DistributorName = x.DistributorName,
                DistributorId = x.DistributorId,
                Flag = x.Flag,
                Token = x.Token.Value,
                SAName = x.SAName
            }).ToList();
        }

        public List<DistributorModel> GetWinnerDistributor(SAModel sa)
        {
            return GetWinnerDistributorPvt(sa.SAId);
        }

        private List<DistributorModel> GetWinnerDistributorPvt(int SAId)
        {
            return ContextManager._Context.GetWinnerDistributorDetails(SAId,0).Select(x => new DistributorModel
            {
                DistributorName = x.DistributorName,
                DistributorId = x.DistributorId,
                Flag = x.Flag,
                Token = x.Token.Value,
                SAName = x.SAName
            }).ToList();
        }

        public Nullable<int> GetActiveFlagCount(SAModel sa)
        {
            return GetActiveFlagCountPvt(sa.SAId);
        }

        private Nullable<int> GetActiveFlagCountPvt(int SAId)
        {
            int? Tokens = null;
            Tokens = ContextManager._Context.GetActiveFlags(SAId,0).FirstOrDefault();
            return Tokens;
        }

        public DistributorModel GetDistributorTokenBySAId(SAModel sa)
        {
            return GetDistributorTokenBySAIdPvt(sa.SAId);
        }
        private DistributorModel GetDistributorTokenBySAIdPvt(int SAId)
        {
            List<int?> Tokens = null;
            DistributorModel distributorModel = null;
            int? number;
            try
            {
                Tokens = new List<int?>();
                distributorModel = new DistributorModel();
                Tokens = ContextManager._Context.sp_GetDistributorTokensBySAId(SAId).ToList();
                Random random = new Random();
                number = Tokens.OrderBy(o => random.Next()).Take(1).FirstOrDefault();
                distributorModel = UpdateFlag(number.Value, SAId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return distributorModel;
        }

        public DistributorModel GetDistributorDetailsByToken(int Token)
        {
            return GetDistributorDetailsByTokenPvt(Token);
        }

        private DistributorModel GetDistributorDetailsByTokenPvt(int Token)
        {
            try
            {
                return ContextManager._Context.GetDistributorDetailsByTokenNumber(Token).Select(x => new DistributorModel
                {
                    DistributorName = x.DistributorName,
                    DistributorId = x.DistributorId,
                    Flag = x.Flag,
                    Token = x.Token.Value,
                    SAName = x.SAName
                }).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DistributorModel UpdateFlag(int Token, int SAId)
        {
            return UpdateFlagPvt(Token, SAId);
        }

        private DistributorModel UpdateFlagPvt(int Token, int SAId)
        {
            try
            {
                return ContextManager._Context.UpdateDistributorflag(Token, SAId,0,0).Select(x => new DistributorModel
                {
                    DistributorName = x.DistributorName,
                    DistributorId = x.DistributorId,
                    Flag = x.Flag,
                    Token = x.Token.Value,
                    SAName = x.SAName
                }).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<SAModel> GetSADetails()
        {
            return GetSADetailsPvt();
        }

        private List<SAModel> GetSADetailsPvt()
        {
            return ContextManager._Context.sp_GetAllSA().Select(x => new SAModel
            {
                SAId = x.SAId,
                SAcode = x.SAcode,
                SAName = x.SAName
            }).ToList();
        }

        #region Dispose 

        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }

        #endregion
    }
}
