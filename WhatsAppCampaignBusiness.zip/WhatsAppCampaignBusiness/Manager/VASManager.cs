using HPGASNCEnquiryBusiness.BusinessConstant;
using HPGASNCEnquiryBusiness.Models.Entity;
using HPGASNCEnquiryBusiness.Models.VAS;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.Core.Objects;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using WhatsAppCampaignBusiness.Models.Entity;
using Newtonsoft.Json;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class VASManager : IDisposable
    {
        ContextManager contextManager = new ContextManager();

        #region Dispose 
        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }
        #endregion

        #region Add/Edit SLA Master
        public int SLAAddEdit(SLAModel model)
        {
            return SLAAddEditPvt(model);
        }
        private int SLAAddEditPvt(SLAModel model)
        {
            int Retvalue = 0;
            ObjectParameter obj = new ObjectParameter("RetValue", typeof(string));
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    Retvalue = _Context.usp_SLAMasterAddEdit(model.SLAId, model.SLADesc, model.SLAValue, model.IsActive, model.AddedBy, model.Action, obj);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "SLAAddEditPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region SLA Master List
        public List<SLAModel> SLAList(int flag)
        {
            return SLAListPvt(flag);
        }
        private List<SLAModel> SLAListPvt(int flag)
        {
            List<SLAModel> list = new List<SLAModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    list = _Context.usp_SLAMasterList(flag).Select(s => new SLAModel
                    {
                        SLAId = Convert.ToInt32(s.SLAId),
                        SLADesc = s.SLADesc,
                        SLAValue = Convert.ToInt32(s.SLAValue),
                        IsActive = Convert.ToInt32(s.IsActive),
                        AddedBy = s.AddedBy
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "SLAAddEditPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return list;
        }
        #endregion

        #region VAS Consumers Add Update
        public int ConsumersAddUpdate(VASConsumersModel model)
        {
            return ConsumersAddUpdatePvt(model);
        }
        private int ConsumersAddUpdatePvt(VASConsumersModel model)
        {
            int Retvalue = 0;
            try
            {
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    var result = context.usp_VASConsumersAddUpdate(model.SACode, model.DistributorId, model.DistributorCode, model.DistributorName,
                        Convert.ToInt64(model.UniqueConsumerId), Convert.ToInt32(model.ConsumerNo), model.MobileNo, model.ConsumerName, model.AreaName, model.ConsumerAddress, model.IsRegistered, Convert.ToDateTime(model.RegisterDate).
                        ToString("yyyy-MM-dd"), model.Status, model.Action, model.IsApprove, model.AddedBy, "").FirstOrDefault();
                    Retvalue = Convert.ToInt32(result.RetValue);
                }
                if (Retvalue > 0 && model.Action == "ADD")
                {
                    var RetValue = GenerateWhatsappMsg(model); // Send WhatsApp Message through pickyassist
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "ConsumersAddUpdatePvt", DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region VAS Consumers List
        public List<VASConsumersModel> VASConsumerList(string DistributorCode)
        {
            return VASConsumerListPvt(DistributorCode);
        }
        private List<VASConsumersModel> VASConsumerListPvt(string DistributorCode)
        {
            List<VASConsumersModel> list = new List<VASConsumersModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    list = _Context.usp_VASConsumersList(DistributorCode).Select(s => new VASConsumersModel
                    {
                        SACode = s.SACode,
                        DistributorId = s.DistributorId,
                        DistributorCode = s.DistributorCode,
                        DistributorName = s.DistributorName,
                        UniqueConsumerId = Convert.ToString(s.UniqueConsumerId),
                        ConsumerNo = Convert.ToString(s.ConsumerNo),
                        MobileNo = s.MobileNo,
                        ConsumerName = s.ConsumerName,
                        AreaName = s.AreaName,
                        ConsumerAddress = s.ConsumerAddress,
                        IsMobNoDuplicate = s.IsMobNoDuplicate,
                        IsWhatsappNo = s.IsWhatsappNo,
                        IsMessageSent = s.IsMessageSent,
                        IsRegistered = s.IsRegistered,
                        RegistrationDate = Convert.ToDateTime(s.RegistrationDate),
                        ExpiryDate = Convert.ToDateTime(s.ExpiryDate),
                        Status = Convert.ToInt32(s.Status),
                        IsApprove = s.IsApprove,
                        AddedBy = s.AddedBy
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "SLAAddEditPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return list;
        }
        #endregion

        #region Get Refill Pending Booking List
        public List<RefillBookingPendingListModel> RefillBookingPendingList(string DistributorCode, DateTime? FromDate, DateTime? Todate, string Flag)
        {
            return RefillBookingPendingListPvt(DistributorCode, FromDate, Todate, Flag);
        }
        private List<RefillBookingPendingListModel> RefillBookingPendingListPvt(string DistributorCode, DateTime? FromDate, DateTime? Todate, string Flag)
        {
            List<RefillBookingPendingListModel> list = new List<RefillBookingPendingListModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    list = _Context.usp_RefillBookingPendingList(DistributorCode, FromDate, Todate, Flag).Select(r => new RefillBookingPendingListModel
                    {
                        PkOrderId = r.PkOrderId,
                        DistributorId = Convert.ToInt32(r.DistributorId),
                        DistributorCode = r.DistributorCode,
                        OrderNo = r.OrderNo,
                        OrderDateTime = Convert.ToDateTime(r.OrderDate).ToString("yyyy/MM/dd hh:mm:ss"),
                        OrderStatus = r.OrderStatus,
                        OrderSource = r.OrderSource,
                        OrderType = r.OrderType,
                        ConsumerNo = r.ConsumerNo,
                        ConsumerName = r.ConsumerName,
                        CashMemoNo = r.CashMemoNo,
                        CashMemoDate = Convert.ToDateTime(r.CashMemoDate),
                        CMCancelDate = Convert.ToDateTime(r.CMCancelDate),
                        CMStatus = r.CMStatus,
                        CMCancelReason = r.CMCancelReason,
                        ActualDelDate = Convert.ToDateTime(r.ActualDelDate),
                        MobNo = r.MobNo,
                        ConsAddress = r.ConsAddress,
                        DeliveredBy = r.DeliveredBy,
                        AddedOn = Convert.ToDateTime(r.AddedOn),
                        LastUpdatedOn = Convert.ToDateTime(r.LastUpdatedOn),
                        AssignTo = r.AssignTo
                    }).OrderBy(x => x.ConsumerName).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "RefillBookingPendingListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return list;
        }
        #endregion

        #region Assign Delivery Boy Add 
        public int AssignDeliveryBoyAdd(AssignDeliveryBoyAddModel model)
        {
            return AssignDeliveryBoyAddPvt(model);
        }
        private int AssignDeliveryBoyAddPvt(AssignDeliveryBoyAddModel model)
        {
            int Retvalue = 0;
            ObjectParameter obj = new ObjectParameter("RetValue", typeof(string));
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    Retvalue = _Context.USP_RefillBookingAssign(model.PkOrderId, model.DistributorCode, model.DelBoyName, obj);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "AssignDeliveryBoyAdd", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region Add Update Service
        public int AddUpdateService(ServiceModel model)
        {
            return AddUpdateServicePvt(model);
        }
        private int AddUpdateServicePvt(ServiceModel model)
        {
            int Retvalue = 0;
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    ObjectParameter obj = new ObjectParameter("RetValue", typeof(string));
                    Retvalue = _Context.usp_ServiceReqAddUpdate(model.SRId, Convert.ToInt32(model.DistributorCode), model.UniqueConsumerId, model.ConsumerNo,
                      Convert.ToDateTime(model.SRDate).ToString("yyyy-MM-dd"), model.AssignTo, model.SRStatus, model.Action, obj);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Add Update Service Pvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return Retvalue;
        }
        #endregion

        #region Service Request List
        public List<ServiceModel> ServiceReqList(string DistributorCode)
        {
            return ServiceReqListPvt(DistributorCode);
        }
        private List<ServiceModel> ServiceReqListPvt(string DistributorCode)
        {
            List<ServiceModel> list = new List<ServiceModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    list = _Context.usp_GetServiceReqList(DistributorCode).Select(s => new ServiceModel
                    {
                        SRId = Convert.ToInt32(s.SRId),
                        DistributorId = Convert.ToInt32(s.DistributorId),
                        DistributorName = s.DistributorName,
                        DistributorCode = s.JDEDistributorCode,
                        SRCompletedOn = Convert.ToDateTime(s.SRCompletedOn).ToString("dd-MM-yyyy"),
                        UniqueConsumerId = Convert.ToInt64(s.UniqueConsumerId),
                        ConsumerNo = Convert.ToInt32(s.ConsumerNo),
                        ConsumerName = s.ConsumerName,
                        MobileNo = s.MobileNo,
                        SRDate = Convert.ToDateTime(s.SReqDate).ToString("yyyy/MM/dd hh:mm:ss"),
                        SReqDate = Convert.ToDateTime(s.SReqDate),
                        SRStatus = Convert.ToInt16(s.SRStatus),
                        AssignTo = s.AssignTo,
                        SRDoneCount = Convert.ToInt32(s.SRDoneCount)
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "SLAAddEditPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return list;
        }
        #endregion

        #region VAS Counts
        public VASCountsModel VASCounts(string DistributorCode)
        {
            return VASCountsPvt(DistributorCode);
        }
        private VASCountsModel VASCountsPvt(string DistributorCode)
        {
            VASCountsModel modal = new VASCountsModel();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    modal = _Context.usp_VASPageCounts(DistributorCode).Select(s => new VASCountsModel
                    {
                        DistributorId = Convert.ToInt32(s.DistributorId),
                        DistributorCode = s.JDEDistributorCode,
                        VASConsumer = Convert.ToInt32(s.VASConsumer),
                        ActiveCount = Convert.ToInt32(s.ActiveCount),
                        ExpConsCount = Convert.ToInt32(s.ExpConsCount),
                        PendingBookings = Convert.ToInt32(s.PendingBookings),
                        AssignBookingCnt = Convert.ToInt32(s.AssignBookingCnt),
                        DueBookingCnt = Convert.ToInt32(s.DueBookingCnt),
                        DelBookingCnt = Convert.ToInt32(s.DelBookingCnt),
                        TotalSRCnt = Convert.ToInt32(s.TotalSRCnt),
                        PendingSRCnt = Convert.ToInt32(s.PendingSRCnt),
                        TodayCompSR = Convert.ToInt32(s.TodayCompSR),
                        NoServiceDoneCnt = Convert.ToInt32(s.NoServiceDoneCnt),
                        Service1DoneCnt = Convert.ToInt32(s.Service1DoneCnt),
                        Service2DoneCnt = Convert.ToInt32(s.Service2DoneCnt)
                    }).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "VASCountsPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return modal;
        }
        #endregion

        #region Generate Whats app Msg
        // GenerateWhatsappMsg - WhatsApp Set Message
        public int GenerateWhatsappMsg(VASConsumersModel model)
        {
            int RetValue = 0;
            string FinalWhatsappMsg = string.Empty, ValidToken = string.Empty, SendWhatsappMsg = string.Empty;
            Task<string> result = null;
            try
            {
                BusinessCont.SaveLog(0, model.DistributorId, "GenerateWhatsappMsg", "GenerateWhatsappMsg - WhatsApp Set Message: " + model.MobileNo, "START", "");
                ValidToken = ConfigurationManager.AppSettings["WhatsappAPIToken"];
                SendWhatsappMsg = ConfigurationManager.AppSettings["SendWhatsappMsg"];
                if (!string.IsNullOrEmpty(ValidToken) && SendWhatsappMsg == "Y")
                {
                    using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                    {
                        // VASWhatsAppMsgSent = 1 - WhatsApp Message Sent otherwise not sent
                        // Note:  VASWhatsAppMsgSent = 1 value through Activate Campaign
                        var consumerList = _Context.usp_VASConsumersListForMessageSent(model.DistributorCode).Where(c => c.DistributorCode == model.DistributorCode && c.MobileNo == model.MobileNo && c.VASWhatsAppMsgSent == 1).FirstOrDefault();
                        if (consumerList != null)
                        {
                            FinalWhatsappMsg = "Dear HPGAS Customer\n*"
                                             + consumerList.ConsumerName + "* � *" + Convert.ToInt32(model.ConsumerNo) + "*\n"
                                             + "Thanks for availing HPGAS Suraksha Kavach (AMC)"
                                             + "\nEnrollment Date: *" + Convert.ToDateTime(model.RegisterDate).ToString(BusinessCont.DateFormat)
                                             + "*\nValid upto- *"
                                             + Convert.ToDateTime(consumerList.ExpiryDate).ToString(BusinessCont.DateFormat)
                                             + "*\n\nBenefits : "
                                             + "\n \t Refill Delivery within 24 hrs of Booking \n \t *Two FREE* mechanic services"
                                             + "\n\nThanks\n*" + consumerList.DistributorName
                                             + "*\nCont No: *" + consumerList.DistributorMobileNo + "* & *" + consumerList.DPhoneNo + "*";

                            result = Task.Run(() => BusinessCont.WhatsAppMsg(FinalWhatsappMsg, consumerList.MobileNo, ""));
                            Task.WaitAll(result);
                            PkAssistModel response = JsonConvert.DeserializeObject<PkAssistModel>(result.Result);
                            if (response.message == "Success")
                            {
                                RetValue = UpdateFlagIsMessageSentVASConsumers(model.MobileNo);
                            }
                            else
                            {
                                RetValue = 0;
                            }
                        }
                        else
                        {
                            BusinessCont.SaveLog(0, model.DistributorId, "GenerateWhatsappMsg", "consumerList - Not Data Found " + model.MobileNo, "", "");
                        }
                    }
                }
                BusinessCont.SaveLog(0, model.DistributorId, "GenerateWhatsappMsg", "GenerateWhatsappMsg - WhatsApp Set Message: " + model.MobileNo, "END", "");
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, model.DistributorId, "GenerateWhatsappMsg", "Mobile No = " + model.MobileNo, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            finally { FinalWhatsappMsg = ""; model.MobileNo = ""; }
            return RetValue;
        }
        #endregion

        #region Update Flag IsMessageSent VASConsumers
        private int UpdateFlagIsMessageSentVASConsumers(string MobileNo)
        {
            int RetValue = 0;
            ObjectParameter objRetVal = new ObjectParameter("RetVal", typeof(int));
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    RetValue = _Context.usp_UpdateFlagIsMessageSentVASConsumers(MobileNo, objRetVal);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveAPILog(0, 0, "UpdateFlagIsMessageSentVASConsumers", "Update Flag IsMessageSent VASConsumers Mobile No = " + MobileNo, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            return RetValue;
        }
        #endregion

        #region Get Refill Booking Pending By Code
        public string GetRefillBookingPendingByCode(string DistributorCode)
        {
            return GetRefillBookingPendingByCodePvt(DistributorCode);
        }
        private string GetRefillBookingPendingByCodePvt(string DistributorCode)
        {
            string msgResult = string.Empty;
            List<RefillBookingPendingListModel> pendingBookingList = new List<RefillBookingPendingListModel>();
            try
            {
                BusinessCont.SaveLog(0, 0, "GetRefillBookingPendingByCodePvt -> DistributorCode:  " + DistributorCode, DateTime.Now.ToString(), "START", "");

                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    pendingBookingList = _Context.usp_GetRefillBookingPendingByCode(DistributorCode).Select(r => new RefillBookingPendingListModel
                    {
                        PkOrderId = Convert.ToInt64(r.PkOrderId),
                        DistributorId = Convert.ToInt32(r.DistributorId),
                        DistributorCode = Convert.ToString(r.DistributorCode),
                        OrderNo = Convert.ToString(r.OrderNo),
                        OrderDate = Convert.ToDateTime(r.OrderDate),
                        OrderStatus = Convert.ToString(r.OrderStatus),
                        ConsumerNo = Convert.ToString(r.ConsumerNo),
                        ConsumerName = Convert.ToString(r.ConsumerName),
                        ConsumerMobNo = Convert.ToString(r.ConsumerMobNo),
                        DealerMobNo = Convert.ToString(r.DealerMobNo),
                        DistributorName = Convert.ToString(r.DistributorName),
                        TimeinHrs = Convert.ToInt32(r.TimeinHrs),
                        ActualDelDate = Convert.ToDateTime(r.ActualDelDate),
                        PhoneNo = Convert.ToString(r.PhoneNo),
                        VASWhatsAppMsgSent = Convert.ToInt32(r.VASWhatsAppMsgSent)
                    }).ToList();

                    if (pendingBookingList.Count > 0)
                    {
                        msgResult = PendingBookingListByCode(DistributorCode, pendingBookingList);
                    }
                }

                BusinessCont.SaveLog(0, 0, "GetRefillBookingPendingByCodePvt -> DistributorCode:  " + DistributorCode, DateTime.Now.ToString(), "END", "");
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetRefillBookingPendingByCodePvt -> DistributorCode:  " + DistributorCode, DateTime.Now.ToString(), BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            return msgResult;
        }
        #endregion

        #region Pending Booking List By Code
        public string PendingBookingListByCode(string DistributorCode, List<RefillBookingPendingListModel> pendingBookingList)
        {
            string ValidToken = string.Empty, SendWhatsappMsg = string.Empty, msgResult = string.Empty;
            try
            {
                BusinessCont.SaveAPILog(0, 0, "PendingBookingListByCode", "Pending Booking List By Code: " + DistributorCode, "START", "");

                ValidToken = ConfigurationManager.AppSettings["WhatsappAPIToken"];
                SendWhatsappMsg = ConfigurationManager.AppSettings["SendWhatsappMsg"];

                // STEP 1: Send Notification
                SendNotification(pendingBookingList[0].DistributorId, "PendingBookingList", "Added Pending Booking List");

                // STEP 2: To Check Valid Token in PkAssist Portal
                if (!string.IsNullOrEmpty(ValidToken) && SendWhatsappMsg == "Y" && pendingBookingList.Count > 0)
                {
                    msgResult = PendingBookingList(DistributorCode, pendingBookingList);
                }
                else
                {
                    BusinessCont.SaveLog(0, pendingBookingList[0].DistributorId, "PendingBookingListByCode", "Pending Booking List By Code: " + DistributorCode, "No Records Found", "");
                }

                BusinessCont.SaveLog(0, pendingBookingList[0].DistributorId, "PendingBookingListByCode", "Pending Booking List By Code: " + DistributorCode, "END", "");
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, pendingBookingList[0].DistributorId, "PendingBookingListByCode", "Pending Booking List By Code: " + DistributorCode, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            return msgResult;
        }
        #endregion

        #region Pending Booking List (Pending Refill Booking & Pending Delivery) - WhatsApp Set & Send Message
        private string PendingBookingList(string DistributorCode, List<RefillBookingPendingListModel> pendingBookingList)
        {
            string FinalWhatsappMsg = string.Empty, msgHtml = string.Empty, Table = string.Empty, InsertedTablesDetails = string.Empty, MobileNo = string.Empty, PDFFilePath = string.Empty, msgResult = string.Empty, PDFURL = string.Empty, htmlPath = string.Empty, FilePath = string.Empty;
            Task<string> result = null;
            Guid guidValue = Guid.NewGuid();
            try
            {
                PDFURL = ConfigurationManager.AppSettings["PDFURL"];
                htmlPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\PendingRefillBooking.html");
                msgHtml = File.OpenText(htmlPath).ReadToEnd().ToString();
                if (pendingBookingList.Count > 0)
                {
                    // STEP 3: Pending Bookings List
                    //PDFFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\VASUploadPDF\\" + DistributorCode + "_" + DateTime.Now.ToString(BusinessCont.DateFormat) + "_" + guidValue + ".pdf");

                    //Table = "";
                    //InsertedTablesDetails = "";

                    //Table += "<table border='1' BORDERCOLOR=grey style='width:100 %;border-collapse: collapse;white-space:nowrap;'>";
                    //Table += "<thead><tr bgcolor='lightgrey' style='font-size:9px;text-align: center;font-weight: bold;'>";
                    //Table += "<th style='border: 1px solid grey;' width='5%'> Sr.No </th>";
                    //Table += "<th style='border: 1px solid grey;padding: 5px;' width='10%'> Consumer No. </th>";
                    //Table += "<th style='border: 1px solid grey;padding: 10px;' width='25%'> Consumer Name </th>";
                    //Table += "<th style='border: 1px solid grey;padding: 5px;' width='10%'> Mobile No. </th>";
                    //Table += "<th style='border: 1px solid grey;padding: 5px;' width='7%'> Order No. </th>";
                    //Table += "<th style='border: 1px solid grey;padding: 5px;' width='10%'> Order Date </th>";
                    //Table += "<th style='border: 1px solid grey;padding: 5px;' width='10%'> Order Status </th>";
                    //Table += "<th style='border: 1px solid grey;padding: 5px;' width='10%'> Booking Hours </th>";
                    //Table += "</tr></thead><tbody>";
                    //int Count = 1;
                    //InsertedTablesDetails += Table;
                    //for (int i = 0; i < pendingBookingList.Count; i++)
                    //{
                    //	InsertedTablesDetails += "<tr style='font-size:9px;'>";
                    //	InsertedTablesDetails += "<td style='border: 1px solid grey;text-align:center;'>" + Count + "</td>";
                    //	InsertedTablesDetails += "<td style='border: 1px solid grey;padding: 5px;text-align: center;'>" + pendingBookingList[i].ConsumerNo + "</td>";
                    //	InsertedTablesDetails += "<td style='border: 1px solid grey;padding: 10px;text-align:left;'>" + pendingBookingList[i].ConsumerName + "</td>";
                    //	InsertedTablesDetails += "<td style='border: 1px solid grey;padding: 5px;text-align:center;'>" + pendingBookingList[i].ConsumerMobNo + "</td>";
                    //	InsertedTablesDetails += "<td style='border: 1px solid grey;padding: 5px;text-align:center;'>" + pendingBookingList[i].OrderNo + "</td>";
                    //	InsertedTablesDetails += "<td style='border: 1px solid grey;padding: 5px;text-align: center;'>" + pendingBookingList[i].OrderDate.Date.ToString(BusinessCont.DateFormat) + "</td>";
                    //	InsertedTablesDetails += "<td style='border: 1px solid grey;padding: 5px;text-align:center;text-transform: capitalize;'>" + pendingBookingList[i].OrderStatus + "</td>";
                    //	InsertedTablesDetails += "<td style='border: 1px solid grey;padding: 5px;text-align:center;'>" + pendingBookingList[i].TimeinHrs + "</td>";
                    //	InsertedTablesDetails += "</tr>";
                    //	Count++;
                    //}
                    //InsertedTablesDetails += "</tbody></table>";
                    //if (!string.IsNullOrEmpty(InsertedTablesDetails))
                    //{
                    //	msgHtml = msgHtml.Replace("<!--SchedulerTableStringDistributorName-->", pendingBookingList[0].DistributorName);
                    //	msgHtml = msgHtml.Replace("<!--SchedulerTableStringOrderDate-->", DateTime.Now.Date.ToString(BusinessCont.DateFormat));
                    //	msgHtml = msgHtml.Replace("<!--SchedulerTableStringPRBooking-->", InsertedTablesDetails);
                    //	HTMLToPdf(msgHtml, PDFFilePath);
                    //}
                    //FilePath = PDFURL + DistributorCode + "_" + DateTime.Now.ToString(BusinessCont.DateFormat) + "_" + guidValue + ".pdf";
                    //MobileNo = pendingBookingList[0].DealerMobNo;
                    //FinalWhatsappMsg = "Dear *" + pendingBookingList[0].DistributorName + "*, Please find attached file of Refill Booking Status Report" + "\n*" + MobileNo + "*";
                    //// STEP 4: message send through MobileNo
                    //if (!string.IsNullOrEmpty(FinalWhatsappMsg) && !string.IsNullOrEmpty(MobileNo) && !string.IsNullOrEmpty(FilePath))
                    //{
                    //	// STEP 5: To Send Message through PkAssist (Dealer/Distributor)
                    //	result = Task.Run(() => BusinessCont.WhatsAppMsg(FinalWhatsappMsg, MobileNo, FilePath));
                    //	Task.WaitAll(result);
                    //  PkAssistModel response = JsonConvert.DeserializeObject<PkAssistModel>(result.Result);
                    //	if (response.message == "Success")
                    //	{
                    //		msgResult = BusinessCont.SuccessStatus;
                    //	}
                    //	else
                    //	{
                    //		msgResult = BusinessCont.FailStatus;
                    //	}
                    //	FinalWhatsappMsg = "";
                    //	MobileNo = "";
                    //	FilePath = "";
                    //}

                    // STEP 6: Refill Sales Register (DELIVERED) Consumer
                    // VASWhatsAppMsgSent = 1 - WhatsApp Message Sent otherwise not sent
                    // Note:  VASWhatsAppMsgSent = 1 value through Activate Campaign
                    var deliveredData = pendingBookingList.Where(p => p.DistributorCode == DistributorCode && p.OrderStatus == "Delivered" || p.OrderStatus == "DLVD" && p.VASWhatsAppMsgSent == 1).ToList();
                    if (deliveredData.Count > 0)
                    {
                        foreach (var item in deliveredData)
                        {
                            FinalWhatsappMsg = "Dear HPGAS Customer\n*"
                                                 + item.ConsumerName + "* � *" + Convert.ToInt32(item.ConsumerNo) + "*\n"
                                                 + "Happy to share that as commiteed your refill was delivered within 24 hrs from booking.\n\n"
                                                 + "Thankyou for using HPGAS Servcies.\n*" + item.DistributorName + "*\n"
                                                 + "Cont No: *" + item.DealerMobNo + "* & *" + item.PhoneNo + "*";

                            MobileNo = item.ConsumerMobNo;

                            // STEP 7: message send through MobileNo in (DELIVERED) Consumer
                            result = Task.Run(() => BusinessCont.WhatsAppMsg(FinalWhatsappMsg, MobileNo, ""));
                            Task.WaitAll(result);
                            PkAssistModel response = JsonConvert.DeserializeObject<PkAssistModel>(result.Result);
                            if (response.message == "Success")
                            {
                                msgResult = BusinessCont.SuccessStatus;
                            }
                            else
                            {
                                msgResult = BusinessCont.FailStatus;
                            }
                            FinalWhatsappMsg = "";
                            MobileNo = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, pendingBookingList[0].DistributorId, "PendingBookingList", "DistributorCode: " + DistributorCode, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            return msgResult;
        }
        #endregion

        #region HTML To PDF (Dealer/Distributor)
        private void HTMLToPdf(string HTML, string FilePath)
        {
            Document document = null;
#pragma warning disable CS0612 // 'HTMLWorker' is obsolete
            HTMLWorker hw = null;
#pragma warning restore CS0612 // 'HTMLWorker' is obsolete
            PdfWriter writer = null;
            try
            {
                document = new Document(PageSize.A4);
                using (FileStream fs = new FileStream(FilePath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                {
                    writer = PdfWriter.GetInstance(document, fs);
                    document.Open();
                    writer.CloseStream = false;
#pragma warning disable CS0612 // 'HTMLWorker' is obsolete
                    hw = new HTMLWorker(document);
#pragma warning restore CS0612 // 'HTMLWorker' is obsolete
                    hw.Parse(new StringReader(HTML));
                    hw.Close();
                    document.Close();
                    fs.Flush();
                    fs.Close();
                }
                //Force clean up
                GC.Collect();
            }
            catch (Exception ex)
            {
                BusinessCont.SaveAPILog(0, 0, "HTMLToPdf", "HTML To PDF (Dealer/Distributor) - FilePath: " + FilePath, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
            }
            finally { document = null; hw = null; writer = null; }
        }
        #endregion

        #region Get Booking Report History List
        public List<BookReportHistoryModel> GetBookingReportHistoryList(string DistributorCode, string FromDate, string ToDate, string Flag)
        {
            return GetBookingReportHistoryListPvt(DistributorCode, FromDate, ToDate, Flag);
        }

        private List<BookReportHistoryModel> GetBookingReportHistoryListPvt(string DistributorCode, string FromDate, string ToDate, string Flag)
        {
            List<BookReportHistoryModel> BookingReportHistoryLst = new List<BookReportHistoryModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    BookingReportHistoryLst = _Context.usp_RefillBookingPendingList(DistributorCode, Convert.ToDateTime(FromDate), Convert.ToDateTime(FromDate), Flag).Select(r => new BookReportHistoryModel
                    {
                        PkOrderId = r.PkOrderId,
                        DistributorId = Convert.ToInt32(r.DistributorId),
                        DistributorCode = r.DistributorCode,
                        OrderNo = r.OrderNo,
                        OrderDate = Convert.ToDateTime(r.OrderDate),
                        OrderStatus = r.OrderStatus,
                        OrderSource = r.OrderSource,
                        OrderType = r.OrderType,
                        ConsumerNo = r.ConsumerNo,
                        ConsumerName = r.ConsumerName,
                        CashMemoNo = r.CashMemoNo,
                        CashMemoDate = Convert.ToDateTime(r.CashMemoDate),
                        CMCancelDate = Convert.ToDateTime(r.CMCancelDate),
                        CMStatus = r.CMStatus,
                        CMCancelReason = r.CMCancelReason,
                        ActualDelDate = Convert.ToDateTime(r.ActualDelDate),
                        MobNo = r.MobNo,
                        ConsAddress = r.ConsAddress,
                        DeliveredBy = r.DeliveredBy,
                        AddedOn = Convert.ToDateTime(r.AddedOn),
                        LastUpdatedOn = Convert.ToDateTime(r.LastUpdatedOn),
                        AssignTo = r.AssignTo
                    }).ToList();
                }

            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "GetBookingReportHistoryListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            return BookingReportHistoryLst;
        }
        #endregion

        #region Add/Update Active User
        public ActiveUserModel AddUpdateActiveUser(AddActiveUserModel model)
        {
            return AddUpdateActiveUserServicePvt(model);
        }
        private ActiveUserModel AddUpdateActiveUserServicePvt(AddActiveUserModel model)
        {
            ActiveUserModel message = new ActiveUserModel();
            int RetValue = 0;
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    ObjectParameter objRetValue = new ObjectParameter("RetValue", typeof(int));
                    RetValue = _Context.usp_AddActiveUser(model.DistibutorId, model.UserId, model.Username, model.VersionNo, model.DeviceId, objRetValue);
                    if (RetValue > 0)
                    {
                        message.messageResult = BusinessCont.SuccessStatus;
                    }
                    else
                    {
                        message.messageResult = BusinessCont.FailStatus;
                    }
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Add/Update Active User Pvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return message;
        }
        #endregion

        #region Firebase push Notification For Customer Surver
        /// <summary>
        /// Method for send notification to android user
        /// </summary>
        /// <param name="DistributorId">Distributor Id for send notification</param>
        /// <param name="Title">Notification title</param>
        /// <param name="Message">Notification message</param>
        /// <returns></returns>
        public void SendNotification(int DistibutorId, string Title, string Message)
        {
            try
            {
                BusinessCont.SaveLog(0, DistibutorId, "Send Notification", "DistibutorId= " + DistibutorId + ", Title=" + Title + ", Message=" + Message, "START", "");

                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    var DeviceDetails = _Context.usp_GetUserDeviceDetails(DistibutorId).ToList();
                    if (DeviceDetails.Count > 0)
                    {
                        for (int i = 0; i < DeviceDetails.Count; i++)
                        {
                            BusinessCont.AndroidNotification(DeviceDetails[i].DeviceId, Title, Message);
                        }
                    }
                }

                BusinessCont.SaveLog(0, DistibutorId, "Send Notification", "DistibutorId= " + DistibutorId + ", Title=" + Title + ", Message=" + Message, "END", "");
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistibutorId, "Send Notification", "DistibutorId= " + DistibutorId + ", Title=" + Title + ", Message=" + Message, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
        }
        #endregion

        #region VAS Consumers Add Edit For Mob
        public VasConsResultModel ConsumersAddEditForMob(VASConsumersModel model)
        {
            return ConsumersAddEditForMobPvt(model);
        }
        private VasConsResultModel ConsumersAddEditForMobPvt(VASConsumersModel model)
        {
            VasConsResultModel message = new VasConsResultModel();
            int Retvalue = 0;
            try
            {
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    var result = context.usp_VASConsumersAddUpdate(model.SACode, model.DistributorId, model.DistributorCode, model.DistributorName,
                        Convert.ToInt64(model.UniqueConsumerId), Convert.ToInt32(model.ConsumerNo), model.MobileNo, model.ConsumerName, model.AreaName, model.ConsumerAddress, model.IsRegistered, Convert.ToDateTime(model.RegisterDate).
                        ToString("yyyy-MM-dd"), model.Status, model.Action, model.IsApprove, model.AddedBy, "").FirstOrDefault();
                    Retvalue = Convert.ToInt32(result.RetValue);
                }
                if (Retvalue > 0 && model.Action == "ADD")
                {
                    var RetValue = GenerateWhatsappMsg(model);
                }
                if (Retvalue > 0)
                {
                    message.messageResult = BusinessCont.SuccessStatus;
                }
                else
                {
                    message.messageResult = BusinessCont.FailStatus;
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "ConsumersAddEditForMobPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return message;
        }
        #endregion

        #region Vas Consumer List For Mob
        public List<VASConsumersModel> VasConsumerListForMob(string DistributorCode, string StaffName, int ConsumerNo)
        {
            return VasConsumerListForMobPvt(DistributorCode, StaffName, ConsumerNo);
        }
        private List<VASConsumersModel> VasConsumerListForMobPvt(string DistributorCode, string StaffName, int ConsumerNo)
        {
            List<VASConsumersModel> list = new List<VASConsumersModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    list = _Context.usp_VASConsumersListForMob(DistributorCode, StaffName, ConsumerNo).Select(s => new VASConsumersModel
                    {
                        SACode = s.SACode,
                        DistributorId = s.DistributorId,
                        DistributorCode = s.DistributorCode,
                        DistributorName = s.DistributorName,
                        UniqueConsumerId = Convert.ToString(s.UniqueConsumerId),
                        ConsumerNo = Convert.ToString(s.ConsumerNo),
                        MobileNo = s.MobileNo,
                        ConsumerName = s.ConsumerName,
                        AreaName = s.AreaName,
                        ConsumerAddress = s.ConsumerAddress,
                        IsMobNoDuplicate = s.IsMobNoDuplicate,
                        IsWhatsappNo = s.IsWhatsappNo,
                        IsMessageSent = s.IsMessageSent,
                        IsRegistered = s.IsRegistered,
                        RegistrationDate = Convert.ToDateTime(s.RegistrationDate),
                        ExpiryDate = Convert.ToDateTime(s.ExpiryDate),
                        Status = Convert.ToInt32(s.Status),
                        IsApprove = s.IsApprove,
                        AddedBy = s.AddedBy,
                        OrderNo = s.OrderNo,
                        OrderDate = Convert.ToDateTime(s.OrderDate),
                        OrderStatus = s.OrderStatus,
                        ActualDelDate = Convert.ToDateTime(s.ActualDelDate)
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "RefillBookingPendingListPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return list;
        }
        #endregion

        #region VAS MIS Report
        public List<VASMISModel> VASMISReport(string SACode, string ROCode, string Flag)
        {
            return VASMISReportPvt(SACode, ROCode, Flag);
        }

        private List<VASMISModel> VASMISReportPvt(string SACode, string ROCode, string Flag)
        {
            List<VASMISModel> VASMISReportLst = new List<VASMISModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    VASMISReportLst = _Context.usp_VASMISReportData(SACode, ROCode, Flag).Select(m => new VASMISModel
                    {
                        SACode = m.SACode,
                        SAName = m.SAName,
                        DistributorIdint = m.DistributorIdint,
                        JDEDistributorCode = m.JDEDistributorCode,
                        DistributorName = m.DistributorName,
                        TotalRegConsumer = m.TotalRegConsumer,
                        PendingBooking = m.PendingBooking,
                        YestDelivery = m.YestDelivery,
                        DelDelay = m.DelDelay,
                        S1 = m.S1,
                        S2 = m.S2
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "VASMISReportPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            return VASMISReportLst;
        }
        #endregion

        #region VAS User Wise Counts For Mob
        public VASUserCountsModel VASUserWiseCounts(string DistributorCode, string StaffName)
        {
            return VASUserWiseCountsPvt(DistributorCode, StaffName);
        }
        private VASUserCountsModel VASUserWiseCountsPvt(string DistributorCode, string StaffName)
        {
            VASUserCountsModel modal = new VASUserCountsModel();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    modal = _Context.usp_VASUserWiseCountsForMob(DistributorCode, StaffName).Select(s => new VASUserCountsModel
                    {
                        DistributorId = Convert.ToInt32(s.DistributorId),
                        DistributorCode = s.JDEDistributorCode,
                        VASConsumer = Convert.ToInt32(s.VASConsumer),
                        ApprovedCount = Convert.ToInt32(s.ApprovedCount),
                        PendingForApprove = Convert.ToInt32(s.PendingForApprove),
                    }).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "VASUserWiseCountsPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return modal;
        }
        #endregion

        #region Get Log Save List
        public List<LogSaveModel> GetLogList()
        {
            return GetLogListPvt();
        }
        private List<LogSaveModel> GetLogListPvt()
        {
            List<LogSaveModel> logsavelst = new List<LogSaveModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    logsavelst = _Context.usp_GetVASDataFetchLogList().Select(r => new LogSaveModel
                    {
                        LogId = r.LogId,
                        DistributorCode = r.DistributorCode,
                        //LoginDateTime = Convert.ToDateTime(r.LoginDateTime).ToString("dd/MM/yyyy"),
                        LoginDateTime = Convert.ToDateTime(r.LoginDateTime).ToString("dd/MM/yyyy"),
                        LoginStatus = r.LoginStatus,
                        LogFor = r.LogFor,
                        FileFor = r.FileFor,
                        BkgFileName = r.BkgFileName,
                        BkgFileAddedOn = Convert.ToDateTime(r.BkgFileAddedOn),
                        SRFileName = r.SRFileName,
                        SRFileAddedOn = Convert.ToDateTime(r.SRFileAddedOn),
                        BkgExcelCount = Convert.ToInt32(r.BkgExcelCount),
                        BkgImportedCount = Convert.ToInt32(r.BkgImportedCount),
                        SRExcelCount = Convert.ToInt32(r.SRExcelCount),
                        SRImportedCount = Convert.ToInt32(r.SRImportedCount)
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Get Log List Pvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return logsavelst;
        }
        #endregion

        #region Summary Counts for auto fetch data 
        public VasSummaryCountAutoFetchDataModel VasSummaryCountAutoFetchData()
        {
            return VasSummaryCountAutoFetchDataPvt();
        }
        private VasSummaryCountAutoFetchDataModel VasSummaryCountAutoFetchDataPvt()
        {
            VasSummaryCountAutoFetchDataModel modal = new VasSummaryCountAutoFetchDataModel();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    modal = _Context.usp_VasSummaryCountAutoFetchData().Select(s => new VasSummaryCountAutoFetchDataModel
                    {
                        LoginFailCount = s.LoginFailCount,
                        BKGFileFailCount = s.BKGFileFailCount,
                        SRFileFailCounts = s.SRFileFailCounts,
                        BkgEmptyExcelCounts = s.BkgEmptyExcelCounts,
                        SREmptyExcelCounts = s.SREmptyExcelCounts,
                        LastCycleTime = Convert.ToInt32(s.LastCycleTime),
                        OneamshedularExeutedornot = Convert.ToString(s.MrngCycle),
                        OneamshedularExeutedornot1 = Convert.ToInt32(s.OneAM),
                        TotalBkgDownloadFile = Convert.ToInt32(s.TotalBkgDownloadFile),
                        TotalNoofCycle = Convert.ToInt32(s.TotalNoofCycle)
                    }).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "VasSummaryCountAutoFetchDataPvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return modal;
        }
        #endregion

        #region Get List For Log Save Count
        public List<LogSaveListModel> GetVasLogFeacthList()
        {
            return GetVasLogFeacthListPvt();
        }
        private List<LogSaveListModel> GetVasLogFeacthListPvt()
        {
            List<LogSaveListModel> logsavelst = new List<LogSaveListModel>();
            try
            {
                using (HPGASNCEnquiryEntities _Context = new HPGASNCEnquiryEntities())
                {
                    logsavelst = _Context.usp_GetVasLogFeacthList().Select(r => new LogSaveListModel
                    {
                        LogId = r.LogId,
                        DistributorCode = r.DistributorCode,
                        LoginDateTime = Convert.ToDateTime(r.LoginDateTime).ToString("dd/MM/yyyy hh:mm"),
                        //LoginDateTime = Convert.ToDateTime(r.LoginDateTime),
                        LoginStatus = r.LoginStatus,
                        LogFor = r.LogFor,
                        FileFor = r.FileFor,
                        BkgFileName = r.BkgFileName,
                        BkgFileAddedOn = Convert.ToDateTime(r.BkgFileAddedOn),
                        SRFileName = r.SRFileName,
                        SRFileAddedOn = Convert.ToDateTime(r.SRFileAddedOn),
                        BkgExcelCount = Convert.ToInt32(r.BkgExcelCount),
                        BkgImportedCount = Convert.ToInt32(r.BkgImportedCount),
                        SRExcelCount = Convert.ToInt32(r.SRExcelCount),
                        SRImportedCount = Convert.ToInt32(r.SRImportedCount)
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "Get Vas Log Feacth List Pvt", DateTime.Now.ToString(), "", BusinessCont.ExceptionMsg(ex));
            }
            return logsavelst;
        }
        #endregion
    }
}
