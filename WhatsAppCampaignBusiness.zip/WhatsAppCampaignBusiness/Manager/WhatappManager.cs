using HPGASNCEnquiryBusiness.BusinessConstant;
using System;
using WhatsAppCampaignBusiness.Models.Entity;

namespace HPGASNCEnquiryBusiness.Manager
{
    public class WhatappManager
    {
        #region Update Flag IsMessageSent SBC
        public int UpdateFlagIsMessageSentSBC(string MobileNumbers, int DistributorId)
        {
            return UpdateFlagIsMessageSentSBCPvt(MobileNumbers, DistributorId);
        }
        private int UpdateFlagIsMessageSentSBCPvt(string MobileNumbers, int DistributorId)
        {
            int Result = 0;
            try
            {
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    Result = context.sp_UpdateFlagIsMessageSentSBC(MobileNumbers, Convert.ToString(DistributorId));
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "UpdateFlagIsMessageSentSBCPvt", "", "Failed", BusinessCont.ExceptionMsg(ex));
            }
            return Result;
        }
        #endregion

        #region Update Flag IsMessageSent SURAKSHA
        public int UpdateFlagIsMessageSentSURAKSHA(string MobileNumbers, int DistributorId)
        {
            return UpdateFlagIsMessageSentSURAKSHAPvt(MobileNumbers, DistributorId);
        }
        private int UpdateFlagIsMessageSentSURAKSHAPvt(string MobileNumbers, int DistributorId)
        {
            int Result = 0;
            try
            {
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    Result = context.sp_UpdateFlagIsMessageSentSURAKSHA(MobileNumbers, Convert.ToString(DistributorId));
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "UpdateFlagIsMessageSentSURAKSHA", "", "Failed", BusinessCont.ExceptionMsg(ex));
            }
            return Result;
        }
        #endregion

        #region Update Flag IsMessageSent ARB
        public int UpdateFlagIsMessageSentARB(string MobileNumbers, int DistributorId)
        {
            return UpdateFlagIsMessageSentARBPvt(MobileNumbers, DistributorId);
        }
        private int UpdateFlagIsMessageSentARBPvt(string MobileNumbers, int DistributorId)
        {
            int Result = 0;
            try
            {
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    Result = context.usp_UpdateFlagIsMessageSentARB(MobileNumbers, Convert.ToString(DistributorId));
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, DistributorId, "UpdateFlagIsMessageSentARBPvt", "", "Failed", BusinessCont.ExceptionMsg(ex));
            }
            return Result;
        }
        #endregion

        #region Update User Reply For All Campaign
        public int UpdateUserReplyForAllCampaign(string MobileNumbers, decimal uniqueConsumerId, string Message, string StatusCode, string MessageStatus, string EventType)
        {
            return UpdateUserReplyForAllCampaignPvt(MobileNumbers, uniqueConsumerId, Message, StatusCode, MessageStatus, EventType);
        }
        private int UpdateUserReplyForAllCampaignPvt(string MobileNumbers, decimal uniqueConsumerId, string Message, string StatusCode, string MessageStatus, string EventType)
        {
            int Result = 0;
            try
            {
                using (HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities())
                {
                    Result = context.sp_UpdateUserReplyForAllCampaign(MobileNumbers, uniqueConsumerId, Message, StatusCode, MessageStatus, EventType);
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, "UpdateUserReplyForAllCampaign by Webhook", "", "Failed", BusinessCont.ExceptionMsg(ex));
            }
            return Result;
        }
        #endregion
    }
}
