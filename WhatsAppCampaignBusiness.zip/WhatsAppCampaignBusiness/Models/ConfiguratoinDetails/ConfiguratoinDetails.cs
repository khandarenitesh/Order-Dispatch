﻿using System;

namespace HPGASNCEnquiryBusiness.Models.ConfiguratoinDetails
{
    public class TemplateDetails
    {
        public string TemplateId { get; set; }
        public string TemplateName { get; set; }
        public string IsActive { get; set; }
    }

    public class SBCConfigDetails
    {
        public int DBCConfId { get; set; }
        public string SACode { get; set; }
        public DateTime ScheduleDate { get; set; }
        public string GroupName { get; set; }
        public int DistributorId { get; set; }
        public string DistributorIdarray { get; set; }
        public string DistributorMobNo { get; set; }
        public string EmergencyNo { get; set; }
        public string IsWithRefillCost { get; set; }
        public string RSP { get; set; }
        public string TemplateId { get; set; }
        public int MsgQty { get; set; }
        public string CurrentStatus { get; set; }
        public string Action { get; set; }
        public string Retvalue { get; set; }
        public string ScheduleDaily { get; set; }
    }
    public class SBCConfigDetailsList
    {
        public int DBCConfId { get; set; }
        public string SACode { get; set; }
        public DateTime ScheduleDate { get; set; }
        public int DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string DistributorMobNo { get; set; }
        public string EmergencyNo { get; set; }
        public string IsWithRefillCost { get; set; }
        public string RSP { get; set; }
        public string TemplateId { get; set; }
        public string TemplateName { get; set; }
        public int MsgQty { get; set; }
        public DateTime EntryDate { get; set; }
        public string CurrentStatus { get; set; }
        public string Completed { get; set; }
        public int Pending { get; set; }
        public int SendMsg { get; set; }
        public string GroupName { get; set; }
        public int NonWhatsAppNo { get; set; }
        public int TotalConsumer { get; set; }
        public int TotalMsgSend { get; set; }
        public int Balanced { get; set; }
        public int TodaySend { get; set; }
    }

    public class SBCConfigDetailsJobScheduler
    {
        public int DBCConfId { get; set; }
        public int DistributorId { get; set; }
        public string DistributorMobNo { get; set; }
        public string EmergencyNo { get; set; }
        public string IsWithRefillCost { get; set; }
        public string RSP { get; set; }
        public string TemplateId { get; set; }
        public int MsgQty { get; set; }
        public string CurrentStatus { get; set; }
        public string SACode { get; set; }
    }

    public class SBCConfigDetailsDistributorByList
    {
        public int DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string DistributorMobile { get; set; }
        public string EmergencyContactNo { get; set; }
        public string RSPAmount { get; set; }
    }

    public class SBCDistributorGroupMappingAddEdit
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public string SACode { get; set; }
        public string DistributorIdArray { get; set; }
        public string TemplateId { get; set; }
        public string IsActive { get; set; }
        public string Action { get; set; }
        public string RetValue { get; set; }
    }

    public class SBCDistributorGroupMappingList
    {
        public string GroupId { get; set; }
        public string GroupName { get; set; }
    }
    public class SurakshaDistributorGroupMappingList
    {
        public string GroupId { get; set; }
        public string GroupName { get; set; }
    }
    public class ARBDistributorGroupMappingList
    {
        public string GroupId { get; set; }
        public string GroupName { get; set; }
    }
    public class ARBDistributorListByGroupList
    {
        public int DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string OwnerName { get; set; }
        public string IsDistributorLive { get; set; }
        public decimal MobileNo { get; set; }
        public string Email { get; set; }
        public string SACode { get; set; }
        public string GroupName { get; set; }
        public int selected { get; set; }
        public string TemplateId { get; set; }
        public string TemplateName { get; set; }
    }
    public class ARBDistributorGroupMappingAddEdit
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public string SACode { get; set; }
        public string DistributorIdArray { get; set; }
        public string TemplateId { get; set; }
        public string IsActive { get; set; }
        public string Action { get; set; }
        public string RetValue { get; set; }
    }

    public class ARBConfigDetails
    {
        public int DBCConfId { get; set; }
        public string SACode { get; set; }
        public DateTime ScheduleDate { get; set; }
        public string GroupName { get; set; }
        public int DistributorId { get; set; }
        public string DistributorIdarray { get; set; }
        public string DistributorMobNo { get; set; }
        public string EmergencyNo { get; set; }
        public string IsWithRefillCost { get; set; }
        public string RSP { get; set; }
        public string TemplateId { get; set; }
        public int MsgQty { get; set; }
        public string CurrentStatus { get; set; }
        public string Action { get; set; }
        public string Retvalue { get; set; }
        public string ScheduleDaily { get; set; }
    }
    public class ARBConfigDetailsList
    {
        public int DBCConfId { get; set; }
        public string SACode { get; set; }
        public DateTime ScheduleDate { get; set; }
        public int DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string DistributorMobNo { get; set; }
        public string EmergencyNo { get; set; }
        public string IsWithRefillCost { get; set; }
        public string RSP { get; set; }
        public string TemplateId { get; set; }
        public string TemplateName { get; set; }
        public int MsgQty { get; set; }
        public DateTime EntryDate { get; set; }
        public string CurrentStatus { get; set; }
        public string Completed { get; set; }
        public int Pending { get; set; }
        public int SendMsg { get; set; }
        public string GroupName { get; set; }
        public int NonWhatsAppNo { get; set; }
        public int TotalConsumer { get; set; }
        public int TotalMsgSend { get; set; }
        public int Balanced { get; set; }
        public int TodaySend { get; set; }
    }
    public class SBCDistributorListByGroupList
    {
        public int DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string OwnerName { get; set; }
        public string IsDistributorLive { get; set; }
        public decimal MobileNo { get; set; }
        public string Email { get; set; }
        public string SACode { get; set; }
        public string GroupName { get; set; }
        public int selected { get; set; }
        public string TemplateId { get; set; }
        public string TemplateName { get; set; }
    }

    public class SurakshaUsersByAreaSeqModel
    {
        public string JDEDistributorCode { get; set; }
        public string AreaRefNo { get; set; }
        public decimal UniqueConsumerId { get; set; }
        public decimal ConsCnt { get; set; }
        public string AreaName { get; set; }
        public int AreaSeqNo { get; set; }
        public string AreaRefNoStr { get; set; }
        public string SeqNoStr { get; set; }

    }

    public class Resetpassmodel
    {
        public string Distributor_Code { get; set; }
        public string Distributor_Name { get; set; }
        public string CDCMS_Password { get; set; }
        public string CDCMS_ID_Email { get; set; }
        public DateTime Updated_Date { get; set; }
    }
    public class SurakshaConfigDetailsList
    {
        public int ConfgId { get; set; }
        public string SACode { get; set; }
        public DateTime ScheduleDate { get; set; }
        public int DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string DistributorMobNo { get; set; }
        public string EmergencyNo { get; set; }
        public string IsWithRefillCost { get; set; }
        public string RSP { get; set; }
        public string TemplateId { get; set; }
        public string TemplateName { get; set; }
        public int MsgQty { get; set; }
        public DateTime EntryDate { get; set; }
        public string CurrentStatus { get; set; }
        public string Completed { get; set; }
        public int Pending { get; set; }
        public int SendMsg { get; set; }
        public string GroupName { get; set; }
        public int NonWhatsAppNo { get; set; }
        public int TotalConsumer { get; set; }
        public int TotalMsgSend { get; set; }
        public int Balanced { get; set; }
        public int TodaySend { get; set; }
    }    
    public class SurakshaDistributorListByGroupList
    {
        public int DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string OwnerName { get; set; }
        public string IsDistributorLive { get; set; }
        public decimal MobileNo { get; set; }
        public string Email { get; set; }
        public string SACode { get; set; }
        public string GroupName { get; set; }
        public int selected { get; set; }
        public string TemplateId { get; set; }
        public string TemplateName { get; set; }
    }
    public class SurakshaDistributorGroupMappingAddEdit
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public string SACode { get; set; }
        public string DistributorIdArray { get; set; }
        public string TemplateId { get; set; }
        public string IsActive { get; set; }
        public string Action { get; set; }
        public string RetValue { get; set; }
    }
    public class SurakshaConfigDetails
    {
        public int ConfgId { get; set; }
        public string SACode { get; set; }
        public DateTime ScheduleDate { get; set; }
        public string GroupName { get; set; }
        public int DistributorId { get; set; }
        public string DistributorIdarray { get; set; }
        public string DistributorMobNo { get; set; }
        public string EmergencyNo { get; set; }
        public string IsWithRefillCost { get; set; }
        public string RSP { get; set; }
        public string TemplateId { get; set; }
        public int MsgQty { get; set; }
        public string CurrentStatus { get; set; }
        public string Action { get; set; }
        public string Retvalue { get; set; }
        public string ScheduleDaily { get; set; }
    }
    public class ConfigDetailsJobScheduler
    {
        public int DBCConfId { get; set; }
        public int DistributorId { get; set; }
        public string DistributorMobNo { get; set; }
        public string EmergencyNo { get; set; }
        public string IsWithRefillCost { get; set; }
        public string RSP { get; set; }
        public string TemplateId { get; set; }
        public int MsgQty { get; set; }
        public string CurrentStatus { get; set; }
        public string SACode { get; set; }
    }
    public class SurakshaConfigDetailsJobScheduler
    {
        public int ConfgId { get; set; }
        public int DistributorId { get; set; }
        public string DistributorMobNo { get; set; }
        public string EmergencyNo { get; set; }
        public string IsWithRefillCost { get; set; }
        public string RSP { get; set; }
        public string TemplateId { get; set; }
        public int MsgQty { get; set; }
        public string CurrentStatus { get; set; }
        public string SACode { get; set; }
    }
}
