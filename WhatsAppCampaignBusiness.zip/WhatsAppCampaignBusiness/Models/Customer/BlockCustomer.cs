﻿using HPGASNCEnquiryBusiness.Models.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPGASNCEnquiryBusiness.Models.Customer
{

    public class GetBlockCustomerDetails : StatusDetails
    {
        public IEnumerable<BlockCustomer> blockCustomers { get; set; }
    }
    public class postData
    {
        public int DistributorId { get; set; }
        public  string Distributorcode { get; set; }
        public string CallStatusColour { get; set; }
        public string uniSearch { get; set; }
        public string flag { get; set; }
        public int? PageNo { get; set; }
        public int PageSize { get;set; }
        public string SACode { get; set; }
    }

    public class BlockCustomer
    {
        public long Srno { get; set; }
        public int DistributorId { get; set; }
        public string DistributorCode { get; set; }
            public string UniqueConsumerId { get; set; }
            public string ConsumerNo { get; set; }
            public string ConsumerName { get; set; }
            public string Address { get; set; }
            public string AreaName { get; set; }
            public string IVRSMobNo { get; set; }
            public string CDCMSMobNo { get; set; }
            public string BlockDate { get; set; }
            public string Feedback { get; set; }
            public Nullable<decimal> CallStatusId { get; set; }
            public string CallStatusName { get; set; }
            public string FeedbackDT { get; set; }
            public string IsCylinderBook { get; set; }
            public string Blockedby { get; set; }
        public string FeedbackType { get; set; }
        public Nullable<int> NoOfCall { get; set; }
        public string ActualMobCallStatus { get; set; }
        public string Flag { get; set; }
    }


    public class GetCallStatusMst : StatusDetails
    {
        public List<CallStatusMst> callStatusMsts { get; set; }
    }


    public class CallStatusMst
    {
        public decimal Id { get; set; }
        public string CallStatusName { get; set; }
        public string Colour { get; set; }
        public string IsActive { get; set; }
    }
 
    public class postMdl :StatusDetails
    {
        public decimal Id { get; set; }
    }

    public class BlockConsumerCallStatus : StatusDetails
    {
        public List<SaveFeedBack> getBlkConsCallStatuslst { get; set; }
    }

    public class SaveFeedBack
    {
        public decimal Id { get; set; }
        public long StaffRefNo { get; set; }
        public string UniqueConsumerId { get; set; }
        public int DistributorId { get; set; }
        public string DistributorCode { get; set; }
        public decimal CallStatusId { get; set; }
        public string CallStatusName { get; set; }
        public string Feedback { get; set; }
        public Nullable<System.DateTime> FeedbackDate { get; set; }
        public string FeedbackDateSt { get; set; }
        public string Flag { get; set; }
        public string FeedbackType { get; set; }
        public string Operation { get; set; }
        public string ActualMobCallStatus { get; set; }
    }
    public class DistributorDashboardDtls : StatusDetails
    {
        public List<CltFeedbackCount> colorWiseCount { get; set; }
        public BlkcltCnt blkcltCnt { get; set; }

        public List<AreaWiseCount> areaWiseCount { get; set; }
    }

    public class UpdateCylinderBookStatus
    {

    }


    public class CltFeedbackCount
    {
        public string CallStatusColour { get; set; }
        public int ConsCnt { get; set; }

    }
    public class BlkcltCnt
    {
        public Nullable<int> TotalConsCnt { get; set; }
        public Nullable<int> CalledCnt { get; set; }
        public Nullable<int> PendingCnt { get; set; }
        public Nullable<int> ConsWithNo { get; set; }
    }

    public class AreaWiseCount
    {
        public string DistributorCode { get; set; }
        public string AreaName { get; set; }
        public Nullable<int> TotalConsCnt { get; set; }
        public Nullable<int> CalledCnt { get; set; }
        public Nullable<int> PendingCnt { get; set; }
    }


    public class SAwiseBkConCount
    {
        public string SACode { get; set; }
        public string SAName { get; set; }
        public string DistributorCode { get; set; }
        public string DistributorName { get; set; }
        public int TotalConsCnt { get; set; }
        public int ConsWithNo { get; set; }
        public int PendingConsCnt { get; set; }
        public int CompCnt { get; set; }
        public int TodCompCnt { get; set; }
    }


}
