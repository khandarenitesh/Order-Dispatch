using HPGASNCEnquiryBusiness.Models;
using HPGASNCEnquiryBusiness.Models.EmailScheduler;
using HPGASNCEnquiryBusiness.Models.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace HPGASNCEnquiryBusiness.Models.Customer
{
    public class CustomerDetails
    {
        public long CId { get; set; }
        public string CustPersonalDtls { get; set; }
        public string CustEnquiryDtls { get; set; }
        public int QueId { get; set; }
        public int DistributorId { get; set; }
        public string DistributorName { get; set; }
        public long StaffRefNo { get; set; }
        public string ConsName { get; set; }
        public string Address { get; set; }
        public string MobileNo { get; set; }
        public string ConnectionType { get; set; }
        public string ConsumerNo { get; set; }
        public int QId { get; set; }
        public int AnsId { get; set; }
        public string Ans { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string EnquiryId { get; set; }
        public string ResidentiaArea { get; set; }
        public string EmailId { get; set; }
        public string CompanyName { get; set; }
        public string SourceType { get; set; }
    }

    public class UnassginConsumer
    {
        public long CId { get; set; }
        public Nullable<int> DistributorId { get; set; }
        public string DistributorName { get; set; }
        public Nullable<long> StaffRefNo { get; set; }
        public string ConsumerName { get; set; }
        public string Address { get; set; }
        public string ResidentiaArea { get; set; }
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public string CompanyName { get; set; }
        public string ConsumerNo { get; set; }
        public string IsPurchase { get; set; }
        public string PurchaseDate { get; set; }
        public string EnquiryDate { get; set; }
        public string Reason { get; set; }
        public string SourceType { get; set; }

        public long ConnectionType { get; set; }
        public long Stove { get; set; }
        public long burnerType { get; set; }
        public string Brand { get; set; }
        public string ExpectedDate { get; set; }
    }

    public class ConsumerDetailsForWA
    {

        public string ConsumerName { get; set; }
        public string Address { get; set; }
        public string MobileNo { get; set; }
        public string ResidentiaArea { get; set; }
        public string EmailId { get; set; }
        public string CompanyName { get; set; }
        public string ErrorMsg { get; set; }
        public bool flag { get; set; }
        public string SourceType { get; set; }
    }



    public class DocumentsDetails: StatusDetails
    {
        public List<Documents> Documents { get; set; }
        public string EnquiryId { get; set; }
    }
    public class Documents
    {
        public string DocumentName { get; set; }
        public Nullable<long> EQueId { get; set; }
    }
    public class ConsumerDetails:StatusDetails
    {
        public List<ConsDtls> ConsDtls { get; set; }
        public List<UnassginConsumer> unassginConsumers { get; set; }
        public EmailSchedulerModel emailSchedulerModel { get; set; }
        public UnassginConsumer unassginConsumersDtls { get; set; }
    }
    public class ConsDtls
    {
        public long CId { get; set; }
        public string ConsumerName { get; set; }
        public string ConsAddress { get; set; }
        public string MobileNo { get; set; }
        public string ResidentiaArea { get; set; }
        public string SourceType { get; set; }
        public string EmailId { get; set; }
        public string CompanyName { get; set; }
        public Nullable<int> DistributorId { get; set; }
        public string IsPurchase { get; set; }
        public string PurchaseDate { get; set; }
        public string EnquiryDate { get; set; }
        public string DistributorName { get; set; }
        public string DistributorCode { get; set; }
        public string DistAddress { get; set; }
        public long StaffRefNo { get; set; }
        public string StaffType { get; set; }
        public string StaffName { get; set; }
        public string Operation { get; set; }
        public string ConsumerNo { get; set; }
        public string Reason { get; set; }
        public string EnquiryType { get; set; }
    }
    public class EmailSend
    {
        public string Email { get; set; }
        public string Status { get; set; }
        public Nullable<int> Id { get; set; }
    }
    public class CustomerQueAnsDetails
    {
        public int QId { get; set; }
        public int AnsId { get; set; }
        public string Ans { get; set; }
    }

    public class WhatsappAPIDtls
    {
        public string Token { get; set; }
        public string WhatsappMsgDtls { get; set; }
        public LPGDetails MsgDtls { get; set; }
        public int EventId { get; set; }
    }

    public class MessageSend
    {
        public string Status { get; set; }
    }

    public class LPGDetails
    {
        public string CustomerName { get; set; }
        public string CRN { get; set; }
        public string ActiveDate { get; set; }
        public string MobileNo { get; set; }
        public string MeterReading { get; set; }
        public string ReadingDate { get; set; }
        public string OfficeNumbers { get; set; }
        public string TotalAmountDue { get; set; }
        public string DueDate { get; set; }
        public string PaymentLink { get; set; }
        public string BillingMonth { get; set; }
        public string AmountPaid { get; set; }
		public string Billurl { get; set; }
	}
}
