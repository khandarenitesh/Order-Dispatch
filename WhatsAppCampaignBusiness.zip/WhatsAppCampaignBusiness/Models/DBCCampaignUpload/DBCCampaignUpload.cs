namespace HPGASNCEnquiryBusiness.Models.DBCCampaignUpload
{
    public class DBCCampaignUpload
    {
        public int pkId { get; set; }
        public int SACode { get; set; }
        public int DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public long UniqueConsumerId { get; set; }
        public long ConsumerNo { get; set; }
        public string ConsumerName { get; set; }
        public string MobileNo { get; set; }
		public decimal AreaRefNo { get; set; }
		public string AreaName { get; set; }
	}

    public class SecondCylenderUpload
    {
        public string SrNo { get; set; }
        public string DistributorID { get; set; }
        public string JDEDistributorCode { get; set; }
        public string UniqueConsumerId { get; set; }
        public string consumerNo { get; set; }
        public string SVDate { get; set; }
    }
}
