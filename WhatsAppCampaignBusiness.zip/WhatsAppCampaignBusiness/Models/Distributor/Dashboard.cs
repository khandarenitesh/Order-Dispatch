﻿using HPGASNCEnquiryBusiness.Models.Masters;
using System;
using System.Collections.Generic;

namespace HPGASNCEnquiryBusiness.Models.Distributor
{

    public class DashboardCountDtls : StatusDetails
    {
        public DashboardCount getDashboardCount { get; set; }
        public List<DashboardStaffCount> Staffwisecount { get; set; }

        public MessageSentConsumerCount messageSentConsumerCount { get; set; }

        public InterestedConsumerCount interestedConsumerCount { get; set; }
    }

    public class DashboardCount
    {
        public int DistributorId { get; set; }
        public int TotalNcEnquiry { get; set; }
        public int TodayNcEnquiry { get; set; }
        public int TotalPurchase { get; set; }
        public int TodayPurchase { get; set; }
        public long StaffRefNo { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string Id { get; set; }
    }
    public class DashboardStaffCount
    {
        public int DistributorId { get; set; }
        public long StaffRefNo { get; set; }
        public string StaffName { get; set; }
        public int TotalNcEnquiry { get; set; }
        public int TodayNcEnquiry { get; set; }
        public int TotalPurchase { get; set; }
        public int TodayPurchase { get; set; }
        public string IsInactiveConsActive { get; set; }
    }




    public class DistLanguageModel
    {
        public int DistributorId { get; set; }
        public int LanguageId { get; set; }
        public string LanguageName { get; set; }
        public string ActiveStatus { get; set; }

    }

    public partial class MessageSentConsumerCount
    {
        public Nullable<int> TotalCnt { get; set; }
        public int TodaysCnt { get; set; }
        public Nullable<int> Messagesentcount { get; set; }
        public Nullable<int> Interestedcount { get; set; }
        public Nullable<int> SBCCount { get; set; }
        public Nullable<int> ConnectionReleasedCount { get; set; }
        public Nullable<int> DuplicateMobCount { get; set; }
        public Nullable<int> ReadCount { get; set; }
        public Nullable<int> ConsumerContactedCount { get; set; }
        public Nullable<int> NotIntrestedCount { get; set; }
        public Nullable<int> ReadContactedCount { get; set; }
        public Nullable<int> CheckMsgSent { get; set; }
        public Nullable<int> MIDoneCount { get; set; }
        public Nullable<int> SurakshaHostChangedCount { get; set; }
        public Nullable<int> Both { get; set; }
        public string Id { get; set; }
        public Nullable<int> ARBDone { get; set; }
        public int SurkshaCount { get; set; }
        public int ARBCount { get; set; }
        public int ARBDoneCount { get; set; }
    }

    public partial class InterestedConsumerCount
    {
        public Nullable<int> TotalConsumerCnt { get; set; }
        public int TodaysConsumerCnt { get; set; }
    }

    public class AdminDBC
    {
        public string SACode { get; set; }
        public string SAName { get; set; }
        public Nullable<int> DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public Nullable<int> TotalConsumer { get; set; }
        public Nullable<int> ConsumerProcessed { get; set; }
        public Nullable<int> ConsumerBalance { get; set; }
        public Nullable<int> MessageSend { get; set; }
        public Nullable<int> Interested { get; set; }
        public Nullable<decimal> InterestedPercent { get; set; }
        public Nullable<int> NotInterestedCount { get; set; }
        public Nullable<int> ConnectionReleased { get; set; }
        public Nullable<int> MessageRead { get; set; }
        public Nullable<int> Contacted { get; set; }
        public Nullable<int> PendingForContact { get; set; }

        //public string Id { get; set; }
        //public string UserName { get; set; }
        //public int YesterdayMessageSent { get; set; }
        //public int YesterdayIntersted { get; set; }
        //public int ThisMonthMessageSent { get; set; }
        //public int ThisMonthIntersted { get; set; }
        //public int TotalMessageSent { get; set; }
        //public int TotalIntersted { get; set; }
        //public Nullable<int> Interestedcount { get; set; }
        //public Nullable<int> NotIntrestedCount { get; set; }
        //public Nullable<int> ReadCount { get; set; }
        //public Nullable<int> ConsumerContactedCount { get; set; }
        //public Nullable<int> ConnectionReleasedCount { get; set; }
    }

    public class SAModel
    {
        public string SACode { get; set; }
        public string SAName { get; set; }
        public string ROCode { get; set; }
        public string ZOCode { get; set; }
        public string ActiveFlag { get; set; }
        public string LastUpdateBy { get; set; }
        public System.DateTime LastUpdateDateTime { get; set; }
    }
    public class InterestedCountsModel
    {
        public int DistributorId { get; set; }
        public string StatusName { get; set; }
        public int ReadCnt { get; set; }
        public int InterestedCnt { get; set; }
    }

    public class ARBItemModel
    {
        public int itemId { get; set; }
        public string ItemName { get; set; }
        public int ItemPrice { get; set; }
        public int IsActive { get; set; }
    }

    public class ARBItemSoldCountsModel
    {
        public string JDEDistributorCode { get; set; }
        public string ItemName { get; set; }
        public decimal ItemSoldCnt { get; set; }
        public int itemId { get; set; }
    }
}
