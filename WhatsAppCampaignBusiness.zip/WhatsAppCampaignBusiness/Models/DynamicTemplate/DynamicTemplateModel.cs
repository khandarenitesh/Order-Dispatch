﻿
using System;
using System.Collections.Generic;

namespace WhatsAppCampaignBusiness.Models.DynamicTemplate
{
    public class DynamicTemplateModel
    {
        public int pkId { get; set; }
        public string CampaignId { get; set; }
        public string CampaignName { get; set; }
        public string TemplateId { get; set; }
        public string TemplateName { get; set; }
        public string TemplateFor { get; set; }
        public string TemplateType { get; set; }
        public string IsActive { get; set; }
        public string MediaType { get; set; }
        public string FileName { get; set; }
        public List<TemplateModel> TemplateData { get; set; }
    }

    public class TemplateModel
    {
        public int pkId { get; set; }
        public string TemplateId { get; set; }
        public string Value { get; set; }
        public string FieldType { get; set; }
        public string IsBold { get; set; }
        public string IsActive { get; set; }
        public DateTime AddedOn { get; set; }
    }

    public class TemplateMasterModel
    {
        public int pkId { get; set; }
        public string CampaignId { get; set; }
        public string CampaignName { get; set; }
        public string TemplateId { get; set; }
        public string TemplateName { get; set; }
        public string TemplateFor { get; set; }
        public string TemplateType { get; set; }
        public string IsActive { get; set; }
        public string MediaType { get; set; }
        public string FileName { get; set; }
    }

    public class AddSendTemplateMessageModel
    {
        public int pkId { get; set; }
        public string SACode { get; set; }
        public int DistributorId { get; set; }
        public string DistributorCode { get; set; }
        public string DistributorName { get; set; }
        public int ConsumerNo { get; set; }
        public string ConsumerName { get; set; }
        public string MobileNo { get; set; }
        public string TemplateId { get; set; }
        public string TemplateName { get; set; }
        public string Action { get; set; }
        public string CurrentStatus { get; set; }
    }

    public class SampleWhatsAppMessageSentModel
    {
        public int pkId { get; set; }
        public string SACode { get; set; }
        public int DistributorId { get; set; }
        public string DistributorName { get; set; }
        public string DistributorMobileNo { get; set; }
        public string PhoneNo { get; set; }
        public string DistributorEmergencyContactNo { get; set; }
        public int ConsumerNo { get; set; }
        public string MobileNo { get; set; }
        public string TemplateId { get; set; }
        public string ConsumerName { get; set; }
        public string RSPAmount { get; set; }
        public string DistrAddress { get; set; }
    }

}
