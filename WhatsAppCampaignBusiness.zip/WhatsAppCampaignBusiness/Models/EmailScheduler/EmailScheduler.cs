using HPGASNCEnquiryBusiness.BusinessConstant;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace HPGASNCEnquiryBusiness.Models.EmailScheduler
{
    public class EmailSchedulerModel
    {
        public int srno { get; set; }
        public string ZOCode { get; set; }
        public string JDEDistributorCode { get; set; }
        public string ZOName { get; set; }
        public string ROCode { get; set; }
        public string ROName { get; set; }
        public string SACode { get; set; }
        public string SAName { get; set; }
        public string Id { get; set; }
        public string UserName { get; set; }
        public string SourceType { get; set; }
        public int YesterdayEnquiry { get; set; }
        public int ThisMonthEnquiry { get; set; }
        public int TotalEnquiry { get; set; }
        public int YesterdayPurchase { get; set; }
        public int ThisMonthPurchase { get; set; }
        public int TotalPurchase { get; set; }
    }
    public class ExcelModel
    {
        public int srno { get; set; }
        public string Id { get; set; }
        public string UserName { get; set; }
        public string SourceType { get; set; }
        public int YesterdayEnquiry { get; set; }
        public int ThisMonthEnquiry { get; set; }
        public int TotalEnquiry { get; set; }
        public int YesterdayPurchase { get; set; }
        public int ThisMonthPurchase { get; set; }
        public int TotalPurchase { get; set; }

    }
    public class DBCExcelModel
    {
        public int srno { get; set; }
        public string Id { get; set; }
        public string UserName { get; set; }
        public int YesterdayEnquiry { get; set; }
        public int ThisMonthEnquiry { get; set; }
        public int TotalEnquiry { get; set; }
        public int YesterdayPurchase { get; set; }
        public int ThisMonthPurchase { get; set; }
        public int TotalPurchase { get; set; }

    }

    public class DBCExcelAdminModelSA
    {
        public int srno { get; set; }
        //public string SACode { get; set; }
        public string SAName { get; set; }
        //public string JDEDistributorCode { get; set; }
        //public string DistributorName { get; set; }
        //public int? ConsumerProcessed { get; set; }
        public int? MessageSend { get; set; }
        public int? Interested { get; set; }
        public decimal? InterestedPercent { get; set; }
        public int? ConnectionReleased { get; set; }
        //public int? PendingForContact { get; set; }
        //public int? MessageRead { get; set; }
        //public int? Contacted { get; set; }
        //public int? TotalConsumer { get; set; }
        //public int? ConsumerBalance { get; set; }
        //public int? NotInterestedCount { get; set; }
    }

    public class SurakshaExcelAdminModelSA
    {
        public int srno { get; set; }
        public string SAName { get; set; }
        //public int? ConsumerProcessed { get; set; }
        public int? MessageSend { get; set; }
        public int? Interested { get; set; }
        public decimal? InterestedPercent { get; set; }
        public int? MIDone { get; set; }
        public int? SurakshaChanged { get; set; }
        public int? Both { get; set; }
    }
    public class ARBExcelAdminModelSA
    {
        public int srno { get; set; }
        public string SAName { get; set; }
        public int? ConsumerProcessed { get; set; }
        public int? MessageSend { get; set; }
        public int? Interested { get; set; }
        public decimal? InterestedPercent { get; set; }
        public int? ARBDone { get; set; }
    }

    public class VASExcelAdminModelSA
    {
        public int srno { get; set; }
        public string SAName { get; set; }
        public int? TotalRegConsumer { get; set; }
        public int? PendingBooking { get; set; }
        public int? YestDelivery { get; set; }
        public int? DelDelay { get; set; }
        public int? S1 { get; set; }
        public int? S2 { get; set; }
    }

    public class VAS_ExcelAdminModel
    {
        public int srno { get; set; }
        public string SACode { get; set; }
        public string SAName { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public int? TotalRegConsumer { get; set; }
        public int? PendingBooking { get; set; }
        public int? YestDelivery { get; set; }
        public int? DelDelay { get; set; }
        public int? S_1 { get; set; }
        public int? S_2 { get; set; }
    }

    public class DBCExcelAdminModel
    {
        public int srno { get; set; }
        public string SACode { get; set; }
        public string SAName { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public int? TotalConsumer { get; set; }
        //public int? ConsumerProcessed { get; set; }
        public int? MessageSend { get; set; }
        public int? ConsumerBalance { get; set; }
        public int? Interested { get; set; }
        public decimal? InterestedPercent { get; set; }
        public int? NotInterestedCount { get; set; }
        public int? ConnectionReleased { get; set; }
        public int? MessageRead { get; set; }
        public int? Contacted { get; set; }
        public int? PendingForContact { get; set; }
        public int TotalConsumers { get; set; }
        //public int TotalConsumerProcessed { get; set; }
        public int TotalMessageSend { get; set; }
        public int TotalConsumerBalance { get; set; }
        public int TotalInterested { get; set; }
        public int TotalNotInterestedCount { get; set; }
        public int TotalConnectionReleased { get; set; }
        public int TotalMesageRead { get; set; }
        public int TotalContacted { get; set; }
        //public int TotalPendingForContacted { get; set; }

    }

    public class SurakshaExcelAdminModel
    {
        public int srno { get; set; }
        public string SACode { get; set; }
        public string SAName { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public int? TotalConsumer { get; set; }
        //public int? ConsumerProcessed { get; set; }
        public int? MessageSend { get; set; }
        public int? ConsumerBalance { get; set; }
        public int? Interested { get; set; }
        public decimal? InterestedPercent { get; set; }
        public int? NotInterestedCount { get; set; }
        public int? MessageRead { get; set; }
        public int? Contacted { get; set; }
        public int? PendingForContact { get; set; }
        public int? MIDone { get; set; }
        public int? SurakshaChanged { get; set; }
        public int? Both { get; set; }
        //public int TotalConsumers { get; set; }
        //public int TotalConsumerProcessed { get; set; }
        //public int TotalConsumerBalance { get; set; }
        //public int TotalMessageSend { get; set; }
        //public int TotalInterested { get; set; }
        //public int TotalNotInterestedCount { get; set; }
        //public int TotalConnectionReleased { get; set; }
        //public int TotalMesageRead { get; set; }
        //public int TotalContacted { get; set; }
        //public int TotalPendingForContacted { get; set; }
    }
    public class ARBExcelAdminModel
    {
        public int srno { get; set; }
        public string SACode { get; set; }
        public string SAName { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public int? TotalConsumer { get; set; }
        public int? ConsumerProcessed { get; set; }
        public int? ConsumerBalance { get; set; }
        public int? Interested { get; set; }
        public decimal? InterestedPercent { get; set; }
        public int? MessageSend { get; set; }
        public int? NotInterestedCount { get; set; }
        public int? MessageRead { get; set; }
        public int? Contacted { get; set; }
        public int? PendingForContact { get; set; }
        public int? ARBDone { get; set; }
    }
    public class ExcelZOModel
    {
        public int srno { get; set; }
        public string ROName { get; set; }
        public string SAName { get; set; }
        public string JDEDistributorCode { get; set; }
        public string UserName { get; set; }
        public string SourceType { get; set; }
        public int YesterdayEnquiry { get; set; }
        public int ThisMonthEnquiry { get; set; }
        public int TotalEnquiry { get; set; }
        public int YesterdayPurchase { get; set; }
        public int ThisMonthPurchase { get; set; }
        public int TotalPurchase { get; set; }

    }

    public class DBCExcelZOModel
    {
        public int srno { get; set; }
        public string ROName { get; set; }
        public string SAName { get; set; }
        public string JDEDistributorCode { get; set; }
        public string UserName { get; set; }
        public int YesterdayEnquiry { get; set; }
        public int ThisMonthEnquiry { get; set; }
        public int TotalEnquiry { get; set; }
        public int YesterdayPurchase { get; set; }
        public int ThisMonthPurchase { get; set; }
        public int TotalPurchase { get; set; }

    }

    public class Master
    {
        public string Id { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public string ParentId { get; set; }
        public string ActiveFlag { get; set; }
    }
    public class SchedulerSettings
    {
        public int SettingId { get; set; }
        public string SchedulerName { get; set; }
        public Nullable<int> WithIntervalInHours { get; set; }
        public Nullable<int> Hours { get; set; }
        public Nullable<int> Minutes { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<System.DateTime> LastUpdatedDate { get; set; }
    }

    public class EmailSending
    {
        public bool SendEmails(string ToEmail, string CCEmail, string Subject, string message)
        {
            bool bResult = false;
            SmtpClient mailClient = null;
            // Create the mail message
            MailMessage mailMessage = null;
            try
            {
                mailClient = new SmtpClient();
                mailMessage = new MailMessage();//(from, to, subject, body);
                                                //mailMessage.From = new MailAddress(UserName);
                if (!string.IsNullOrWhiteSpace(ToEmail))//Recipient Email
                {
                    string ToEmailId = ToEmail.Trim();
                    if (ToEmailId.Contains(";"))
                    {
                        string[] emails = ToEmailId.Trim().Split(';');
                        foreach (string email in emails)
                        {
                            mailMessage.To.Add(email.Trim());
                        }
                    }
                    else
                    {
                        mailMessage.To.Add(ToEmailId);
                    }

                    if (!string.IsNullOrWhiteSpace(CCEmail))//Recipient Email
                    {
                        string CCEmailId = CCEmail.Trim();
                        if (CCEmailId.Contains(";"))
                        {
                            string[] emails = CCEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.CC.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.CC.Add(CCEmailId);
                        }
                    }

                    string MappedFilePath = AppDomain.CurrentDomain.BaseDirectory;
                    string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Mailfile\\SendEmail.html");
                    string messageformat = System.IO.File.OpenText(filePath).ReadToEnd().ToString();
                    // Replace Notification Table
                    messageformat = messageformat.Replace("<!--SchedulerTableString-->", message);

                    mailMessage.Subject = Subject;
                    mailMessage.IsBodyHtml = true;
                    mailMessage.Body = messageformat;
                    mailClient.Send(mailMessage);

                    bResult = true;
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "OnboardingEmailScheduler - EmailClass", "ToEmail= " + ToEmail + ", Subject= " + Subject, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            finally
            {
                if (mailClient != null)
                    mailClient.Dispose();

                if (mailMessage != null)
                    mailMessage.Dispose();
            }
            return bResult;
        }

        public bool SendEmails(string ToEmail, string Subject, string message, string[] AttachFilePath)
        {
            bool bResult = false;
            // To send an Email
            SmtpClient mailClient = null;
            // Create the mail message
            MailMessage mailMessage = null;
            // Attach file
            Attachment attachment1 = null;
            try
            {
                string userName = WebConfigurationManager.AppSettings["PFUserName"];
                string password = WebConfigurationManager.AppSettings["PFPassWord"];
                mailClient = new SmtpClient("smtp.gmail.com");
                // Create the mail message
                mailMessage = new MailMessage();//(from, to, subject, body);

                if (!string.IsNullOrWhiteSpace(ToEmail))//For RO Email
                {
                    try
                    {
                        string ToEmailId = ToEmail.Trim();
                        if (ToEmailId.Contains(";"))
                        {
                            string[] emails = ToEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.To.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.To.Add(ToEmailId.Trim());
                        }
                        //mailMessage.To.Add(ToEmail);
                    }
                    catch (Exception ex)
                    {
                        BusinessCont.SaveLog(0, 100, "EmailClass", "Code= 0, Flag=ALL", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
                        throw ex;
                    }
                }
                if (AttachFilePath != null)
                {
                    foreach (string filePath in AttachFilePath)
                    {
                        if (filePath != null)
                        {
                            attachment1 = new System.Net.Mail.Attachment(filePath); //Attaching File to Mail
                            mailMessage.Attachments.Add(attachment1);
                            attachment1 = null;
                        }
                    }
                }

                string MappedFilePath = AppDomain.CurrentDomain.BaseDirectory;
                string filePath1 = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Mailfile\\SendEmail.html");
                string messageformat = System.IO.File.OpenText(filePath1).ReadToEnd().ToString();
                // Replace Notification Table
                messageformat = messageformat.Replace("<!--SchedulerTableString-->", message);
                mailMessage.Subject = Subject;
                mailMessage.IsBodyHtml = true;
                mailMessage.Body = messageformat;
                mailClient.Send(mailMessage);
                bResult = true;
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "EmailClass", "Code= 0, Flag=ALL", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            finally
            {
                if (mailClient != null)
                    mailClient.Dispose();

                if (mailMessage != null)
                    mailMessage.Dispose();

                if (attachment1 != null)
                    attachment1.Dispose();
            }

            return bResult;
        }

        public bool DailySchedulerEmail(string ToEmail, string CCEmail, string BCCEmail, string Subject,string messageSA, string messagedist, string surakshamessageSA, string[] AttachmentPaths1, string[] AttachFilePath)
        {
            bool bResult = false;
            SmtpClient mailClient = null;
            // Create the mail message surakshamessageSA
            MailMessage mailMessage = null;
            Attachment attachmentPaths1Value = null;
            Attachment attachFilePathValue = null;
            string DBCTitle = "2)DBC Campaign Report:";
            string SurakshaTitle = "1)Suraksha MI Campaign Report:";
            string commonTitle = "Please find attached file of:";
            string OnlyDBCTitle = "Please find attached file of DBC campaign report:";
            try
            {
                mailClient = new SmtpClient();
                mailMessage = new MailMessage();//(from, to, subject, body);
                                                //mailMessage.From = new MailAddress(UserName);
                if (!string.IsNullOrWhiteSpace(ToEmail))//Recipient Email
                {
                    string ToEmailId = ToEmail.Trim();
                    if (ToEmailId.Contains(";"))
                    {
                        string[] emails = ToEmailId.Trim().Split(';');
                        foreach (string email in emails)
                        {
                            mailMessage.To.Add(email.Trim());
                        }
                    }
                    else
                    {
                        mailMessage.To.Add(ToEmailId);
                    }

                    if (!string.IsNullOrWhiteSpace(CCEmail))//Recipient Email cc
                    {
                        string CCEmailId = CCEmail.Trim();
                        if (CCEmailId.Contains(";"))
                        {
                            string[] emails = CCEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.CC.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.CC.Add(CCEmailId);
                        }
                    }
                    if (!string.IsNullOrWhiteSpace(BCCEmail))//Recipient Email bcc
                    {
                        string BccEmailId = BCCEmail.Trim();
                        if (BccEmailId.Contains(";"))
                        {
                            string[] emails = BccEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.Bcc.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.Bcc.Add(BccEmailId);
                        }
                    }

                }

                // For DBC Attachment
                if (AttachFilePath != null)
                {
                    foreach (string filePathValue in AttachFilePath)
                    {
                        if (filePathValue != null)
                        {
                            attachFilePathValue = new Attachment(filePathValue); //Attaching File to Mail
                            mailMessage.Attachments.Add(attachFilePathValue);
                            attachFilePathValue = null;
                        }
                    }
                }
                

                // For Suraksha Attachment
                if (AttachmentPaths1 != null)
                {
                    // AttachmentPaths1
                    foreach (string filePath1Value in AttachmentPaths1)
                    {
                        if (filePath1Value != null)
                        {
                            attachmentPaths1Value = new Attachment(filePath1Value); // Attaching File to Mail
                            mailMessage.Attachments.Add(attachmentPaths1Value);
                            attachmentPaths1Value = null;
                        }
                    }
                }
                

                string MappedFilePath = AppDomain.CurrentDomain.BaseDirectory;
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\EmailDraft.html");
                string messageformat = System.IO.File.OpenText(filePath).ReadToEnd().ToString();
                // Replace Notification Table
                if (surakshamessageSA != null && surakshamessageSA !="")
                {
                    messageformat = messageformat.Replace("<!--commontile-->", commonTitle);
                    messageformat = messageformat.Replace("<!--surakshatitle-->", SurakshaTitle);
                    messageformat = messageformat.Replace("<!--dbctile-->", DBCTitle);
                    messageformat = messageformat.Replace("<!--SurakshaSchedulerTableStringSA_suraksha-->", surakshamessageSA);
                    messageformat = messageformat.Replace("<!--SchedulerTableStringSA_suraksha-->", messageSA);
                    messageformat = messageformat.Replace("<!--SchedulerTableString_suraksha-->", messagedist);

                }
                else
                {
                    messageformat = messageformat.Replace("<!--onlyDbcTitle-->", OnlyDBCTitle);
                    messageformat = messageformat.Replace("<!--SchedulerTableStringSA_DBC-->", messageSA);
                    messageformat = messageformat.Replace("<!--SchedulerTableString_DBC-->", messagedist);
                }

                //messageformat = messageformat.Replace("<!--SurakshaSchedulerTableStringSA-->", surakshamessageSA);
                //messageformat = messageformat.Replace("<!--SchedulerTableStringSA-->", messageSA);
                //messageformat = messageformat.Replace("<!--SchedulerTableString-->", messagedist);

                mailMessage.Subject = Subject;
                mailMessage.IsBodyHtml = true;
                mailMessage.Body = messageformat;
                mailClient.Send(mailMessage);

                bResult = true;

            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "OnboardingEmailScheduler - EmailClass", "ToEmail= " + ToEmail + ", Subject= " + Subject, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            finally
            {
                if (mailClient != null)
                    mailClient.Dispose();

                if (mailMessage != null)
                    mailMessage.Dispose();
            }
            return bResult;
        }


        public bool ConsumerStatusEmail(string ToEmail, string CCEmail, string Subject, string message)
        {
            bool bResult = false;
            SmtpClient mailClient = null;
            // Create the mail message
            MailMessage mailMessage = null;
            try
            {
                mailClient = new SmtpClient();
                mailMessage = new MailMessage();//(from, to, subject, body);
                                                //mailMessage.From = new MailAddress(UserName);
                if (!string.IsNullOrWhiteSpace(ToEmail))//Recipient Email
                {
                    string ToEmailId = ToEmail.Trim();
                    if (ToEmailId.Contains(";"))
                    {
                        string[] emails = ToEmailId.Trim().Split(';');
                        foreach (string email in emails)
                        {
                            mailMessage.To.Add(email.Trim());
                        }
                    }
                    else
                    {
                        mailMessage.To.Add(ToEmailId);
                    }

                    if (!string.IsNullOrWhiteSpace(CCEmail))//Recipient Email
                    {
                        string CCEmailId = CCEmail.Trim();
                        if (CCEmailId.Contains(";"))
                        {
                            string[] emails = CCEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.CC.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.CC.Add(CCEmailId);
                        }
                    }

                    string MappedFilePath = AppDomain.CurrentDomain.BaseDirectory;
                    string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Mailfile\\SendEmail.html");
                    string messageformat = System.IO.File.OpenText(filePath).ReadToEnd().ToString();
                    messageformat = messageformat.Replace("Here is the status of Onboarding activity started at distributor level.", "SDS Consumer Verification Status:");
                    // Replace Notification Table
                    messageformat = messageformat.Replace("<!--SchedulerTableString-->", message);

                    mailMessage.Subject = Subject;
                    mailMessage.IsBodyHtml = true;
                    mailMessage.Body = messageformat;
                    mailClient.Send(mailMessage);

                    bResult = true;
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100,  "ConsumerStatusEmail - EmailClass", "ToEmail= " + ToEmail + ", Subject= " + Subject, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            finally
            {
                if (mailClient != null)
                    mailClient.Dispose();

                if (mailMessage != null)
                    mailMessage.Dispose();
            }
            return bResult;
        }

        // EnquiryCampaignDailySchedulerEmail
        public bool EnquiryCampaignDailySchedulerEmail(string ToEmail, string CCEmail, string BCCEmail, string Subject, string messageSA, string messagedist)
        {
            bool bResult = false;
            SmtpClient mailClient = null;
            // Create the mail message
            MailMessage mailMessage = null;
            try
            {
                BusinessCont.SaveLog(0, 0, "EnquiryCampaignDailySchedulerEmail", "EmailScheduler", "Start", BusinessCont.SuccessStatus);

                mailClient = new SmtpClient();
                mailMessage = new MailMessage();//(from, to, subject, body);

                if (!string.IsNullOrWhiteSpace(ToEmail)) // Recipient Email
                {
                    string ToEmailId = ToEmail.Trim();
                    if (ToEmailId.Contains(";"))
                    {
                        string[] emails = ToEmailId.Trim().Split(';');
                        foreach (string email in emails)
                        {
                            mailMessage.To.Add(email.Trim());
                        }
                    }
                    else
                    {
                        mailMessage.To.Add(ToEmailId);
                    }

                    if (!string.IsNullOrWhiteSpace(CCEmail)) // Recipient Email cc
                    {
                        string CCEmailId = CCEmail.Trim();
                        if (CCEmailId.Contains(";"))
                        {
                            string[] emails = CCEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.CC.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.CC.Add(CCEmailId);
                        }
                    }
                    if (!string.IsNullOrWhiteSpace(BCCEmail)) // Recipient Email bcc
                    {
                        string BccEmailId = BCCEmail.Trim();
                        if (BccEmailId.Contains(";"))
                        {
                            string[] emails = BccEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.Bcc.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.Bcc.Add(BccEmailId);
                        }
                    }

                }

                string MappedFilePath = AppDomain.CurrentDomain.BaseDirectory;
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\EnquiryCampaignDailySchedulerEmail.html");
                string messageformat = File.OpenText(filePath).ReadToEnd().ToString();
                // Replace Notification Table
                messageformat = messageformat.Replace("<!--SchedulerTableStringSA-->", messageSA);
                messageformat = messageformat.Replace("<!--SchedulerTableString-->", messagedist);
                mailMessage.Subject = Subject;
                mailMessage.IsBodyHtml = true;
                mailMessage.Body = messageformat;
                mailClient.Send(mailMessage);
                bResult = true;
                BusinessCont.SaveLog(0, 0, "EnquiryCampaignDailySchedulerEmail", "EmailScheduler", "End", BusinessCont.SuccessStatus);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "EnquiryCampaignDailySchedulerEmail - EmailClass", "ToEmail= " + ToEmail + ", Subject= " + Subject, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
            }
            finally
            {
                if (mailClient != null)
                    mailClient.Dispose();

                if (mailMessage != null)
                    mailMessage.Dispose();
            }
            return bResult;
        }

        public bool ARBDailySchedulerEmail(string ToEmail, string CCEmail, string BCCEmail, string Subject, string messageSA, string messagedist,string[] AttachFilePath)
        {
            bool bResult = false;
            SmtpClient mailClient = null;
            MailMessage mailMessage = null;
            Attachment attachFilePathValue = null;
            
            try
            {
                mailClient = new SmtpClient();
                mailMessage = new MailMessage(); // (from, to, subject, body);

                if (!string.IsNullOrWhiteSpace(ToEmail)) // Recipient Email
                {
                    string ToEmailId = ToEmail.Trim();
                    if (ToEmailId.Contains(";"))
                    {
                        string[] emails = ToEmailId.Trim().Split(';');
                        foreach (string email in emails)
                        {
                            mailMessage.To.Add(email.Trim());
                        }
                    }
                    else
                    {
                        mailMessage.To.Add(ToEmailId);
                    }

                    if (!string.IsNullOrWhiteSpace(CCEmail)) // Recipient Email cc
                    {
                        string CCEmailId = CCEmail.Trim();
                        if (CCEmailId.Contains(";"))
                        {
                            string[] emails = CCEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.CC.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.CC.Add(CCEmailId);
                        }
                    }

                    if (!string.IsNullOrWhiteSpace(BCCEmail)) // Recipient Email bcc
                    {
                        string BccEmailId = BCCEmail.Trim();
                        if (BccEmailId.Contains(";"))
                        {
                            string[] emails = BccEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.Bcc.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.Bcc.Add(BccEmailId);
                        }
                    }
                }

                // For ARB Attachment
                if (AttachFilePath != null)
                {
                    foreach (string filePathValue in AttachFilePath)
                    {
                        if (filePathValue != null)
                        {
                            attachFilePathValue = new Attachment(filePathValue); //Attaching File to Mail
                            mailMessage.Attachments.Add(attachFilePathValue);
                            attachFilePathValue = null;
                        }
                    }
                }

                string MappedFilePath = AppDomain.CurrentDomain.BaseDirectory;
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\ARB_EmailDraft.html");
                string messageformat = File.OpenText(filePath).ReadToEnd().ToString();

                // Replace Notification Table
                messageformat = messageformat.Replace("<!--SchedulerTableStringSA-->", messageSA);
                messageformat = messageformat.Replace("<!--SchedulerTableString-->", messagedist);
                mailMessage.Subject = Subject;
                mailMessage.IsBodyHtml = true;
                mailMessage.Body = messageformat;
                mailClient.Send(mailMessage);
                bResult = true;
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "ARBDailySchedulerEmail - EmailClass", "ToEmail= " + ToEmail + ", Subject= " + Subject, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            finally
            {
                if (mailClient != null)
                    mailClient.Dispose();

                if (mailMessage != null)
                    mailMessage.Dispose();
            }
            return bResult;
        }

        #region VAS MIS Email Send
        public bool VASDailySchedulerEmail(string ToEmail, string CCEmail, string BCCEmail, string Subject, string messageSA, string messagedist, string[] AttachFilePath)
        {
            bool bResult = false;
            SmtpClient mailClient = null;
            MailMessage mailMessage = null;
            Attachment attachFilePathValue = null;

            try
            {
                mailClient = new SmtpClient();
                mailMessage = new MailMessage();//(from, to, subject, body);
                                                //mailMessage.From = new MailAddress(UserName);
                if (!string.IsNullOrWhiteSpace(ToEmail))//Recipient Email
                {
                    string ToEmailId = ToEmail.Trim();
                    if (ToEmailId.Contains(";"))
                    {
                        string[] emails = ToEmailId.Trim().Split(';');
                        foreach (string email in emails)
                        {
                            mailMessage.To.Add(email.Trim());
                        }
                    }
                    else
                    {
                        mailMessage.To.Add(ToEmailId);
                    }

                    if (!string.IsNullOrWhiteSpace(CCEmail))//Recipient Email cc
                    {
                        string CCEmailId = CCEmail.Trim();
                        if (CCEmailId.Contains(";"))
                        {
                            string[] emails = CCEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.CC.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.CC.Add(CCEmailId);
                        }
                    }
                    if (!string.IsNullOrWhiteSpace(BCCEmail))//Recipient Email bcc
                    {
                        string BccEmailId = BCCEmail.Trim();
                        if (BccEmailId.Contains(";"))
                        {
                            string[] emails = BccEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.Bcc.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.Bcc.Add(BccEmailId);
                        }
                    }

                }

                // For VAS Attachment
                if (AttachFilePath != null)
                {
                    foreach (string filePathValue in AttachFilePath)
                    {
                        if (filePathValue != null)
                        {
                            attachFilePathValue = new Attachment(filePathValue); //Attaching File to Mail
                            mailMessage.Attachments.Add(attachFilePathValue);
                            attachFilePathValue = null;
                        }
                    }
                }


                string MappedFilePath = AppDomain.CurrentDomain.BaseDirectory;
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MailFile\\VAS_EmailDraft.html");
                string messageformat = System.IO.File.OpenText(filePath).ReadToEnd().ToString();

                // Replace Notification Table
                messageformat = messageformat.Replace("<!--SchedulerTableStringSA-->", messageSA);
                messageformat = messageformat.Replace("<!--SchedulerTableString-->", messagedist);
                mailMessage.Subject = Subject;
                mailMessage.IsBodyHtml = true;
                mailMessage.Body = messageformat;
                mailClient.Send(mailMessage);

                bResult = true;

            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, "VASDailySchedulerEmail - EmailClass", "ToEmail= " + ToEmail + ", Subject= " + Subject, BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex));
                throw ex;
            }
            finally
            {
                if (mailClient != null)
                    mailClient.Dispose();

                if (mailMessage != null)
                    mailMessage.Dispose();
            }
            return bResult;
        }
        #endregion
    }
}
