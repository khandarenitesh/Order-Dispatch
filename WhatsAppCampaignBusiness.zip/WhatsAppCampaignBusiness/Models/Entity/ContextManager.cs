﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WhatsAppCampaignBusiness.Models.Entity;

namespace HPGASNCEnquiryBusiness.Models.Entity
{
    public class ContextManager:IDisposable
    {
        public static HPGASNCEnquiryEntities _Context;
        public ContextManager()
        {
            HPGASNCEnquiryEntities context = new HPGASNCEnquiryEntities();
            _Context = context;
        }

        #region Dispose 

        private bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // TO DO: clean up managed objects
                }
                // TO DO: clean up unmanaged objects
                disposed = true;
            }
        }

        #endregion
    }
}
