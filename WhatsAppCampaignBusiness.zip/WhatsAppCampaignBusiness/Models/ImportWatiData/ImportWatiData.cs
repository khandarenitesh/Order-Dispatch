﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPGASNCEnquiryBusiness.Models.ImportWatiData
{
    public class ImportWatiData
    {
        public DateTime ScheduledAt { get; set; }
        public string MobileNo { get; set; }
        public string BroadcastName { get; set; }
        public string TemplateName { get; set; }
        public string DeliveryStatus { get; set; }
    }
}
