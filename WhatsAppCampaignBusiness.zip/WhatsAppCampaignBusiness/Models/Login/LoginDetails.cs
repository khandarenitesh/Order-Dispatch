﻿using HPGASNCEnquiryBusiness.Models.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPGASNCEnquiryBusiness.Models.Login
{
    public class LoginDetails : StatusDetails
    {
        public LoginUser LoginUser { get; set; }
    }
    public class UserModel
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string MobileNo { get; set; }
        public string OTP { get; set; }
        public decimal StaffRefNo { get; set; }
    }
    public class LoginUser
    {
        public long StaffRefNo { get; set; }
        public int DistributorId { get; set; }
        public string StaffName { get; set; }
        public string StaffAddress { get; set; }
        public string DistributorName { get; set; }
        public string DistributorCode { get; set; }
        public string Password { get; set; }
        public string Source { get; set; }
    }


    public class UserLoginDetails :StatusDetails
    {
        public  UserLogin userDetails{ get;set;}
        public string LoginStatus { get; set; }
    }
    public class ResetPassword
    {
        public long UserId { get; set; }
        public int RoleId { get; set; }
        public string RefId { get; set; }
        public string UserName { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
        public string ConfirmPassword { get; set; }
        public string EncryptPwd { get; set; }
        public string Flag { get; set; }

    }


    public class UserLogin
    {
        public decimal UserId { get; set; }
        public Nullable<int> RoleId { get; set; }
        public Nullable<decimal> refNo { get; set; }
        public string DisplayName { get; set; }
        public string UserName { get; set; }
        public string EncryptUserName { get; set; }
        public string Password { get; set; }
        public string EncryptPassword { get; set; }
        public string ActiveStatus { get; set; }
        public Nullable<System.DateTime> LastUpdatedDate { get; set; }

        public string IsFillMandatorydtls { get; set; }
        public string RoleName { get; set; }
        public string IsLive { get; set; }
        public string SBCLive { get; set; }
        public string SurakshaLive { get; set; }
        public string ARBLive { get; set; }
        public string VASLive { get; set; }
    }

    public class PostBackModel : StatusDetails
    {
        public long ResultId { get; set; }
    }
}
