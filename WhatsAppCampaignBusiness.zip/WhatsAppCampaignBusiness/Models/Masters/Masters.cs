﻿using HPGASNCEnquiryBusiness.Models.Customer;
using HPGASNCEnquiryBusiness.Models.Distributor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPGASNCEnquiryBusiness.Models.Masters
{
    public class StatusDetails
    {
        public string Status { get; set; }
        public string ExMsg { get; set; }
    }
    public class QuestionDetails : StatusDetails
    {
        public List<QuestionMaster> QuestionMaster { get; set; }
        public List<QuestionMaster> StoveMaster { get; set; }
        public List<Documents> Documents { get; set; }
        public List<DashboardStaffCount> DashboardCounts { get; set; }
        public string PSVersion { get; set; }
        public string IsUserActive { get; set; }
    }
    public class QuestionMaster
    {
        public long EQueId { get; set; }
        public string EnquiryQue { get; set; }
        public Nullable<int> QuestionType { get; set; }
        public Nullable<long> Id { get; set; }
        public string StoveType { get; set; }
        public decimal Price { get; set; }
        public string DistributorName { get; set; }
        public string DistributorCode { get; set; }
        public string ContactNo { get; set; }
        public Nullable<int> LanguageId { get; set; }
        public string LanguageName { get; set; }
    }

    public class PostRespMdl : StatusDetails
    {
        public long StaffRefNo { get; set; }
    }


    public class GetDistStaffDtls : StatusDetails
    {
        public List<DistributorStaff> distributorStaffsLst { get; set; }
        public DistributorStaff distributorStaffDetails { get; set; }
    }

    public class DistributorStaff
    {
        public long StaffRefNo { get; set; }
        public string StaffType { get; set; }
        public int DistributorId { get; set; }
        public string StaffName { get; set; }
        public string StaffAddress { get; set; }
        public string MobileNo { get; set; }
        public string OTP { get; set; }
        public string ActiveStatus { get; set; }
        public string VersionNo { get; set; }
        public string Operation { get; set; }
        public long UserId { get; set; }

        public Nullable<bool> IsEnquiryActive { get; set; }
        public Nullable<bool> IsInactiveConsActive { get; set; }
        public string ActiveFrom { get; set; }
        public string LastUpdateDateTime { get; set; }

    }

    public class Distributor
    {
        public List<DistributorDtls> DistributorList { get; set; }
    }
    public class DistributorDtls
    {
        public int DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string OwnerName { get; set; }
        public string IsDistributorLive { get; set; }
        public Nullable<decimal> MobileNo { get; set; }
        public string Email { get; set; }
        public string EmergencyContactNo { get; set; }
        public string PhoneNo { get; set; }
    }
    public class MobNoInfo
    {
        public string number { get; set; }
        public string message { get; set; }
    }

    public class PickyJSON
    {
        public string token { get; set; }
        public string priority { get; set; }
        public string application { get; set; }
        public string sleep { get; set; }
        public string globalmessage { get; set; }
        public string globalmedia { get; set; }
        public string action { get; set; }
        public int push_id { get; set; }
        public string media_file { get; set; }
        public List<MobNoInfo> data { get; set; }
    }
    public class TinyJSON
    {
        public string url { get; set; }
        public string domain { get; set; }
        public string alias { get; set; }
        public string tags { get; set; }
        public string Authorization { get; set; }

    }
    public class Data
    {
        public string url { get; set; }
        public string domain { get; set; }
        public string alias { get; set; }
        public List<object> tags { get; set; }
        public string tiny_url { get; set; }
    }

    public class Root
    {
        public int code { get; set; }
        public Data data { get; set; }
        public List<object> errors { get; set; }
    }
    public class DistConnTypeDtls : StatusDetails
    {
        public DistConnType GetDistConnType { get; set; }
    }

    public class DistConnType
    {
        public Nullable<long> PId { get; set; }
        public int DistributorId { get; set; }
        public decimal RSP { get; set; }
        public string ContactNo { get; set; }
        public string ActiveStatus { get; set; }
        public int StoveBrandCnt { get; set; }
        public int DistributorStaffCnt { get; set; }
        public Nullable<int> LanguageId { get; set; }
        public string LanguageName { get; set; }
        public string Flag { get; set; }
    }

    public class StoveItemMst : StatusDetails
    {
        public List<StoveItemDtls> stoveItemList { get; set; }
        public StoveItemDtls stoveItemDtls { get; set; }
    }

    public class StoveItemDtls
    {
        public long Id { get; set; }
        public int DistributorId { get; set; }
        public long StoveId { get; set; }
        public string ItemName { get; set; }
        public Nullable<decimal> Price { get; set; }
        public string ActiveStatus { get; set; }
        public string LastUpdateDateTime { get; set; }
        public string StoveType { get; set; }
        public string Operation { get; set; }
        public Nullable<decimal> StoveTypePrice { get; set; }

    }

    public class PriceMaster : StatusDetails
    {
        public List<PriceDetails> PriceDetails { get; set; }
        public List<StoveItemDtls> StoveItemDtls { get; set; }
        public int RSPUpdateFlag { get; set; }
    }
    public class PriceDetails
    {
        public long EQueId { get; set; }
        public string EnquiryQue { get; set; }
        public Nullable<long> ID { get; set; }
        public string ItemName { get; set; }
        public string ItemNameInEnglish { get; set; }
        public string ItemNameInHindi { get; set; }
        public string ItemNameInMarathi { get; set; }
        public Nullable<decimal> TotalAmount { get; set; }
        public decimal RSP { get; set; }
        public int RSPMonthFlag { get; set; }
    }

    public class LanguageModel : StatusDetails
    {
        public List<LanguageMaster> LangList { get; set; }
    }

    public class LanguageMaster
    {
        public int LanguageId { get; set; }
        public string LanguageName { get; set; }
        public string ActiveStatus { get; set; }
    }

    public class DataReceived
    {
        public string project_id { get; set; }
        public int event_id { get; set; }
        public List<CustDetails> data { get; set; }
    }
    public class CustDetails
    {
        public string number { get; set; }
        public string msg_id { get; set; }
        public string status { get; set; }
        public string error_code { get; set; }
        public string error_message { get; set; }
        public string push_id { get; set; }
    }
    public class ConsumerDetailsForSendMsg
    {
        public int DistributorId { get; set; }
        public long QueTypeId { get; set; }
        public long StoveType { get; set; }
        public long StoveSubType { get; set; }
        public string ConsumerName { get; set; }
        public string VendorName { get; set; }
        public string DistWhatsappNo { get; set; }
    }
    public class ContactDetails
    {
        public string MobileNo { get; set; }
    }

    public class WatiJSONMultiple
    {
        public string template_name { get; set; }
        public string broadcast_name { get; set; }
        public List<TemplateDataMultiple> receivers { get; set; }

    }
    public class TemplateDataMultiple
    {
        public string whatsappNumber { get; set; }
        public List<Template> customParams { get; set; }
    }

    public class TemplateAddContact
    {
        public string name { get; set; }
        public List<Template> customParams { get; set; }
    }
    public class Template
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
   
    public class WATIErrors
    {
        public string error { get; set; }
        public List<string> invalidWhatsappNumbers { get; set; }
        public List<object> invalidCustomParameters { get; set; }
    }

    public class WATIRoot
    {
        public bool result { get; set; }
        public WATIErrors errors { get; set; }
    }

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class ValidWhatsAppRoot
    {
        public string blocking { get; set; }
        public List<string> contacts { get; set; }
        public bool force_check { get; set; }
    }

    public class Contact
    {
        public string id { get; set; }
        public object wAid { get; set; }
        public string firstName { get; set; }
        public string fullName { get; set; }
        public string phone { get; set; }
        public object source { get; set; }
        public string contactStatus { get; set; }
        public object photo { get; set; }
        public string created { get; set; }
        public List<object> tags { get; set; }
        public bool optedIn { get; set; }
        public bool isDeleted { get; set; }
        public DateTime lastUpdated { get; set; }
        public bool allowBroadcast { get; set; }
        public bool allowSMS { get; set; }
        public List<string> teamIds { get; set; }
        public bool isInFlow { get; set; }
        public object lastFlowId { get; set; }
        public object currentFlowNodeId { get; set; }
    }

    public class ContactRoot
    {
        public bool result { get; set; }
        public Contact contact { get; set; }
    }
    public class CallStatusList
    {
        public List<CallStatusDetails> CallStatusParameter { get; set; }
    }
    public class CallStatusDetails
    {
        public int Id { get; set; }
        public string StatusName { get; set; }
        public string Colour { get; set; }
        public string IsActive { get; set; }
        public string LastUpdatedDatetime { get; set; }
    }

    public class UpdateDistContact
    {
        public int DistributorId { get; set; }
        public decimal MobileNo { get; set; }
        public string EmergencyContactNo { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }

    }
    public class GeneralMasterList
    {
        public List<GeneralMasterDetails> GeneralMasterParameter { get; set; }
    }
    public class GeneralMasterDetails
    {
        public int CatId { get; set; }
        public string CategoryName { get; set; }
        public string isActive { get; set; }
    }
    public class MasterDetails
    {
        public string Status { get; set; }
        public string ExMsg { get; set; }
    }
    public class BranchMasterpMdl : MasterDetails
    {
        public long BranchId { get; set; }
    }


    public class GeBranchMasterDtls : MasterDetails
    {
        public List<BranchMasterDetails> branchmasterLst { get; set; }
        public BranchMasterDetails branchmasterDtls { get; set; }
    }
    public class BranchMasterDetails
    {
        public long BranchId { get; set; }
        public string BranchCode { get; set; }
        public string BranchName { get; set; }
        public string BranchAddress { get; set; }
        public string City { get; set; }
        public string Pin { get; set; }
        public string ContactNo { get; set; }
        public string Email { get; set; }
        public string Pan { get; set; }
        public string GSTNo { get; set; }
        public string IsActive { get; set; }
        public string Addedby { get; set; }
        public Nullable<bool> Action { get; set; }
        public string RetValue { get; set; }

    }

    public class GetStateList
    {
        public List<GetStateDtls> GetStateParameter { get; set; }
    }
    public class GetStateDtls
    {
        public int StateCode { get; set; }
        public string StateName { get; set; }
        public string ActiveFlag { get; set; }
        public string LastUpdateBy { get; set; }
        public string LastUpdateTime { get; set; }
    }

    public class ActivateCampaignModel
    {
        public string SACode { get; set; }
        public List<AllFlag> AllFlag { get; set; }
    }

    public class AllFlag
    {
        public int DistributorId { get; set; }
        public string IsLive { get; set; }
        public string SBCLive { get; set; }
        public string SurakshaLive { get; set; }
        public string ARBLive { get; set; }
        public string VASLive { get; set; }
        
    }

    public class ChecklistDtlsModel
    {
        public int DistributorId { get; set; }
        public string IsLive { get; set; }
        public string SBCLive { get; set; }
        public string SurakshaLive { get; set; }
        public string ARBLive { get; set; }
        public string VASLive { get; set; }
        public int RetValue { get; set; }

    }

    public class DistriCampRightsList
    {
        public string Sacode { get; set; }
        public int DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string IsLive { get; set; }
        public string SBCLive { get; set; }
        public int SBCCount { get; set; }
        public string SurakshaLive { get; set; }
        public int SurakshaCount { get; set; }
        public string ARBLive { get; set; }
        public int ARBCount { get; set; }
        public string VASLive { get; set; }
        public int VASActiveCount { get; set; }
        public DateTime UpdatedOn { get; set; }
    }

    #region Start - Activate RO MIS
    public class ActivateROMISModel
    {
        public string ROCode { get; set; }
        public List<ActivateROMISFlag> ActivateROMISFlag { get; set; }
    }

    public class ActivateROMISFlag
    {
        public string ROCode { get; set; }
        public string IsDBC { get; set; }
        public string IsSuraksha { get; set; }
        public string IsARB { get; set; }
        public string IsVAS { get; set; }
    }

    public class ChecklistDtlsROMISModel
    {
        public string ROCode { get; set; }
        public string IsDBC { get; set; }
        public string IsSuraksha { get; set; }
        public string IsARB { get; set; }
        public string IsVAS { get; set; }
        public int RetValue { get; set; }

    }
    #endregion End - Activate RO MIS

}
