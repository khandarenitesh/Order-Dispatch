﻿using HPGASNCEnquiryBusiness.Models.Customer;
using HPGASNCEnquiryBusiness.Models.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPGASNCEnquiryBusiness.Models.RO
{
    public class ROMasterModel
    {
        public string ROCode { get; set; }
        public string ROName { get; set; }
        public string ZOCode { get; set; }
        public string ActiveFlag { get; set; }
        public string LastUpdateBy { get; set; }
        public string LastUpdateDateTime { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
        public string IsDBC { get; set; }
        public string IsSuraksha { get; set; }
        public string IsARB { get; set; }
        public string IsVAS { get; set; }
        public DateTime UpdatedOn { get; set; }
    }

    public class RODashboardDetails : StatusDetails
    {
        public List<RODashboardCount> rODashboardCounts { get; set; }
        public List<SAwiseBkConCount> sAwiseBkConCounts { get; set; }
    }

    public class RODashboardCount
    {
        public string ROCode { get; set; }
        public string SACode { get; set; }
        public string SAName { get; set; }
        public int Enquiry { get; set; }
        public int ConnectionRels { get; set; }
        public int ActiveDist { get; set; }
        public int InActiveDist { get; set; }
        public int TotalDist { get; set; }
        public int YestEnquiry { get; set; }
        public Nullable<int> DistributorId { get; set; }
        public string DistributorName { get; set; }
        public string DistributorCode { get; set; }
        public int ActiveUsers { get; set; }
    }
}
