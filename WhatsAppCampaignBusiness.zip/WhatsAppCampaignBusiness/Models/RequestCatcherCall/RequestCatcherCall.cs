﻿using System;
using System.Collections.Generic;

namespace HPGASNCEnquiryBusiness.Models.RequestCatcherCall
{
    public class RequestCatcherCallModel
    {
        public string EnquiryNo { get; set; }
        public long pkId { get; set; }
        public string CallSid { get; set; }
        public string CallFrom { get; set; }
        public string CallTo { get; set; }
        public string Direction { get; set; }
        public DateTime Created { get; set; }
        public string DialCallDuration { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string CallType { get; set; }
        public string DialWhomNumber { get; set; }
        public string flow_id { get; set; }
        public string tenant_id { get; set; }
        public DateTime CurrentTime { get; set; }
        public string digits { get; set; }
        public string IsValidPincode { get; set; }
        public int? DistributorId { get; set; }
        public string Status { get; set; }
        public string IsCallByAdmin { get; set; }
        public string PincodeArea { get; set; }
        public string DistributorName { get; set; }
        public string Remark { get; set; }
        public string AOHRemark { get; set; }
        public string IsCallNotAttended { get; set; }
        public string gflag { get; set; }
        public string maxpkId { get; set; }

        public List<RequestCatcherCallModel> requestCatcherCallModelList { get; set; }
    }

    public class Get5KGAppuCampaignByAdminCountModel
    {
        public string Today { get; set; }
        public string AsOfDate { get; set; }
        public string ValidPincode { get; set; }
        public string InValidPincode { get; set; }
        public string MissedCall { get; set; }
        public string AfterOfficeHrs { get; set; }
        public int? Forwarded { get; set; }
    }

    public class Get5KGAppuCampaignByDistributorCountModel
    {
        public string Accepted { get; set; }
        public string Pending { get; set; }
    }

    public class Get5KGAppuCampaignByPincodeModel
    {
        public int Id { get; set; }
        public string Pincode { get; set; }
        public string Area { get; set; }
    }

    public class Update5KGAppuCampaignByPincodeModel
    {
        public int pkId { get; set; }
        public string Pincode { get; set; }
        public string ResultMessage { get; set; }
    }

    // To Get 5 KG Appu Campaign Enquiry Status
    public class Get5KGAppuEnquiryStatusModel
    {
        public int pkid { get; set; }
        public string EnquiryStatusName { get; set; }
        public string IsActive { get; set; }
        public string UpdatedDate { get; set; }
    }

    // To Get 5 KG Appu Campaign Enquiry Action Taken
    public class Get5KGAppuEnquiryActionTakenModel
    {
        public int pkid { get; set; }
        public string ActionTakenName { get; set; }
        public string IsActive { get; set; }
        public string UpdatedDate { get; set; }
    }

    // To Get 5KG Appu Enquiry Campaign By Distributor
    public class Get5KGAppuEnquiryCampaignByDistributorModel
    {
        public int gflag { get; set; }
        public long maxpkId { get; set; }
        public long pkid { get; set; }
        public int DistributorId { get; set; }
        public string Status { get; set; }
        public string EnquiryNo { get; set; }
        public string MobileNumber { get; set; }
        public string CustomerName { get; set; }
        public string Pincode { get; set; }
        public string AreaAddress { get; set; }
        public string StartTime { get; set; }
        public string EnquiryStatus { get; set; }
        public string ActionTaken { get; set; }
        public string ActionTakenDateTime { get; set; }
    }

    // To Get 5KG Appu Enquiry Campaign By Distributor Count
    public class Get5KGAppuEnquiryCampaignByDistributorCountModel
    {
        public string CallNotAttendedEnquiryStatus { get; set; }
        public string Attended { get; set; }
        public string Closed { get; set; }
        public string CallNotAttendedEnquiryActionTaken { get; set; }
        public string RefillProvided { get; set; }
        public string FTLProvided { get; set; }
        public string Others { get; set; }
    }

}
