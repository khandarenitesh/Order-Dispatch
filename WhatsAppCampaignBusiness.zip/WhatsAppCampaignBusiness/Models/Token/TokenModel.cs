﻿using System;

namespace HPGASNCEnquiryBusiness.Models.Token
{
    public class DistributorModel
    {
        public int DistributorId { get; set; }
        public string DistributorName { get; set; }
        public int Token { get; set; }
        public bool Flag { get; set; }
        public string SAName { get; set; }

    }

    public class DistributorflagCount
    {
        public int FlagCount { get; set; }
    }

    public class SAModel
    {
        public int SAId { get; set; }
        public int SAcode { get; set; }
        public string SAName { get; set; }
    }

    public class TestCounsumerDetails
    {
        public string C_Name { get; set; }
        public string C_Number { get; set; }
        public int DistId { get; set; }
        public string Dist_Name { get; set; }
        public string DistContact { get; set; }
        public Nullable<bool> Msg_Send { get; set; }
        public Nullable<bool> Relay_Rec { get; set; }
    
}
}
