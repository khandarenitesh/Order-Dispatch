using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPGASNCEnquiryBusiness.Models.VAS
{
    public class SLAModel
    {
        public int SLAId { get; set; }
        public string SLADesc { get; set; }
        public int SLAValue { get; set; }
        public int IsActive { get; set; }
        public string AddedBy { get; set; }
        public string Action { get; set; }
    }

    public class VASConsumersModel
    {
        public int SACode { get; set; }
        public int DistributorId { get; set; }
        public string DistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string UniqueConsumerId { get; set; }
        public string ConsumerNo { get; set; }
        public string MobileNo { get; set; }
        public string ConsumerName { get; set; }
        public string AreaName { get; set; }
        public string ConsumerAddress { get; set; }
        public string IsMobNoDuplicate { get; set; }
        public string IsWhatsappNo { get; set; }
        public string IsMessageSent { get; set; }
        public string IsRegistered { get; set; }
        public DateTime RegistrationDate { get; set; }
        public string RegisterDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int Status { get; set; }
        public string IsApprove { get; set; }
        public string AddedBy { get; set; }
        public string Action { get; set; }
        public string OrderNo { get; set; }
        public DateTime OrderDate { get; set; }
        public string OrderStatus { get; set; }
        public DateTime ActualDelDate { get; set; }
        public string StaffName { get; set; }
    }
    public class VasConsumerListForMob
    {
        public List<VASConsumersModel> VASConsumersList { get; set; }
    }

    public class RefillBookingPendingListModelMob
    {
        public List<RefillBookingPendingListModel> RefillBookingPendingList { get; set; }
    }

    public class RefillBookingPendingListModel
    {
        public long PkOrderId { get; set; }
        public int DistributorId { get; set; }
        public string DistributorCode { get; set; }
        public string OrderNo { get; set; }
        public DateTime OrderDate { get; set; }
        public string OrderStatus { get; set; }
        public string OrderSource { get; set; }
        public string OrderType { get; set; }
        public string ConsumerNo { get; set; }
        public string ConsumerName { get; set; }
        public string CashMemoNo { get; set; }
        public DateTime CashMemoDate { get; set; }
        public DateTime CMCancelDate { get; set; }
        public string CMStatus { get; set; }
        public string CMCancelReason { get; set; }
        public DateTime ActualDelDate { get; set; }
        public string MobNo { get; set; }
        public string ConsAddress { get; set; }
        public string DeliveredBy { get; set; }
        public DateTime AddedOn { get; set; }
        public DateTime LastUpdatedOn { get; set; }
        public string AssignTo { get; set; }
        public string ConsumerMobNo { get; set; }
        public string DealerMobNo { get; set; }
        public string DistributorName { get; set; }
        public string PhoneNo { get; set; }
        public int TimeinHrs { get; set; }
        public string OrderDateTime { get; set; }
        public string FromDate { get; set; }
        public string Todate { get; set; }
        public string Flag { get; set; }
        public int VASWhatsAppMsgSent { get; set; }
    }

    public class AssignDeliveryBoyAddModel
    {
        public long PkOrderId { get; set; }
        public string DistributorCode { get; set; }
        public string DelBoyName { get; set; }
        public string DeliveryDate { get; set; }
    }

    public class ServiceModel
    {
        public int SRId { get; set; }
        public int DistributorId { get; set; }
        public string DistributorCode { get; set; }
        public string DistributorName { get; set; }
        public int ConsumerNo { get; set; }
        public string ConsumerName { get; set; }
        public string MobileNo { get; set; }
        public long UniqueConsumerId { get; set; }
        public string SRDate { get; set; }
        public DateTime SReqDate { get; set; }
        public string AssignTo { get; set; }
        public int SRStatus { get; set; }
        public string Action { get; set; }
        public int SRDoneCount { get; set; }
        public string SRCompletedOn { get; set; }
    }
    public class ServiceModelForMob
    {
        public List<ServiceModel> ServiceList { get; set; }
    }
    public class VASCountsModel
    {
        public int DistributorId { get; set; }
        public string DistributorCode { get; set; }
        public int VASConsumer { get; set; }
        public int ActiveCount { get; set; }
        public int ExpConsCount { get; set; }
        public int PendingBookings { get; set; }
        public int AssignBookingCnt { get; set; }
        public int DueBookingCnt { get; set; }
        public int DelBookingCnt { get; set; }
        public int TotalSRCnt { get; set; }
        public int PendingSRCnt { get; set; }
        public int TodayCompSR { get; set; }
        public int NoServiceDoneCnt { get; set; }
        public int Service1DoneCnt { get; set; }
        public int Service2DoneCnt { get; set; }
    }
    public class VASDashCountForMob
    {
        public VASCountsModel VASAllCounts { get; set; }
    }
    public class VasConsResultModel
    {
        public string messageResult { get; set; }
    }

    public class BookReportHistoryModel
    {
        public long PkOrderId { get; set; }
        public int DistributorId { get; set; }
        public string DistributorCode { get; set; }
        public string OrderNo { get; set; }
        public DateTime OrderDate { get; set; }
        public string OrderStatus { get; set; }
        public string OrderSource { get; set; }
        public string OrderType { get; set; }
        public string ConsumerNo { get; set; }
        public string ConsumerName { get; set; }
        public string CashMemoNo { get; set; }
        public DateTime CashMemoDate { get; set; }
        public DateTime CMCancelDate { get; set; }
        public string CMStatus { get; set; }
        public string CMCancelReason { get; set; }
        public DateTime ActualDelDate { get; set; }
        public string MobNo { get; set; }
        public string ConsAddress { get; set; }
        public string DeliveredBy { get; set; }
        public DateTime AddedOn { get; set; }
        public DateTime LastUpdatedOn { get; set; }
        public string AssignTo { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string Flag { get; set; }
    }

    public class ActiveUserModel
    {
        public string messageResult { get; set; }
    }

    public class AddActiveUserModel
    {
        public int DistibutorId { get; set; }
        public int UserId { get; set; }
        public string Username { get; set; }
        public string VersionNo { get; set; }
        public string DeviceId { get; set; }
    }


    public class VASMISModel
    {
        public string SACode { get; set; }
        public string ROCode { get; set; }
        public string SAName { get; set; }
        public int DistributorIdint { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public int TotalRegConsumer { get; set; }
        public int PendingBooking { get; set; }
        public int YestDelivery { get; set; }
        public int DelDelay { get; set; }
        public int S1 { get; set; }
        public int S2 { get; set; }
        public string Flag { get; set; }
    }

    public class VASUserWiseCountModel
    {
        public VASUserCountsModel VASUserWiseCounts { get; set; }
    }
    public class VASUserCountsModel
    {
        public int DistributorId { get; set; }
        public string DistributorCode { get; set; }
        public int VASConsumer { get; set; }
        public int ApprovedCount { get; set; }
        public int PendingForApprove { get; set; }
        public string StaffName { get; set; }
    }
    public class LogSaveModel
    {
        public long LogId { get; set; }
        public string DistributorCode { get; set; }
        public string LoginDateTime { get; set; }
        public string LoginStatus { get; set; }
        public string LogFor { get; set; }
        public string FileFor { get; set; }
        public string BkgFileName { get; set; }
        public DateTime BkgFileAddedOn { get; set; }
        public string SRFileName { get; set; }
        public DateTime SRFileAddedOn { get; set; }
        public int BkgExcelCount { get; set; }
        public int BkgImportedCount { get; set; }
        public int SRExcelCount { get; set; }
        public int SRImportedCount { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }

    }

    public class PkAssistModel
    {
        public int status { get; set; }
        public string push_id { get; set; }
        public string message { get; set; }
        public List<PkAssistDataModel> data { get; set; }
    }

    public class PkAssistDataModel
    {
        public string msg_id { get; set; }
        public string number { get; set; }
        public string credit { get; set; }
    }

    public class VasSummaryCountAutoFetchDataModel
    {
        public int LoginFailCount { get; set; }
        public int BKGFileFailCount { get; set; }
        public int SRFileFailCounts { get; set; }
        public int BkgEmptyExcelCounts { get; set; }
        public int SREmptyExcelCounts { get; set; }
        public int LastCycleTime { get; set; }
        public string OneamshedularExeutedornot { get; set; }
        public int OneamshedularExeutedornot1 { get; set; }
        public int TotalBkgDownloadFile { get; set; }
        public int TotalNoofCycle { get; set; }
    }

    public class LogSaveListModel
    {
        public long LogId { get; set; }
        public string DistributorCode { get; set; }
        public string LoginDateTime { get; set; }
        public string LoginStatus { get; set; }
        public string LogFor { get; set; }
        public string FileFor { get; set; }
        public string BkgFileName { get; set; }
        public DateTime BkgFileAddedOn { get; set; }
        public string SRFileName { get; set; }
        public DateTime SRFileAddedOn { get; set; }
        public int BkgExcelCount { get; set; }
        public int BkgImportedCount { get; set; }
        public int SRExcelCount { get; set; }
        public int SRImportedCount { get; set; }
    }
}
