using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Remoting.MetadataServices;

namespace HPGASNCEnquiryBusiness.Models.WhatApp
{
    public class WhatAppModel
    {
        public string MobileNo { get; set; }
        public string MessagesIn { get; set; }
        public string Application { get; set; }
        public string Type { get; set; }
        public string UniqueId { get; set; }
        public int SequenceId { get; set; }
        public string MessageOut { get; set; }
        public int Delay { get; set; }

    }
    public class WhatappAutoReply
    {
        public Nullable<long> CId { get; set; }
        public string WhatAppReply { get; set; }
        public Nullable<int> CurrSequenceId { get; set; }
        public string Flag { get; set; }
        public Nullable<bool> sentEmail { get; set; }
    }
    public class SBCWhatsApp
    {
        public int pkId { get; set; }
        public int SACode { get; set; }
        public int DistributorIdint { get; set; }
        public string DistributorCode { get; set; }
        public string DistributorName { get; set; }
        public Nullable<decimal> DistributorMobileNo { get; set; }
        public string DistributorEmergencyContactNo { get; set; }
        public decimal UniqueConsumerId { get; set; }
        public int ConsumerNo { get; set; }
        public string MobileNo { get; set; }
        public string ConsumerName { get; set; }
        public string IsMessageSent { get; set; }
        public string MessageSentDate { get; set; }
        public string AutoReplySent { get; set; }
        public string AutoReplyDate { get; set; }
        public string ConnectionReleased { get; set; }
        public string ConnectionReleasedDate { get; set; }
        public string IsReplayReceived { get; set; }
        public string IsReplayReceivedDate { get; set; }
        public string ConsumerFeedback { get; set; }
        public string StatusName { get; set; }
        public string UserReply { get; set; }
        public int LinkVisited { get; set; }
        public string MessageStatus { get; set; }
        public string NotIntrested { get; set; }
        public string ConsumerMobileNo { get; set; }
        public DateTime UserReplyDateTime { get; set; }
        public string NeedMoreInfo { get; set; }
        public string ExotelCallStatus { get; set; }
        public decimal DealerMobileNo { get; set; }
        public string EmergencyContactNo { get; set; }
        public int OfficeStartTime { get; set; }
        public int OfficeEndTime { get; set; }
        public string RSPAmount { get; set; }
		public string DistributorAddress { get; set; }
        public string MIDone { get; set; }
        public string HoseChanged { get; set; }
        public string MI_Suraksha { get; set; }
        public string UniqueConsumerid { get; set; }
        public string ARBDone { get; set; }
		public string DPhoneNo { get; set; }
        public string ItemIdstr { get; set; }
    }

    public class ConsumerDtlsModel
    {
        public int SACode { get; set; }
        public int DistributorIdint { get; set; }
        public string DistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string DistributorMobileNo { get; set; }
        public string DistributorEmergencyContactNo { get; set; }
        public decimal UniqueConsumerId { get; set; }
        public string ConsumerNo { get; set; }
        public string MobileNo { get; set; }
        public string ConsumerName { get; set; }
        public string IsMessageSent { get; set; }
        public string MessageSentDate { get; set; }
        public string AutoReplySent { get; set; }
        public string AutoReplyDate { get; set; }
        public string ConnectionReleased { get; set; }
        public string ConnectionReleasedDate { get; set; }
        public string IsReplayReceived { get; set; }
        public string IsReplayReceivedDate { get; set; }
        public string ConsumerFeedback { get; set; }
        public string StatusName { get; set; }
        public string UserReply { get; set; }
        public int LinkVisited { get; set; }
        public string MessageStatus { get; set; }
        public string NotIntrested { get; set; }
        public string ConsumerMobileNo { get; set; }
        public DateTime UserReplyDateTime { get; set; }
        public string NeedMoreInfo { get; set; }
        public string ExotelCallStatus { get; set; }
        public decimal DealerMobileNo { get; set; }
        public string EmergencyContactNo { get; set; }
        public int OfficeStartTime { get; set; }
        public int OfficeEndTime { get; set; }
        public string RSPAmount { get; set; }
        public string DistributorAddress { get; set; }
        public string MIDone { get; set; }
        public string HoseChanged { get; set; }
        public string MI_Suraksha { get; set; }
        public string UniqueConsumerid { get; set; }
        public string ARBDone { get; set; }
        public string DPhoneNo { get; set; }
        public string ItemIdstr { get; set; }
    }

    #region
    /// <summary>
    /// WATI Auto Reply Models
    /// </summary>
    /// 
    public class WatiJSON
    {
        //public string token { get; set; }
        public string template_name { get; set; }
        public string broadcast_name { get; set; }
        public List<TemplateData> parameters { get; set; }
    }


    public class TemplateData
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
    public class WATIWhatSAppModel
    {
        public MessageObjectWATI messages { get; set; }
        public StatusesWATI statuses { get; set; }
        public ErrorsWATI errors { get; set; }
    }
    public class WATIWebhookModel
    {
        public string id { get; set; }
        public string Created { get; set; }
        public string ConversationId { get; set; }
        public string TicketId { get; set; }
        public string Text { get; set; }
        public string Type { get; set; }
        public string Data { get; set; }
        public string Timestamp { get; set; }
        public string Owner { get; set; }
        public string EventType { get; set; }
        public string StatusString { get; set; }
        public string AvatarUrl { get; set; }
        public string AssignedId { get; set; }
        public string OperatorName { get; set; }
        public string OperatorEmail { get; set; }
        public string WaId { get; set; }
        public string SenderName { get; set; }
    }

        public class MessageObjectWATI
    {
        public ContactsWATI contacts { get; set; }
        public MessagesWATI messages { get; set; }
    }
    public class ContactsWATI
    {
        public Profile profile { get; set; }
        public string wa_id { get; set; }
    }
    public class Profile
    {
        public string name { get; set; }
    }
    public class MessagesWATI
    {
        public string from { get; set; }
        public string id { get; set; }
        public string timestamp { get; set; }
        public string type { get; set; }
        public Context context { get; set; }
        public Identity identity { get; set; }
        public Media media { get; set; }
        public Referral referral { get; set; }
        public Text text { get; set; }
        public Location location { get; set; }
        public Contacts contacts { get; set; }
        public System system { get; set; }
        public Interactive interactive { get; set; }
    }
    public class List_reply
    {
        public string id { get; set; }
        public string title { get; set; }
        public string description { get; set; }
    }
    public class Button_reply
    {
        public string id { get; set; }
        public string title { get; set; }
    }
    public class Interactive
    {
        public string type { get; set; }
        public List_reply list_reply { get; set; }
        public Button_reply button_reply { get; set; }
    }
    public class Context
    {
        public string from { get; set; }
        public string id { get; set; }
    }
    public class Identity
    {
        public string acknowledged { get; set; }
        public int created_timestamp { get; set; }

        public string hash { get; set; }
    }
    public class Media
    {
        public string caption { get; set; }
        public string file { get; set; }
        public string filename { get; set; }
        public string id { get; set; }
        public MetaData metadata { get; set; }
        public string mime_type { get; set; }
        public string sha256 { get; set; }
    }
    public class Addresses
    {
        public string street { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string zip { get; set; }
        public string country { get; set; }
        public string country_code { get; set; }
        public string type { get; set; }
    }
    public class Emails
    {
        public string email { get; set; }
        public string type { get; set; }
    }
    public class Ims
    {
        public string service { get; set; }
        public string user_id { get; set; }
    }
    public class Name
    {
        public string first_name { get; set; }
        public string middle_name { get; set; }
        public string last_name { get; set; }
        public string formatted_name { get; set; }
        public string name_prefix { get; set; }
        public string name_suffix { get; set; }
    }
    public class Org
    {
        public string company { get; set; }
        public string department { get; set; }
        public string title { get; set; }
    }
    public class Phones
    {
        public string phone { get; set; }
        public string wa_id { get; set; }
        public string type { get; set; }
    }
    public class Urls
    {
        public string url { get; set; }
        public string type { get; set; }
    }
    public class Contacts
    {
        public Addresses[] addresses { get; set; }
        public string birthday { get; set; }
        public Emails[] emails { get; set; }
        public Ims[] ims { get; set; }
        public Name[] name { get; set; }
        public Org[] org { get; set; }
        public Phones[] phones { get; set; }
        public Urls[] urls { get; set; }


    }
    public class Referral
    {
        public string headline { get; set; }
        public string body { get; set; }
        public string source_type { get; set; }
        public string source_id { get; set; }
        public string source_url { get; set; }
    }
    public class Text
    {
        public string body { get; set; }
    }
    public class Location
    {
        public int latitude { get; set; }
        public int longitude { get; set; }
        public string address { get; set; }
        public string name { get; set; }
        public string url { get; set; }

    }
    public class System
    {
        public string body { get; set; }
    }
    public class StatusesWATI
    {
        public string id { get; set; }
        public string recipient_id { get; set; }

        public string status { get; set; }

        public string timestamp { get; set; }
        public ConversationWATI conversation { get; set; }
        public PricingWATI pricing { get; set; }
    }
    public class ConversationWATI
    {
        public string id { get; set; }
    }
    public class PricingWATI
    {
        public string pricing_model { get; set; }
        public bool billable { get; set; }
    }
    public class ErrorsWATI
    {
        public decimal code { get; set; }
        public string title { get; set; }

        public string details { get; set; }

        public string href { get; set; }

    }

    #endregion


    public class CallConnect
    {
        public TwilioResponse TwilioResponse { get; set; }
    }

    public class TwilioResponse
    {
        public Call Call { get; set; }
    }

    #region Exotel Model
    ///<summary>
    ///Exotel Model
    ///</summary>
    public class Call
    {
        public string Sid { get; set; }
        public object ParentCallSid { get; set; }
        public string DateCreated { get; set; }
        public string DateUpdated { get; set; }
        public string AccountSid { get; set; }
        public string To { get; set; }
        public string From { get; set; }
        public string PhoneNumberSid { get; set; }
        public string Status { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public object Duration { get; set; }
        public object Price { get; set; }
        public string Direction { get; set; }
        public object AnsweredBy { get; set; }
        public object ForwardedFrom { get; set; }
        public object CallerName { get; set; }
        public string Uri { get; set; }
        public object RecordingUrl { get; set; }
    }
    public class ExotelModel
    {
        public string From { get; set; }
        public string To { get; set; }

        public string CallerId { get; set; }

    }

    public class UpdateSBCConsumersCallDataForExotel
    {
        public int DistributorId { get; set; }
        public decimal UniqueConsumerId { get; set; }
        public string ExotelCallStatus { get; set; }
        public string CallStartTime { get; set; }
        public string CallEndTime { get; set; }
    }

    #endregion

    public class DistributorDtlCD
    {
        public int DistributorId { get; set; }
        public string JDEDistributorCode { get; set; }
        public string DistributorName { get; set; }
        public string OwnerName { get; set; }
        public string IsDistributorLive { get; set; }
        public Nullable<decimal> MobileNo { get; set; }
        public string Email { get; set; }
        public string SACode { get; set; }
        public int selected { get; set; }
    }
    public class Content
    {
        public string type { get; set; }
        public MediaTemplate mediaTemplate { get; set; }
    }

    public class KarixMedia
    {
        public string type { get; set; }
        public string url { get; set; }
        public string fileName { get; set; }
    }

    public class MediaTemplate
    {
        public string templateId { get; set; }
        //public string Keystr { get; set; }
        //public string Valuestr { get; set; }
        //public string TemplateName { get; set; }
        public KarixMedia media { get; set; }
        public BodyParameterValues bodyParameterValues { get; set; }
    }

    public class Message
    {
        public Message2 message { get; set; }
    }

    public class Message2
    {
        public Content content { get; set; }
        public Recipient recipient { get; set; }
    }

    public class MetaData
    {
        public string version { get; set; }
    }

    public class Preferences
    {
        public string webHookDNId { get; set; }
    }

    public class Recipient
    {
        public string to { get; set; }
        public Reference reference { get; set; }
    }

    public class Reference
    {
        public string cust_ref { get; set; }
    }

    public class KarixRoot
    {
        public string channel { get; set; }
        public string campaignId { get; set; }
        public ScheduleDetails scheduleDetails { get; set; } //single obj
        public Sender sender { get; set; } //single obj
        public MetaData metaData { get; set; } //single obj
        public Preferences preferences { get; set; } 
        public List<Message> messages { get; set; }
    }

    public class ScheduleDetails
    {
        public string campaignName { get; set; }
        public string scheduledTimestamp { get; set; }
        public string timeZone { get; set; }
        public string timeOffSet { get; set; }
    }

    public class Sender
    {
        public string from { get; set; }
    }

    public class KarixResponse
    {
        public List<BatchResponse> batchResponse { get; set; }
        public string batchId { get; set; }
        public string batchStatus { get; set; }
        public string batchMessage { get; set; }
    }
    public class BatchResponse
    {
        public string statusCode { get; set; }
        public string statusDesc { get; set; }
        public string mid { get; set; }
        public string recepientId { get; set; }
    }
    // WebHook Reply
    public class WebHookReplyAppDetails
    {
        public string type { get; set; }
    }

    public class WebHookReplyButton
    {
        public string payload { get; set; }
        public string text { get; set; }
    }

    public class WebHookReplyEventContent
    {
        public WebHookReplyMessage message { get; set; }
    }

    public class WebHookReplyEvents
    {
        public string eventType { get; set; }
        public string timestamp { get; set; }
        public string date { get; set; }
        public string mid { get; set; }
    }

    public class WebHookReplyMessage
    {
        public string from { get; set; }
        public string id { get; set; }
        public WebHookReplyButton button { get; set; }
        public string to { get; set; }
        public string contentType { get; set; }
        public string contextmid { get; set; }
        public WebHookUserReplyText text { get; set; }
    }
    public class WebHookUserReplyText
    {
        public string body { get; set; }
        // public string text { get; set; }
    }

    // WebHookReplyRecipient
    public class WebHookReplyRecipient
    {
        public string to { get; set; }
        public string recipient_type { get; set; }
        public WebHookReplyReference reference { get; set; }
    }

    // WebHookReplyReference
    public class WebHookReplyReference
    {
        public string cust_ref { get; set; }
        public string messageTag1 { get; set; }
        public string conversationId { get; set; }
    }

    // WebHookReplySender
    public class WebHookReplySender
    {
        public string from { get; set; }
    }

    // NotificationAttributes
    public class NotificationAttributes
    {
        public string status { get; set; }
        public string reason { get; set; }
        public string code { get; set; }
    }

    public class WebHookReplyRoot
    {
        public string channel { get; set; }
        public WebHookReplyAppDetails appDetails { get; set; }
        public WebHookReplyEvents events { get; set; }
        public WebHookReplyEventContent eventContent { get; set; }
        public WebHookReplyRecipient recipient { get; set; }
        public WebHookReplySender sender { get; set; }
        public NotificationAttributes notificationAttributes { get; set; }
    }
    public class BodyParameterValues
    {
        [JsonProperty("0")]
        public string _0 { get; set; }

        [JsonProperty("1")]
        public string _1 { get; set; }

        [JsonProperty("2")]
        public string _2 { get; set; }

        [JsonProperty("3")]
        public string _3 { get; set; }

        [JsonProperty("4")]
        public string _4 { get; set; }

        [JsonProperty("5")]
        public string _5 { get; set; }

        [JsonProperty("6")]
        public string _6 { get; set; }

        [JsonProperty("7")]
        public string _7 { get; set; }

        [JsonProperty("8")]
        public string _8 { get; set; }

        [JsonProperty("9")]
        public string _9 { get; set; }

        [JsonProperty("10")]
        public string _10 { get; set; }

        [JsonProperty("11")]
        public string _11 { get; set; }

        [JsonProperty("12")]
        public string _12 { get; set; }

        [JsonProperty("13")]
        public string _13 { get; set; }

        [JsonProperty("14")]
        public string _14 { get; set; }

        [JsonProperty("15")]
        public string _15 { get; set; }

        [JsonProperty("16")]
        public string _16 { get; set; }

        [JsonProperty("17")]
        public string _17 { get; set; }

        [JsonProperty("18")]
        public string _18 { get; set; }

        [JsonProperty("19")]
        public string _19 { get; set; }

        [JsonProperty("20")]
        public string _20 { get; set; }

        [JsonProperty("21")]
        public string _21 { get; set; }

        [JsonProperty("22")]
        public string _22 { get; set; }

        [JsonProperty("23")]
        public string _23 { get; set; }

        [JsonProperty("24")]
        public string _24 { get; set; }

        [JsonProperty("25")]
        public string _25 { get; set; }

        [JsonProperty("26")]
        public string _26 { get; set; }

        [JsonProperty("27")]
        public string _27 { get; set; }

        [JsonProperty("28")]
        public string _28 { get; set; }

        [JsonProperty("29")]
        public string _29 { get; set; }

        [JsonProperty("30")]
        public string _30 { get; set; }
    }

}
