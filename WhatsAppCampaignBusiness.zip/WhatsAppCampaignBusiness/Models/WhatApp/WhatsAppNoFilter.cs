﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPGASNCEnquiryBusiness.Models.WhatApp
{
    public class WhatsAppNoFilter
    {
        public string project_id { get; set; }
        public int event_id { get; set; }
        public List<CustDetails> data { get; set; }
        public string MobileNos { get; set; }
    }
    public class CustDetails
    {
        public string number { get; set; }
        public string msg_id { get; set; }
        public string status { get; set; }
        public string error_code { get; set; }
        public string error_message { get; set; }
        public string push_id { get; set; }
    }
}
