// Angular
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
// RxJS
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
// NGRX
import { select, Store } from '@ngrx/store';
// Auth reducers and selectors
import { AppState} from '../../../core/reducers/';
import { isLoggedIn } from '../_selectors/auth.selectors';
import {UserModel} from '../../../models/Auth/signin.model';
@Injectable()
export class AuthGuard implements CanActivate {
    constructor(private store: Store<AppState>, private router: Router) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean>  {
        return this.store
            .pipe(
                select(isLoggedIn),
                tap(loggedIn => {

                    if (!loggedIn) {
                        this.router.navigateByUrl('/auth/login');
                    }
                    // (route.data.roles );
                    let roleId: string = this.routeListRoleBased();
                    if (route.data.roles && route.data.roles.indexOf(roleId) === -1) {
                        this.router.navigateByUrl('/auth/login');
                        return false;
                    }
                })
            );
    }

     routeListRoleBased(): string {
        let user = new UserModel();
        user.RoleId = 0;
        if (sessionStorage.getItem('LoginData') != null && sessionStorage.getItem('LoginData') !== undefined) {
            user =  JSON.parse(sessionStorage.getItem('LoginData'));
            if (user == null) {
                this.router.navigateByUrl('/auth/login');
            }
        }
        // user.RoleId==null ? user.RoleId = 0:user.RoleId;
        return user.RoleId.toString();
	}
}
