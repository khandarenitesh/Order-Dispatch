export class SendSampleMsgModel {
pkId: number = 0;
SelectedSA: string = '';
Selectistributor: string = '';
ConsumerNo: string = '';
ConsumerName: string = '';
SelectTemplate: string = '';
} 