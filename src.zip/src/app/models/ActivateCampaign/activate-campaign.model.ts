export class ActivateCampaign {

}

// When SA CODE Select DistributorId and DistributorName Bind
export class DistributorModel {
  DistributorId: any;
  DistributorName: string = "";
  JDEDistributorCode: string = "";
  constructor(public selected?: boolean) {
    if (selected === undefined) selected = false;
  }
}


// For Checkbox code
export class DistributorFlagsModel {
  DistributorId: string = '';
  IsLive : string = '';
  SBCLive : string ='';
  SurakshaLive : string ='';
  ARBLive : string ='';
  VASLive : string='';
}

// When RO Select RO and RO Name Bind
export class ActivateMISModel {
  ROCode: string = '';
  ROName: string = '';
  constructor(public selected?: boolean) {
    if (selected === undefined) selected = false;
  }
}


// For Checkbox code
export class ActivateMISFlagsModel {
  ROCode: string = '';
  IsDBC : string = '';
  IsSuraksha : string ='';
  IsARB : string ='';
  IsVAS : string ='';
}
