
export class UserModel {
    UserId: number;
    RoleId: number;
    refNo: string;
    EncryptUserName: string;
    DisplayName: string;
    UserName: string;
    Password: string;
    EncryptPassword: string;
    ActiveStatus: string;
    LastUpdatedDate: string;
    IsFillMandatorydtls: string;
    RoleName: string;
}
