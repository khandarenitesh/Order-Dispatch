export class CommonPostModel {
    LocationId: number;
    DateTime: string;
}
