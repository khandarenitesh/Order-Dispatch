export class ConfigurationDetailsMasterModel {
  TotalSBC: number = 0;
  MessageSent: number = 0;
  MessagePending: number = 0;
  FromTime: string = "";
  ToTime: string = "";
  SendMessageValue: number = 0;
  DistributorMobile: string = "";
  EmergencyContact: string = "";
  RSP: string = "";
  IsWithRefillCost: string = "";
}

export class DistributorModel {
  DistributorId: any;
  DistributorName: string = "";
  JDEDistributorCode: string = "";
  constructor(public selected?: boolean) {
    if (selected === undefined) selected = false;
  }
}

export class TemplateModel {
  TemplateId: string = "";
  TemplateName: string = "";
}

export class SBCConfigDetailsAddUpdateModel {
  DBCConfId: number = 0;
  SACode: string = "";
  ScheduleDate: any;
  DistributorId: number = 0;
  DistributorMobNo: string = "";
  EmergencyNo: string = "";
  IsWithRefillCost: string = "";
  RSP: string = "";
  TemplateId: string = "";
  MsgQty: number = 0;
  CurrentStatus: string = "";
  Action: string = "";
  Retvalue: string = "";
}

export class SBCConfigDetailsModel {
  ScheduleDate: any;
}

export class SBCConfigDetailsListModel {
  ConfgId: number = 0;
  SACode: string = "";
  ScheduleDate: Date = new Date();
  DistributorId: number = 0;
  JDEDistributorCode: string = "";
  DistributorName: string = "";
  DistributorMobNo: string = "";
  EmergencyNo: string = "";
  IsWithRefillCost: string = "";
  RSP: string = "";
  TemplateId: string = "";
  TemplateName: string = "";
  MsgQty: number = 0;
  EntryDate: Date = new Date();
  CurrentStatus: string = "";
}

export class GroupModel {
  GroupId: string = "";
  GroupName: string = "";
}

export class SBCDistributorGroupMappingAddEdit {
  GroupId: number = 0;
  GroupName: string = "";
  SACode: string = "";
  DistributorIdArray: string = "";
  TemplateId: string = "";
  IsActive: string = "";
  Action: string = "";
  RetValue: string = "";
}

export class SBCDistributorListByGroupList {
  DistributorId: string = "";
  JDEDistributorCode: string = "";
  DistributorName: string = "";
  OwnerName: string = "";
  IsDistributorLive: string = "";
  MobileNo: number = 0;
  Email: string = "";
  SACode: string = "";
  GroupName: string = "";
  IsInGroup: string = "";
  TemplateId: string = "";
}
