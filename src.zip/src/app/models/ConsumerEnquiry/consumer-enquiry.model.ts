export class ConsumerEnquiry {
    CId: number;
    ConsumerName: string;
    ConsAddress: string;
    MobileNo: string;
    DistributorId: number;
    IsPurchase: string;
    PurchaseDate: string;
    DistributorName: string;
    DistributorCode: string;
    DistAddress: string;
    StaffType: string;
    StaffName: string;
    Operation: string;
    EnquiryDate: string;
    PurchaseDateTemp: any;
    IsPurchaseTemp: boolean;


    ConsumerNo: string;
    EnquiryType: string;
    Reason: string;
    TempReason: string;
    SourceType: string;
}
