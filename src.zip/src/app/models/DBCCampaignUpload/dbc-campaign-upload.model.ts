export class DBCCampaignUploadModel {
    pkId: number = 0;
    SACode: number = 0;
    DistributorId: number = 0;
    JDEDistributorCode: string = "";
    DistributorName: string = "";
    UniqueConsumerId: number = 0;
    ConsumerNo: number = 0;
    ConsumerName: string = "";
    MobileNo: string = "";
    Email: string="";
}

export class DistributorModel {
    DistributorId: number = 0;
    DistributorName: string = "";
    JDEDistributorCode: string = "";
  }