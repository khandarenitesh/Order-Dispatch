export class DistDashboard {
    DistributorId: number;
    TotalNcEnquiry: string;
    TodayNcEnquiry: string;
    TotalPurchase: string;
    TodayPurchase: string;
}
export class MessageSentConsumerCount {
    TotalCnt: string;
    TodaysCnt: string;
    Messagesentcount: string;
    AutoReplySentcount: string;
    SBCCount: string;
	SurkshaCount:string;
    ConnectionReleasedCount: string;
    onAdminCountSummary: string;
    DuplicateMobCount: string;
    CheckMsgSent: string;
    Interestedcount: string;
    NotIntrestedCount: string;
    MIDoneCount: string;
	ARBDone:string;
    SurakshaHostChangedCount: string;
    Both: string;
    ConsumerContactedCount: string;
    ReadCount: string;
    ReadContactedCount:string;
    ARBCount:string;
    ARBDoneCount:string;
}
export class InterestedConsumerCount {
    TotalConsumerCnt: string;
    TodaysConsumerCnt: string;
}
export class Staffwisecount {
    DistributorId: number;
    StaffRefNo: number;
    StaffName: string;
    TotalNcEnquiry: string;
    TodayNcEnquiry: string;
    TotalPurchase: string;
    TodayPurchase: string;
}

