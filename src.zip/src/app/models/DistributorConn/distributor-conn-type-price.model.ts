export class DistributorConnTypePrice {
PId: number;
RSP: number;
ContactNo: string;
ActiveStatus: string;
DistributorId: number;
Flag: string;
DistributorStaffCnt: number;
StoveBrandCnt: number;
LanguageId: number;
LanguageName: string;
}

