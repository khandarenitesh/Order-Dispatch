export class DistStaff {
    StaffRefNo: number;
    StaffType: string;
    DistributorId: number;
    StaffName: string;
    StaffAddress: string;
    MobileNo: string;
    OTP: string;
    ActiveStatus: string;
    Operation: string;
    UserId: string;
    ActiveFrom: string;
    LastUpdateDateTime: string;
    VersionNo: string;
    IsEnquiryActive: boolean;
    IsInactiveConsActive: boolean;
}
