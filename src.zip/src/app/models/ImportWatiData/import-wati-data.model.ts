export class ImportWatiData {
    ScheduledAt: string = "";
    MobileNo: string = "";
    BroadcastName: string = "";
    TemplateName: string = "";
    DeliveryStatus: string = "";
}