export class UserLogin {
    UserID: number;
    EmployeeId: number;
    DisplayName: string;
    UserName: string;
    Password: string;
    ActiveStatus: string;
    RoleName: string;
    RoleId: number;
    RefineryId: number;
    RefineryName: string;
    PlantId: number;
    PlantName: string;
    LoginStatus: string;
}
