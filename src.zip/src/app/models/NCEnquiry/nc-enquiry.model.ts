export class NCEnquiry {
    CId: number;
    EQueId: number;
    ConsName: string;
    Address: string;
    ResidentiaArea: string;
    PhoneNumber: string;
    EmailId: string;
    CompanyName: string;
    MobileNo: string;
    DistributorId: number;
    ActiveStatus: string;
    Operation: string;
    ExpectedDate: string;
    StoveId: number;
    ItemName: string;
    TotalAmount: number;
    Price: number;
    BrandId: string;
    CustEnquiryDtls: string;
    SourceType: string;
  }

  export class CustEnquiryDtls {
    QueId: number;
    DistributorId: number;
    StaffRefNo: string;
    ConsName: string;
    Address: string;
    MobileNo: string;
    ConsumerNo: string;
    QId: number;
    AnsId: number;
    Ans: string;
    FromDate: string;
    ToDate: string;
    EnquiryId: number;
    ResidentiaArea: string;
    EmailId: string;
    CompanyName: string;
  }
  export class EnquiryQuestion {
    EQueId: number;
    EnquiryQue: string;
    QuestionType: number;
    ActiveStatus: string;
  }

