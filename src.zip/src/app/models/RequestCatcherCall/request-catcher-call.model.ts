export class RequestCatcherCallModel {
     pkId: number = 0;
     CallSid: string = "";
     CallFrom: string = "";
     CallTo: string = "";
     Direction: string = "";
     Created: string = "";
     DialCallDuration: string = "";
     StartTime: string = "";
     EndTime: string = "";
     CallType: string = "";
     DialWhomNumber: string = "";
     flow_id: string = "";
     tenant_id: string = "";
     CurrentTime: string = "";
     digits: string = "";
     IsValidPincode: string = "";
     PincodeArea: string = "";
     DistributorName: string = "";
     Remark: string = "";
     AOHRemark: string = "";
     IsCallByAdmin: string = "";
     IsCallNotAttended: string = "";
     EnquiryNo: string = "";
     Status: string = "";
}

export class Get5KGAppuCampaignByAdminCountModel {
     Today: string = "";
     AsOfDate: string = "";
     ValidPincode: string = "";
     InValidPincode: string = "";
     MissedCall: string = "";
     AfterOfficeHrs: string = "";
     Forwarded: number = 0;
}

export class Get5KGAppuCampaignByDistributorCountModel {
     Accepted: string = "";
     Pending: string = "";
}

export class Get5KGAppuCampaignByPincodeModel {
     Id: number = 0;
     Pincode: string = "";
     Area: string = "";
}

export class Update5KGAppuCampaignByPincodeModel {
     pkId: number = 0;
     Pincode: string = "";
     ResultMessage: string = "";
}