export class StoveItem {
    Id: number;
DistributorId: number;
StoveId: number;
ItemName: string;
Price: string;
ActiveStatus: string;
LastUpdateDateTime: string;
StoveType: string;
Operation: string;
}
