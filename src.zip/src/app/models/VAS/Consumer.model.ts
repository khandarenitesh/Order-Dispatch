export class ConsumerModel {
    SACode: number = 0;
    DistributorId: number;
    DistributorCode: string;
    DistributorName: string;
    UniqueConsumerId: number;
    ConsumerNo: string;
    MobileNo: string;
    ConsumerName: string;
    AreaName: string;
    IsRegistered: string;
    RegistrationDate: string;
    StatusName: string;
}
