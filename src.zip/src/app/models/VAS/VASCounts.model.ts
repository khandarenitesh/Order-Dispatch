export class VASCounts {
	DistributorId: number = 0;
	DistributorCode: string = '';
	VASConsumer: number = 0;
	ActiveCount: number = 0;
	ExpConsCount: number = 0;
	PendingBookings: number = 0;
	AssignBookingCnt: number = 0;
	DueBookingCnt: number = 0;
	TotalSRCnt: number = 0;
	PendingSRCnt: number = 0;
	TodayCompSR: number = 0;
	NoServiceDoneCnt: number = 0;
	Service1DoneCnt: number = 0;
	Service2DoneCnt: number = 0;
	DelBookingCnt: number = 0;
}

export class VasLogCounts {
	LoginFailCount :  number=0;
	BKGFileFailCount : number = 0;
	SRFileFailCounts : number = 0;
	BkgEmptyExcelCounts : number = 0;
	SREmptyExcelCounts : number = 0;
	LastCycleTime : number = 0;
	OneamshedularExeutedornot : number =0;
	TotalBkgDownloadFile : number = 0;
	TotalNoofCycle : number = 0;
}

