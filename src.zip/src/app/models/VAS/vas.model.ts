export class VASModel {
    SLAId: number;
    SLADesc: string;
    SLAValue: string;
    IsActive: boolean;
    AddedBy: number;
}