import { Injectable } from '@angular/core';
import { ToggleOptions } from '../../core/_base/metronic';
import { GlobalVariable } from '../common.service';
import { HttpClient } from '@angular/common/http';
import { tap, map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export class ActivateCampaignService {
	private API = GlobalVariable.BASE_API_URL;
	private GetDistributorList_Url = `${this.API}Masters/GetdistributorList`;
	private GetSAListList_Url = `${this.API}ConfiguratoinDetails/GetDistributorDetailsBySAList`;
	private GetSAByRoCode_Url = `${this.API}Distributor/GetSAbyRO`;
	private GetSaveActivateCheckBox_Url = `${this.API}Masters/ADDActivateCampaign`;
	private DistriCampRightsList_Url = `${this.API}Masters/DistriCampRightsList`;
	private SaveSendSamplemessages_Url = `${this.API}DynamicTemplate/AddSendTemplateMessage`;
	private SendSampleMessage_Url = `${this.API}DynamicTemplate/SendSampleMessage`;
	private GetSendSampleMessageList_Url = `${this.API}DynamicTemplate/GetSendSampleMessageList`;
	private GetTemplateList_Url = `${this.API}ConfiguratoinDetails/GetSBCMsgTemplateList`;
	private GetROMasterListByCode_Url = `${this.API}Masters/GetROMasterListByCode`;
	private SaveActivateROMIS_Url = `${this.API}Masters/ADDActivateROMIS`;
	
	OpenToggle: any = false;
	IsModelOn: any = false;
	displayValue: any = true;
	DivToggleWidth: any = '100%';

	toggleOptions: ToggleOptions = {
		target: 'body',
		targetState: 'kt-aside--minimize',
		togglerState: 'kt-aside__brand-aside-toggler--active'
	};
	Toggler: any = new KTToggle('kt_aside_toggler', this.toggleOptions);


	constructor(private _httpClient: HttpClient) { }

	// Get Distributor List
	GetDistDetails(Dtls: any): Observable<any> {
		return this._httpClient.post<any>(this.GetDistributorList_Url, Dtls, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	GetSAListDetails(Dtls: any): Observable<any> {
		return this._httpClient.post<any>(this.GetSAListList_Url, Dtls, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	GetSAByRoCode(Id: any): Observable<any> {
		return this._httpClient.get<any>(this.GetSAByRoCode_Url + "/" + Id, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	GetSaveActivateCampaign(model: any): Observable<any> {
		return this._httpClient.post<any>(this.GetSaveActivateCheckBox_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	DistriCampRightsList(SACode: any): Observable<any> {
		return this._httpClient.get<any>(this.DistriCampRightsList_Url + "/" + SACode, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Save Sample WhatsApp Message
	SaveSendSamplemessages(model: any): Observable<any> {
		return this._httpClient.post<any>(this.SaveSendSamplemessages_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Send Sample WhatsApp Message
	SendSampleMessage(model: any): Observable<any> {
		return this._httpClient.post<any>(this.SendSampleMessage_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Send Sample WhatsApp Message List
	GetSendSampleMessageList(): Observable<any> {
		return this._httpClient.get<any>(this.GetSendSampleMessageList_Url , { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Get Template List
	GetTemplateDetails(TemplateFor: string): Observable<any> {
		return this._httpClient.get<any>(this.GetTemplateList_Url + "/" + TemplateFor, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Get RO Master List
	GetROMasterListByCode(ROCode: string): Observable<any> {
		return this._httpClient.get<any>(this.GetROMasterListByCode_Url + "/" + ROCode, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Activate RO MIS
	SaveActivateROMIS(model: any): Observable<any> {
		return this._httpClient.post<any>(this.SaveActivateROMIS_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

}
