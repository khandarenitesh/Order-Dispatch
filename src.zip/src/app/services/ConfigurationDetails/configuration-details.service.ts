import { Injectable } from '@angular/core';
import { ToggleOptions } from '../../core/_base/metronic';
import { GlobalVariable } from '../common.service';
import { HttpClient } from '@angular/common/http';

// Models
import { SBCConfigDetailsAddUpdateModel, SBCConfigDetailsListModel, SBCDistributorGroupMappingAddEdit } from '../../models/ConfigurationDetails/configuration-details.model';

import { tap, map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export class ConfigurationDetailsService {
	private API = GlobalVariable.BASE_API_URL;
	private GetDistributorList_Url = `${this.API}Masters/GetdistributorList`;
	private GetTemplateList_Url = `${this.API}ConfiguratoinDetails/GetSBCMsgTemplateList`;
	private GetSAListList_Url = `${this.API}ConfiguratoinDetails/GetDistributorDetailsBySAList`;
	private SBCConfigDetailsAddUpdate_Url = `${this.API}ConfiguratoinDetails/SBCConfigDetailsAddUpdate`;
	private GetSBCConfigDetailsList_Url = `${this.API}ConfiguratoinDetails/GetSBCConfigDetailsList`;

	private SendMessageConfigurationDetails_Url = `${this.API}ConfiguratoinDetails/SendMessageConfigurationDetails`;
	private SendMessageAllConfigurationDetails_Url = `${this.API}ConfiguratoinDetails/SendMessageAllConfigurationDetails`;

	private GetSBCConfigDetailsDistributorByList_Url = `${this.API}ConfiguratoinDetails/GetSBCConfigDetailsDistributorByList`;
	private SBCDistributorGroupMappingAddEdit_Url = `${this.API}ConfiguratoinDetails/SBCDistributorGroupMappingAddEdit`;
	private GetSBCDistributorGroupMappingList_Url = `${this.API}ConfiguratoinDetails/GetSBCDistributorGroupMappingList`;
	private GetDistributorListByGroup_Url = `${this.API}ConfiguratoinDetails/GetDistributorListByGroup`;
	private SurakshaDistributorGroupMappingAddEdit_Url = `${this.API}ConfiguratoinDetails/SurakshaDistributorGroupMappingAddEdit`;
	private GetSurakshaConfigDetailsList_Url = `${this.API}ConfiguratoinDetails/GetSurkshaConfigDetailsList`;
	private GetMsgTemplateList_Url = `${this.API}ConfiguratoinDetails/GetSurakshaMsgTemplateList`;
	private GetSurakshaDistributorGroupMappingList_Url = `${this.API}ConfiguratoinDetails/GetSurakshaDistributorGroupMappingList`;
	private GetSurakshaDistributorListByGroup_Url = `${this.API}ConfiguratoinDetails/GetSurakshaDistributorListByGroup`;
	private SurakshaConfigDetailsAddUpdate_Url = `${this.API}ConfiguratoinDetails/SurakshaConfigDetailsAddUpdate`;
	private SendMessageSurakshaConfigurationDetails_Url = `${this.API}ConfiguratoinDetails/SendMessageSurakshaConfigurationDetails`;
	private SendMessageSurakshaAllConfigurationDetails_Url = `${this.API}ConfiguratoinDetails/SendMessageSurakshaAllConfigurationDetails`;
	private GetArRBTemplateList_Url = `${this.API}ConfiguratoinDetails/GetSBCMsgTemplateList`;
	private GetARBSBCConfigDetailsList_Url = `${this.API}ConfiguratoinDetails/GetARBConfigDetailsList`;
	private GetARBDistributorGroupMappingList_Url = `${this.API}ConfiguratoinDetails/GetARBDistributorGroupMappingList`;
	private GetARBDistributorListByGroup_Url = `${this.API}ConfiguratoinDetails/GetARBDistributorListByGroup`;
	private ARBDistributorGroupMappingAddEdit_Url = `${this.API}ConfiguratoinDetails/ARBDistributorGroupMappingAddEdit`;
	private ARBConfigDetailsAddUpdate_Url = `${this.API}ConfiguratoinDetails/ARBConfigDetailsAddUpdate`;
	private ARBSendMessageAllConfigurationDetails_Url = `${this.API}ConfiguratoinDetails/SendMessageARBAllConfigurationDetails`;
	private ARBSendMessageConfigurationDetails_Url = `${this.API}ConfiguratoinDetails/SendMessageARBConfigurationDetails`;
	private GetSurakshaUsersByAreaSeqList_Url = `${this.API}ConfiguratoinDetails/GetSurakshaUsersByAreaSeqList/`;
	private UpdateAreaSequenceNo_Url = `${this.API}ConfiguratoinDetails/SurakshaUsersUpdateAreaSeq`;
	private GetDistributorListforResetPass_Url = `${this.API}ConfiguratoinDetails/GetListForResetPass`;
	private UpdatePassword_Url = `${this.API}ConfiguratoinDetails/UpdateResetPass`;


	OpenToggle: any = false;
	IsModelOn: any = false;
	displayValue: any = true;
	DivToggleWidth: any = '100%';

	toggleOptions: ToggleOptions = {
		target: 'body',
		targetState: 'kt-aside--minimize',
		togglerState: 'kt-aside__brand-aside-toggler--active'
	};
	Toggler: any = new KTToggle('kt_aside_toggler', this.toggleOptions);

	constructor(private _httpClient: HttpClient) { }

	// Get Distributor List
	GetDistDetails(Dtls: any): Observable<any> {
		return this._httpClient.post<any>(this.GetDistributorList_Url, Dtls, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Get Template List
	GetTemplateDetails(TemplateFor: string): Observable<any> {
		return this._httpClient.get<any>(this.GetTemplateList_Url + "/" + TemplateFor, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	GetSAListDetails(Dtls: any): Observable<any> {
		return this._httpClient.post<any>(this.GetSAListList_Url, Dtls, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// SBC ConfigDetails - AddUpdate
	SBCConfigDetailsAddUpdate(model: SBCConfigDetailsAddUpdateModel): Observable<any> {
		return this._httpClient.post<any>(this.SBCConfigDetailsAddUpdate_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Get SBC ConfigDetails Lista
	GetSBCConfigDetailsList(SACode: string): Observable<any> {
		return this._httpClient.get<any>(this.GetSBCConfigDetailsList_Url + "/" + SACode, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Send Message Configuration Details
	SendMessageConfigurationDetails(model: SBCConfigDetailsListModel): Observable<any> {
		return this._httpClient.post<any>(this.SendMessageConfigurationDetails_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Send Message All Configuration Details
	SendMessageAllConfigurationDetails(): Observable<any> {
		return this._httpClient.get<any>(this.SendMessageAllConfigurationDetails_Url, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Get SBC Configuration Details Distributor By List
	GetSBCConfigDetailsDistributorByList(DistributorId: number): Observable<any> {
		return this._httpClient.get<any>(this.GetSBCConfigDetailsDistributorByList_Url + "/" + DistributorId, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// SBC Distributor Group Mapping -> Add/Update
	SBCDistributorGroupMappingAddEdit(model: SBCDistributorGroupMappingAddEdit): Observable<any> {
		return this._httpClient.post<any>(this.SBCDistributorGroupMappingAddEdit_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Get SBC Distributor Group Mapping List
	GetSBCDistributorGroupMappingList(SACode: string): Observable<any> {
		return this._httpClient.get<any>(this.GetSBCDistributorGroupMappingList_Url + "/" + SACode, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Get Distributor List By Group
	GetDistributorListByGroup(SACode: string, GroupName: string): Observable<any> {
		return this._httpClient.get<any>(this.GetDistributorListByGroup_Url + "/" + SACode + "/" + GroupName, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Suraksha Distributor Group Mapping -> Add/Update
	SurakshaDistributorGroupMappingAddEdit(model: SBCDistributorGroupMappingAddEdit): Observable<any> {
		return this._httpClient.post<any>(this.SurakshaDistributorGroupMappingAddEdit_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Suraksha ConfigDetails List
	GetSurakshaConfigDetailsList(SACode: string): Observable<any> {
		return this._httpClient.get<any>(this.GetSurakshaConfigDetailsList_Url + "/" + SACode, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Get Suraksha Template List
	GetMsgTemplateDetails(): Observable<any> {
		return this._httpClient.get<any>(this.GetMsgTemplateList_Url, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Get Suraksha Distributor Group Mapping List
	GetSurakshaDistributorGroupMappingList(SACode: string): Observable<any> {
		return this._httpClient.get<any>(this.GetSurakshaDistributorGroupMappingList_Url + "/" + SACode, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}
	// Get Suraksha Distributor List By Group
	GetSurakshaDistributorListByGroup(SACode: string, GroupName: string): Observable<any> {
		return this._httpClient.get<any>(this.GetSurakshaDistributorListByGroup_Url + "/" + SACode + "/" + GroupName, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}
	// Suraksha ConfigDetails - AddUpdate
	SurakshaConfigDetailsAddUpdate(model: SBCConfigDetailsAddUpdateModel): Observable<any> {
		return this._httpClient.post<any>(this.SurakshaConfigDetailsAddUpdate_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Send Message suraksha Configuration Details
	SendMessageSurakshaConfigurationDetails(model: SBCConfigDetailsListModel): Observable<any> {
		return this._httpClient.post<any>(this.SendMessageSurakshaConfigurationDetails_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Send Message suraksha All Configuration Details
	SendMessageSurakshaAllConfigurationDetails(): Observable<any> {
		return this._httpClient.get<any>(this.SendMessageSurakshaAllConfigurationDetails_Url, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Get ARB Template List
	GetARBTemplateDetails(TemplateFor: string): Observable<any> {
	return this._httpClient.get<any>(this.GetArRBTemplateList_Url + "/" + TemplateFor, { observe: 'response' })
		.pipe(map(result => {
			// login successful if there's a jwt token in the response
			if (result) {
			}
			return result.body;
		}), tap(() => { // Add This Tap to all services
		}, error => {
			console.log(error.status);
			if (error.status === '401') {
			}
		}));
}

	// Get ARB ConfigDetails List
	GetARBSBCConfigDetailsList(SACode: string): Observable<any> {
		return this._httpClient.get<any>(this.GetARBSBCConfigDetailsList_Url + "/" + SACode, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add This Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}


	// Get ARB Distributor Group Mapping List
	GetARBDistributorGroupMappingList(SACode: string): Observable<any> {
		return this._httpClient.get<any>(this.GetARBDistributorGroupMappingList_Url + "/" + SACode, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Get ARB Distributor List By Group
	GetARBDistributorListByGroup(SACode: string, GroupName: string): Observable<any> {
		return this._httpClient.get<any>(this.GetARBDistributorListByGroup_Url + "/" + SACode + "/" + GroupName, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// ARB Distributor Group Mapping -> Add/Update
	ARBDistributorGroupMappingAddEdit(model: SBCDistributorGroupMappingAddEdit): Observable<any> {
		return this._httpClient.post<any>(this.ARBDistributorGroupMappingAddEdit_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// ARB ConfigDetails - AddUpdate
	ARBConfigDetailsAddUpdate(model: SBCConfigDetailsAddUpdateModel): Observable<any> {
		return this._httpClient.post<any>(this.ARBConfigDetailsAddUpdate_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// ARB Send Message All Configuration Details
	ARBSendMessageAllConfigurationDetails(): Observable<any> {
		return this._httpClient.get<any>(this.ARBSendMessageAllConfigurationDetails_Url, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	//ARB Send Message Configuration Details
	ARBSendMessageConfigurationDetails(model: SBCConfigDetailsListModel): Observable<any> {
		return this._httpClient.post<any>(this.ARBSendMessageConfigurationDetails_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	//  Get Area Sequence List
	GetSurakshaUsersByAreaSeqList(JDEDistributorCode: string): Observable<any> {
		return this._httpClient.get<any>(this.GetSurakshaUsersByAreaSeqList_Url + "/" + JDEDistributorCode, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	//Area Sequence ->Update
	UpdateAreaSequenceNo(model: any): Observable<any> {
		return this._httpClient.post<any>(this.UpdateAreaSequenceNo_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}
	// Get Distributor List for Reset Pass
	GetDistributorListforResetPass(): Observable<any> {
		return this._httpClient.get<any>(this.GetDistributorListforResetPass_Url, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Update Password
	UpdatePassword(model: any): Observable<any> {
		return this._httpClient.post<any>(this.UpdatePassword_Url, model, { observe: 'response' })
			.pipe(map(result => {

				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}


}
