import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders, HttpRequest, HttpEvent } from '@angular/common/http';
import { tap, catchError, map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { GlobalVariable } from '../common.service';

@Injectable({
  providedIn: 'root'
})
export class ConsumerEnquiryService {

  private API = GlobalVariable.BASE_API_URL;
  private getConsumerEnquiryAPI = `${this.API}Customer/GetCustomerDetails`;
  private getUnassignConsumerEnquiryAPI = `${this.API}Customer/GetUnassignCustomerDetails`;
  private updateConsumerDetailsAPI = `${this.API}Customer/UpdateCustomerDtls`;

  constructor(private http: HttpClient) { }

  getConsumerEnquiry(Dtls: any): Observable<any> {
      let apiUrl1 = this.getConsumerEnquiryAPI;
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
      return this.http.post(apiUrl1, Dtls)
      .pipe(
        tap(data => ('getConsumerEnquiry')),
        catchError(this.handleError('getConsumerEnquiry', []))
      );
    }
    getUnassignConsumerEnquiry(Dtls: any): Observable<any> {
      let apiUrl1 = this.getUnassignConsumerEnquiryAPI;
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
      return this.http.post(apiUrl1, Dtls)
      .pipe(
        tap(data => ('getConsumerEnquiry')),
        catchError(this.handleError('getConsumerEnquiry', []))
      );
    }

    UpdateConsumerDetails(Dtls: any): Observable<any> {
      let apiUrl1 = this.updateConsumerDetailsAPI;
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
      return this.http.post(apiUrl1, Dtls)
      .pipe(
        tap(data => ('UpdateConsumerDetails')),
        catchError(this.handleError('UpdateConsumerDetails', []))
      );
    }

    private handleError<T>(operation = 'operation', result?: T) {
      return (error: any): Observable<T> => {
        // TODO: send the error to remote logging infrastructure
        console.error(error); // log to console instead
        // Let the app keep running by returning an empty result.
        return of(result as T);
      };
    }
}
