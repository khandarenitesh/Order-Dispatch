import { Injectable } from '@angular/core';
import { GlobalVariable } from '../common.service';
import { HttpClient} from '@angular/common/http';
import { tap, map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DbcCampaignService {

  private API = GlobalVariable.BASE_API_URL;
  private GetConsumerList_Url = `${this.API}Distributor/GetAllConsumers`;
  private UpdateStatus_Url = `${this.API}Distributor/UpdateStatus`;
  private DbcConsumersCount_Url = `${this.API}Distributor/GetDbcConsumersCount`;
  private CallStatusList_Url = `${this.API}Masters/GetCallStatusList`;
  private GetStatusWiseCounts_Url = `${this.API}Distributor/GetInterestedCnt`;
  private GetConsumerListForSuraksha_Url = `${this.API}Distributor/GetAllSurakshausersByDistributor`;
  private SurakshaConsumersCount_Url = `${this.API}Distributor/GetSurakshaConsumersCount`;
  private GetInterestedCntDetails_Url = `${this.API}Distributor/GetInterestedCntDetailsForSurksha`;
  private UpdatesurakshaStatus_Url = `${this.API}Distributor/UpdateConnectionFlagForSuraksha`;

  // ARB START
  private GetConsumerListForARB_Url = `${this.API}Distributor/GetAllARBUsersByDistributor`;
  private ARBConsumersCount_Url = `${this.API}Distributor/GetARBConsumersCount`;
  private GetInterestedCntARBDetails_Url = `${this.API}Distributor/GetInterestedCntDetailsForARB`;
  private UpdateARBStatus_Url = `${this.API}Distributor/UpdateConnectionFlagForARB`;
  private ARBItemList_Url = `${this.API}Distributor/ARBItemList/`;
  private GetARBItemSoldCountsDetails_Url = `${this.API}Distributor/GetARBItemSoldCount`;
  // ARB END

  constructor(private _httpClient: HttpClient) { }

  GetConsumers_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.GetConsumerList_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

  UpdateStatus_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.UpdateStatus_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }
  DbcConsumersCount_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.DbcConsumersCount_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

  GetCallStatusList(StatusFor : string): Observable<any> {
    return this._httpClient.get<any>(this.CallStatusList_Url+ "/"+ StatusFor,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

  GetStatusWiseCounts_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.GetStatusWiseCounts_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

  //Get All User service.
  GetAllConsumers_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.GetConsumerListForSuraksha_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

  //Suraksha Consumer Count
  SurakshaConsumersCount_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.SurakshaConsumersCount_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

GetStatusWiseCountDetails_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.GetInterestedCntDetails_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

  UpdateSurakshaStatus_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.UpdatesurakshaStatus_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

   //Get ARB All User service.
   GetARBAllConsumers_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.GetConsumerListForARB_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }


   //ARB Consumer Count
   ARBConsumersCount_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.ARBConsumersCount_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }


  GetARBStatusWiseCountDetails_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.GetInterestedCntARBDetails_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

  ARBUpdateARBStatus_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.UpdateARBStatus_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }
  GetARBItemSoldCountsDetails_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.GetARBItemSoldCountsDetails_Url,DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

  ARBItemList_service(Flag: number): Observable<any> {
    return this._httpClient.get<any>(this.ARBItemList_Url + Flag ,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

}
