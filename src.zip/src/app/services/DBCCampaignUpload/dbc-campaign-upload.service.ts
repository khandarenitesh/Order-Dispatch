import { Injectable } from '@angular/core';
import { ToggleOptions } from '../../core/_base/metronic';
import { GlobalVariable } from '../common.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { tap, map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export class DBCCampaignUploadService {
	private API = GlobalVariable.BASE_API_URL;
	private GetDistributorList_Url = `${this.API}Masters/GetdistributorList`;
	private DBCCampaignUploadExcel_Url = `${this.API}DBCCampaignUpload`;
	private SecondSylenderDataExcel_Url = `${this.API}SecondCylenderImport`;
	private SurakshaCampaignUploadExcel_Url = `${this.API}DBCCampaignUpload`;
	private ARBImportDataUploadExcel_Url = `${this.API}DBCCampaignUpload`;

	OpenToggle: any = false;
	IsModelOn: any = false;
	displayValue: any = true;
	DivToggleWidth: any = '100%';

	toggleOptions: ToggleOptions = {
		target: 'body',
		targetState: 'kt-aside--minimize',
		togglerState: 'kt-aside__brand-aside-toggler--active'
	};
	Toggler: any = new KTToggle('kt_aside_toggler', this.toggleOptions);

	constructor(private _httpClient: HttpClient) { }

	// Get Distributor List
	GetDistDetails(Dtls: any): Observable<any> {
		return this._httpClient.post<any>(this.GetDistributorList_Url, Dtls, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Upload Excel
	UploadExcel(DistributorId: number, formData: FormData) {
		let headers = new HttpHeaders();
		headers.append('Content-Type', 'multipart/form-data');
		headers.append('Accept', 'application/json');
		const httpOptions = { headers: headers };
		return this._httpClient.post(this.DBCCampaignUploadExcel_Url + '/SBCUsersImportData/' + DistributorId, formData, httpOptions);
	}

	UploadSecondCylenderExcel(DistributorId: number, formData: FormData) {
		let headers = new HttpHeaders();
		headers.append('Content-Type', 'multipart/form-data');
		headers.append('Accept', 'application/json');
		const httpOptions = { headers: headers };
		return this._httpClient.post(this.SecondSylenderDataExcel_Url + '/SecondCylenderImportData/' + DistributorId, formData, httpOptions);
	}

	//  Suraksha - Upload Excel
	SurakshaUploadExcel(DistributorId: number, formData: FormData) {
		let headers = new HttpHeaders();
		headers.append('Content-Type', 'multipart/form-data');
		headers.append('Accept', 'application/json');
		const httpOptions = { headers: headers };
		return this._httpClient.post(this.SurakshaCampaignUploadExcel_Url + '/SurakshaImportData/' + DistributorId, formData, httpOptions);
	}

	//  ARB - Upload Excel
	ARBUploadExcel(DistributorId: number, formData: FormData) {
		let headers = new HttpHeaders();
		headers.append('Content-Type', 'multipart/form-data');
		headers.append('Accept', 'application/json');
		const httpOptions = { headers: headers };
		return this._httpClient.post(this.ARBImportDataUploadExcel_Url + '/ARBImportData/' + DistributorId, formData, httpOptions);
	}

}
