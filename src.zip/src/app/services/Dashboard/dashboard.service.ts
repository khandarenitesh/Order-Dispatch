import { Injectable } from '@angular/core';

import { GlobalVariable } from '../common.service';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import { Observable, of, throwError } from 'rxjs';
@Injectable()
export class DistributorDashboardService {
  // API Ulrs
  private Host = GlobalVariable.BASE_API_URL;
  private postDistDashboardCountAPI = `${this.Host}Masters/GetDistDashboardCount`;
  private GetRODashboardCount_Api = `${this.Host}RO/GetRODashboardCount`;
  private GetLanguageMaster_Api = `${this.Host}Masters/GetLanguageList`;
  private saveDistLanguage_Api = `${this.Host}Distributor/AddUpdateDistLanguage`;
  private GetRODashboardDistwiseCount_Api = `${this.Host}RO/GetRODashboardDistwiseCount`;

  constructor(private http: HttpClient) { }

  GetDistDashboardCount(Dtls: any): Observable<any> {
    let apiUrl1 = this.postDistDashboardCountAPI;
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(apiUrl1, Dtls)
    .pipe(
      tap(data => ('GetDistDashboardCount')),
      catchError(this.handleError('GetDistDashboardCount', []))
    );
  }

  GetRODashboardCount(Dtls: any): Observable<any> {
    let apiUrl1 = this.GetRODashboardCount_Api;
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(apiUrl1, Dtls)
    .pipe(
      tap(data => ('GetRODashboardCount')),
      catchError(this.handleError('GetRODashboardCount', []))
    );
  }

  GetRODashboardDistwiseCount(Dtls: any): Observable<any> {
    let apiUrl1 = this.GetRODashboardDistwiseCount_Api;
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(apiUrl1, Dtls)
    .pipe(
      tap(data => ('GetRODashboardDistwiseCount')),
      catchError(this.handleError('GetRODashboardDistwiseCount', []))
    );
  }

  GetLanguageMaster(Model: any): Observable<any> {
    let apiUrl1 = this.GetLanguageMaster_Api;
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(apiUrl1, Model)
    .pipe(
      tap(data => ('GetLanguageMaster')),
      catchError(this.handleError('GetLanguageMaster', []))
    );
  }

  SaveDistributorLanguageDtls(Model: any): Observable<any> {
    let apiUrl1 = this.saveDistLanguage_Api;
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(apiUrl1, Model)
    .pipe(
      tap(data => ('SaveDistributorLanguageDtls')),
      catchError(this.handleError('SaveDistributorLanguageDtls', []))
    );
  }



  // common handle error
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
