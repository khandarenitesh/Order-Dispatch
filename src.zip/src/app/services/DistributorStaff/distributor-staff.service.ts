import { Injectable } from '@angular/core';

import { GlobalVariable } from '../common.service';

import { HttpClient, HttpHeaders, HttpRequest, HttpEvent } from '@angular/common/http';
import { tap, catchError, map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DistributorStaffService {

  private API = GlobalVariable.BASE_API_URL;
  private getDistStaffDetailsAPI = `${this.API}Masters/GetdistributorStaffDtls/`;
  private saveDistStaffDetailsAPI = `${this.API}Masters/AddEditDistributorStaffDetails/`;
  constructor(private http: HttpClient) { }

  getDistStaffDetails(Dtls: any): Observable<any> {
      let apiUrl1 = this.getDistStaffDetailsAPI;
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
      return this.http.post(apiUrl1, Dtls)
      .pipe(
        tap(data => 'getDistStaffDetails'),
        catchError(this.handleError('getDistStaffDetails', []))
      );
    }
    saveDistStaffDetails(Dtls: any): Observable<any> {
      let apiUrl1 = this.saveDistStaffDetailsAPI;
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
      return this.http.post(apiUrl1, Dtls)
      .pipe(
        tap(data => 'saveDistStaffDetails'),
        catchError(this.handleError('saveDistStaffDetails', []))
      );
    }


    private handleError<T>(operation = 'operation', result?: T) {
      return (error: any): Observable<T> => {
        // TODO: send the error to remote logging infrastructure
        console.error(error); // log to console instead
        // Let the app keep running by returning an empty result.
        return of(result as T);
      };
    }
}
