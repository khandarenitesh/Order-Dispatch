import { TestBed } from '@angular/core/testing';

import { DynamicTemplateService } from './dynamic-template.service';

describe('DynamicTemplateService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DynamicTemplateService = TestBed.get(DynamicTemplateService);
    expect(service).toBeTruthy();
  });
});
