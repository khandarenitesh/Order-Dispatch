import { GlobalVariable } from './../common.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { result } from 'lodash';

@Injectable({
	providedIn: 'root'
})
export class DynamicTemplateService {

	private API = GlobalVariable.BASE_API_URL;
	private AddDynamicTemplateKeyValues_Url = `${this.API}DynamicTemplate/AddDynamicTemplateValue`;
	private GetynamicTemplateKeyValuesList_Url = `${this.API}DynamicTemplate/GetDynamicTemplateValuesList`
	private GetAllTemplateList_Url = `${this.API}DynamicTemplate/GetAllTemplateList`
	private GetAllTemplateValuesList_Url = `${this.API}DynamicTemplate/GetAllTemplateValuesList/`
	private GetTemplate_Url = `${this.API}DynamicTemplate/GetTemplate/`
	private EditTemplateKeyValues_Url = `${this.API}DynamicTemplate/EditTemplateValue`;


	constructor(private http: HttpClient) { }

	Id: number = 0;

	// Add Dynamic Template Key Values
	AddDynamicTemplateKeyValues(model: any): Observable<any> {
		return this.http.post<any>(this.AddDynamicTemplateKeyValues_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	//Get Template For Dynamic template
	GetDynamicTemplateValuesList(): Observable<any> {
		return this.http.get<any>(this.GetynamicTemplateKeyValuesList_Url, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	//Get All Template List
	GetAllTemplateList(): Observable<any> {
		return this.http.get<any>(this.GetAllTemplateList_Url, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	//Get All Template List
	GetAllTemplateValuesList(TemplateId: any): Observable<any> {
		return this.http.get<any>(this.GetAllTemplateValuesList_Url + TemplateId, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	//Get All Template List
	GetTemplate(pkId: any): Observable<any> {
		return this.http.get<any>(this.GetTemplate_Url + pkId, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				if (result) {
				}
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

	// Edit Template Key Values
	EditTemplateKeyValues(model: any): Observable<any> {
		return this.http.post<any>(this.EditTemplateKeyValues_Url, model, { observe: 'response' })
			.pipe(map(result => {
				// login successful if there's a jwt token in the response
				return result.body;
			}), tap(() => { // Add Thid Tap to all services
			}, error => {
				console.log(error.status);
				if (error.status === '401') {
				}
			}));
	}

}
