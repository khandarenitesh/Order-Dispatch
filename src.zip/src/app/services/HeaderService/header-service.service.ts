import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class HeaderServiceService {

  // private pageState = new BehaviorSubject<boolean>(false);
  // currentPage = this.pageState.asObservable();

  public title = new BehaviorSubject('Dashboard');

  // currentPagename = 'Dashboard';

  constructor() { }

  // changeState(state: boolean) {
  //   this.pageState.next(state);
  //   // this.currentPagename = state;
  //   // console.log(this.currentPagename);
  // }

  setTitle(title) {
    this.title.next(title);
  }

}
