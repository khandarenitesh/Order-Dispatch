import { Injectable } from '@angular/core';
import { ToggleOptions } from '../../core/_base/metronic';
import { GlobalVariable } from '../common.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ImportWatiDataService {
  private API = GlobalVariable.BASE_API_URL;
  private UploadExcel_Url = `${this.API}ImportWatiDataDBC`;
  private SurakshaExcelUpload_Url = `${this.API}ImportWatiDataForSuraksha`;
  private ARBExcelUpload_Url = `${this.API}ImportWatiDataForARB`;

  OpenToggle: any = false;
  IsModelOn: any = false;
  displayValue: any = true;
  DivToggleWidth: any = '100%';

  toggleOptions: ToggleOptions = {
    target: 'body',
    targetState: 'kt-aside--minimize',
    togglerState: 'kt-aside__brand-aside-toggler--active'
  };
  Toggler: any = new KTToggle('kt_aside_toggler', this.toggleOptions);

  constructor(private _httpClient: HttpClient) { }

  // DBC Excel Upload
  DBCExcelUpload(formData: FormData) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Accept', 'application/json');
    const httpOptions = { headers: headers };
    return this._httpClient.post(this.UploadExcel_Url + '/DBCExcelUpload', formData, httpOptions);
  }

  // Suraksha Excel Upload
  SurakshaExcelUpload(formData: FormData) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Accept', 'application/json');
    const httpOptions = { headers: headers };
    return this._httpClient.post(this.SurakshaExcelUpload_Url + '/SurakshaExcelUpload', formData, httpOptions);
  }

  // ARB Excel Upload
  ARBExcelUpload(formData: FormData) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Accept', 'application/json');
    const httpOptions = { headers: headers };
    return this._httpClient.post(this.ARBExcelUpload_Url + '/ARBExcelUpload', formData, httpOptions);
  }

}