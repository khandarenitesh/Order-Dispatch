import { Injectable } from '@angular/core';
import { ToggleOptions } from '../../core/_base/metronic';
import { GlobalVariable } from '../common.service';
import { HttpClient } from '@angular/common/http';
import { tap, map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RequestCatcherCallService {
  private API = GlobalVariable.BASE_API_URL;
  private GetRequestCatcherCall_Url = `${this.API}GetRequestCatcherCall`;
  private CallParticularNumber_Url = `${this.API}RequestCatcherCall/CallParticularNumber`;
  private Get5KGAppuCampaignByDistributor_Url = `${this.API}Get5KGAppuCampaignByDistributor`;
  private AssignDistributor_Url = `${this.API}RequestCatcherCallController/AssignDistributor`;
  private Get5KGAppuCampaignByAdminCount_Url = `${this.API}Get5KGAppuCampaignByAdminCount`;
  private Get5KGAppuCampaignByDistributorCount_Url = `${this.API}Get5KGAppuCampaignByDistributorCount`;
  private Get5KGAppuCampaignByAdminCountSummary_Url = `${this.API}Get5KGAppuCampaignByAdminCountSummary`;
  private Get5KGAppuCampaignByPincode_Url = `${this.API}Get5KGAppuCampaignByPincode`;
  private Update5KGAppuCampaignByPincode_Url = `${this.API}Update5KGAppuCampaignByPincode`;
  private Get5KGAppuEnquiryStatus_Url = `${this.API}RequestCatcherCall/Get5KGAppuEnquiryStatus`;
  private Get5KGAppuEnquiryActionTaken_Url = `${this.API}RequestCatcherCall/Get5KGAppuEnquiryActionTaken`;
  private Get5KGAppuEnquiryCampaignByDistributor_Url = `${this.API}RequestCatcherCall/Get5KGAppuEnquiryCampaignByDistributor`;
  private Update5KGAppuEnquiryStatusDistributor_Url = `${this.API}RequestCatcherCall/Update5KGAppuEnquiryStatusDistributor`;
  private Update5KGAppuEnquiryActionDistributor_Url = `${this.API}RequestCatcherCall/Update5KGAppuEnquiryActionDistributor`;
  private Get5KGAppuEnquiryCampaignByDistributorCount_Url = `${this.API}RequestCatcherCall/Get5KGAppuEnquiryCampaignByDistributorCount`;
  private Get5KGAppuEnquiryCampaignByDistributorCountSummary_Url = `${this.API}RequestCatcherCall/Get5KGAppuEnquiryCampaignByDistributorCountSummary`;

  OpenToggle: any = false;
  IsModelOn: any = false;
  displayValue: any = true;
  DivToggleWidth: any = '100%';

  toggleOptions: ToggleOptions = {
    target: 'body',
    targetState: 'kt-aside--minimize',
    togglerState: 'kt-aside__brand-aside-toggler--active'
  };
  Toggler: any = new KTToggle('kt_aside_toggler', this.toggleOptions);

  constructor(private _httpClient: HttpClient) { }

  GetRequestCatcherCall(FromDate: any, ToDate: any): Observable<any> {
    return this._httpClient.get<any>(this.GetRequestCatcherCall_Url + "/" + FromDate + "/" + ToDate, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }


  CallToParticularNumber(pkId: number, callFrom: string, callNumber: string): Observable<any> {
    return this._httpClient.post<any>(this.CallParticularNumber_Url + "/" + pkId + "/" + callFrom + "/" + callNumber, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  // To Get 5KG Appu Campaign By Distributor
  Get5KGAppuCampaignByDistributor(distributorId: number, FromDate: any, ToDate: any): Observable<any> {
    return this._httpClient.get<any>(this.Get5KGAppuCampaignByDistributor_Url + "/" + distributorId + "/" + FromDate + "/" + ToDate, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  AssignDistributor(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.AssignDistributor_Url, DataModel, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  // To Get 5 KG Appu Campaign By Admin Count
  Get5KGAppuCampaignByAdminCount(): Observable<any> {
    return this._httpClient.get<any>(this.Get5KGAppuCampaignByAdminCount_Url, { observe: 'response' })
               .pipe(map(result => {
                  // login successful if there's a jwt token in the response
                  if (result) {
                  }
                  return result.body;
                }), tap(() => { // Add Thid Tap to all services
                },  error => {
                    console.log(error.status);
                    if (error.status === '401') {
                    }
                }));
  }

  // To Get 5 KG Appu Campaign By Distributor Count
  Get5KGAppuCampaignByDistributorCount(distributorId: number): Observable<any> {
    return this._httpClient.get<any>(this.Get5KGAppuCampaignByDistributorCount_Url + "/" + distributorId, { observe: 'response' })
               .pipe(map(result => {
                  // login successful if there's a jwt token in the response
                  if (result) {
                  }
                  return result.body;
                }), tap(() => { // Add Thid Tap to all services
                },  error => {
                    console.log(error.status);
                    if (error.status === '401') {
                    }
                }));
  }

  // To Get 5 KG Appu Campaign By Admin Count Summary
  Get5KGAppuCampaignByAdminCountSummary(type: string): Observable<any> {
    return this._httpClient.get<any>(this.Get5KGAppuCampaignByAdminCountSummary_Url + "/" + type, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  // To Get 5 KG Appu Campaign By Pincode
  Get5KGAppuCampaignByPincode(): Observable<any> {
    return this._httpClient.get<any>(this.Get5KGAppuCampaignByPincode_Url, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  // To Update 5 KG Appu Campaign By Pincode
  Update5KGAppuCampaignByPincode(Id: number, Pincode: string, IsCallNotAttended: string = ""): Observable<any> {
    return this._httpClient.get<any>(this.Update5KGAppuCampaignByPincode_Url + "/" + Id + "/" + Pincode + "/" + IsCallNotAttended, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  // To Get 5 KG Appu Campaign Enquiry Status
  Get5KGAppuEnquiryStatus(): Observable<any> {
    return this._httpClient.get<any>(this.Get5KGAppuEnquiryStatus_Url,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  // To Get 5 KG Appu Campaign Enquiry Action Taken
  Get5KGAppuEnquiryActionTaken(): Observable<any> {
    return this._httpClient.get<any>(this.Get5KGAppuEnquiryActionTaken_Url,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  // To Get 5KG Appu Enquiry Campaign By Distributor
  Get5KGAppuEnquiryCampaignByDistributor(distributorId: number, FromDate: any, ToDate: any): Observable<any> {
    return this._httpClient.get<any>(this.Get5KGAppuEnquiryCampaignByDistributor_Url + "/" + distributorId + "/" + FromDate + "/" + ToDate, { observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  // Update 5KG Appu Enquiry Status Distributor
  Update5KGAppuEnquiryStatusDistributor(pkId: number, distributorId: number, EnquiryStatusName: string, EnquiryStatusFeedback: string): Observable<any> {
    return this._httpClient.get<any>(this.Update5KGAppuEnquiryStatusDistributor_Url + "/" + pkId + "/" + distributorId + "/" + EnquiryStatusName + "/" + EnquiryStatusFeedback, { observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  // Update 5KG Appu Enquiry Action Distributor
  Update5KGAppuEnquiryActionDistributor(pkId: number, distributorId: number, ActionTakenName: string, EnquiryActionTakenFeedback: string): Observable<any> {
    return this._httpClient.get<any>(this.Update5KGAppuEnquiryActionDistributor_Url + "/" + pkId + "/" + distributorId + "/" + ActionTakenName + "/" + EnquiryActionTakenFeedback, { observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  // To Get 5 KG Appu Enquiry Campaign By Distributor Count
  Get5KGAppuEnquiryCampaignByDistributorCount(distributorId: number): Observable<any> {
    return this._httpClient.get<any>(this.Get5KGAppuEnquiryCampaignByDistributorCount_Url + "/" + distributorId, { observe: 'response' })
               .pipe(map(result => {
                  // login successful if there's a jwt token in the response
                  if (result) {
                  }
                  return result.body;
                }), tap(() => { // Add Thid Tap to all services
                },  error => {
                    console.log(error.status);
                    if (error.status === '401') {
                    }
                }));
  }

  // To Get 5KG Appu Enquiry Campaign By Distributor Count Summary
  Get5KGAppuEnquiryCampaignByDistributorCountSummary(distributorId: number, type: string): Observable<any> {
    return this._httpClient.get<any>(this.Get5KGAppuEnquiryCampaignByDistributorCountSummary_Url + "/" + distributorId + "/" + type, { observe: 'response' })
               .pipe(map(result => {
                  // login successful if there's a jwt token in the response
                  if (result) {
                  }
                  return result.body;
                }), tap(() => { // Add Thid Tap to all services
                },  error => {
                    console.log(error.status);
                    if (error.status === '401') {
                    }
                }));
  }

}