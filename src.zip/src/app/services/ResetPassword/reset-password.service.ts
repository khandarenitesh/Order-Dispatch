import { Injectable } from '@angular/core';

import { GlobalVariable } from '../common.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ResetPasswordService {

  private API = GlobalVariable.BASE_API_URL;
  private resetUserPasswordAPI = `${this.API}Login/ResetUserPassword/`;

  constructor(private http: HttpClient) { }


  ResetUserPasswordSrv(Dtls: any): Observable<any> {
    let apiUrl1 = this.resetUserPasswordAPI;
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(apiUrl1, Dtls)
    .pipe(
      tap(data => ('saveDistConnTypePriceDtls')),
      catchError(this.handleError('saveDistConnTypePriceDtls', []))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
