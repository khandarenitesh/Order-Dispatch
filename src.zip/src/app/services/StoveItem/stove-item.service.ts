import { Injectable } from '@angular/core';

import { GlobalVariable } from '../common.service';

import { HttpClient, HttpHeaders, HttpRequest, HttpEvent } from '@angular/common/http';
import { tap, catchError, map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class StoveItemService {

  private API = GlobalVariable.BASE_API_URL;
  private getStoveItemDetailsAPI = `${this.API}Masters/GetStoveItemMst/`;
  private getStoveTypeAPI = `${this.API}Masters/GetStoveTypeMst/`;
  private saveStoveItemDetailsAPI = `${this.API}Masters/AddEditStoveItemDetails/`;
  constructor(private http: HttpClient) { }
  getStoveItemDetails(Dtls: any): Observable<any> {
    let apiUrl1 = this.getStoveItemDetailsAPI;
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(apiUrl1, Dtls)
      .pipe(
        tap(data => ('getStoveItemDetails')),
        catchError(this.handleError('getStoveItemDetails', []))
      );
  }

  getStoveTypeDetails(Dtls: any): Observable<any> {
    let apiUrl1 = this.getStoveTypeAPI;
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(apiUrl1, Dtls)
      .pipe(
        tap(data => ('getStoveItemDetails')),
        catchError(this.handleError('getStoveItemDetails', []))
      );
  }
  saveStoveItemDetails(Dtls: any): Observable<any> {
    let apiUrl1 = this.saveStoveItemDetailsAPI;
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(apiUrl1, Dtls)
      .pipe(
        tap(data => ('saveStoveItemDetails')),
        catchError(this.handleError('saveStoveItemDetails', []))
      );
  }


  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
