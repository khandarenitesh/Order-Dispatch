import { Injectable } from '@angular/core';
import { GlobalVariable } from '../common.service';
import { HttpClient} from '@angular/common/http';
import { tap, map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TokenDistributorService {
  private API = GlobalVariable.BASE_API_URL;
  private GetSAList_Url = `${this.API}Token_Distributor/GetSA`;
  private GetDistributors_Url = `${this.API}Token_Distributor/GetWinnerDistributors`;
  private GetWinner_Url = `${this.API}Token_Distributor/GetTokens`;
  private GetActiveFlgas_Url = `${this.API}Token_Distributor/GetActiveFlags`;
  constructor(private _httpClient: HttpClient) { }

  GetSA_service(): Observable<any> {
    return this._httpClient.post<any>(this.GetSAList_Url,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
           // this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

  GetWinnerDistributors_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.GetDistributors_Url, DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
            //this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

  GetWinner_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.GetWinner_Url, DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
            //this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

  GetActiveFlags_service(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.GetActiveFlgas_Url, DataModel,{ observe: 'response' })
    .pipe(
      map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }),
      tap(data => { // Add Thid Tap to all services
        // this._JWTAccountService.ReadStatusCode(data.status)
      },
        error => {
          console.log(error.status);
          if (error.status === '401') {
            //this._JWTAccountService.RefreshToken();
          }
        }
      )
    );
  }

}




