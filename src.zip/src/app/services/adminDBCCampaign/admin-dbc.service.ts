import { Injectable } from '@angular/core';
import { GlobalVariable } from '../common.service';
import { HttpClient} from '@angular/common/http';
import { tap, map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminDbcService {

 
  private API = GlobalVariable.BASE_API_URL;
  private GetAdminDbcInformation_Url = `${this.API}Distributor/GetAdminDbcInformation`;
  private GetSAByRoCode_Url = `${this.API}Distributor/GetSAbyRO`;
  private GetUserCount_Url = `${this.API}Distributor/GetConsumerCtnForAdminDetails`;
  constructor(private _httpClient: HttpClient) { }

  GetAdminDbcInformation(Id: string, flag: string): Observable<any> {
    return this._httpClient.get<any>(this.GetAdminDbcInformation_Url + "/" + Id + "/" + flag, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }


  GetSAByRoCode(Id: any): Observable<any> {
    return this._httpClient.get<any>(this.GetSAByRoCode_Url + "/" + Id, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  GetUserCount(DataModel: any): Observable<any> {
    return this._httpClient.post<any>(this.GetUserCount_Url, DataModel, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

}
