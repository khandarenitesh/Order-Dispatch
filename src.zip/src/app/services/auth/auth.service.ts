import { ToastrModule, ToastrService } from 'ngx-toastr';
import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, tap, map, timeout } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';


import { UserModel } from '../../models/Auth/signin.model';

import { AppState } from '../../core/reducers';
// Auth
import { AuthNoticeService, AuthService, Login } from '../../core/auth';

import { currentUser, Logout, User } from '../../core/auth';

import { PagesRoutingModule } from '../../views/themes/default/pages-routing.module';
import { GlobalVariable } from '../common.service';

@Injectable({
  providedIn: 'root',
})
export class OMCAuthService {
  UserData: UserModel;
  private API_ENDPOINT = GlobalVariable.BASE_API_URL + 'Login/UserLogin';
  private API_ENDPOINTAnotherWeb = GlobalVariable.BASE_API_URL + 'Login/UserLoginAnotherWeb';
  private SendEmailAPI = GlobalVariable.BASE_API_URL + 'Customer/SendResetPasswordEmail';


  constructor(private _HttpClient: HttpClient, private store: Store<AppState>, private router: Router, private toastr: ToastrService) { }

  public isAuthenticated(): boolean {
    const UserData = sessionStorage.getItem('LoginData');
    if (UserData && UserData.length > 0) {
      return true;
    }
    return false;
  }

  //Reset password new cahanges
  SendEmail(DistributorId: any): Observable<any> {
    return this._HttpClient.get<any>(this.SendEmailAPI + "/" + DistributorId, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }), tap(() => { // Add Thid Tap to all services
      }, error => {
        console.log(error.status);
        if (error.status === '401') {
        }
      }));
  }

  SendresetPasswordEmail(DistributorId: any) {
    if (DistributorId !== undefined && DistributorId !== null && DistributorId !== '') {
      this.SendEmail(DistributorId).subscribe(data => {
        if (data.Status === 'Success') {
          // this.toastr.success('Email Sent Successfully.', 'Email reset Password', { timeOut: 2000 });
        } else {
          this.toastr.error('Error in Email sending.', 'Email reset Password', { timeOut: 2000 });
        }
      });
    }
  }

  public CheckLogin(user, password) {
    return new Promise(resolve => {
      this.postSignin(user, password)
        .subscribe(data => {
          let resSTR = JSON.stringify(data);
          let resJSON = JSON.parse(resSTR);
          if (resSTR.length > 2) {
            if (resJSON.LoginStatus === 'Success') {
              if (sessionStorage.getItem('LoginData') !== null || sessionStorage.getItem('LoginData') !== undefined) {
                sessionStorage.removeItem('LoginData');
              }
              sessionStorage.setItem('LoginData', JSON.stringify(data.userDetails));
              this.store.dispatch(new Login({ authToken: 'access-token-8f3ae836da744329a6f93bf20594b5cc' }));

              // if (data.userDetails.RoleId === 3 && data.userDetails.IsFillMandatorydtls === 'false') {

              //   this.router.navigate(['/default/MandatoryStepper']).then(() => {
              //     this.toastr.success('Login Successfully','NC Enquiry', {timeOut: 2000});
              //   });
              // }
              if (data.userDetails.ActiveStatus !== undefined && data.userDetails.ActiveStatus === 'Y') {
                resJSON.LoginStatus = 'Success';
                if (data.userDetails.RoleId === 3 && data.userDetails.IsFillMandatorydtls === 'false') {
                  if (data.userDetails.ARBLive == 'Y') {
                    this.router.navigate(['/default/ArbDistributorCampaign']).then(() => {
                      this.toastr.success('Login Successfully', 'NC Enquiry', { timeOut: 2000 });
                    });
                  }
                  else if (data.userDetails.SBCLive == 'Y') {
                    this.router.navigate(['/default/dbcCampaign']).then(() => {
                      this.toastr.success('Login Successfully', 'NC Enquiry', { timeOut: 2000 });
                    });
                  }
                  else if (data.userDetails.VASLive == 'Y') {
                    this.router.navigate(['/default/RefillPendingBooking']).then(() => {
                      this.toastr.success('Login Successfully', 'NC Enquiry', { timeOut: 2000 });
                    });
                  }
                  else if (data.userDetails.SurakshaLive == 'Y') {
                    this.router.navigate(['/default/surakshaCampaign']).then(() => {
                      this.toastr.success('Login Successfully', 'NC Enquiry', { timeOut: 2000 });
                    });
                  }
                  else {
                    this.router.navigate(['']).then(() => {
                      this.toastr.success('Login Successfully', 'NC Enquiry', { timeOut: 2000 });
                    });
                  }
                }
                else if (data.userDetails.RoleId === 4) {
                  this.router.navigate(['/default/getUnassignConsumer']).then(() => {
                    this.toastr.success('Login Successfully', 'NC Enquiry', { timeOut: 2000 });
                  });
                } else {
                  this.router.navigate(['']).then(() => {
                    this.toastr.success('Login Successfully', 'NC Enquiry', { timeOut: 2000 });
                  });
                }
              } else {
                if (data.userDetails.refNo !== undefined && data.userDetails.refNo !== null && data.userDetails.refNo !== '')
                  this.SendresetPasswordEmail(data.userDetails.refNo);
                resJSON.LoginStatus = 'EmailSuccess';
              }
            } else {
              // if(data.userDetails.refNo !== undefined && data.userDetails.refNo !== null && data.userDetails.refNo !== '')
              // this.SendresetPasswordEmail(data.userDetails.refNo);
              this.toastr.error(resJSON.LoginStatus);
              // result = false;
            }

            resolve(resJSON.LoginStatus);
          } else {
            this.toastr.error('username or password is incorrect', 'NC Enquiry', { timeOut: 1000 });
            resolve(null);
          }
        },
          (error) => {
            this.toastr.error('server not responding', 'NC Enquiry', { timeOut: 1000 });
            // result = false;
          });
    });
  }

  public CheckLoginAnotherWeb(user, password) {
    return new Promise(resolve => {
      this.postSigninAnotherWeb(user, password)
        .subscribe(data => {
          let resSTR = JSON.stringify(data);
          let resJSON = JSON.parse(resSTR);
          if (resSTR.length > 2) {
            if (resJSON.LoginStatus === 'Success') {
              if (sessionStorage.getItem('LoginData') !== null || sessionStorage.getItem('LoginData') !== undefined) {
                sessionStorage.removeItem('LoginData');
              }
              sessionStorage.setItem('LoginData', JSON.stringify(data.userDetails));
              this.store.dispatch(new Login({ authToken: 'access-token-8f3ae836da744329a6f93bf20594b5cc' }));

              if (data.userDetails.RoleId === 3 && data.userDetails.IsFillMandatorydtls === 'false') {

                this.router.navigate(['/default/MandatoryStepper']).then(() => {
                  this.toastr.success('Login Successfully', 'NC Enquiry', { timeOut: 2000 });
                });
              } else if (data.userDetails.RoleId === 4) {
                this.router.navigate(['/default/getUnassignConsumer']).then(() => {
                  this.toastr.success('Login Successfully', 'NC Enquiry', { timeOut: 2000 });
                });
              } else {
                this.router.navigate(['']).then(() => {
                  this.toastr.success('Login Successfully', 'NC Enquiry', { timeOut: 2000 });
                });
              }
            } else {
              this.toastr.error(resJSON.LoginStatus);
              // result = false;
            }

            resolve(resJSON.LoginStatus);
          } else {
            this.toastr.error('username or password is incorrect', 'NC Enquiry', { timeOut: 1000 });
            resolve(null);
          }
        },
          (error) => {
            console.error(error);
            this.toastr.error('server not responding', 'NC Enquiry', { timeOut: 1000 });
            // result = false;
          });
    });
  }


  public login(user, password) {
    let result: string = null;
    if (user !== null && password !== null) {
      this.postSignin(user, password)
        .subscribe(data => {
          let resSTR = JSON.stringify(data);
          let resJSON = JSON.parse(resSTR);
          // let datastr = resJSON._body;
          // this.UserData = JSON.parse(datastr);
          if (resSTR.length > 2) {
            if (resJSON.LoginStatus === 'Success') {
              if (sessionStorage.getItem('LoginData') !== null || sessionStorage.getItem('LoginData') !== undefined) {
                sessionStorage.removeItem('LoginData');
              }
              sessionStorage.setItem('LoginData', JSON.stringify(data.userDetails));
              this.store.dispatch(new Login({ authToken: 'access-token-8f3ae836da744329a6f93bf20594b5cc' }));
              this.router.navigate(['']).then(() => {
                this.toastr.success('Login Successfully', 'NC Enquiry', { timeOut: 1000 });
              });
            } else {
              this.toastr.error('Login Error : 1 ', 'NC Enquiry', { timeOut: 1000 });
              // result = false;
            }
            return resJSON.LoginStatus;
          } else {
            this.toastr.error('username or password is incorrect', 'NC Enquiry', { timeOut: 1000 });
            // result = false;
          }
        },
          (error) => {
            console.error(error);
            this.toastr.error('server not responding', 'NC Enquiry', { timeOut: 1000 });
            // result = false;
          });
    }
  }

  routeListRoleBased() {
    if (sessionStorage.getItem('LoginData') !== null || sessionStorage.getItem('LoginData') !== undefined) {
      let user = new UserModel();
      user = JSON.parse(sessionStorage.getItem('LoginData'));
      // (user);
    } else {
      console.error('session null');
      this.logout();
    }
  }

  async logout() {
    await sessionStorage.removeItem('LoginData');
    await sessionStorage.clear();
    await this.store.dispatch(new Logout());
    await this.router.navigate(['auth/login']);
  }

  postSigninAnotherWeb(username, password): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    let Body = { 'UserName': username, 'Password': password };
    return this._HttpClient.post<any>(this.API_ENDPOINTAnotherWeb, Body, httpOptions)
      .pipe(
        tap(data => ('postSignin')),
        catchError(this.handleError)
      );

  }

  postSignin(username, password): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    let Body = { 'UserName': username, 'Password': password };
    return this._HttpClient.post<any>(this.API_ENDPOINT, Body, httpOptions)
      .pipe(
        tap(data => ('postSignin')),
        catchError(this.handleError)
      );

  }
  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    // window.alert(errorMessage);
    return throwError(errorMessage);
  }

  public signUp(postData) {

  }

  // public async logOut() {
  //   await sessionStorage.removeItem('LoginData');
  //   await sessionStorage.clear();
  //   return true;
  // }


}
