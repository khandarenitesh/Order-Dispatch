import { Injectable } from '@angular/core';
// State
import { AppState } from '../../core/reducers';
import { currentUser, Logout, User } from '../../core/auth';
import { Router } from '@angular/router';
import { UserModel } from '../../models/Auth/signin.model';
// NGRX
import { select, Store } from '@ngrx/store';
@Injectable()
  export class RoutesByRoles {
	private store: Store<AppState>;
	constructor(private router: Router) {
		if (sessionStorage.getItem('LoginData') !== null || sessionStorage.getItem('LoginData') !== undefined) {
			this.routeListRoleBased();
		} else {
			// this.logout();
		}
	}

	routeListRoleBased() {
		let user = new UserModel();
		user = JSON.parse(sessionStorage.getItem('LoginData'))
		(user);
	}

	logout() {
		// this.store.dispatch(new Logout());
		// this.router.navigate(['auth/login']);
	}
  }
