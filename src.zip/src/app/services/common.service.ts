import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor() { }
}
export const GlobalVersion = Object.freeze({
  Version: '01'
 // BASE_API_URL: 'http://localhost:57300/'
});

export const GlobalVariable = Object.freeze({
 // BASE_API_URL: 'http://13.250.137.238/NCEnquiryAPITEST/'
 // BASE_API_URL: 'http://13.250.137.238/NCEnquiryAPI/'
 BASE_API_URL: 'http://localhost:57800/'
  // BASE_API_URL: 'https://aadyaminfotech.com/NCEWhatsappAPI/'
});
