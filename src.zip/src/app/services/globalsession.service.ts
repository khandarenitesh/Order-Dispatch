import { Injectable } from '@angular/core';
import { UserModel } from '../models/Auth/signin.model';
import { Router } from '@angular/router';
import { DistributorConnTypePrice } from '../models/DistributorConn/distributor-conn-type-price.model';
@Injectable({
  providedIn: 'root',
})
export class GetSessionService {
  _ConnTypeLst: DistributorConnTypePrice;

  finalStepper: boolean;
  constructor(private router: Router) { }

  GetSessionData(): any {
    if (sessionStorage.getItem('LoginData') !== null && sessionStorage.getItem('LoginData') !== undefined) {
      let user = JSON.parse(sessionStorage.getItem('LoginData'));
      if (user !== null && user.RoleId > 0) {
        return user;
      } else {
        this.router.navigateByUrl('/auth/login');
      }
    } else {
      this.router.navigateByUrl('/auth/login');
    }
  }
  GetLoginDetails() {
    let item = JSON.parse(sessionStorage.getItem('LoginData'));
    if (item !== null && item.RoleId > 0) {
      return item.refNo;
    } else {
      this.router.navigateByUrl('/auth/login');
    }

	}
}
