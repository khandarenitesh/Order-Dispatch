import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivateCampaignComponent } from './activate-campaign.component';

describe('ActivateCampaignComponent', () => {
  let component: ActivateCampaignComponent;
  let fixture: ComponentFixture<ActivateCampaignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivateCampaignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivateCampaignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
