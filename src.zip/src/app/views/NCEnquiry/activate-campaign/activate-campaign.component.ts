import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';

import { FormControl } from '@angular/forms';

// Import Angular Material Added
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';

// Models
import {  DistributorModel, DistributorFlagsModel } from '../../../models/ActivateCampaign/activate-campaign.model';

// Services
import { GetSessionService } from '../../../services/globalsession.service';
import { ToastrService } from 'ngx-toastr';
import { Subscription, Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { ActivateCampaignService } from '../../../services/ActivateCampaign/activate-campaign.service';

@Component({
  selector: 'kt-activate-campaign',
  templateUrl: './activate-campaign.component.html',
  styleUrls: ['./activate-campaign.component.scss']
})
export class ActivateCampaignComponent implements OnInit {
  displayed = ['SrNo', 'JDEDistributorCode', 'DistributorName', 'SBCCount', 'SurakshaCount', 'ARBCount', 'VASActiveCount'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public DataSource = new MatTableDataSource<any>();
  SelectedSA: any;
  isLoading: boolean = false;
  SAList = [];
  postModal: any;
  UserId: number = 0;
  IsFlag: boolean = true;
  private unsubscribe: Subscription[] = [];
  DDLDistributorList: DistributorModel[];
  filteredSelectDistributorOptions: Observable<DistributorModel[]>;
  myControlSelectDistributors = new FormControl();
  DistributorFlags: DistributorFlagsModel[] = [];

  constructor(private _activateCampaign: ActivateCampaignService, private toastr: ToastrService, private chRef: ChangeDetectorRef, private getSession: GetSessionService) { }

  ngOnInit() {
    let user = JSON.parse(sessionStorage.getItem('LoginData'));
    this.UserId = user.UserId;
    this.postModal = {
      'Id': this.GetLoginDetails()
    };
    this.GetSAList(this.postModal);
    this.IsFlag = false; // Pageload Save button disabled
  }

  GetLoginDetails() {
    let item = this.getSession.GetSessionData();
    return item.refNo;
  }

  // Get SA List
  GetSAList(postModel) {
    this.unsubscribe.push(this._activateCampaign.GetSAByRoCode(postModel.Id)
        .subscribe((data) => {
          this.SAList = data;
          if (!this.chRef['destroyed']) {
            this.chRef.detectChanges();
          }
        }, (error) => {
          console.error(error);
          this.chRef.detectChanges();
        }));
  }

  // Change Distributor when SA Code selected
  onChangeDistributor() {
    this.isLoading = true;
    this._activateCampaign.DistriCampRightsList(this.SelectedSA)
        .subscribe((data: any) => {
          if (data.length === 0) {
            this.DDLDistributorList = [];
            this.DistributorFlags = [];
            this.DataSource.data = [];
            this.IsFlag = false;
          } else {
            this.IsFlag = true;
            this.DDLDistributorList = data;
            this.DistributorFlags = data;
            this.DataSource.data = data;
            this.DataSource.paginator = this.paginator;
            this.DataSource.sort = this.sort;
            this.filteredSelectDistributorOptions = this.myControlSelectDistributors.valueChanges
              .pipe(startWith<string | DistributorModel>(''),
                map(value => typeof value === 'string' ? value : value !== null ? value.DistributorName : null),
                map(DistributorName => DistributorName ? this.filterDistributor(DistributorName) : this.DDLDistributorList.slice()));
          }
          this.isLoading = false;
          this.chRef.detectChanges();
      });
  }

  // filter - Distributor By Name
  private filterDistributor(name: string): DistributorModel[] {
    const filterDistributorValue = name.toLowerCase();
    return this.DDLDistributorList.filter((option) => option.DistributorName.toLowerCase().includes(filterDistributorValue) ||
      option.JDEDistributorCode.toLocaleLowerCase().includes(filterDistributorValue));
  }

  // SBC, Suraksha, ARB & VAS
  checkUncheckAll(evt, flag: string) {
    if (this.DataSource.data.length > 0) {
      for (var i = 0; i < this.DataSource.data.length; i++) {
        if (flag === "SBCLive") {
          if (evt.target.checked === true) {
            this.DataSource.data[i].SBCLive = "Y";
          } else {
            this.DataSource.data[i].SBCLive = "N";
          }
          this.DistributorFlags[i].SBCLive = this.DataSource.data[i].SBCLive;
        } else if (flag === "SurakshaLive") {
          if (evt.target.checked === true) {
            this.DataSource.data[i].SurakshaLive = "Y";
          } else {
            this.DataSource.data[i].SurakshaLive = "N";
          }
          this.DistributorFlags[i].SurakshaLive = this.DataSource.data[i].SurakshaLive;
        } else if (flag === "ARBLive") {
          if (evt.target.checked === true) {
            this.DataSource.data[i].ARBLive = "Y";
          } else {
            this.DataSource.data[i].ARBLive = "N";
          }
          this.DistributorFlags[i].ARBLive = this.DataSource.data[i].ARBLive;
        } else {
          if (evt.target.checked === true) {
            this.DataSource.data[i].VASLive = "Y";
          } else {
            this.DataSource.data[i].VASLive = "N";
          }
          this.DistributorFlags[i].VASLive = this.DataSource.data[i].VASLive;
        }
      }
      this.chRef.detectChanges();
    }
  }

  // Check Box Code 
  getCheckboxesData(flag: string, i: number) {
    if (flag == 'SBCLive') {
      if (this.DistributorFlags[i].SBCLive == 'Y') {
        this.DistributorFlags[i].SBCLive = 'N';  // DistributorFlags[i] Array of Json -> i index
      } else {
        this.DistributorFlags[i].SBCLive = 'Y';
      }
    } else if (flag == 'SurakshaLive') {
      if (this.DistributorFlags[i].SurakshaLive == 'Y') {
        this.DistributorFlags[i].SurakshaLive = 'N';
      } else {
        this.DistributorFlags[i].SurakshaLive = 'Y';
      }
    } else if (flag == 'ARBLive') {
      if (this.DistributorFlags[i].ARBLive == 'Y') {
        this.DistributorFlags[i].ARBLive = 'N';
      } else {
        this.DistributorFlags[i].ARBLive = 'Y';
      }
    } else if (flag == 'VASLive') {
      if (this.DistributorFlags[i].VASLive == 'Y') {
        this.DistributorFlags[i].VASLive = 'N';
      } else {
        this.DistributorFlags[i].VASLive = 'Y';
      }
    }
  }

  // Save Activate Campaign
  SaveActiveCampaign() {
    this.isLoading = true;
    let model = {
      'SACode': this.SelectedSA,
      'AllFlag': this.DistributorFlags
    }
    this.unsubscribe.push(this._activateCampaign.GetSaveActivateCampaign(model)
        .subscribe((data) => {
          if (data > 0) {
            this.toastr.success('Record Added Successfully!!!');
            this.SelectedSA = null;
            this.DataSource.data = [];
            this.IsFlag = false; // Pageload Save button disabled
            (<HTMLInputElement>document.getElementById('SBC')).checked = false;
            (<HTMLInputElement>document.getElementById('Suraksha')).checked = false;
            (<HTMLInputElement>document.getElementById('ARB')).checked = false;
            (<HTMLInputElement>document.getElementById('VAS')).checked = false;
          } else {
            this.toastr.error('Failed');
          }
          this.isLoading = false;
          this.chRef.detectChanges();
        }, () => {
          this.toastr.error('Error');
          this.isLoading = false;
          this.chRef.detectChanges();
        }));
  }

}