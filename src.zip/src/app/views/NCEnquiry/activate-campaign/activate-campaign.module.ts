import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../../../app/core/auth';
import { NgModule } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { GetSessionService } from '../../../services/globalsession.service';
import { PartialsModule } from '../../partials/partials.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';
import { CommonModule } from '@angular/common';
import {
  MatButtonModule, MatInputModule, MatTableModule, MatProgressSpinnerModule, MatAutocompleteModule,
  MatRippleModule, MatFormFieldModule, MatSelectModule, MatCheckboxModule, MatIconModule, MatPaginatorModule, MatSortModule, MatRadioModule, MatTooltipModule
} from '@angular/material';
import { ActivateCampaignComponent } from './activate-campaign.component';
import { SendSampleMessagesComponent } from './send-sample-messages/send-sample-messages.component';

const UpdateActivateCampaignRoutes: Routes = [
  {
    path: '',
    children: [
      { path: 'ActivateCampaign', component: ActivateCampaignComponent, canActivate: [AuthGuard], data: { roles: ['1'] } },
	  { path: 'SendSampleMessages', component: SendSampleMessagesComponent, canActivate: [AuthGuard], data: { roles: ['1'] } }
    ]

  }
]

const modules = [
  MatButtonModule, MatFormFieldModule, MatInputModule, MatRippleModule, MatTableModule,
  MatAutocompleteModule, MatSelectModule, MatProgressSpinnerModule, MatSortModule,
  MatPaginatorModule, MatIconModule, MatCheckboxModule, MatRadioModule
];

@NgModule({
  declarations: [ActivateCampaignComponent, SendSampleMessagesComponent],
  providers: [GetSessionService, ToastrService],
  imports: [
    modules,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    PartialsModule,
    NgbModule,
    MatTooltipModule,
    DataTablesModule,
    RouterModule.forChild(UpdateActivateCampaignRoutes)
  ],
  exports: [RouterModule]
})
export class ActivateCampaignModule { }
