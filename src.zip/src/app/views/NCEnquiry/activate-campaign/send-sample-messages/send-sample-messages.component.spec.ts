import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendSampleMessagesComponent } from './send-sample-messages.component';

describe('SendSampleMessagesComponent', () => {
  let component: SendSampleMessagesComponent;
  let fixture: ComponentFixture<SendSampleMessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendSampleMessagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendSampleMessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
