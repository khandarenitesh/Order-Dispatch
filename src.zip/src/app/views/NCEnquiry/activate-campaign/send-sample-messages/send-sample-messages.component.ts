import { Component, OnInit, ChangeDetectorRef, ViewChild, AfterViewInit } from '@angular/core';

import { NgForm, FormControl } from '@angular/forms';

// Angular Material Added
import { MatSort, MatTableDataSource, MatPaginator } from '@angular/material';

// Models
import { TemplateModel } from '../../../../models/ConfigurationDetails/configuration-details.model';
import { DistributorModel } from '../../../../models/ActivateCampaign/activate-campaign.model';

// Services
import { ActivateCampaignService } from '../../../../services/ActivateCampaign/activate-campaign.service';
import { UpdateDistContactService } from '../../../../services/UpdateDistContact/update-dist-contact.service';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';

@Component({
	selector: 'kt-send-sample-messages',
	templateUrl: './send-sample-messages.component.html',
	styleUrls: ['./send-sample-messages.component.scss']
})
export class SendSampleMessagesComponent implements OnInit, AfterViewInit {
	isLoading: boolean = false;
	Selectistributor: any;
	ConsumerNo: any;
	ConsumerName: any;
	SelectTemplate: any;
	MobileNo: any;
	postDistributorModal: any;
	DDLTemplateList: TemplateModel[];
	DDLDistributorList: DistributorModel[];
	filteredDistributorOptions: Observable<DistributorModel[]>;
	myControlDistributor = new FormControl();
	searchModel: any;
	@ViewChild("sensmplMsgForm") sensmplMsgForm: NgForm;
	displayedColumnsForApi = ['SrNo','TemplateName','DistributorName','ConsumerNo','ConsumerName','MobileNo','CurrentStatus','Action'];
	@ViewChild('paginator') paginator: MatPaginator;
	@ViewChild('Sort') Sort: MatSort;
	public DataSource = new MatTableDataSource<any>();

	constructor(private chRef: ChangeDetectorRef, private toastr: ToastrService, private _activateCampaign: ActivateCampaignService, private updatedistcontactservice: UpdateDistContactService) { }

	ngOnInit() {
		this.GetDDLDistributorList();
		this.BindAllDDLTemplateList();
		this.GetSendSampleMessageList();
	}

	// GET DISTRIBUTOR LIST FOR SEARCH BOX
	GetDDLDistributorList() {
		this.isLoading = true;
		this.postDistributorModal = {
			'DistributorId': 0
		};
		this.updatedistcontactservice.GetDistDetails(this.postDistributorModal)
			.subscribe(async (data: any) => {
				this.DDLDistributorList = await data.DistributorList;
				this.DDLDistributorList = this.DDLDistributorList.sort((a: any, b: any) => a.DistributorName.localeCompare(b.DistributorName));
				this.filteredDistributorOptions = this.myControlDistributor.valueChanges
					.pipe(startWith<string | DistributorModel>(''),
						map(value => typeof value === 'string' ? value : value !== null ? value.DistributorName : null),
						map(DistributorName => DistributorName ? this.filterDistributor(DistributorName) : this.DDLDistributorList.slice()));
				this.isLoading = false;
				this.chRef.detectChanges();
			}, () => {
			});
	}

	// FILTER BY DISTRIBUTOR NAME OR ID
	private filterDistributor(name: string): DistributorModel[] {
		const filterDistributorValue = name.toLowerCase();
		return this.DDLDistributorList.filter((option) => option.DistributorName.toLowerCase().includes(filterDistributorValue) ||
			option.JDEDistributorCode.toLocaleLowerCase().includes(filterDistributorValue));
	}
	displayFnDistributor(user?: DistributorModel): string | undefined {
		return user ? user.DistributorName + "( " + user.JDEDistributorCode + " ) " : undefined;
	}

	// Get Template List
	BindAllDDLTemplateList() {
		this._activateCampaign.GetTemplateDetails("0")
			.subscribe(async (data: any) => {
				this.DDLTemplateList = await data;
			}, (error: any) => {
				console.log(error);
			});
		this.chRef.detectChanges();
	}

	// Get Send Sample WhatsApp Message List
	GetSendSampleMessageList() {
		this.isLoading = true;
		this._activateCampaign.GetSendSampleMessageList()
			.subscribe(async (data: any) => {
			if (data.length > 0) {
				this.DataSource.data = await data;
				this.DataSource.paginator = this.paginator;
				this.DataSource.sort = this.Sort;
			} else {
				this.DataSource.data = [];
			}
			this.isLoading = false;
			this.chRef.detectChanges();
		});
	}

	//Save Send sample message data
	SaveSendMsgData() {
		this.isLoading = true;
		if (this.Selectistributor == null || this.Selectistributor == undefined
			|| this.ConsumerNo == null || this.ConsumerNo == undefined || this.ConsumerName == null
			|| this.ConsumerName == undefined || this.MobileNo == null || this.MobileNo == undefined
			|| this.SelectTemplate == null || this.SelectTemplate == undefined) {
			this.toastr.warning('Please Fill Data!', 'Send Sample Message');
			this.isLoading = false;
			return;
		}
		let model = {
			'pkId': 0,
			'DistributorId': this.Selectistributor.DistributorId,
			'DistributorCode': this.Selectistributor.JDEDistributorCode,
			'ConsumerNo': this.ConsumerNo,
			'ConsumerName': this.ConsumerName,
			'MobileNo': this.MobileNo,
			'TemplateId': this.SelectTemplate,
			'CurrentStatus': 'QUEUED',
			'Action': 'ADD'
		}
		this._activateCampaign.SaveSendSamplemessages(model).subscribe((data: any) => {
			if (data > 0) {
				this.toastr.success('Data Saved Successfully!', 'Send Sample Message');
				this.GetSendSampleMessageList();
				this.ClearFormData();
			} else if (data == -1) {
				this.toastr.warning('Consumer No already exist!');
			}
		},(error: any) => {
			console.log(error);
			this.toastr.warning('Failed!');
		});
		this.isLoading = false;
		this.chRef.detectChanges();
	}

	// EVENT FOR MOBILE NUMBER VALIDATION ONLY DIGIT ALLOWED
	numberOnly(event): boolean {
		const charCode = (event.which) ? event.which : event.keyCode;
		if (charCode > 31 && (charCode < 48 || charCode > 57)) {
			return false;
		}
		return true;
	}

	// Clear Form Data
	ClearFormData() {
		this.myControlDistributor.reset();
		this.sensmplMsgForm.reset();
		this.chRef.detectChanges();
	}

	// Send sample Message
	SendSampalMessage(row: any) {
		let model = {
			'pkId': row.pkId,
			'DistributorId': row.DistributorId,
			'DistributorCode': '',
			'ConsumerNo': '',
			'ConsumerName': '',
			'MobileNo': row.MobileNo,
			'TemplateId': row.TemplateId,
			'CurrentStatus': 'In-Progress',
			'Action': 'EDIT'
		}
		this._activateCampaign.SendSampleMessage(model)
			.subscribe(() => {
			this.GetSendSampleMessageList();
			}, (error: any) => {
				console.log(error);
				this.chRef.detectChanges();
			});
	}

	// Search - Apply Filter
	applyFilter() {
		this.isLoading = true;
		this.searchModel = this.searchModel.toLowerCase(); // Datasource defaults to lowercase matches
		this.DataSource.filter = this.searchModel;
		this.isLoading = false;
		this.chRef.detectChanges(); // IMMEDIATE ACTION FIRED
	}

	// Set side menu close
	ngAfterViewInit() {
		this._activateCampaign.Toggler = new KTToggle('kt_aside_toggler', this._activateCampaign.toggleOptions);
		this._activateCampaign.DivToggleWidth = '100%';
		this._activateCampaign.IsModelOn = false;
		this._activateCampaign.displayValue = false;
		this._activateCampaign.Toggler.toggleOn();
		$('#kt_aside_close_btn').click();
		setTimeout(() => {
			this._activateCampaign.OpenToggle = true;
			this._activateCampaign.Toggler.toggleOn();
			$('#kt_aside_close_btn').click();
		}, 500);
	}

}
