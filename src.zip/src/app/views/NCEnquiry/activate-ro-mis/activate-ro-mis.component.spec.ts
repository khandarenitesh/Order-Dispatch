import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivateRoMisComponent } from './activate-ro-mis.component';

describe('ActivateRoMisComponent', () => {
  let component: ActivateRoMisComponent;
  let fixture: ComponentFixture<ActivateRoMisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivateRoMisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivateRoMisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
