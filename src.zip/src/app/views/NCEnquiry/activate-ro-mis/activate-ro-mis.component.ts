import { Component, OnInit, ChangeDetectorRef, ViewChild, AfterViewInit } from '@angular/core';

// Import Angular Material Added
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';

// Models
import { ActivateMISFlagsModel } from '../../../models/ActivateCampaign/activate-campaign.model';

// Services
import { GetSessionService } from '../../../services/globalsession.service';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { ActivateCampaignService } from '../../../services/ActivateCampaign/activate-campaign.service';

@Component({
  selector: 'kt-activate-ro-mis',
  templateUrl: './activate-ro-mis.component.html',
  styleUrls: ['./activate-ro-mis.component.scss']
})
export class ActivateRoMisComponent implements OnInit, AfterViewInit {
  displayed = ['SrNo', 'ROCode', 'ROName', 'IsDBC', 'IsSuraksha', 'IsARB', 'IsVAS'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public DataSource = new MatTableDataSource<any>();
  isLoading: boolean = false;
  ROList = [];
  postModal: any;
  UserId: number = 0;
  IsFlag: boolean = true;
  SelectedRO: string = "";
  private unsubscribe: Subscription[] = [];
  ActivateMISFlags: ActivateMISFlagsModel[] = [];

  constructor(private _activateCampaign: ActivateCampaignService, private toastr: ToastrService,
	 private chRef: ChangeDetectorRef, private getSession: GetSessionService) { }

  ngOnInit() {
    this.GetROMasterList();
    this.IsFlag = false; // Pageload Save button disabled
  }

  // Get RO Master List
  GetROMasterList() {
    this.isLoading = true;
	this.IsFlag = true;
    this.unsubscribe.push(this._activateCampaign.GetROMasterListByCode("0")
      .subscribe(async (data: any) => {
        this.ROList = await data;
		this.ROList = data;
		this.ActivateMISFlags = data;
		this.DataSource.data = data
		this.ActivateMISFlags = data;
		this.DataSource.data = data;
		this.DataSource.paginator = this.paginator;
		this.DataSource.sort = this.sort;
        this.isLoading = false;
		this.IsFlag = false;
        this.chRef.detectChanges();
      }, () => {
        this.toastr.error('Error');
        this.isLoading = false;
        this.chRef.detectChanges();
      }));
  }

  // Change RO
//   onChangeRO() {
    // let responseRO = this.ROList.filter(r => r.ROCode === this.SelectedRO);
    // if (responseRO.length === 0) {
    //   this.ROList = [];
    //   this.ActivateMISFlags = [];
    //   this.DataSource.data = [];
    //   this.IsFlag = false;
    //   this.GetROMasterList();
    // } else {
    //   this.IsFlag = true;
    //   this.ROList = responseRO;
    //   this.ActivateMISFlags = responseRO;
    //   this.DataSource.data = responseRO;
    //   this.DataSource.paginator = this.paginator;
    //   this.DataSource.sort = this.sort;
    // }
    // this.isLoading = false;
    // this.chRef.detectChanges();
//   }

  // SBC, Suraksha, ARB & VAS
  checkUncheckAll(evt, flag: string) {
    if (this.DataSource.data.length > 0) {
      for (var i = 0; i < this.DataSource.data.length; i++) {
        if (flag === "IsDBC") {
          if (evt.target.checked === true) {
            this.DataSource.data[i].IsDBC = "Y";
          } else {
            this.DataSource.data[i].IsDBC = "N";
          }
          this.ActivateMISFlags[i].IsDBC = this.DataSource.data[i].IsDBC;
        } else if (flag === "IsSuraksha") {
          if (evt.target.checked === true) {
            this.DataSource.data[i].IsSuraksha = "Y";
          } else {
            this.DataSource.data[i].IsSuraksha = "N";
          }
          this.ActivateMISFlags[i].IsSuraksha = this.DataSource.data[i].IsSuraksha;
        } else if (flag === "IsARB") {
          if (evt.target.checked === true) {
            this.DataSource.data[i].IsARB = "Y";
          } else {
            this.DataSource.data[i].IsARB = "N";
          }
          this.ActivateMISFlags[i].IsARB = this.DataSource.data[i].IsARB;
        } else {
          if (evt.target.checked === true) {
            this.DataSource.data[i].IsVAS = "Y";
          } else {
            this.DataSource.data[i].IsVAS = "N";
          }
          this.ActivateMISFlags[i].IsVAS = this.DataSource.data[i].IsVAS;
        }
      }
      this.chRef.detectChanges();
    }
  }

  // Check Box Code
  getCheckboxesData(flag: string, i: number) {
    if (flag == 'IsDBC') {
      if (this.ActivateMISFlags[i].IsDBC == 'Y') {
        this.ActivateMISFlags[i].IsDBC = 'N';  // DistributorFlags[i] Array of Json -> i index
      } else {
        this.ActivateMISFlags[i].IsDBC = 'Y';
      }
    } else if (flag == 'IsSuraksha') {
      if (this.ActivateMISFlags[i].IsSuraksha == 'Y') {
        this.ActivateMISFlags[i].IsSuraksha = 'N';
      } else {
        this.ActivateMISFlags[i].IsSuraksha = 'Y';
      }
    } else if (flag == 'IsARB') {
      if (this.ActivateMISFlags[i].IsARB == 'Y') {
        this.ActivateMISFlags[i].IsARB = 'N';
      } else {
        this.ActivateMISFlags[i].IsARB = 'Y';
      }
    } else if (flag == 'IsVAS') {
      if (this.ActivateMISFlags[i].IsVAS == 'Y') {
        this.ActivateMISFlags[i].IsVAS = 'N';
      } else {
        this.ActivateMISFlags[i].IsVAS = 'Y';
      }
    }
  }

  // Save Active RO MIS
  SaveActiveROMIS() {
      let model = {
        'ActivateROMISFlag': this.ActivateMISFlags
      }
      this.unsubscribe.push(this._activateCampaign.SaveActivateROMIS(model)
        .subscribe((data) => {
          if (data > 0) {
            this.toastr.success('Record Added Successfully!!!');
            this.GetROMasterList();
			this.chRef.detectChanges();
          } else {
            this.toastr.error('Failed');
          }
        }, () => {
          this.toastr.error('Error');
          this.isLoading = false;
          this.chRef.detectChanges();
        }));
  }

//   Clear() {
    // this.SelectedRO = null;
    // this.DataSource.data = [];
    // this.IsFlag = false; // Pageload Save button disabled
    // (<HTMLInputElement>document.getElementById('IsDBC')).checked = false;
    // (<HTMLInputElement>document.getElementById('IsSuraksha')).checked = false;
    // (<HTMLInputElement>document.getElementById('IsARB')).checked = false;
    // (<HTMLInputElement>document.getElementById('IsVAS')).checked = false;
    // this.GetROMasterList();
//   }
//
  // Set side menu close
  ngAfterViewInit() {
    this._activateCampaign.Toggler = new KTToggle('kt_aside_toggler', this._activateCampaign.toggleOptions);
    this._activateCampaign.DivToggleWidth = '100%';
    this._activateCampaign.IsModelOn = false;
    this._activateCampaign.displayValue = false;
    this._activateCampaign.Toggler.toggleOn();
    $('#kt_aside_close_btn').click();
    setTimeout(() => {
      this._activateCampaign.OpenToggle = true;
      this._activateCampaign.Toggler.toggleOn();
      $('#kt_aside_close_btn').click();
    }, 500);
  }

}
