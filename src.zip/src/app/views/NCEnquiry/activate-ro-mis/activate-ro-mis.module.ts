import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../../../app/core/auth';
import { NgModule } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { GetSessionService } from '../../../services/globalsession.service';
import { PartialsModule } from '../../partials/partials.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';
import { CommonModule } from '@angular/common';
import {
  MatButtonModule, MatInputModule, MatTableModule, MatProgressSpinnerModule, MatAutocompleteModule,
  MatRippleModule, MatFormFieldModule, MatSelectModule, MatCheckboxModule, MatIconModule, MatPaginatorModule, MatSortModule, MatRadioModule, MatTooltipModule
} from '@angular/material';

// Activate RO MIS
import { ActivateRoMisComponent } from './activate-ro-mis.component';

const UpdateActivateROMISRoutes: Routes = [
  {
    path: '',
    children: [
      { path: 'ActivateROMIS', component: ActivateRoMisComponent, canActivate: [AuthGuard], data: { roles: ['1'] } }
    ]
  }
]

const modules = [
  MatButtonModule, MatFormFieldModule, MatInputModule, MatRippleModule, MatTableModule,
  MatAutocompleteModule, MatSelectModule, MatProgressSpinnerModule, MatSortModule,
  MatPaginatorModule, MatIconModule, MatCheckboxModule, MatRadioModule
];

@NgModule({
  declarations: [ ActivateRoMisComponent ],
  providers: [ GetSessionService, ToastrService ],
  imports: [
    modules, CommonModule, FormsModule, ReactiveFormsModule, CommonModule,
    PartialsModule, NgbModule, MatTooltipModule, DataTablesModule,
    RouterModule.forChild(UpdateActivateROMISRoutes)
  ],
  exports: [ RouterModule ]
})
export class ActivateROMISModule { }
