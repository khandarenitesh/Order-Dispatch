import { ChangeDetectorRef, Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { AdminDbcService } from '../../../services/adminDBCCampaign/admin-dbc.service';
import { GetSessionService } from '../../../services/globalsession.service';
import { Subscription } from 'rxjs';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { MessageSentConsumerCount } from '../../../models/Dashboard/dist-dashboard.model';
import * as XLSX from 'xlsx';

@Component({
  selector: 'kt-admin-dbc-campaign',
  templateUrl: './admin-dbc-campaign.component.html',
  styleUrls: ['./admin-dbc-campaign.component.scss']
})
export class AdminDbcCampaignComponent implements OnInit {
  private unsubscribe: Subscription[] = [];
  postModal: any;
  DataSource = new MatTableDataSource<any>();
  SAList = [];
  SelectedSA: any;
  search: string = '';
  titlename: string = '';
  id: string ='0';
  ConsumerCount: MessageSentConsumerCount;
  interestedcount: string = '0';
  notinterstedcount: string ='0';
  connectionreleased: string ='0';
  messageread: string ='0';
  messagesentcount: string ='0';
  againstcontacted: string='0';
  TotalConsumers: number = 0;
  TotalMessageSend: number = 0;
  TotalInterested: number = 0;
  TotalInterestedPercent: number = 0;
  TotalNotInterestedCount: number = 0;
  TotalConnectionReleased: number = 0;
  TotalMesageRead: number = 0;
  TotalContacted: number = 0;
  TotalPendingForContacted: number = 0;
  SACountList: any;
  IntPerPercentage: Number = 0;
  ConnectionReleasedPercent: number = 0;
  MessageReadPercent: number = 0;
  DataserviceParam: string ="0";
  flag: string="";
  isLoading: boolean = false;

  // displayedColumns = ['Code', 'Name', 'YesterdayMessageSent', 'YesterdayIntersted', 'ThisMonthMessageSent', 'ThisMonthIntersted', 'TotalMessageSent', 'TotalIntersted',
  //                     'Interested', 'NotInterested', 'ConnectionReleased', 'MessageRead', 'AgainstContacted'];
  // @ViewChild(MatPaginator) paginator: MatPaginator;
  // @ViewChild(MatSort) sort: MatSort;

  displayedColumns = ['SACode', 'SAName', 'DistributorName', 'TotalConsumer', 'MessageSend', 'Interested', 'InterestedPercent', 'NotInterestedCount', 
                      'ConnectionReleased', 'MessageRead', 'Contacted', 'PendingForContact'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('TABLE') table: ElementRef;
	dtOption: any;
  dtTrigger: any;
  constructor(private chRef: ChangeDetectorRef, private adminDbcService: AdminDbcService
    , private toastr: ToastrService, private getSession: GetSessionService, private modalService: NgbModal) { }

  ngOnInit() {
    // this.titlename="Sales Area Wise Count";
    this.postModal = {
      'SACode': this.GetLoginDetails()
    };
    this.GetAdminDbcInformation(this.DataserviceParam);
    this.GetSAList(this.postModal);
    this.GetConsumerCount();
  }

  ngAfterViewInit(){
    this.dtOption = {
			paging: false,
			filter: false,
      sort: false,
      info: false,
      language : {
        "zeroRecords": " "
      }
		};
    
    $(() => {
      $('.DataTable').DataTable(this.dtOption);
    });
  }

  GetLoginDetails() {
    let item = this.getSession.GetSessionData();
    return item.refNo;
  }

  GetConsumerCount() {
    const model ={
      'Id': this.id
    }
    this.unsubscribe.push(this.adminDbcService.GetUserCount(model)
      .subscribe(data => this.afterconsumercount(data)));
  }

  afterconsumercount(data){
    this.ConsumerCount = data;
    this.interestedcount = this.ConsumerCount.Interestedcount;
    this.notinterstedcount = this.ConsumerCount.NotIntrestedCount;
    this.connectionreleased = this.ConsumerCount.ConnectionReleasedCount;
    this.messagesentcount = this.ConsumerCount.Messagesentcount;
    this.messageread = this.ConsumerCount.ReadCount;
    this.againstcontacted = this.ConsumerCount.ReadContactedCount;
    this.chRef.detectChanges();
  }

  // checkmethodtocall(SelectedSA) {
  //   if (SelectedSA == "SAwise") {
  //     // this.titlename="Sales Area Wise Count";
  //     this.GetAdminDbcInformation(this.postModal)
  //   }
  //   else {
  //     // this.titlename="Distributor Wise Count";
  //     this.GetAdminDbcInformationByDistributor(SelectedSA);
  //   }

  // }

  GetAdminDbcInformation(SACode) {
    this.isLoading = true;
    this.DataserviceParam = SACode;
    this.flag = "distwise";
    this.unsubscribe.push(this.adminDbcService.GetAdminDbcInformation(this.DataserviceParam, this.flag)
      .subscribe(data => {
        this.afterAdminDBCInformation(data);       
      }));
  }

  afterAdminDBCInformation(data){
    if (data != null && data != undefined) {
      this.isLoading = false;
      this.SACountList = [];
      this.SACountList = data;
      this.clearCounts();
      for (let q = 0; q < data.length; q++) {
        this.TotalConsumers = this.TotalConsumers + data[q].TotalConsumer;
        this.TotalMessageSend = this.TotalMessageSend + data[q].MessageSend;
        this.TotalInterested = this.TotalInterested + data[q].Interested;
        this.TotalInterestedPercent = this.TotalInterestedPercent + data[q].InterestedPercent;
        this.TotalNotInterestedCount = this.TotalNotInterestedCount + data[q].NotInterestedCount;
        this.TotalConnectionReleased = this.TotalConnectionReleased + data[q].ConnectionReleased;
        this.TotalMesageRead = this.TotalMesageRead + data[q].MessageRead;
        this.TotalContacted = this.TotalContacted + data[q].Contacted;
        this.TotalPendingForContacted = this.TotalPendingForContacted + data[q].PendingForContact;
        this.IntPerPercentage = Number((this.TotalInterested * 100 / this.TotalMessageSend).toFixed(2));
        this.ConnectionReleasedPercent = Number((this.TotalConnectionReleased * 100 / this.TotalInterested).toFixed(2));
        this.MessageReadPercent = Number((this.TotalMesageRead * 100 / this.TotalMessageSend).toFixed(2));
      }
      this.DataSource = new MatTableDataSource();
      this.DataSource.data = data;
      this.DataSource.paginator = this.paginator;
      this.DataSource.sort = this.sort;
      this.chRef.detectChanges();
    } else {
      this.DataSource = new MatTableDataSource();
      this.DataSource.data = null;
    }
  }

  clearCounts() {
    this.TotalConsumers = 0;
    this.TotalMessageSend = 0;
    this.TotalInterested = 0;
    this.TotalInterestedPercent = 0;
    this.TotalNotInterestedCount = 0;
    this.TotalConnectionReleased = 0;
    this.TotalMesageRead = 0;
    this.TotalContacted = 0;
    this.TotalPendingForContacted = 0;
    this.IntPerPercentage = 0;
    this.ConnectionReleasedPercent = 0;
    this.MessageReadPercent = 0;
  }
  
  GetSAList(postModel) {
    this.unsubscribe.push(this.adminDbcService.GetSAByRoCode(postModel.SACode)
      .subscribe(async (data) => {
        this.SAList = [];
        this.SAList = await data;
        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      },
        (error) => {
          console.error(error);
        })
    );
  }

  GetAdminDbcInformationByDistributor(SelectedSA) {
    this.flag ="distwise";
    this.unsubscribe.push(this.adminDbcService.GetAdminDbcInformation(SelectedSA, this.flag)
      .subscribe(data => {
        // tslint:disable-next-line: triple-equals
        if (data != null && data != undefined) {
          this.DataSource = new MatTableDataSource();
          this.DataSource.data = data;
          this.DataSource.paginator = this.paginator;
          this.DataSource.sort = this.sort;
          this.chRef.detectChanges();
        } else {
          this.DataSource = new MatTableDataSource();
          this.DataSource.data = null;
        }
      }));
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.DataSource.filter = filterValue;
   // alert("hi");
  }

  exportAsExcel() {
    let data: any[] = [];
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.table.nativeElement);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'All Data Export');
    XLSX.writeFile(wb, 'excelFile.xlsx');
  }

  ngOnDestroy() {
    this.unsubscribe.forEach(sb => sb.unsubscribe());
  }

}
