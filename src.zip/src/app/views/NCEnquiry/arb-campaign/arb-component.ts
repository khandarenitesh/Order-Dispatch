import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-arb',
  templateUrl: './arb-component.html',
  styleUrls: ['./arb-component.scss']
})
export class ARBComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
