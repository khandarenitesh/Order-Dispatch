import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { ConsumerEnquiry } from '../../../models/ConsumerEnquiry/consumer-enquiry.model';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ConsumerEnquiryService } from '../../../services/ConsumerEnquiry/consumer-enquiry.service';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import moment = require('moment');
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { GetSessionService } from '../../../services/globalsession.service';


@Component({
  selector: 'kt-consumer-enquiry',
  templateUrl: './consumer-enquiry.component.html',
  styleUrls: ['./consumer-enquiry.component.scss']
})
export class ConsumerEnquiryComponent implements OnInit {

  myValue: boolean = true;
  postModel: any;
  _ConsumerEnquiryLst: ConsumerEnquiry[];
  // displayedColumns = ['SrNo', 'ConsumerName', 'ConsAddress', 'MobileNo', 'IsPurchase', 'PurchaseDate', 'DistributorName', 'DistributorCode', 'DistAddress', 'StaffName'];
  displayedColumns = ['SrNo','EnquiryType','ConsumerNo','ConsumerName', 'ConsAddress', 'MobileNo', 'UpdateStatus','SourceType','EnquiryDate','StaffName', 'StaffType'];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public ConsEnqLstSource = new MatTableDataSource<any>();

  _TempModel: TempModel;
  FromDate: Date;
  ToDate: Date;
  space: string = '&nbsp; &nbsp; &nbsp;';
  IsValidDate: boolean = true;

  // Update Purchase Date
  _UpdateEnqDetails: ConsumerEnquiry;
  loadingTitle = '';
  closeResult: string;
  public PurchaseDateMinDate: any;
  public IsPurchase: string;

  constructor(
    private consumerEnquiryService: ConsumerEnquiryService,
    private chRef: ChangeDetectorRef,
    public datepipe: DatePipe,
    private toastr: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private modalService: NgbModal,
    private getSession: GetSessionService
  ) { }

  ngOnInit() {
    this._TempModel = new TempModel();
    this._UpdateEnqDetails = new ConsumerEnquiry();

    let d = new Date();
    let datePipe = new DatePipe('en-US'); // converting date to ddmmyy format
    this.FromDate = d;
    this.ToDate = d;
    this._TempModel = {
      DistributorId: this.GetLoginDetails(), // 8131,
      MobileNo: '0',
      FromDate: this.ConvertStringToDateObj(this.FromDate),
      ToDate: this.ConvertStringToDateObj(this.ToDate)
    };
    this.PurchaseDateMinDate = this.ConvertStringToDateObj(d);

    this.getConsumerDetails(this._TempModel);
  }
  Changed() {
    if ( this._UpdateEnqDetails.IsPurchaseTemp === false) {
      this._UpdateEnqDetails.PurchaseDateTemp = null;
    }
  }
  getConsumerDetails(model: TempModel) {

    let datePipe = new DatePipe('en-US');
    // let fromDate = datePipe.transform(model.FromDate, 'dd-MM-yyyy');
    // let toDate = datePipe.transform(model.ToDate, 'dd-MM-yyyy');
    this.postModel = {
      DistributorId: this.GetLoginDetails(), // 8131,
      MobileNo: '0',
      FromDate: this.ConvertDateFormat(model.FromDate),
      ToDate: this.ConvertDateFormat(model.ToDate)
    };

    this.consumerEnquiryService.getConsumerEnquiry(this.postModel)
      .subscribe(data => {
        // (data);

        this._ConsumerEnquiryLst = data.ConsDtls;
        this.ConsEnqLstSource = new MatTableDataSource(data.ConsDtls);
        this.ConsEnqLstSource.paginator = this.paginator;
        this.ConsEnqLstSource.sort = this.sort;

        if (data.ConsDtls.length === 0) {
          this.toastr.warning('Record not found.', 'Consumer Enquiry', {timeOut: 2000});
        }

        // table
        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      },
        (error) => {
          console.error(error);
        });

  }

  onDateSelect(FromDate: Date, ToDate: Date) {
    if (FromDate > ToDate) {
      this.IsValidDate = false;
    } else {
      this.IsValidDate = true;
    }
  }
  // use to convert string to date obj
  ConvertStringToDateObj(SelDate) {

    let d = new Date(moment(SelDate, 'DD-MM-YYYY hh:mm tt').format('YYYY-MM-DD'));
    return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() };
  }

  // Use to Convert object to  Date Format string
  ConvertDateFormat(condate) {
    let dateInput = new Date(condate.year, condate.month - 1, condate.day);
    return moment(dateInput).format('YYYY-MM-DD');
  }
  GetLoginDetails() {
    let item = this.getSession.GetSessionData();
    return item.refNo;
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.ConsEnqLstSource.filter = filterValue;
  }

  // Update Purchase Date
  open(content) {
    this.resetForm();
    this.loadingTitle = 'Update Status';
    this.modalService.open(content, { centered: true }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  showForEdit(ref: any) {
    this._UpdateEnqDetails = ref;
    this._UpdateEnqDetails.PurchaseDateTemp = this.ConvertStringToDateObj(this._UpdateEnqDetails.PurchaseDate);
    this._UpdateEnqDetails.TempReason = ref.Reason;
    if (!this.chRef['destroyed']) {
      this.chRef.detectChanges();
    }
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  resetForm(form?: NgForm) {

    this._UpdateEnqDetails = {
      CId: 0,
      ConsumerName: '',
      ConsAddress: '',
      MobileNo: '',
      DistributorId: 0,
      IsPurchase: '',
      PurchaseDate: '',
      DistributorName: '',
      DistributorCode: '',
      DistAddress: '',
      StaffType: '',
      StaffName: '',
      Operation: '',
      EnquiryDate: '',
      PurchaseDateTemp: null,
      IsPurchaseTemp: false,
      EnquiryType: '',
      ConsumerNo: '',
      Reason: '',
      TempReason: '',
      SourceType: ''

    };
  }

  _UpdatePurchaseDate(UpdateEnqDetails: ConsumerEnquiry) {
    if (UpdateEnqDetails.IsPurchaseTemp !== true) {
      UpdateEnqDetails.IsPurchase = 'Y';
      UpdateEnqDetails.Reason = '';
        UpdateEnqDetails.PurchaseDate = this.ConvertDateFormat(UpdateEnqDetails.PurchaseDateTemp);
    } else {
      UpdateEnqDetails.PurchaseDate = '';
      UpdateEnqDetails.IsPurchase = 'N';
      UpdateEnqDetails.Reason = UpdateEnqDetails.TempReason;
    }
    UpdateEnqDetails.Operation = '';


    this.consumerEnquiryService.UpdateConsumerDetails(UpdateEnqDetails).subscribe(data => {
      if (data.Status === 'Success') {
        if (data.StaffRefNo === -1) {
          this.toastr.error('Consumer Details not exists.', 'Consumer Enquiry Master', {timeOut: 2000});
        } else if (data.StaffRefNo > 0) {

          // this.router.navigateByUrl("/default/getConsumerEnquiry");
          this.toastr.success('Release Date Updated Successfully.', 'Consumer Enquiry Master', {timeOut: 2000});
        } else {
          this.toastr.error('Network error', 'Consumer Enquiry Master', {timeOut: 2000});
        }
      }
      this.resetForm();
      this.modalService.dismissAll();
      this.getConsumerDetails(this._TempModel);
    });
  }

  getExcelFileName() {
    return 'Customer Details Report' + this.datepipe.transform(new Date(), 'dd-MM-yyyy hh:mm').toString();
  }

}
export class TempModel {
  DistributorId: number;
  FromDate: any;
  MobileNo: string;
  ToDate: any;
}
