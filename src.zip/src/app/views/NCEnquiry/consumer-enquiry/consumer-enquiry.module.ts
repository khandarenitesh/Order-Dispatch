import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsumerEnquiryComponent } from './consumer-enquiry.component';
import { AuthGuard } from '../../../../app/core/auth';
import { Routes, RouterModule } from '@angular/router';

import { MatButtonModule, MatInputModule, MatTableModule, MatStepperModule, MatProgressSpinnerModule, MatAutocompleteModule, MatRippleModule, MatFormFieldModule, MatSelectModule, MatDatepickerModule, MatCheckboxModule, MatIconModule, MatPaginatorModule, MatSortModule, MatRadioModule, MatTabsModule, MatProgressBarModule, MatTooltipModule } from '@angular/material';
import { MatTableExporterModule } from 'mat-table-exporter';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { PartialsModule } from '../../partials/partials.module';
import { CoreModule } from '../../../../app/core/core.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';

const ConsumerEnquiryroutes: Routes = [
	{ path: 'getConsumerEnquiry', component: ConsumerEnquiryComponent, canActivate: [AuthGuard], data: { roles: ['1', '2', '3'] } }
];

const modules = [
	MatButtonModule,MatFormFieldModule,
	MatInputModule,MatRippleModule,
	MatTableModule,MatAutocompleteModule,MatSelectModule,MatDatepickerModule,MatStepperModule,
  MatProgressSpinnerModule,
  MatSortModule,MatPaginatorModule,MatIconModule,MatTableExporterModule,MatCheckboxModule,MatRadioModule
];

@NgModule({
  declarations: [ConsumerEnquiryComponent],
  imports: [
    modules,
    FormsModule,
    ReactiveFormsModule,
		CommonModule,
		PartialsModule,
		CoreModule,
		NgbModule,
		MatTooltipModule,
		DataTablesModule,
    RouterModule.forChild(ConsumerEnquiryroutes)
  ]
})
export class ConsumerEnquiryModule { }
