import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DbcCampaignUploadComponent } from './dbc-campaign-upload.component';

describe('DbcCampaignUploadComponent', () => {
  let component: DbcCampaignUploadComponent;
  let fixture: ComponentFixture<DbcCampaignUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DbcCampaignUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DbcCampaignUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
