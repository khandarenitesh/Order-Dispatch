import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { MessageSentConsumerCount } from '../../../models/Dashboard/dist-dashboard.model';
import { DbcCampaignService } from '../../../services/DBCCampaign/dbc-campaign.service';
import { GetSessionService } from '../../../services/globalsession.service';
import moment = require('moment');
import { HeaderServiceService } from '../../../services/HeaderService/header-service.service';
import * as XLSX from 'xlsx';


@Component({
  selector: 'kt-dbc-campaign',
  templateUrl: './dbc-campaign.component.html',
  styleUrls: ['./dbc-campaign.component.scss']
})
export class DbcCampaignComponent implements OnInit, OnDestroy {
  private unsubscribe: Subscription[] = [];
  postModal: any;
  DataSource = new MatTableDataSource<any>();
  _messageSentConsumerCount: MessageSentConsumerCount;
  @ViewChild('TABLE') table: ElementRef;
  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild('sort1') sort1: MatSort;
  displayedColumns = ['ConsumerNo', 'ConsumerName', 'MobileNo', 'MessageStatus', 'IsReplayReceivedDate', 'StatusName', 'Feedback', 'ConnectionUpdate', 'UserRemark'];
  DataSourceInterestedCount = new MatTableDataSource<any>();
  @ViewChild('paginator2') paginator2: MatPaginator;
  @ViewChild('sort2') sort2: MatSort;
  coloumns = ['SrNo', 'Status', 'Read', 'Interested'];
  search: string = '';
  flag: any;
  loadingTitle = '';
  closeResult: string;
  DistributorIdint: number;
  ConsumerNo: number;
  UniqueConsumerId: string;
  PurchaseDateTemp: any;
  CallStatusList: any[] = [];
  CallStatus: string;
  ConsumerFeedback: string;
  ConsumerListBackup: any;
  ConsumerList: any;
  isdbccampaign: boolean;
  FromDate: any = null;
  ToDate: any = null;
  isLoading: boolean = false;
  tempstatus: string = "";
  tempfeedback: string = "";
  temprecord: any;

  constructor(private chRef: ChangeDetectorRef, private _dbcCampaignService: DbcCampaignService,
     private toastr: ToastrService, private getSession: GetSessionService, private modalService: NgbModal) { }

  ngOnInit() {
    this.isdbccampaign = true;
    this.postModal = {
      'DistributorId': this.GetLoginDetails()
    };
    this._messageSentConsumerCount = new MessageSentConsumerCount();
    this.GetConsumerList();
    this.GetConsumerCount(this.postModal);
    this.GetStatuswiseCounts(this.postModal);
  }

  GetLoginDetails() {
    let item = this.getSession.GetSessionData();
    return item.refNo;
  }

  GetConsumerList() {
    const modal = {
      'DistributorId': this.postModal.DistributorId,
      'Fromdate': this.FromDate === null ? null : this.ConvertDateFormat(this.FromDate),
      'Todate': this.ToDate === null ? null : this.ConvertDateFormat(this.ToDate)
    }
    this.isLoading = true;
    this.unsubscribe.push(this._dbcCampaignService.GetConsumers_service(modal)
      .subscribe(data => {
        if (data != null && data != undefined) {
          this.DataSource = new MatTableDataSource();
          this.DataSource.data = data.filter(x => x.IsReplayReceived === 'Y' || x.UserReply !== null);
          this.ConsumerListBackup = data;
          this.DataSource.paginator = this.paginator;
          this.DataSource.sort = this.sort1;
          this.isLoading = false;
          this.chRef.detectChanges();
        } else {
          this.DataSource = new MatTableDataSource();
          this.DataSource.data = null;
          this.isLoading = false;
        }
      }));
  }

  GetStatuswiseCounts(postModel) {
    this.unsubscribe.push(this._dbcCampaignService.GetStatusWiseCounts_service(postModel)
      .subscribe(data => {
        if (data != null && data != undefined) {
          this.DataSourceInterestedCount = new MatTableDataSource();
          this.DataSourceInterestedCount.data = data;
          this.DataSourceInterestedCount.paginator = this.paginator2;
          this.DataSourceInterestedCount.sort = this.sort2;
          this.chRef.detectChanges();
        } else {
          this.DataSourceInterestedCount = new MatTableDataSource();
          this.DataSourceInterestedCount.data = null;
        }
      }));
  }

  ShowConsList(Flag?: any) {
    if (this.ConsumerListBackup != null && this.ConsumerListBackup !== undefined) {

      if (Flag === 'All') {
        this.ConsumerList = this.ConsumerListBackup;
      }
      else if (Flag === 'ConnectionReleased') {
        this.ConsumerList = this.ConsumerListBackup.filter(x => x.ConnectionReleased === 'Y');

      } else if (Flag === 'Interested') {
        this.ConsumerList = this.ConsumerListBackup.filter(x => x.IsReplayReceived === 'Y' || x.UserReply !== null);

      } else if (Flag === 'Read') {
        this.ConsumerList = this.ConsumerListBackup.filter(x => x.MessageStatus === 'READ' || x.MessageStatus === 'REPLIED');

      } else if (Flag === 'Contacted') {
        this.ConsumerList = this.ConsumerListBackup.filter(x => x.StatusName !== null);
      }
      else if (Flag === 'NotInterested') {
        this.ConsumerList = this.ConsumerListBackup.filter(x => x.NotIntrested === 'Y');
      }
      else if (Flag === 'ReadContacted') {
        this.ConsumerList = this.ConsumerListBackup.filter(x => x.StatusName !== null && (x.MessageStatus === 'READ' || x.MessageStatus === 'REPLIED'));
      }
      else if (Flag === 'Sent') {
        this.ConsumerList = this.ConsumerListBackup.filter(x => x.IsMessageSent === 'Y');
      }
      // this.ConsumerList = this.ConsumerListBackup;
      this.DataSource = new MatTableDataSource(this.ConsumerList);
      this.DataSource.paginator = this.paginator;
      this.DataSource.sort = this.sort1;
      if (!this.chRef['destroyed']) {
        this.chRef.detectChanges();
      }
    }
  }

  GetConsumerCount(postModel) {
    this.unsubscribe.push(this._dbcCampaignService.DbcConsumersCount_service(postModel)
      .subscribe(data => {
        if (data != null && data != undefined) {
          this._messageSentConsumerCount = data;
          this.chRef.detectChanges();
        }
      }));
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.DataSource.filter = filterValue;
  }

  open(content, ref: any) {
    this.temprecord = ref;
    this.getMsgStatus();
    this.DistributorIdint = ref.DistributorIdint;
    this.ConsumerNo = ref.ConsumerNo;
    this.UniqueConsumerId = ref.UniqueConsumerId;
    this.PurchaseDateTemp = null;
    this.CallStatus = " ";
    this.ConsumerFeedback = " ";
    // this.resetForm();
    this.loadingTitle = 'Release Connection';
    this.modalService.open(content, { centered: true, size: 'lg', backdrop: 'static' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  UpdateStatus() {
    let model = null;
    if ((this.CallStatus === null || this.CallStatus === undefined || this.CallStatus === " ") ||
      (this.ConsumerFeedback === null || this.ConsumerFeedback === undefined || this.ConsumerFeedback === " " || this.ConsumerFeedback === "")) {
      this.toastr.error('Please Enter Data');
    } else {
      model = {
        DistributorIdint: this.DistributorIdint,
        UniqueConsumerId: this.UniqueConsumerId,
        ConsumerNo: this.ConsumerNo,
        ConnectionReleased: 'Y',
        StatusName: this.CallStatus,
        ConsumerFeedback: this.ConsumerFeedback
      };
      this.unsubscribe.push(this._dbcCampaignService.UpdateStatus_service(model)
        .subscribe(data => {
          if (data != null && data != undefined) {
            this.flag = data;
            if (this.flag === 1) {
              this.toastr.success('Status Submited Successfully!');
              this.modalService.dismissAll();
              this.PurchaseDateTemp = null;

              for (let i = 0; i <= this.ConsumerListBackup.length-1; i++) {
                if (this.ConsumerListBackup[i].UniqueConsumerId == this.temprecord.UniqueConsumerId) {
                  this.ConsumerListBackup[i].StatusName = this.CallStatus;
                  this.ConsumerListBackup[i].ConsumerFeedback = this.ConsumerFeedback;
                }
              }

              this.DataSource = new MatTableDataSource(this.ConsumerListBackup);
              this.DataSource.paginator = this.paginator;
              this.DataSource.sort = this.sort1;
			  this.GetConsumerList();
			  this.GetConsumerCount(this.postModal);
			  this.GetStatuswiseCounts(this.postModal);
              if (!this.chRef['destroyed']) {
                this.chRef.detectChanges();
              }
              this.chRef.detectChanges();
            } else {
              this.toastr.error('Something went wrong!');
            }
          }
        }));
    }
  }

  ConvertDateFormat(condate) {
    let dateInput = new Date(condate.year, condate.month - 1, condate.day);
    return moment(dateInput).format('YYYY-MM-DD');
  }

  getMsgStatus() {
    this.unsubscribe.push(this._dbcCampaignService.GetCallStatusList("DBC")
      .subscribe(data => {
        this.CallStatusList = data.CallStatusParameter;
      }));
  }

  // exportAsExcel() {
  //     // const ws: XLSX.WorkSheet=XLSX.utils.table_to_sheet(this.table.nativeElement);//converts a DOM TABLE element to a worksheet
  //     // // ws['!cols'] = [];
  //     // // ws['!cols'][2] = { hidden: true };
  //     // delete (ws['08']);
  //     // const wb: XLSX.WorkBook = XLSX.utils.book_new();
  //     // XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

  //     // /* save to file */
  //     // XLSX.writeFile(wb, 'Sheet.xlsx');

  //     const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.table.nativeElement);
  //     const wb: XLSX.WorkBook = XLSX.utils.book_new();
  //     XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  //     XLSX.writeFile(wb, 'SheetTest.xlsx');
  //   }

  ngOnDestroy() {
    this.unsubscribe.forEach(sb => sb.unsubscribe());
  }
}
