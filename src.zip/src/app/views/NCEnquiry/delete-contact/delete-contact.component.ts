import { DeleteContactService } from './../../../services/DeleteContact/delete-contact.service';
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { GetSessionService } from '../../../services/globalsession.service';
import moment = require('moment');
import { FormGroup, FormBuilder, Validators } from '@angular/forms';


@Component({
  selector: 'kt-delete-contact',
  templateUrl: './delete-contact.component.html',
  styleUrls: ['./delete-contact.component.scss']
})
export class DeleteContactComponent implements OnInit, OnDestroy {
  private unsubscribe: Subscription[] = [];
  Mobileno: string;

  deleteContactFormGroup: FormGroup;

  constructor(private chRef: ChangeDetectorRef, private _deleteContactService: DeleteContactService, 
    private toastr: ToastrService, private getSession: GetSessionService, private modalService: NgbModal) {

    }

  ngOnInit() {
  }

  deleteContactNumber() {
    const model = {
      'MobileNo': this.Mobileno
    };
    this.unsubscribe.push(this._deleteContactService.DeleteContact_service(model).
      subscribe(data => {
        if (data != null && data != undefined) {
          if ( data >= 1) {
            this.toastr.success('Contact Deleted Succesfully');
            this.Mobileno = null;
          } else {
            this.toastr.error('No record found !!');
          }
        }
      }));
  }

  ngOnDestroy() {
    this.unsubscribe.forEach(sb => sb.unsubscribe());
  }
}
