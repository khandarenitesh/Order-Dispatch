import { DeleteContactComponent } from '../delete-contact/delete-contact.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../../../app/core/auth';
import {
	MatButtonModule, MatInputModule, MatTableModule, MatStepperModule, MatProgressSpinnerModule, MatAutocompleteModule,
	MatRippleModule, MatFormFieldModule, MatSelectModule, MatDatepickerModule, MatCheckboxModule, MatIconModule, MatPaginatorModule, MatSortModule, MatRadioModule, MatTooltipModule
} from '@angular/material';
import { MatTableExporterModule } from 'mat-table-exporter';
import { ToastrService } from 'ngx-toastr';
import { GetSessionService } from '../../../services/globalsession.service';
import { PartialsModule } from '../../partials/partials.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '../../../../../src/app/core/core.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';



const deleteContactComponentRoutes: Routes = [
	{
		path: '',
		children: [
			{ path: 'deletecontact', component: DeleteContactComponent, canActivate: [AuthGuard], data: { roles: ['1', '2', '3'] } }
		]
	}
];


const modules = [
	MatButtonModule, MatFormFieldModule,
	MatInputModule, MatRippleModule,
	MatTableModule, MatAutocompleteModule, MatSelectModule, MatDatepickerModule, MatStepperModule,
	MatProgressSpinnerModule,
	MatSortModule, MatPaginatorModule, MatIconModule, MatTableExporterModule, MatCheckboxModule, MatRadioModule
];

@NgModule({
	declarations: [DeleteContactComponent],
	providers: [GetSessionService, ToastrService],
	imports: [
		modules,
		FormsModule,
		ReactiveFormsModule,
		CommonModule,
		PartialsModule,
		CoreModule,
		NgbModule,
		MatTooltipModule,
		DataTablesModule,
		RouterModule.forChild(deleteContactComponentRoutes)
	],
	exports: [RouterModule]
})
export class DeleteContactModule { }
