import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { DistributorStaffService } from '../../../../services/DistributorStaff/distributor-staff.service';
import { DistStaff } from '../../../../models/Distributorstaff/dist-staff.model';
import moment = require('moment');

import { NgForm, FormControl, NgModel } from '@angular/forms';
import { GetSessionService } from '../../../../services/globalsession.service';

@Component({
  selector: 'kt-add-dist-staff',
  templateUrl: './add-dist-staff.component.html',
  styleUrls: ['./add-dist-staff.component.scss']
})
export class AddDistStaffComponent implements OnInit {

  _DistStaffModel: DistStaff;
  postModal: any;
  // For Add and Edit
  StaffRefNo: number;
  Operation: string;
  DistributorId: number;
  disabled: boolean;

  _StaffType: any[];

  constructor(
    private toastr: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private distributorStaffService: DistributorStaffService,
    private chRef: ChangeDetectorRef,
    private getSession: GetSessionService
  ) { }

  ngOnInit() {
debugger
    this._StaffType = [
      { Id: 'Deliveryboy', value: 'Deliveryboy' },
      { Id: 'Vendor', value: 'Vendor' }
    ];

    this.disabled = true;
    this._DistStaffModel = new DistStaff();
    this.resetForm();
    this.route.params.subscribe(params => {
      this._DistStaffModel.StaffRefNo = params['StaffRefNo'];
      this.StaffRefNo = params['StaffRefNo'];

    });
    if (this._DistStaffModel.StaffRefNo === null || this._DistStaffModel.StaffRefNo === undefined || this._DistStaffModel.StaffRefNo === 0) {
      this._DistStaffModel.StaffRefNo = 0;
      this.StaffRefNo = 0;
      this.Operation = 'ADD';
      this._DistStaffModel.Operation = 'ADD';
      this._DistStaffModel.DistributorId = this.GetLoginDetails();
    } else {
      this.getStaffDetails();
      this.Operation = 'EDIT';
      this._DistStaffModel.Operation = 'EDIT';
    }
  }


  resetForm() {

    this._DistStaffModel = {
      StaffRefNo: this.StaffRefNo,
      DistributorId: 0,
      StaffName: '',
      StaffAddress: '',
      MobileNo: '',
      OTP: '',
      ActiveStatus: '',
      Operation: '',
      UserId: '',
      ActiveFrom: '',
      LastUpdateDateTime: '',
      VersionNo: '',
      IsEnquiryActive: true,
      IsInactiveConsActive: false,
      StaffType: ''
    };
  }
  GetLoginDetails() {
    let item = this.getSession.GetSessionData();
    return item.refNo;

  }
  getStaffDetails() {

    this.postModal = {
      'DistributorId': this.GetLoginDetails(), // 8131,
      'StaffRefNo': this.StaffRefNo,
      'Operation': 'Y'
    };
    this.distributorStaffService.getDistStaffDetails(this.postModal)
      .subscribe(data => {
        this._DistStaffModel = data.distributorStaffDetails;
        this._DistStaffModel.DistributorId= this.GetLoginDetails();
        this._DistStaffModel.IsEnquiryActive = true;
        // this._DistStaffModel.DateOfPassing = this.ConvertStringToDateObj(this._DistStaffModel.DateOfPassing);
      },
        (error) => {
          console.error(error);
        });
  }
  // use to convert string to date obj
  ConvertStringToDateObj(SelDate) {
    let d = new Date(moment(SelDate, 'DD-MM-YYYY hh:mm tt').format('YYYY-MM-DD'));
    return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() };
  }
  onSubmit(productForm: DistStaff) {
    // Converting all date format


    productForm.Operation = this.Operation;

    this.distributorStaffService.saveDistStaffDetails(productForm).subscribe(data => {
      if (data.Status === 'Success') {
        if (data.StaffRefNo === -1) {
          this.toastr.error('Distributor Staff already exists.', 'Distributor Staff Master', { timeOut: 2000 });
        } else if (data.StaffRefNo === -2) {
          this.toastr.error('Phone No already exists.', 'Distributor Staff Master', { timeOut: 2000 });
        } else if (data.StaffRefNo > 0 && this.Operation === 'EDIT') {

          this.router.navigateByUrl('/default/distributorStaff');
          this.toastr.success('Record Updated Successfully.', 'Distributor Staff Master', { timeOut: 2000 });
        } else if (data.StaffRefNo > 0) {
          this.toastr.success('Record Inserted Successfully.', 'Distributor Staff Master', { timeOut: 2000 });
          this.router.navigateByUrl('/default/distributorStaff');
        }
      }
    });
  }
}
