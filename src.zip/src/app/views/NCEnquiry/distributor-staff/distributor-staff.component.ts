import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { DistributorStaffService } from '../../../services/DistributorStaff/distributor-staff.service';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { DistStaff } from '../../../models/Distributorstaff/dist-staff.model';
import { Subscription, interval } from 'rxjs';

@Component({
  selector: 'kt-distributor-staff',
  templateUrl: './distributor-staff.component.html',
  styleUrls: ['./distributor-staff.component.scss']
})
export class DistributorStaffComponent implements OnInit {

  postModal: any;
  _DistStaffLst: DistStaff[];
  displayedColumns = ['SrNo', 'StaffType','StaffName', 'StaffAddress', 'MobileNo', 'OTP', 'VersionNo', 'ActiveFrom','IsNcEnquiryApp','IsBlockConsumer', 'ActiveStatus', 'Actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public DistStaffSource = new MatTableDataSource<any>();

  // To store the warning message to display while activate or deactivete the record.
  WarningMessage: string;
  private updateSubscription: Subscription;

  constructor(private distributorStaffService: DistributorStaffService,
    private chRef: ChangeDetectorRef,
    public datepipe: DatePipe,
    private toastr: ToastrService) { }

  ngOnInit() {
    this.GetStaffDetails();
    // let Tempitem = JSON.parse(sessionStorage.getItem("LoginData"));

    // if (Tempitem !== null && Tempitem.RoleId===3) {
    //   this.updateSubscription = interval(5000).subscribe(
    //     (val) => {
    //       if (sessionStorage.getItem('LoginData') !== null && sessionStorage.getItem('LoginData') !== undefined) {
    //       this.GetStaffDetails()
    //       }
    //     }
    //   );
    // }
  }
  //   private updateStats() {
  //     ('I am doing something every second');
  // }
  GetStaffDetails() {
    this.postModal = {
      'DistributorId': this.GetLoginDetails(), // 8131,
      'StaffRefNo': 0,
      'Operation': 'Y'
    };
    this.distributorStaffService.getDistStaffDetails(this.postModal)
      .subscribe(data => {
        this._DistStaffLst = data.distributorStaffsLst;
        this.DistStaffSource = new MatTableDataSource(data.distributorStaffsLst);
        this.DistStaffSource.paginator = this.paginator;
        this.DistStaffSource.sort = this.sort;
        // table
        // this.chRef.detectChanges();
      },
        (error) => {
          console.error(error);
        });

  }

  GetStaffDetailsRefresh() {
    this.postModal = {
      'DistributorId': this.GetLoginDetails(), // 8131,
      'StaffRefNo': 0,
      'Operation': 'Y'
    };
    this.distributorStaffService.getDistStaffDetails(this.postModal)
      .subscribe(data => {
        this._DistStaffLst = data.distributorStaffsLst;
        this.DistStaffSource = new MatTableDataSource(data.distributorStaffsLst);
        this.DistStaffSource.paginator = this.paginator;
        this.DistStaffSource.sort = this.sort;
        this.toastr.success('Data Refresh Successfully.', 'Distributor Staff Master', {timeOut: 2000});
        // table
        // if (!this.chRef['destroyed']) {
        //   this.chRef.detectChanges();
        // }
      },
        (error) => {
          console.error(error);
        });

  }


  onDelete(id: number, Status: string) {
    if (Status === 'N') {
      this.WarningMessage = 'Are you sure to Deactivate this record?';
    } else {
      this.WarningMessage = 'Are you sure to Activate this record?';
    }
    if (confirm(this.WarningMessage) === true) {
      this.postModal = {
        'StaffRefNo': id,
        'ActiveStatus': Status,
        'Operation': 'DELETE'
      };
      this.distributorStaffService.saveDistStaffDetails(this.postModal)
        .subscribe(data => {

          if (data.Status === 'Success') {

            if (Status === 'N') {
              this.toastr.success('Record Deactivated Successfully.', 'Distributor Staff Master', { timeOut: 2000 });
            } else {
              this.toastr.success('Record Activated Successfully.', 'Distributor Staff Master', { timeOut: 2000 });
            }
          } else if (data < 0) {
            this.toastr.error('Something Went Wrong.', 'Distributor Staff Master', { timeOut: 2000 });
          }
          this.GetStaffDetails();
          if (!this.chRef['destroyed']) {
            this.chRef.detectChanges();
          }
        });
    }
  }

  GetLoginDetails() {
    let item = JSON.parse(sessionStorage.getItem('LoginData'));
    return item.refNo;

  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.DistStaffSource.filter = filterValue;
  }

}
