import { Component, OnDestroy, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
// import { EmployeeService } from '../../../services/Employee/employee.service'; // path of employee.services from Employee folder
@Component({
  selector: 'employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss'],
})
export class EmployeeComponent implements OnInit, OnDestroy {
  // required to show colum name on page
  displayedColumnsForApi = ['SrNo', 'EmpFirstName', 'EmpMiddleName', 'EmpLastName', 'Gender', 'EmailId', 'MobileNo', 'Address', 'Actions'];

  model: any = {};

  private unsubscribe: Subscription[] = [];


  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild('Sort') Sort: MatSort;
  public DataSource = new MatTableDataSource<any>();
  EmployeeService: any;
  EmpId: any;

  isSave: boolean = true; // save button enable while we open employee page
  isUpdate: boolean = false; //update button disabled there is no need of update button

  constructor(
    // private _EmployeeService: EmployeeService,
     private toastr: ToastrService, private chRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.GetEmployee();
  }
  //  Get employee list in table after saved
  GetEmployee() {
    // this.unsubscribe.push(this._EmployeeService.GetEmployeeDetails()
    //   .subscribe((data) => {
    //     if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
    //       this.DataSource.data = data;
    //       this.DataSource.paginator = this.paginator;
    //       this.DataSource.sort = this.Sort;
    //       this.chRef.detectChanges();
    //     } else {
    //       this.DataSource.data = [];
    //       this.chRef.detectChanges();
    //     }
    //   }));
  }
  // Event for mobile number validation (only allowed digits)
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // Email Validation
  isEmail(email: string): boolean {
    var result: boolean;
    let regexp;
    regexp = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    result = regexp.test(email);
    return result
  }

  // Mobile number Validation
  isMobile(mobile: string): boolean {
    var result: boolean;
    let regexp;
    regexp = new RegExp(/(((^[\+,0][9][1])(((\s[0-9]{7,10})|(\S[0-9]{7,10}))|([-]\S[0-9]{7,10})))|((^[\+,0][2]{2,2})((\S[0-9]{7,8})|((([-])[0-9]{7,8})|(\s[0-9]{7,8})))))|(((^[6,7,8,9][0-9]{9,9}))|(^[0,\+](([9][1)|[6,7,8,9]))[0-9]{8,9}))(@"^[0-9]{10}$");/);
    result = regexp.test(mobile);
    return result
  }

  //  Save employee details on click (Save) button
  // !=="" - type check
  SaveEmployeeDetails() {
    if ((this.model.firstname !== "" && this.model.firstname !== null && this.model.firstname !== undefined) &&
      (this.model.middlename !== "" && this.model.middlename !== null && this.model.middlename !== undefined) &&
      (this.model.lastname !== "" && this.model.lastname !== null && this.model.lastname !== undefined) &&
      (this.model.emailid !== "" && this.model.emailid !== null && this.model.emailid !== undefined && this.isEmail(this.model.emailid)) &&
      (this.model.mobileno !== "" && this.model.mobileno !== null && this.model.mobileno !== undefined && this.isMobile(this.model.mobileno)) &&
      (this.model.address !== "" && this.model.address !== null && this.model.address !== undefined) &&
      (this.model.gender !== "" && this.model.gender !== null && this.model.gender !== undefined)) {

      // if(!this.isEmail(this.model.emailid)){
      //   this.toastr.error ('Invalid Email Id !', 'Employee Details');
      // }
      // if(!this.isMobile(this.model.mobileno)){
      //   this.toastr.error ('Invalid Mobile number !', 'Employee Details');
      // }
      // this.unsubscribe.push(this._EmployeeService.AddEmployeeDetails(this.model)
      //   .subscribe((data: any) => {
      //     if (data === 1) {
      //       this.toastr.success('Record Added Successfully!!!', 'Employee Details');
      //       this.ClearEmployeeDetails();
      //       this.GetEmployee();
      //       this.chRef.detectChanges();

      //     }
      //   }, () => {
      //     this.toastr.error('Error', 'Employee Details');
      //   }));
    }
  }
  // Fecth employee value row wise on click (Edit) button
  editemployee(row: any) {
    this.isSave = false;
    this.isUpdate = true;
    // two way data binding
    this.model.empid = row.EmpId;
    this.model.firstname = row.FirstName;  // model.firstname is from model & row.FirstName is from table(database)
    this.model.middlename = row.MiddleName;
    this.model.lastname = row.LastName;
    this.model.emailid = row.EmailId;
    this.model.mobileno = row.MobileNo;
    this.model.address = row.Address;
    this.model.gender = row.Gender;
    this.model.isactive = row.IsActive;
  }
  // Update employee row wise on click (Update) button
  UpdateEmployeeDetails() {
    if ((this.model.firstname !== "" && this.model.firstname !== null && this.model.firstname !== undefined) && // not empty,not null,not undefined then condition is true
      (this.model.middlename !== "" && this.model.middlename !== null && this.model.middlename !== undefined) &&
      (this.model.lastname !== "" && this.model.lastname !== null && this.model.lastname !== undefined) &&
      (this.model.emailid !== "" && this.model.emailid !== null && this.model.emailid !== undefined) &&
      (this.model.mobileno !== "" && this.model.mobileno !== null && this.model.mobileno !== undefined) &&
      (this.model.address !== "" && this.model.address !== null && this.model.address !== undefined) &&
      (this.model.gender !== "" && this.model.gender !== null && this.model.gender !== undefined)) {
      // this.unsubscribe.push(this._EmployeeService.UpdateEmployeeDetails(this.model).subscribe((data: any) => {
      //   if (data === 1) {
      //     this.toastr.success('Record Updated Successfully!!!', 'Employee Details');
      //     this.GetEmployee();
      //     this.chRef.detectChanges();
      //     this.ClearEmployeeDetails();
      //   }

      // }, () => {
      //   this.toastr.error('Error', 'Employee Details');
      // }));
    } 
  }
  // Delete empid  row wise on click (Delete) button
  deleteemployee(EmpId: number) {
    console.log(EmpId)
    // this.unsubscribe.push(this._EmployeeService.DeleteEmployee(EmpId)
    //   .subscribe((data: any) => {
    //     this.toastr.success('Record Deleted Successfully!!!', 'Employee Details');
    //     this.GetEmployee();
    //     this.chRef.detectChanges();

    //   }, () => {
    //     this.toastr.error('Error', 'Employee Details');
    //   }));
  }
  // Clear employee value on click (Clear) button
  ClearEmployeeDetails() {
    this.isSave = true;
    this.isUpdate = false;
    this.model.firstname = "";
    this.model.middlename = "";
    this.model.lastname = "";
    this.model.emailid = "";
    this.model.mobileno = "";
    this.model.address = "";
    this.model.gender = "";
  }
// Hide Menu after click Employee
  ngAfterViewInit() {
    // this._EmployeeService.Toggler = new KTToggle('kt_aside_toggler', this._EmployeeService.toggleOptions);
    // this._EmployeeService.DivToggleWidth = '100%';
    // this._EmployeeService.IsModelOn = false;
    // this._EmployeeService.displayValue = false;
    // this._EmployeeService.Toggler.toggleOn();
    // $('#kt_aside_close_btn').click();
    // setTimeout(() => {
    //   this._EmployeeService.OpenToggle = true;
    //   this._EmployeeService.Toggler.toggleOn();
    //   $('#kt_aside_close_btn').click();
    // }, 500);
  }


  ngOnDestroy() {
    this.unsubscribe.forEach(sb => sb.unsubscribe());
  }
}

