import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeComponent } from '../employee/employee.component';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../../../../app/core/auth';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PartialsModule } from '../../partials/partials.module'; //important (kt-portlet & kt-portlet-body)

import {
	MatButtonModule, MatInputModule, MatTableModule, MatStepperModule, MatProgressSpinnerModule, MatAutocompleteModule,
	MatRippleModule, MatFormFieldModule, MatSelectModule, MatDatepickerModule, MatCheckboxModule,MatListModule, MatIconModule, 
	MatPaginatorModule, MatSortModule, MatRadioModule
} from '@angular/material';

const employeeComponentRoutes: Routes = [
	{
		path: '',
		children: [
			{ path: 'Employee', component: EmployeeComponent, canActivate: [AuthGuard], data: { roles: ['1'] } }
		]
	}
];

const modules = [
	MatButtonModule, MatFormFieldModule, MatInputModule, MatRippleModule, MatTableModule, 
    MatAutocompleteModule, MatSelectModule, MatDatepickerModule, MatStepperModule, MatProgressSpinnerModule, MatSortModule, 
    MatPaginatorModule, MatIconModule, MatCheckboxModule, MatRadioModule,MatListModule
];

@NgModule({
  declarations: [EmployeeComponent],
  imports: [
    CommonModule,modules,
    RouterModule.forChild(employeeComponentRoutes),
	FormsModule, ReactiveFormsModule, PartialsModule
  ]
})
export class EmployeeModule { }
