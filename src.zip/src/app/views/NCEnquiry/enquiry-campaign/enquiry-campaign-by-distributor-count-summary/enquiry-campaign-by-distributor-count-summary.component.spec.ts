import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnquiryCampaignByDistributorCountSummaryComponent } from './enquiry-campaign-by-distributor-count-summary.component';

describe('EnquiryCampaignByDistributorCountSummaryComponent', () => {
  let component: EnquiryCampaignByDistributorCountSummaryComponent;
  let fixture: ComponentFixture<EnquiryCampaignByDistributorCountSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnquiryCampaignByDistributorCountSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnquiryCampaignByDistributorCountSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
