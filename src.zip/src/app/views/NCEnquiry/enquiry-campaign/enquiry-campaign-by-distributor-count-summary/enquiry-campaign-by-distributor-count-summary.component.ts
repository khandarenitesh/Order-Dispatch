import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, AfterViewInit, ElementRef } from '@angular/core';

import { ActivatedRoute } from '@angular/router';

import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';

// Services
import { RequestCatcherCallService } from '../../../../services/RequestCatcherCall/request-catcher-call.service';
import { Subscription } from 'rxjs';
import { GetSessionService } from '../../../../services/globalsession.service';

@Component({
  selector: 'kt-enquiry-campaign-by-distributor-count-summary',
  templateUrl: './enquiry-campaign-by-distributor-count-summary.component.html',
  styleUrls: ['./enquiry-campaign-by-distributor-count-summary.component.scss']
})
export class EnquiryCampaignByDistributorCountSummaryComponent implements OnInit, OnDestroy, AfterViewInit {
  private unsubscribe: Subscription[] = [];
  type: string = "";
  distributorCountSummary = [];
  isLoading: boolean = false;
  DataSource = new MatTableDataSource<any>();
  @ViewChild('TABLE') table: ElementRef;
  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild('sort') sort: MatSort;
  displayedColumns = ['SrNo', 'EnquiryNo', 'MobileNo', 'CustomerName', 'Pincode', 'Area', 'CallReceivedDateAndTime', 'EnquiryStatus', 'ActionTakenDateAndTime'];
  distributorId: number = 0;

  constructor(private _RequestCatcherCallSevice: RequestCatcherCallService, private chRef: ChangeDetectorRef, private route: ActivatedRoute, private getSession: GetSessionService) { }

  ngOnInit() {
    this.distributorId = this.GetDistributorDetails(); // Get Distibutor Details
    this.type = this.route.snapshot.paramMap.get("type");
    switch (this.type) {
      case "NotAttendedES":
          console.log("NotAttendedES " + this.type);
          this.Get5KGAppuEnquiryCampaignByDistributorCountSummary(this.distributorId, this.type);
          this.type = this.type.replace("NotAttendedES", "Enquiry Status - Not Attended");
          break;
      case "Attended":
          console.log("Attended " + this.type);
          this.Get5KGAppuEnquiryCampaignByDistributorCountSummary(this.distributorId, this.type);
          this.type = this.type.replace("Attended", "Enquiry Status - Attended");
          break;
      case "Closed":
          console.log("Closed " + this.type);
          this.Get5KGAppuEnquiryCampaignByDistributorCountSummary(this.distributorId, this.type);
          this.type = this.type.replace("Closed", "Enquiry Status - Closed");
          break;
      case "NotAttendedAT":
          console.log("NotAttendedAT " + this.type);
          this.Get5KGAppuEnquiryCampaignByDistributorCountSummary(this.distributorId, this.type);
          this.type = this.type.replace("NotAttendedAT", "Action Taken - Not Attended");
          break;
      case "RefillProvided":
          console.log("RefillProvided " + this.type);
          this.Get5KGAppuEnquiryCampaignByDistributorCountSummary(this.distributorId, this.type);
          this.type = this.type.replace("RefillProvided", "Action Taken - Refill Provided");
          break;
      case "FTLProvided":
          console.log("FTLProvided " + this.type);
          this.Get5KGAppuEnquiryCampaignByDistributorCountSummary(this.distributorId, this.type);
          this.type = this.type.replace("FTLProvided", "Action Taken - FTL Provided");
          break;
      case "Others":
          console.log("Others " + this.type);
          this.Get5KGAppuEnquiryCampaignByDistributorCountSummary(this.distributorId, this.type);
          this.type = this.type.replace("Others", "Action Taken - Others (Remarks)");
          break;
      default:
          console.log("No such type exists!");
          break;
    }
  }

  // Get Distributor Details
  GetDistributorDetails() {
    let item = this.getSession.GetSessionData();
    return item.refNo;
  }

  // To Get 5KG Appu Enquiry Campaign By Distributor Count Summary
  Get5KGAppuEnquiryCampaignByDistributorCountSummary(distributorId: number, type: string) { 
    this.isLoading = true;
    this.unsubscribe.push(this._RequestCatcherCallSevice.Get5KGAppuEnquiryCampaignByDistributorCountSummary(distributorId, type).subscribe((data: any) => {
      if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
        this.distributorCountSummary = data;
        this.DataSource = new MatTableDataSource();
        this.DataSource.data = this.distributorCountSummary;
        this.DataSource.paginator = this.paginator;
        this.DataSource.sort = this.sort;
        this.isLoading = false;
        this.chRef.detectChanges();
      } else {
        this.distributorCountSummary = [];
        this.DataSource = new MatTableDataSource();
        this.DataSource.data.length = null;
        this.isLoading = false;
        this.chRef.detectChanges();
      }
    }, (error) => {
      this.isLoading = false;
      console.error("Error:   " + error);
    }));
  }
  
  // Angular Life Cycle hooks used
  ngAfterViewInit() {
    // hide menu
    this._RequestCatcherCallSevice.Toggler = new KTToggle('kt_aside_toggler', this._RequestCatcherCallSevice.toggleOptions);
    this._RequestCatcherCallSevice.DivToggleWidth = '100%';
    this._RequestCatcherCallSevice.IsModelOn = false;
    this._RequestCatcherCallSevice.displayValue = false;
    this._RequestCatcherCallSevice.Toggler.toggleOn();
    $('#kt_aside_close_btn').click();
    setTimeout(() => {
      this._RequestCatcherCallSevice.OpenToggle = true;
      this._RequestCatcherCallSevice.Toggler.toggleOn();
      $('#kt_aside_close_btn').click();
    }, 500);
  }

  ngOnDestroy() {
    this.unsubscribe.forEach(sb => sb.unsubscribe());
  }

}
