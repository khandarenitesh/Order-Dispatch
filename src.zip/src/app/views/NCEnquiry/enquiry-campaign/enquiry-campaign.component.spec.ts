import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnquiryCampaignComponent } from './enquiry-campaign.component';

describe('EnquiryCampaignComponent', () => {
  let component: EnquiryCampaignComponent;
  let fixture: ComponentFixture<EnquiryCampaignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnquiryCampaignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnquiryCampaignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
