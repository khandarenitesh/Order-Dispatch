import { ChangeDetectorRef, Component, OnInit, ViewChild, ElementRef, OnDestroy, AfterViewInit, ChangeDetectionStrategy } from '@angular/core';

import { MatPaginator, MatSort, MatTableDataSource, MatSelectChange, MatOption } from '@angular/material';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

// Services
import { RequestCatcherCallService } from '../../../services/RequestCatcherCall/request-catcher-call.service';
import { ToastrService } from 'ngx-toastr';
import { Subscription, timer, Observable } from 'rxjs';
import { switchMap, startWith, map } from 'rxjs/operators';
import moment = require('moment');
import { GetSessionService } from '../../../services/globalsession.service';

@Component({
  selector: 'kt-enquiry-campaign',
  templateUrl: './enquiry-campaign.component.html',
  styleUrls: ['./enquiry-campaign.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EnquiryCampaignComponent implements OnInit, OnDestroy, AfterViewInit {
  private unsubscribe: Subscription[] = [];
  postModal: any;
  DataSource = new MatTableDataSource<any>();
  @ViewChild('TABLE') table: ElementRef;
  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild('sort') sort: MatSort;
  displayedColumns = ['SrNo', 'EnquiryNo', 'MobileNo', 'CustomerName', 'Pincode', 'Area', 'CallReceivedDateAndTime', 'EnquiryStatus', 'ActionTaken', 'ActionTakenDateAndTime'];
  EnquiryStatusTitle: string = "";
  EnquiryActionTitle: string = "";
  closeResult: string = "";
  EnquiryStatusFeedback: string = "";
  EnquiryActionTakenFeedback: string = "";
  EnquiryStatusList: any[] = [];
  EnquiryActionList: any[] = [];
  EnquiryStatus: any;
  EnquiryAction: any;
  FromDate: any = null;
  ToDate: any = null;
  isLoading: boolean = false;
  distributorId: number = 0;
  _TempModel: TempModel;
  FromDateResult: Date;
  ToDateResult: Date;
  postModel: any;
  public selectedDate: any;
  pkId: number = 0;
  EnquiryStatusName: string = "";
  EnquiryActionTakenName: string = "";
  modalReference: NgbModalRef;
  distributorCountArray = [];
  subscription: Subscription;

  constructor(private chRef: ChangeDetectorRef, private _RequestCatcherCallSevice: RequestCatcherCallService, 
              private toastr: ToastrService, private modalService: NgbModal, private getSession: GetSessionService) { }

  ngOnInit() {
    this._TempModel = new TempModel();
    let d = new Date();
    this.FromDateResult = d;
    this.ToDateResult = d;
    this._TempModel = {
      FromDate: this.ConvertStringToDateObj(this.FromDateResult),
      ToDate: this.ConvertStringToDateObj(this.ToDateResult)
    };
    this.selectedDate = this.ConvertStringToDateObj(d);
    this.distributorId = this.GetDistributorDetails(); // Get Distibutor Details
    this.Get5KGAppuEnquiryCampaignByDistributorCount(this.distributorId);
    this.Get5KGAppuEnquiryCampaignList(this._TempModel);

    // To Get 5KG Appu Enquiry Campaign By Distributor - DistributorId, FromDate and ToDate
    this.subscription = timer(0, 10000)
        .pipe(
         switchMap(() => 
         this._RequestCatcherCallSevice.Get5KGAppuEnquiryCampaignByDistributor(this.distributorId, this.ConvertDateFormat(this._TempModel.FromDate), 
         this.ConvertDateFormat(this._TempModel.ToDate)))
        ).subscribe(async (data) => {
         console.log("Distributor -> timer used service every 10 seconds");
         if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
          this.DataSource = new MatTableDataSource();
          this.DataSource.data = data;
          this.DataSource.paginator = this.paginator;
          this.DataSource.sort = this.sort;
          this.isLoading = false;
          this.chRef.detectChanges();
        } else {
          this.DataSource = new MatTableDataSource();
          this.DataSource.data.length = null;
          this.isLoading = false;
          this.chRef.detectChanges();
        }
        await this.Get5KGAppuEnquiryCampaignByDistributorCount(this.distributorId);
    });
  }

  // Use to convert string to date obj
  ConvertStringToDateObj(SelDate) {
    let d = new Date(moment(SelDate, 'DD-MM-YYYY hh:mm tt').format('YYYY-MM-DD'));
    return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() };
  }

  // Get Distributor Details
  GetDistributorDetails() {
    let item = this.getSession.GetSessionData();
    return item.refNo;
  }

  onDateSelect(dateResult: Date) {
    return dateResult;
  }

  // To Get 5 KG Appu Enquiry Campaign By Distributor Count
  Get5KGAppuEnquiryCampaignByDistributorCount(distributorId: number) {
    this.isLoading = true;
    this.unsubscribe.push(this._RequestCatcherCallSevice.Get5KGAppuEnquiryCampaignByDistributorCount(distributorId).subscribe((data: any) => {
      if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
        this.distributorCountArray = data;
        this.isLoading = false;
        this.chRef.detectChanges();
      }
    }, (error) => {
      this.isLoading = false;
      console.error("Error:   " + error);
    }));
  }

  Get5KGAppuEnquiryCampaignList(model: TempModel) {
    this.postModel = {
      FromDate: this.ConvertDateFormat(model.FromDate),
      ToDate: this.ConvertDateFormat(model.ToDate)
    };
    this.Get5KGAppuEnquiryCampaignByDistributor(this.postModel.FromDate, this.postModel.ToDate);
  }

  // To Get 5KG Appu Enquiry Campaign By Distributor - DistributorId, FromDate and ToDate
  Get5KGAppuEnquiryCampaignByDistributor(FromDate: any, ToDate: any) {
    this.isLoading = true;
    this.unsubscribe.push(this._RequestCatcherCallSevice.Get5KGAppuEnquiryCampaignByDistributor(this.distributorId, FromDate, ToDate).subscribe((data: any) => {
      if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
        this.DataSource = new MatTableDataSource();
        this.DataSource.data = data;
        this.DataSource.paginator = this.paginator;
        this.DataSource.sort = this.sort;
        this.isLoading = false;
        this.chRef.detectChanges();
      } else {
        this.DataSource = new MatTableDataSource();
        this.DataSource.data.length = null;
        this.isLoading = false;
        this.chRef.detectChanges();
      }
    }, (error) => {
      this.isLoading = false;
      console.error("Error:   " + error);
    }));
  }

  // // after click on update status open pop-up window for Enquiry Status 
  // OpenEnquiryStatus(content, ref: any) {
  //   this.EnquiryStatus = "";
  //   this.EnquiryStatusFeedback = "";
  //   this.pkId = ref.pkid;
  //   this.getEnquiryStatus();
  //   this.EnquiryStatusTitle = "Enquiry Status";
  //   this.getModalService(content);
  // }

  // // To Get 5KG Appu Enquiry Status
  // getEnquiryStatus() {
  //   this.unsubscribe.push(this._RequestCatcherCallSevice.Get5KGAppuEnquiryStatus()
  //       .subscribe(data => {
  //         this.EnquiryStatusList = data;
  //         this.EnquiryStatus =  this.EnquiryStatusList[0].pkid; // Set Default Value (Not Attended)
  //         this.chRef.detectChanges();
  //       }));
  // }

  // // On Selected Value Enquiry Status
  // onEnquiryStatus(ev: MatSelectChange) {
  //   this.EnquiryStatusName = (ev.source.selected as MatOption).viewValue;
  // }

  // // Update Enquiry Status
  // UpdateEnquiryStatus() {
  //   // Case: By Default Not Attended
  //   if (this.EnquiryStatus === 1 && this.EnquiryStatusFeedback === "") {
  //     this.EnquiryStatusName = "Not Attended";
  //     this.EnquiryStatusFeedback = "None";
  //   } else if (this.EnquiryStatus === 1 && this.EnquiryStatusFeedback !== "") {
  //     this.EnquiryStatusName = "Not Attended";
  //   }
  //   this.isLoading = true;
  //   this.unsubscribe.push(this._RequestCatcherCallSevice.Update5KGAppuEnquiryStatusDistributor(this.pkId, this.distributorId, this.EnquiryStatusName, this.EnquiryStatusFeedback).subscribe((data: any) => {
  //     if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
  //       if (data === 'Success') {
  //         this.toastr.success("Update Enquiry Status", "Successfully");
  //         this.modalReference.close();
  //         this.Get5KGAppuEnquiryCampaignByDistributor(this.ConvertDateFormat(this._TempModel.FromDate), this.ConvertDateFormat(this._TempModel.ToDate));
  //         this.Get5KGAppuEnquiryCampaignByDistributorCount(this.distributorId);
  //         this.isLoading = false;
  //         this.chRef.detectChanges();
  //       } else {
  //         this.toastr.warning("Update Enquiry Status", "Failed");
  //         this.isLoading = false;
  //         this.chRef.detectChanges();
  //       }
  //     }
  //   }, (error) => {
  //     this.isLoading = false;
  //     console.error("Error:   " + error);
  //   }));
  // }

  // after click on update action open pop-up window for Action Taken
  OpenActionTaken(content, ref: any) {
    this.EnquiryAction = "";
    this.EnquiryActionTakenFeedback = "";
    this.pkId = ref.pkid;
    this.getEnquiryAction();
    this.EnquiryActionTitle = "Enquiry Action Taken";
    this.getModalService(content);
  }

  // To Get 5KG Appu Enquiry Action Taken
  getEnquiryAction() {
    this.unsubscribe.push(this._RequestCatcherCallSevice.Get5KGAppuEnquiryActionTaken()
        .subscribe(data => {
          this.EnquiryActionList = data;
          this.EnquiryAction =  this.EnquiryActionList[0].pkid; // Set Default Value (Not Attended)
          this.chRef.detectChanges();
        }));
  }

  // On Selected Value Enquiry Action
  onEnquiryAction(ev: MatSelectChange) {
    this.EnquiryActionTakenName = (ev.source.selected as MatOption).viewValue;
  }

  // Update Enquiry Action Taken
  UpdateEnquiryActionTaken() {
    // Case: By Default Not Attended
    if (this.EnquiryAction === 1 && this.EnquiryActionTakenFeedback === "") {
      this.EnquiryActionTakenName = "Not Attended";
      this.EnquiryActionTakenFeedback = "None";
    } else if (this.EnquiryAction === 1 && this.EnquiryActionTakenFeedback !== "") {
      this.EnquiryActionTakenName = "Not Attended";
    }
    this.isLoading = true;
    this.unsubscribe.push(this._RequestCatcherCallSevice.Update5KGAppuEnquiryActionDistributor(this.pkId, this.distributorId, this.EnquiryActionTakenName, this.EnquiryActionTakenFeedback).subscribe((data: any) => {
      if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
        if (data === 'Success') {
          this.toastr.success("Update Enquiry Action Taken", "Successfully");
          this.modalReference.close();
          this.Get5KGAppuEnquiryCampaignByDistributor(this.ConvertDateFormat(this._TempModel.FromDate), this.ConvertDateFormat(this._TempModel.ToDate));
          this.Get5KGAppuEnquiryCampaignByDistributorCount(this.distributorId);
          this.isLoading = false;
          this.chRef.detectChanges();
        } else {
          this.toastr.warning("Update Enquiry Action Taken", "Failed");
          this.modalReference.close();
          this.Get5KGAppuEnquiryCampaignByDistributor(this.ConvertDateFormat(this._TempModel.FromDate), this.ConvertDateFormat(this._TempModel.ToDate));
          this.Get5KGAppuEnquiryCampaignByDistributorCount(this.distributorId);
          this.isLoading = false;
          this.chRef.detectChanges();
        }
      }
    }, (error) => {
      this.isLoading = false;
      console.error("Error:   " + error);
    }));
  }

  // Apply Filter
  applyFilter(filterValue: string) {
    this.isLoading = true;
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.DataSource.filter = filterValue;
    this.isLoading = false;
  }

  // To Get Modal Service - Modal Popup (Large Size)
  getModalService(content) {
    this.modalReference = this.modalService.open(content, {
      centered: true,
      size: 'lg',
      backdrop: 'static'
    });
  }
  
  // ConvertDateFormat
  ConvertDateFormat(condate) {
    let dateInput = new Date(condate.year, condate.month - 1, condate.day);
    return moment(dateInput).format('YYYY-MM-DD');
  }

  // To Get 5KG Appu Enquiry Campaign By Distributor Count Summary
  onGet5KGAppuEnquiryCampaignByDistributorCountSummary(type: string) {
    switch (type) {
      case "NotAttendedES":
          console.log("NotAttendedES " + type);
          window.open(`#/default/5KGAppuEnquiryCampaignByDistributorSummary/${type}`, "_blank");
          break;
      case "Attended":
          console.log("Attended " + type);
          window.open(`#/default/5KGAppuEnquiryCampaignByDistributorSummary/${type}`, "_blank");
          break;
      case "Closed":
          console.log("Closed " + type);
          window.open(`#/default/5KGAppuEnquiryCampaignByDistributorSummary/${type}`, "_blank");
          break;
      case "NotAttendedAT":
          console.log("NotAttendedAT " + type);
          window.open(`#/default/5KGAppuEnquiryCampaignByDistributorSummary/${type}`, "_blank");
          break;
      case "RefillProvided":
          console.log("RefillProvided " + type);
          window.open(`#/default/5KGAppuEnquiryCampaignByDistributorSummary/${type}`, "_blank");
          break;
      case "FTLProvided":
          console.log("FTLProvided " + type);
          window.open(`#/default/5KGAppuEnquiryCampaignByDistributorSummary/${type}`, "_blank");
          break;
      case "Others":
          console.log("Others " + type);
          window.open(`#/default/5KGAppuEnquiryCampaignByDistributorSummary/${type}`, "_blank");
          break;
      default:
          console.log("No such type exists!");
          break;
    }
  }

  // Angular Life Cycle hooks used
  ngAfterViewInit() {
    // hide menu
    this._RequestCatcherCallSevice.Toggler = new KTToggle('kt_aside_toggler', this._RequestCatcherCallSevice.toggleOptions);
    this._RequestCatcherCallSevice.DivToggleWidth = '100%';
    this._RequestCatcherCallSevice.IsModelOn = false;
    this._RequestCatcherCallSevice.displayValue = false;
    this._RequestCatcherCallSevice.Toggler.toggleOn();
    $('#kt_aside_close_btn').click();
    setTimeout(() => {
      this._RequestCatcherCallSevice.OpenToggle = true;
      this._RequestCatcherCallSevice.Toggler.toggleOn();
      $('#kt_aside_close_btn').click();
    }, 500);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.unsubscribe.forEach(sb => sb.unsubscribe());
  }
}

// TempModel
export class TempModel {
  FromDate: any;
  ToDate: any;
}