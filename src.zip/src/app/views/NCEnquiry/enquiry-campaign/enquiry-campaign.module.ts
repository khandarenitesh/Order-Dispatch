import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../../../app/core/auth';
import {
	MatButtonModule, MatInputModule, MatTableModule, MatStepperModule, MatProgressSpinnerModule, MatAutocompleteModule,
	MatRippleModule, MatFormFieldModule, MatSelectModule, MatDatepickerModule, MatCheckboxModule, MatIconModule, MatPaginatorModule, MatSortModule, MatRadioModule, MatTooltipModule,
	MatCardModule
} from '@angular/material';
import { MatTableExporterModule } from 'mat-table-exporter';
import { ToastrService } from 'ngx-toastr';
import { GetSessionService } from '../../../services/globalsession.service';
import { PartialsModule } from '../../partials/partials.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '../../../../../src/app/core/core.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';
import { EnquiryCampaignComponent } from './enquiry-campaign.component';
import { EnquiryCampaignByDistributorCountSummaryComponent } from './enquiry-campaign-by-distributor-count-summary/enquiry-campaign-by-distributor-count-summary.component';

const enquiryCampaignComponentRoutes: Routes = [
	{
		path: '',
		children: [
			{ path: '5KGAppuEnquiryCampaign', component: EnquiryCampaignComponent, canActivate: [AuthGuard], data: { roles: ['3'] } },
			{ path: '5KGAppuEnquiryCampaignByDistributorSummary/:type', component: EnquiryCampaignByDistributorCountSummaryComponent, canActivate: [AuthGuard], data: { roles: ['3'] } }
		]
	}
];

const modules = [
	MatButtonModule, MatFormFieldModule,
	MatInputModule, MatRippleModule,
	MatTableModule, MatAutocompleteModule, MatSelectModule, MatDatepickerModule, MatStepperModule,
	MatProgressSpinnerModule,
	MatSortModule, MatPaginatorModule, MatIconModule, MatTableExporterModule, MatCheckboxModule, MatRadioModule,
	MatCardModule
];


@NgModule({
	declarations: [EnquiryCampaignComponent, EnquiryCampaignByDistributorCountSummaryComponent],
	providers: [GetSessionService, ToastrService],
	imports: [
		modules,
		FormsModule,
		ReactiveFormsModule,
		CommonModule,
		PartialsModule,
		CoreModule,
		NgbModule,
		MatTooltipModule,
		DataTablesModule,
		RouterModule.forChild(enquiryCampaignComponentRoutes)
	],
	exports: [RouterModule],

})
export class EnquiryCampaignModule { }
