import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportWatiDataSurakshaComponent } from './import-wati-data-suraksha.component';

describe('ImportWatiDataSurakshaComponent', () => {
  let component: ImportWatiDataSurakshaComponent;
  let fixture: ComponentFixture<ImportWatiDataSurakshaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportWatiDataSurakshaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportWatiDataSurakshaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
