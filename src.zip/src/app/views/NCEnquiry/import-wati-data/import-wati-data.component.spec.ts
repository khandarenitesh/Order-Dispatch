import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportWatiDataComponent } from './import-wati-data.component';

describe('ImportWatiDataComponent', () => {
  let component: ImportWatiDataComponent;
  let fixture: ComponentFixture<ImportWatiDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportWatiDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportWatiDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
