
import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DistributorConnTypePrice } from '../../../models/DistributorConn/distributor-conn-type-price.model';
import { ToastrService } from 'ngx-toastr';
import { DistributorConnTypeService } from '../../../services/DistributorConn/distributor-conn-type.service';
import { updateLocale } from 'ngx-bootstrap/chronos/public_api';
import { DatePipe } from '@angular/common';
import { StoveItemService } from '../../../services/StoveItem/stove-item.service';
import { StoveItem } from '../../../models/StoveItem/stove-item.model';
import { DistributorStaffService } from '../../../services/DistributorStaff/distributor-staff.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DistStaff } from '../../../models/Distributorstaff/dist-staff.model';
import { MatStepper, MatInput } from '@angular/material';
import { GetSessionService } from '../../../services/globalsession.service';
import { DistributorDashboardService } from '../../../services/Dashboard/dashboard.service';



const stepperOverview = {
  beforeCodeTitle: 'Stepper overview',
  htmlCode: `
<mat-list>
<h3 mat-subheader>Folders</h3>
<mat-list-item *ngFor="let folder of folders">
  <mat-icon mat-list-icon>folder</mat-icon>
<h4 mat-line>{{folder.name}}</h4>
  <p mat-line> {{folder.updated | date}} </p>
</mat-list-item>
<mat-divider></mat-divider>
<h3 mat-subheader>Notes</h3>
<mat-list-item *ngFor="let note of notes">
  <mat-icon mat-list-icon>note</mat-icon>
  <h4 mat-line>{{note.name}}</h4>
  <p mat-line> {{note.updated | date}} </p>
</mat-list-item>
</mat-list>
`,
  tsCode: `
import {Component} from '@angular/core';\n
/**
* @title List with sections
*/
@Component({
selector: 'list-sections-example',
styleUrls: ['list-sections-example.css'],
templateUrl: 'list-sections-example.html',
})
export class ListSectionsExample {
folders = [
{
  name: 'Photos',
  updated: new Date('1/1/16'),
},
{
  name: 'Recipes',
  updated: new Date('1/17/16'),
},
{
  name: 'Work',
  updated: new Date('1/28/16'),
}
];
notes = [
{
  name: 'Vacation Itinerary',
  updated: new Date('2/20/16'),
},
{
  name: 'Kitchen Remodel',
  updated: new Date('1/18/16'),
}
];
}
`,
  cssCode: `
.mat-list-icon {
color: rgba(0, 0, 0, 0.54);
}
`,
  viewCode: ``,
  isCodeVisible: false,
  isExampleExpanded: true
};

@Component({
  selector: 'kt-mandatory-stepper',
  templateUrl: './mandatory-stepper.component.html',
  styleUrls: ['./mandatory-stepper.component.scss'],
  providers: [DistributorDashboardService]
})
export class MandatoryStepperComponent implements OnInit {

  exampleBasicStepper;
  exampleHorizontalStepper;
  exampleStepperOverview;


  // Defalut
  isLinear = true;
  isCompleted = false;


  // Step 1 Variable  - RSP and Contact Model
  _ContactDetails: DistributorConnTypePrice;


  // Step 1 Variable  - RSP and Contact Model
  _Rspamount: DistributorConnTypePrice;

  // Step 2 Variable Declare - Stove item details
  _stoveTypeLst: StoveItem[];
  _stoveItemDtls: StoveItem;
  Temp: any;

  // Step  3 Variable - Add Distributor Staff Details

  _DistStaffModel: DistStaff;
  postModal: any;
  _ConnTypeLst: DistributorConnTypePrice;

  StepperFirst: boolean;
  StepperRSP: boolean;
  StepperSecond: boolean;
  StepperThird: boolean;
  StepperFour: boolean;
  finalStepper: boolean;


  StepperFirstTP: boolean;
  StepperRSPTP: boolean;
  StepperSecondTP: boolean;
  StepperThirdTP: boolean;
  StepperFourTP: boolean;


  Counter: number;
  StepCount1: number;
  StepCount2: number;
  StepCount3: number;
  StepCount4: number;
  StepCount5: number;
  SessionData: string;


  LanguageMst: any[];
  _DistLangaugeModel: any;


  constructor(
    private distributorConnTypeService: DistributorConnTypeService,
    private distributorStaffService: DistributorStaffService,
    private dashboardService: DistributorDashboardService,
    private chRef: ChangeDetectorRef,
    private router: Router,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    private _stoveItemService: StoveItemService,
    public datepipe: DatePipe,
    private getSession: GetSessionService) { }

  ngOnInit() {


    this.Counter = 0;
    this.StepCount1 = 1;
    this.StepCount2 = 2;
    this.StepCount3 = 3;
    this.StepCount4 = 4;
    this.StepCount5 = 5;

    this.LanguageMst = [];

    this.StepperFirst = true;
    this.StepperRSP = true;
    this.StepperSecond = true;
    this.StepperThird = true;
    this.StepperFour = true;
    this.finalStepper = true;

    this.StepperFirstTP = true;
    this.StepperRSPTP = true;
    this.StepperSecondTP = true;
    this.StepperThirdTP = true;
    this.StepperFourTP = true;

    $('.custom_Test').css('display', 'none');


    this._Rspamount = new DistributorConnTypePrice();
    this._Rspamount.Flag = 'RSP';
    this._ContactDetails = new DistributorConnTypePrice();
    this._ContactDetails.Flag = 'CONTACTNO';
    this._stoveItemDtls = new StoveItem();
    this._DistStaffModel = new DistStaff();
    this.postModal = {
      'DistributorId': this.GetLoginDetails()
    };
    this.CheckMandatoryDetails(this.postModal);
    // this.exampleBasicStepper = basicStepper;
    // this.exampleHorizontalStepper = horizontalStepper;
    this.exampleStepperOverview = stepperOverview;

    this.GetStoveTypeLst();
    this.GetLanguageMaster();

    this._DistLangaugeModel = {
      DistributorId: this.GetLoginDetails(),
      LanguageId: 0,
      LanguageName: '',
      ActiveStatus: 'Y',
    };

  }



  CheckMandatoryDetails(postdata) {

    this.distributorConnTypeService.GetDistConnTypePriceDtls(postdata)
      .subscribe(data => {
        this._ConnTypeLst = data.GetDistConnType;
        if (this._ConnTypeLst.ContactNo === null || this._ConnTypeLst.ContactNo === '') {
          this.StepperFirst = false;
          this.StepperFirstTP = false;
          this.finalStepper = false;
          this.Counter = this.Counter + 1;
          this.StepCount1 = this.Counter;

        }
        if (this._ConnTypeLst.RSP === null || this._ConnTypeLst.RSP === 0) {
          this.StepperRSP = false;
          this.StepperRSPTP = false;
          this.finalStepper = false;
          this.Counter = this.Counter + 1;
          this.StepCount2 = this.Counter;
        }
        if (this._ConnTypeLst.StoveBrandCnt === 0) {
          this.StepperSecond = false;
          this.StepperSecondTP = false;
          this.finalStepper = false;
          this.Counter = this.Counter + 1;
          this.StepCount3 = this.Counter;
        }
        if (this._ConnTypeLst.DistributorStaffCnt === 0) {
          this.StepperThird = false;
          this.StepperThirdTP = false;
          this.finalStepper = false;
          this.Counter = this.Counter + 1;
          this.StepCount4 = this.Counter;
        }
        if (this._ConnTypeLst.LanguageId === 0) {

          this.StepperFour = false;
          this.StepperFourTP = false;
          this.finalStepper = false;
          this.Counter = this.Counter + 1;
          this.StepCount5 = this.Counter;
        }

        // this.finalStepper;
        if (this._ConnTypeLst !== null && this.finalStepper === true) {
          this.router.navigateByUrl('/default/dashboard');
        }

        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      },
        (error) => {
          console.error(error);
        });
  }

  GetLoginDetails() {
    let item = this.getSession.GetSessionData();
    return item.refNo;
  }

  // First Step Record Save  RSP and distributor Contact Details
  _SaveFirstStepDetails(UpdateRspDetails: DistributorConnTypePrice) {

    UpdateRspDetails.DistributorId = this.GetLoginDetails();
    UpdateRspDetails.ActiveStatus = 'Y';
    // UpdateRspDetails.Flag = 'Both';
    this.distributorConnTypeService.saveDistConnTypePriceDtls(UpdateRspDetails).subscribe(data => {
      if (data.Status === 'Success') {
        if (data.StaffRefNo === -1) {
          this.toastr.error('Record not exists.', 'Nc Enquiry', { timeOut: 2000 });
        } else if (data.StaffRefNo > 0) {
          // this.router.navigateByUrl("/default/getConsumerEnquiry");

          if (UpdateRspDetails.Flag === 'CONTACTNO') {
            this.toastr.success('Contect Details Updated Successfully.', 'First Step completed', { timeOut: 2000 });
            this.StepperFirstTP = true;
          } else if (UpdateRspDetails.Flag === 'RSP') {
            this.toastr.success('RSP Amount  Updated Successfully.', ' RSP Updated', { timeOut: 2000 });
            this.StepperRSPTP = true;
          }

          if (this.StepperFirstTP === true && this.StepperRSPTP === true && this.StepperSecondTP === true && this.StepperThirdTP === true && this.StepperFourTP === true) {
            this.router.navigateByUrl('/default/dashboard');
          }
        } else {
          this.toastr.error('Network error', 'First Step', { timeOut: 2000 });
        }

        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      }
    });
  }

  // second Step Save Stove item Details ---Step 2

  // Get Stove  list
  GetStoveTypeLst() {
    this._stoveItemService.getStoveTypeDetails(this.Temp)
      .subscribe(data => {
        this._stoveTypeLst = data.stoveItemList;
        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      },
        (error) => {
          console.error(error);
        });
  }

  // Get Language Master
  GetLanguageMaster() {
    this.dashboardService.GetLanguageMaster(this.Temp)
      .subscribe(data => {
        this.LanguageMst = data.LangList;
        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      },
        (error) => {
          console.error(error);
        });
  }






  // Save Stove Item Details
  _SaveStoveItem(StoveItemForm: StoveItem) {
    // Converting all date format
    StoveItemForm.DistributorId = this.GetLoginDetails();
    StoveItemForm.Operation = 'ADD';

    this._stoveItemService.saveStoveItemDetails(StoveItemForm).subscribe(data => {
      if (data.Status === 'Success') {
        if (data.StaffRefNo === -1) {
          this.toastr.error('Stove Brand already exists.', 'Stove Brand Master', { timeOut: 2000 });
        } else if (data.StaffRefNo === -2) {
          // this.toastr.error("Phone No already exists.", "Stove Item Master", {timeOut: 2000});
        } else if (data.StaffRefNo > 0) {
          this.StepperSecondTP = true;
          if (this.StepperFirstTP === true && this.StepperRSPTP === true && this.StepperSecondTP === true && this.StepperThirdTP === true && this.StepperFourTP === true) {
            this.router.navigateByUrl('/default/dashboard');
          }

          this.toastr.success('Record Inserted Successfully.', 'Stove Brand Master', { timeOut: 2000 });
        }

        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      }
    });
  }

  // Save Distributor Staff Details
  _SaveDistributorStaff(productForm: DistStaff) {
    // Converting all date format

    productForm.DistributorId = this.GetLoginDetails();
    productForm.Operation = 'ADD';

    this.distributorStaffService.saveDistStaffDetails(productForm).subscribe(data => {
      if (data.Status === 'Success') {
        if (data.StaffRefNo === -1) {
          this.toastr.error('Distributor Staff already exists.', 'Distributor Staff Master', { timeOut: 2000 });
        } else if (data.StaffRefNo === -2) {
          this.toastr.error('Phone No already exists.', 'Distributor Staff Master', { timeOut: 2000 });
        } else if (data.StaffRefNo > 0) {
          // this.StepperThird = true;
          this.StepperThirdTP = true;
          this.toastr.success('Record Inserted Successfully.', 'Distributor Staff Master', { timeOut: 2000 });
          if (this.StepperFirstTP === true && this.StepperRSPTP === true && this.StepperSecondTP === true && this.StepperThirdTP === true && this.StepperFourTP === true) {
            this.router.navigateByUrl('/default/dashboard');
          }
        }
        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      }

    });
  }

  // Get Language Master
  _SaveDistributorLanguage(LangModel: any) {

    this.dashboardService.SaveDistributorLanguageDtls(LangModel)
      .subscribe(data => {
        if (data.Status === 'Success') {
          if (data.ResultId === -1) {
            this.toastr.error('Distributor Language not Save', 'Distributor Language', { timeOut: 2000 });
          } else if (data.ResultId > 0) {
            this.router.navigateByUrl('/default/dashboard');
            this.toastr.success('Distributor Language Saved Successfully.', 'Distributor Language', { timeOut: 2000 });
          }

          if (!this.chRef['destroyed']) {
            this.chRef.detectChanges();
          }
        }
      },
        (error) => {
          console.error(error);
        });
  }

}
