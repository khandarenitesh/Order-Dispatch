import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { MandatoryStepperComponent } from './mandatory-stepper.component';
import { AuthGuard } from '../../../../app/core/auth';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MatButtonModule, MatInputModule, MatTableModule, MatStepperModule, MatProgressSpinnerModule, MatAutocompleteModule, MatRippleModule, MatFormFieldModule, MatSelectModule, MatDatepickerModule, MatCheckboxModule, MatIconModule, MatPaginatorModule, MatSortModule, MatRadioModule, MatTabsModule, MatProgressBarModule, MatTooltipModule } from '@angular/material';
import { MatTableExporterModule } from 'mat-table-exporter';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { PartialsModule } from '../../partials/partials.module';
import { CoreModule } from '../../../../app/core/core.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';
import { ToastrService } from 'ngx-toastr';
import { GetSessionService } from '../../../../app/services/globalsession.service';
import { HtmlClassService } from '../../themes/default/html-class.service';


const MandatoryStepperroutes: Routes = [
  {
    path: '',
    // component: DistributorStaffComponent,
    children: [
      { path: 'MandatoryStepper', component: MandatoryStepperComponent, canActivate: [AuthGuard], data: { roles: ['1', '2', '3'] } },
      { path: 'MandatoryStepper/:SessionData', component: MandatoryStepperComponent },
    ]
  }
];
const modules = [
	MatButtonModule,MatFormFieldModule,
	MatInputModule,MatRippleModule,
	MatTableModule,MatAutocompleteModule,MatSelectModule,MatDatepickerModule,MatStepperModule,
  MatProgressSpinnerModule,
  MatSortModule,MatPaginatorModule,MatIconModule,MatTableExporterModule,MatCheckboxModule,MatRadioModule
];

@NgModule({
  declarations: [MandatoryStepperComponent],
  providers: [HtmlClassService,GetSessionService,ToastrService],
  imports: [
    modules,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    PartialsModule,
    CoreModule,
    NgbModule,
    MatTooltipModule,
    DataTablesModule,
    MatProgressBarModule,
    MatTabsModule,
    RouterModule.forChild(MandatoryStepperroutes)
  ], schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [RouterModule]
})
export class MandatoryStepperModule { }
