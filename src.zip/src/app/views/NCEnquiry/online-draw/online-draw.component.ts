import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { interval, Subscription } from 'rxjs';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { TokenDistributorService } from '../../../services/TokenDistributor/token-distributor.service';

@Component({
  selector: 'kt-online-draw',
  templateUrl: './online-draw.component.html',
  styleUrls: ['./online-draw.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class OnlineDrawComponent implements OnInit, OnDestroy {
  private unsubscribe: Subscription[] = [];
  SelectedSA: any;
  displayedColumns = ['Winner', 'DistributorName', 'SAName', 'Token'];
  SAList = [];
  Winner: any;
  ActiveFlags: number = 0;
  TokenNumber: any = '000000';
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  DataSource = new MatTableDataSource<any>();
  flag: boolean = true;
  subscription: Subscription;
  search: string = '';
  isLoading: boolean = false;

  constructor(private chRef: ChangeDetectorRef, private _tokenDistributorService: TokenDistributorService, private toastr: ToastrService) { }

  ngOnInit() {
    this.GetSAList();
  }

  GetSAList() {
    this.unsubscribe.push(this._tokenDistributorService.GetSA_service()
      .subscribe(async (data) => {
        this.SAList = [];
        this.SAList = await data;
        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      },
        (error) => {
          console.error(error);
        })
    );
  }

  onStart(data) {
    this.ActiveFlags = 0;
    this.ActiveFlags = data;
    if (this.ActiveFlags >= 4) {
      this.toastr.error('Online Draw Completed for This Sales Area');
    } else {
      this.flag = false;
      this.subscription = interval(300).subscribe((func => {
        this.TokenNumber = Math.floor(Math.random() * 899999 + 100000);
        this.chRef.detectChanges();
      }));
    }
  }

  onStop() {
    this.subscription.unsubscribe();
    let model = {
      SAId: this.SelectedSA
    };
    this.unsubscribe.push(this._tokenDistributorService.GetWinner_service(model)
      .subscribe(async (data) => {
        if (data !== []) {
          this.flag = true;
          this.Winner = null;
          this.Winner = await data;
          this.GetDistributorList(this.SelectedSA);
          this.TokenNumber = null;
          this.TokenNumber = this.Winner.Token;
          this.toastr.success('Winner is Token Number : ' + this.TokenNumber);
          if (!this.chRef['destroyed']) {
            this.chRef.detectChanges();
          }
        } else {
          // toaster code error
          this.toastr.error('no data found !');
        }
      }, (error) => {
        console.error(error);
      })
    );

  }

  GetDistributorList(SelectedSA) {
    this.isLoading = true;
    this.search = '';
    let model = {
      SAId: SelectedSA
    };
    this.unsubscribe.push(this._tokenDistributorService.GetWinnerDistributors_service(model)
      .subscribe(data => {
        this.DataSource = new MatTableDataSource();
        this.DataSource.data = data;
        this.DataSource.paginator = this.paginator;
        this.DataSource.sort = this.sort;
        this.isLoading = false;
      }));
  }

  GetActiveFlags() {
    let model = {
      SAId: this.SelectedSA
    };
    this.unsubscribe.push(this._tokenDistributorService.GetActiveFlags_service(model)
      .subscribe(async (data) => {
        await this.onStart(data);
      }, (error) => {
        console.error(error);
      })
    );
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.DataSource.filter = filterValue;
  }

  ngOnDestroy() {
    this.unsubscribe.forEach(sb => sb.unsubscribe());
  }

}



