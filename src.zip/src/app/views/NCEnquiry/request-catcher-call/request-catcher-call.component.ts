import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, ChangeDetectionStrategy, AfterViewInit } from '@angular/core';
import { trigger, state, transition, style, animate } from '@angular/animations';
import { FormControl } from '@angular/forms';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import moment = require('moment');

// Models
import { RequestCatcherCallModel, Get5KGAppuCampaignByAdminCountModel,
         Get5KGAppuCampaignByDistributorCountModel, Get5KGAppuCampaignByPincodeModel, Update5KGAppuCampaignByPincodeModel }
from '../../../models/RequestCatcherCall/request-catcher-call.model';

// Services
import { RequestCatcherCallService } from '../../../services/RequestCatcherCall/request-catcher-call.service';
import { GetSessionService } from '../../../services/globalsession.service';
import { ToastrService } from 'ngx-toastr';
import { Subscription, timer, Observable } from 'rxjs';
import { switchMap, startWith, map } from 'rxjs/operators';
declare var $: any;

@Component({
  selector: 'kt-request-catcher-call',
  templateUrl: './request-catcher-call.component.html',
  styleUrls: ['./request-catcher-call.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class RequestCatcherCallComponent implements OnInit, OnDestroy, AfterViewInit {
  private unsubscribe: Subscription[] = [];
  requestCatcherCallModel: RequestCatcherCallModel;
  get5KGAppuCampaignByPincodeModel: Get5KGAppuCampaignByPincodeModel;
  update5KGAppuCampaignByPincodeModel: Update5KGAppuCampaignByPincodeModel;
  public DataSource = new MatTableDataSource<any>();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns =  ['SrNo', 'EnquiryNo', 'CustomerContactNo', 'CallType', 'Duration', 'CallDateandTime', 'Pincode','Area' ,'ValidPincode', 'Status'];
  requestCatcherCallArray = [];
  get5KGAppuCampaignByPincodeArray = [];
  isLoading: boolean = false;
  public selectedDate: any;
  FromDateResult: Date;
  ToDateResult: Date;
  _TempModel: TempModel;
  postModel: any;
  response: string;
  roleId: number = 0;
  distributorId: number = 0;
  get5KGAppuCampaignByAdminCountModel: Get5KGAppuCampaignByAdminCountModel;
  adminCountArray = [];
  get5KGAppuCampaignByDistributorCountModel: Get5KGAppuCampaignByDistributorCountModel;
  distributorCountArray = [];
  WarningMessage: string;
  subscription: Subscription;
  control = new FormControl();
  filteredPincodeList: Observable<Get5KGAppuCampaignByPincodeModel[]>;
  IsCallNotAttended: boolean = false;
  IsCallNotAttendedFlag: string = "";
  expandedElement: any;
  AreaPincode: string = "";
  modalReference: NgbModalRef;
  clickedRowItem: any;
  count: number = 0;

  constructor(private requestCatcherCallService: RequestCatcherCallService, private chRef: ChangeDetectorRef,
              private getSession: GetSessionService, private toastr: ToastrService, private modalService: NgbModal) {
  }

  ngOnInit() {
    this._TempModel = new TempModel();
    this.requestCatcherCallModel = new RequestCatcherCallModel();
    this.get5KGAppuCampaignByAdminCountModel = new Get5KGAppuCampaignByAdminCountModel();
    this.get5KGAppuCampaignByPincodeModel = new Get5KGAppuCampaignByPincodeModel();
    this.update5KGAppuCampaignByPincodeModel = new Update5KGAppuCampaignByPincodeModel();

    let d = new Date();
    this.FromDateResult = d;
    this.ToDateResult = d;
    this._TempModel = {
      FromDate: this.ConvertStringToDateObj(this.FromDateResult),
      ToDate: this.ConvertStringToDateObj(this.ToDateResult)
    };
    this.selectedDate = this.ConvertStringToDateObj(d);

    // To Get roleId and distributorId
    this.roleId = this.GetRoleDetails();
    this.distributorId = this.GetDistributorDetails();

    // Admin Flow
    if (this.roleId === 1) {
      this.GetRequestCatcherCallList(this._TempModel);
      this.Get5KGAppuCampaignByAdminCount();

      this.subscription = timer(0, 10000).pipe(
        switchMap(() => this.requestCatcherCallService.GetRequestCatcherCall(this.ConvertDateFormat(this._TempModel.FromDate), this.ConvertDateFormat(this._TempModel.ToDate)))
      ).subscribe(async (data) => {
        console.log("Admin Flow -> timer used service every 10 seconds");
        if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
          this.requestCatcherCallArray = await data as RequestCatcherCallModel[];
          this.DataSource = new MatTableDataSource();
          this.DataSource.data = this.requestCatcherCallArray;
          this.DataSource.paginator = this.paginator;
          this.DataSource.sort = this.sort;
          this.isLoading = false;
          this.chRef.detectChanges();
          //if (this.clickedRowItem !== null && this.clickedRowItem !== undefined) {
          //  $('#' + this.clickedRowItem.CallFrom).css('display', 'block');
          //  let prevrow = $('#Expand' + this.clickedRowItem.CallFrom).prev()[0];
          //  $(prevrow).addClass('is-blue');
          //}
        } else {
          this.requestCatcherCallArray = [];
          this.DataSource = new MatTableDataSource();
          this.DataSource.data.length = null;
          this.isLoading = false;
          this.chRef.detectChanges();
        }
        await this.Get5KGAppuCampaignByAdminCount();
      });
    }

    // Distributor Flow
    if (this.roleId === 3) {
      if (this.distributorId != 0 && this.distributorId != null && this.distributorId > 0) {
        this.Get5KGAppuCampaignByDistributor(this.distributorId, this._TempModel.FromDate, this._TempModel.ToDate);
        this.Get5KGAppuCampaignByDistributorCount(this.distributorId);

        this.subscription = timer(0, 10000).pipe(
          switchMap(() => this.requestCatcherCallService.Get5KGAppuCampaignByDistributor(this.distributorId, this.ConvertDateFormat(this._TempModel.FromDate), this.ConvertDateFormat(this._TempModel.ToDate)))
        ).subscribe(async (data) => {
          console.log("Distributor Flow -> timer used service every 10 seconds");
          if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
            this.requestCatcherCallArray = await data as RequestCatcherCallModel[];
            this.DataSource = new MatTableDataSource();
            this.DataSource.data = this.requestCatcherCallArray;
            this.DataSource.paginator = this.paginator;
            this.DataSource.sort = this.sort;
            this.isLoading = false;
            this.chRef.detectChanges();
          } else {
            this.requestCatcherCallArray = [];
            this.DataSource = new MatTableDataSource();
            this.DataSource.data.length = null;
            this.isLoading = false;
            this.chRef.detectChanges();
          }
          await this.Get5KGAppuCampaignByDistributorCount(this.distributorId);
        });
      }
    }
  }

  // Get Role Details
  GetRoleDetails() {
    let item = this.getSession.GetSessionData();
    return item.RoleId;
  }

  // Get Distributor Details
  GetDistributorDetails() {
    let item = this.getSession.GetSessionData();
    return item.refNo;
  }

  GetRequestCatcherCallList(model: TempModel) {
    this.postModel = {
      FromDate: this.ConvertDateFormat(model.FromDate),
      ToDate: this.ConvertDateFormat(model.ToDate)
    };
    this.GetRequestCatcherCall();
  }

  onDateSelect(dateResult: Date) {
    return dateResult;
  }

  // To Get Request Catcher Call
  GetRequestCatcherCall() {
    this.isLoading = true;
    this.unsubscribe.push(this.requestCatcherCallService.GetRequestCatcherCall(this.postModel.FromDate, this.postModel.ToDate).subscribe((data: any) => {
      console.log("GetRequestCatcherCall Response Data:  " + JSON.stringify(data));
      if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
        this.requestCatcherCallArray = data as RequestCatcherCallModel[];
        this.DataSource = new MatTableDataSource();
        this.DataSource.data = this.requestCatcherCallArray;
        this.DataSource.paginator = this.paginator;
        this.DataSource.sort = this.sort;
        this.isLoading = false;
        this.chRef.detectChanges();
      } else {
        this.requestCatcherCallArray = [];
        this.DataSource = new MatTableDataSource();
        this.DataSource.data.length = null;
        this.isLoading = false;
        this.chRef.detectChanges();
      }
    }, (error) => {
      this.isLoading = false;
      console.error("Error:   " + error);
    }));

    // Distributor Flow
    if (this.roleId === 3) {
      this.Get5KGAppuCampaignByDistributor(this.distributorId, this._TempModel.FromDate, this._TempModel.ToDate);
    }

  }

  // Apply Filter
  applyFilter(filterValue: string) {
    this.isLoading = true;
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.DataSource.filter = filterValue;
    this.isLoading = false;
  }

  // Use to convert string to date obj
  ConvertStringToDateObj(SelDate) {
    let d = new Date(moment(SelDate, 'DD-MM-YYYY hh:mm tt').format('YYYY-MM-DD'));
    return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() };
  }

  // Use to Convert object to  Date Format string
  ConvertDateFormat(condate) {
    let dateInput = new Date(condate.year, condate.month - 1, condate.day);
    return moment(dateInput).format('YYYY-MM-DD');
  }

  // To Get 5KG Appu Campaign By Distributor
  Get5KGAppuCampaignByDistributor(distributorId: number, FromDate: any, ToDate: any) {
    this.isLoading = true;
    this.unsubscribe.push(this.requestCatcherCallService.Get5KGAppuCampaignByDistributor(distributorId, this.ConvertDateFormat(FromDate), this.ConvertDateFormat(ToDate)).subscribe((data: any) => {
      console.log("Get5KGAppuCampaignByDistributor Response Data:  " + JSON.stringify(data));
      if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
        this.requestCatcherCallArray = data as RequestCatcherCallModel[];
        this.DataSource = new MatTableDataSource();
        this.DataSource.data = this.requestCatcherCallArray;
        this.DataSource.paginator = this.paginator;
        this.DataSource.sort = this.sort;
        this.isLoading = false;
        this.chRef.detectChanges();
      } else {
        this.requestCatcherCallArray = [];
        this.DataSource = new MatTableDataSource();
        this.DataSource.data.length = null;
        this.isLoading = false;
        this.chRef.detectChanges();
      }
    }, (error) => {
      this.isLoading = false;
      console.error("Error:   " + error);
    }));
  }

  // To Assign Distributor
  AssignDistributor(data: any) {
    let model = {
      'CallSid': data.CallSid,
      'CallFrom': data.CallFrom,
      'DistributorId': this.distributorId
    };
    this.unsubscribe.push(this.requestCatcherCallService.AssignDistributor(model)
        .subscribe((data) => {
          if (data != null && data != undefined) {
            this.toastr.success('Consumer Assigned To You', 'Assign Consumer', { timeOut: 4000 });
            this.Get5KGAppuCampaignByDistributor(this.distributorId, this._TempModel.FromDate, this._TempModel.ToDate);
            this.Get5KGAppuCampaignByDistributorCount(this.distributorId);
          }
        }));
  }

  // To Get 5 KG Appu Campaign By Admin Count
  Get5KGAppuCampaignByAdminCount() {
    this.isLoading = true;
    this.unsubscribe.push(this.requestCatcherCallService.Get5KGAppuCampaignByAdminCount().subscribe((data: any) => {
      console.log("Get5KGAppuCampaignByAdminCount Response Data:  " + JSON.stringify(data));
      if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
        this.adminCountArray = data as Get5KGAppuCampaignByAdminCountModel[];
        this.isLoading = false;
        this.chRef.detectChanges();
      }
    }, (error) => {
      this.isLoading = false;
      console.error("Error:   " + error);
    }));
  }

  // To Get 5 KG Appu Campaign By Distributor Count
  Get5KGAppuCampaignByDistributorCount(distributorId: number) {
    this.isLoading = true;
    this.unsubscribe.push(this.requestCatcherCallService.Get5KGAppuCampaignByDistributorCount(distributorId).subscribe((data: any) => {
      console.log("Get5KGAppuCampaignByDistributorCount Response Data:  " + JSON.stringify(data));
      if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
        this.distributorCountArray = data as Get5KGAppuCampaignByDistributorCountModel[];
        this.isLoading = false;
        this.chRef.detectChanges();
      }
    }, (error) => {
      this.isLoading = false;
      console.error("Error:   " + error);
    }));
  }

  // Missed Call against Call
  onCallClick(pkId: number, callFrom: string, callNumber: string) {
	  console.log("Missed Call against Click event  ->  pkId:  " + pkId + " \n Call From:  " + callFrom + " \n callNumber:  " + callNumber);
    this.unsubscribe.push(this.requestCatcherCallService.CallToParticularNumber(pkId, callFrom, callNumber).subscribe(() => {}));
  }

  // To Get 5 KG Appu Campaign By Admin Count Summary
  onAdminCountSummary(type: string) {
    switch (type) {
      case "Today":
          console.log("Today " + type);
          window.open(`#/default/5KGAppuCampaignSummary/${type}`, "_blank");
          break;
      case "AsOfDate":
          console.log("As Of Date " + type);
          window.open(`#/default/5KGAppuCampaignSummary/${type}`, "_blank");
          break;
      case "ValidPincode":
          console.log("ValidPincode " + type);
          window.open(`#/default/5KGAppuCampaignSummary/${type}`, "_blank");
          break;
      case "InValidPincode":
          console.log("InValidPincode " + type);
          window.open(`#/default/5KGAppuCampaignSummary/${type}`, "_blank");
          break;
      case "MissedCall":
          console.log("MissedCall " + type);
          window.open(`#/default/5KGAppuCampaignSummary/${type}`, "_blank");
          break;
      case "Forwarded":
          console.log("Forwarded " + type);
          window.open(`#/default/5KGAppuCampaignSummary/${type}`, "_blank");
          break;
      case "AfterOfficeHrs":
          console.log("AfterOfficeHrs " + type);
          window.open(`#/default/5KGAppuCampaignSummary/${type}`, "_blank");
          break;
      default:
          console.log("No such type exists!");
          break;
    }
  }

  // Open Modal
  openModal(content, pkId: number, callFrom: string, Remark: string, AOHRemark: string) {
    this.AreaPincode = "";
    this.IsCallNotAttended = false;
	  console.log("Open Modal ->  pkId:  " + pkId + " \n Call From:  " + callFrom + " \n Remark:  " + Remark+ " \n AOHRemark:  " + AOHRemark);
    this.requestCatcherCallModel.pkId = pkId;
    this.requestCatcherCallModel.CallFrom = callFrom;
    this.requestCatcherCallModel.Remark = Remark;
    this.requestCatcherCallModel.AOHRemark = AOHRemark;
    this.modalReference = this.modalService.open(content, {
      centered: true,
      size: 'lg',
      backdrop: 'static'
    });

    this.Get5KGAppuCampaignByPincode(); // To Get 5 KG Appu Campaign By Pincode
  }

  onClickHistory(type: string) {
    window.open(`#/default/5KGAppuCampaignSummary/${type}`, "_blank");
  }

  // To Get 5 KG Appu Campaign By Pincode
  Get5KGAppuCampaignByPincode() {
    this.isLoading = true;
    this.unsubscribe.push(this.requestCatcherCallService.Get5KGAppuCampaignByPincode().subscribe((data: any) => {
      console.log("To Get 5 KG Appu Campaign By Pincode Response Data:  " + JSON.stringify(data));
      if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
        this.get5KGAppuCampaignByPincodeArray = data as Get5KGAppuCampaignByPincodeModel[];
        // Autocomplete Code
        this.filteredPincodeList = this.control.valueChanges.pipe(
          startWith<string | Get5KGAppuCampaignByPincodeModel>(''),
          map(value => typeof value === 'string' ? value : value !== null ? value.Area : null),
          map(Area => Area ? this.filter(Area) : this.get5KGAppuCampaignByPincodeArray.slice()));
        this.isLoading = false;
        this.chRef.detectChanges();
      }
    }, (error) => {
      this.isLoading = false;
      console.error("Error:   " + error);
    }));
  }

  private filter(name: string): Get5KGAppuCampaignByPincodeModel[] {
    const filterValue = name.toLowerCase();
    return this.get5KGAppuCampaignByPincodeArray.filter(option => option.Area.toLowerCase().includes(filterValue) || option.Pincode.toLocaleLowerCase().includes(filterValue));
  }

  displayFn(pincodeList?: Get5KGAppuCampaignByPincodeModel): string | undefined {
    return pincodeList ? pincodeList.Area + " (" + pincodeList.Pincode + ") " : undefined;
  }

  // To Update 5 KG Appu Campaign By Pincode
  onUpdate5KGAppuCampaignByPincode(Id: number) {
    this.isLoading = true;
    if (this.control.value.Pincode != null && this.control.value.Pincode != "") {
      this.update5KGAppuCampaignByPincodeModel.Pincode = this.control.value.Pincode;
    } else if (this.control.value != null && this.control.value != "") {
      this.update5KGAppuCampaignByPincodeModel.Pincode = this.control.value;
    } else {
      this.update5KGAppuCampaignByPincodeModel.Pincode = null;
    }
    this.IsCallNotAttendedFlag = (this.IsCallNotAttended === true ? "Y" : "N");

    // Validation
    if (this.update5KGAppuCampaignByPincodeModel.Pincode === null && this.IsCallNotAttendedFlag === "N") {
      this.toastr.error("Please Choose any Area/Pincode", "Area/Pincode", { timeOut: 4000 });
    } else {
      for (let res of this.get5KGAppuCampaignByPincodeArray) {
        if (res.Pincode === this.update5KGAppuCampaignByPincodeModel.Pincode) {
            this.unsubscribe.push(this.requestCatcherCallService.Update5KGAppuCampaignByPincode(Id, this.update5KGAppuCampaignByPincodeModel.Pincode, this.IsCallNotAttendedFlag).subscribe((data: any) => {
            console.log("To Update 5 KG Appu Campaign By Pincode Response Data:  " + JSON.stringify(data));
            if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
              for(let res of data) {
                this.update5KGAppuCampaignByPincodeModel.pkId = res.pkId;
                this.update5KGAppuCampaignByPincodeModel.Pincode = res.Pincode;
                this.update5KGAppuCampaignByPincodeModel.ResultMessage = res.ResultMessage;
                this.toastr.success(this.update5KGAppuCampaignByPincodeModel.ResultMessage, "", { timeOut: 4000 });
              }
              this.modalReference.close();
              this.isLoading = false;
              this.chRef.detectChanges();
            }
            }, (error) => {
              this.isLoading = false;
              console.error("Error:   " + error);
            }));
        } else {
          this.count ++;
        }
      }
      if (this.get5KGAppuCampaignByPincodeArray.length === this.count) {
        this.toastr.error("Invalid", "Area/Pincode", { timeOut: 4000 });
      }
    }
    
    if (this.IsCallNotAttendedFlag === "Y" ) {
      this.unsubscribe.push(this.requestCatcherCallService.Update5KGAppuCampaignByPincode(Id, this.update5KGAppuCampaignByPincodeModel.Pincode, this.IsCallNotAttendedFlag).subscribe((data: any) => {
        console.log("To Update 5 KG Appu Campaign By Pincode Response Data:  " + JSON.stringify(data));
        if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
          for(let res of data) {
            this.update5KGAppuCampaignByPincodeModel.pkId = res.pkId;
            this.update5KGAppuCampaignByPincodeModel.Pincode = res.Pincode;
            this.update5KGAppuCampaignByPincodeModel.ResultMessage = res.ResultMessage;
            this.toastr.success(this.update5KGAppuCampaignByPincodeModel.ResultMessage, "", { timeOut: 4000 });
          }
          this.modalReference.close();
          this.isLoading = false;
          this.chRef.detectChanges();
        }
        }, (error) => {
          this.isLoading = false;
          console.error("Error:   " + error);
        }));
    }
  }

  // Tp Expand Collapse
  expandCollapse(element) {
    if (element != undefined) {
      this.clickedRowItem = element;
      $('.example-element-row').removeClass('is-blue');
  
      if (this.expandedElement !== null && this.expandedElement !== undefined) {
        $('#' + this.expandedElement.CallFrom).css('display', 'none');
      }
      this.expandedElement = this.expandedElement === element ? null : element;
      if (this.expandedElement !== null && this.expandedElement !== undefined) {
        $('#' + this.expandedElement.CallFrom).css('display', 'block');
        let prevrow = $('#Expand' + this.expandedElement.CallFrom).prev()[0];
        $(prevrow).addClass('is-blue');
      } else {
        $('#' + element.CallFrom).css('display', 'none');
      } 
    }
  }

  // Set side menu close
  ngAfterViewInit() {
    this.requestCatcherCallService.Toggler = new KTToggle('kt_aside_toggler', this.requestCatcherCallService.toggleOptions);
    this.requestCatcherCallService.DivToggleWidth = '100%';
    this.requestCatcherCallService.IsModelOn = false;
    this.requestCatcherCallService.displayValue = false;
    this.requestCatcherCallService.Toggler.toggleOn();
    $('#kt_aside_close_btn').click();
    setTimeout(() => {
      this.requestCatcherCallService.OpenToggle = true;
      this.requestCatcherCallService.Toggler.toggleOn();
      $('#kt_aside_close_btn').click();
    }, 500);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.unsubscribe.forEach(sb => sb.unsubscribe());
  }

}

// TempModel
export class TempModel {
  FromDate: any;
  ToDate: any;
}
