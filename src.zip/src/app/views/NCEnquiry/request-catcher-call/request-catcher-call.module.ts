import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../../../app/core/auth';
import { 
	MatButtonModule, MatInputModule, MatTableModule, MatStepperModule, MatProgressSpinnerModule, MatAutocompleteModule,
	MatRippleModule, MatFormFieldModule, MatSelectModule, MatDatepickerModule, MatCheckboxModule, MatIconModule, MatPaginatorModule, MatSortModule, MatRadioModule, MatTooltipModule,
	MatCardModule
} from '@angular/material';
import { MatTableExporterModule } from 'mat-table-exporter';
import { ToastrService } from 'ngx-toastr';
import { GetSessionService } from '../../../services/globalsession.service';
import { PartialsModule } from '../../partials/partials.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '../../../../../src/app/core/core.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';

import { RequestCatcherCallComponent } from './request-catcher-call.component';
import { RequestCatcherCallSummaryComponent } from './request-catcher-call-summary/request-catcher-call-summary.component';

const requestCatcherCallRoutes: Routes = [
	{
		path: '',
		children: [
			{ path: '5KGAppuCampaign', component: RequestCatcherCallComponent, canActivate: [AuthGuard], data: { roles: ['1'] } },
			{ path: '5KGAppuCampaignSummary/:type', component: RequestCatcherCallSummaryComponent, canActivate: [AuthGuard], data: { roles: ['1'] } }
		]
	}
];

const modules = [ 
	MatButtonModule, MatFormFieldModule,
	MatInputModule, MatRippleModule,
	MatTableModule, MatAutocompleteModule, MatSelectModule, MatDatepickerModule, MatStepperModule,
	MatProgressSpinnerModule,
	MatSortModule, MatPaginatorModule, MatIconModule, MatTableExporterModule, MatCheckboxModule, MatRadioModule,
	MatCardModule
];

@NgModule({
	declarations: [RequestCatcherCallComponent, RequestCatcherCallSummaryComponent],
	providers: [GetSessionService, ToastrService],
	imports: [
		modules,
		FormsModule,
		ReactiveFormsModule,
		CommonModule,
		PartialsModule,
		CoreModule,
		NgbModule,
		MatTooltipModule,
		DataTablesModule,
		RouterModule.forChild(requestCatcherCallRoutes)
	],
	exports: [RouterModule]
})
export class RequestCatcherCallModule { }
