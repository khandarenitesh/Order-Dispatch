import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent1 implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
