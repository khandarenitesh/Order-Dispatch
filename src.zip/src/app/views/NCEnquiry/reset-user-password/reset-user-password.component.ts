import { Component, OnInit } from '@angular/core';
import { ResetPasswordService } from '../../../services/ResetPassword/reset-password.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { OMCAuthService } from '../../../services/auth/auth.service';

@Component({
  selector: 'kt-reset-user-password',
  templateUrl: './reset-user-password.component.html',
  styleUrls: ['./reset-user-password.component.scss']
})
export class ResetUserPasswordComponent implements OnInit {

  UserDetailModel: any;
  Oldhide = true;
  Newhide = true;
  Confirmhide = true;
  constructor(private resetPasswordService: ResetPasswordService,
    private toastr: ToastrService,
    private router: Router,
    private _OMCAuthService: OMCAuthService) { }

  ngOnInit() {
    this.resetForm();
    let user = JSON.parse(sessionStorage.getItem('LoginData'));

    if (user !== null) {
      this.UserDetailModel = {
        UserId: user.UserId,
        RoleId: user.RoleId,
        RefId: user.refNo,
        UserName: user.DisplayName,
        OldPassword: '',
        NewPassword: '',
        ConfirmPassword: ''
      };
    }

  }


  resetForm() {

    this.UserDetailModel = {
      UserId: '',
      UserTypeId: '',
      RefId: '',
      UserName: '',
      OldPassword: '',
      NewPassword: '',
      ConfirmPassword: ''
    };
  }

  onSubmit(Resetdata: any) {

    this.resetPasswordService.ResetUserPasswordSrv(Resetdata).subscribe(data => {
      if (data.Status === 'Success') {
      if (data.ResultId === -1) {
        this.toastr.error('User Old password is not match.', 'Reset User Password', {timeOut: 2000});
      } else if (data.ResultId > 0 ) {

        this.toastr.success('User Password Updated Successfully.', 'Reset User Password', {timeOut: 2000});
        // this.router.navigateByUrl('/auth/login');
        this._OMCAuthService.logout();
      }
    }
    });
  }

}
