import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResetUserPasswordComponent } from './reset-user-password.component';
import { AuthGuard } from '../../../../app/core/auth';
import { Routes, RouterModule } from '@angular/router';
import { MatButtonModule, MatInputModule, MatProgressSpinnerModule, MatFormFieldModule, MatRippleModule, MatIconModule, MatCheckboxModule, MatRadioModule, MatTooltipModule } from '@angular/material';
import { MatTableExporterModule } from 'mat-table-exporter';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CoreModule } from '../../../../app/core/core.module';
import { PartialsModule } from '../../partials/partials.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ConfirmEqualValidatorDirective } from '../shared/confirm-equal-validator.directive';


const ResetPasswordroutes: Routes = [
  { path: 'ResetUserPassword', component: ResetUserPasswordComponent,canActivate: [AuthGuard], data: { roles: ['1', '2', '3'] } }
];

const modules = [
	MatButtonModule,MatFormFieldModule,
	MatInputModule,MatRippleModule,
  MatProgressSpinnerModule,
  MatIconModule,MatTableExporterModule,MatCheckboxModule,MatRadioModule
];


@NgModule({
  declarations: [ResetUserPasswordComponent,ConfirmEqualValidatorDirective],
  imports: [
    modules,
    FormsModule,
    ReactiveFormsModule,
		CommonModule,
		PartialsModule,
		CoreModule,
		NgbModule,
		MatTooltipModule,
    RouterModule.forChild(ResetPasswordroutes)
  ]
})
export class ResetUserPasswordModule { }
