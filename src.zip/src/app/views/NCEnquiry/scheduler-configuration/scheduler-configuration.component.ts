import { Component, OnInit, ViewChild, ChangeDetectorRef} from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
// import { SchedulerConfigurationModel } from '../../../models/SchedulerConfiguration/scheduler-configuration-model';
// import { SchedulerConfigurationService } from '../../../services/SchedulerConfiguration/scheduler-configuration.service';

@Component({
  selector: 'kt-schedule-configuration',
  templateUrl: './scheduler-configuration.component.html',
  styleUrls: ['./scheduler-configuration.component.scss'],
  // providers: [SchedulerConfigurationService]
  })
export class SchedulerConfigurationComponent implements OnInit {
  displayedColumnsForApi = ['SrNo', 'Key', 'Value', 'Info', 'Actions'];

  // public _SchedulerConfigurationModel: SchedulerConfigurationModel = new SchedulerConfigurationModel();

  private unsubscribe: Subscription[] = [];

  @ViewChild('Paginator') Paginator: MatPaginator;
  @ViewChild('Sort') sort: MatSort;
  public DataSource = new MatTableDataSource<any>();
  isLoading: boolean = false;
  public ActiveFlag: string;
  public UpdateFlag: boolean = true;
  postModal: any;
  Title: string;
  isSave: boolean = true;
  constructor(
    // private _SchedulerConfigurationServices: SchedulerConfigurationService,
    private toastr: ToastrService,
    private chRef: ChangeDetectorRef,
  
   ) {
  }
  ngOnInit() {
    // this.ClearSchedulerConfiguration();
    // if (this._SchedulerConfigurationModel.Id === null || this._SchedulerConfigurationModel.Id === 0) 
    // {
    //   this._SchedulerConfigurationModel.Id = 0;
    //   this._SchedulerConfigurationModel.Action = 'ADD';
    //   this.ActiveFlag = 'Submit';
    //   this.Title = 'Scheduler Configuration Details';
    //   this.UpdateFlag = false;
    // } else {
    //   this._SchedulerConfigurationModel.Action = 'UPDATE';
    //   this.ActiveFlag = 'UPDATE';
    //   this.Title = 'Scheduler Configuration Details';
    //   this.UpdateFlag = true;
    // }
    // this.GetSchedulerConfiguration();
  }
  // execute schedular
//   ExecuteScheduler() {
//     this._SchedulerConfigurationServices.ExcecuteScheduler_Service()
//       .subscribe(data => {
//         this.toastr.success('Scheduler Executed Successfully.', 'Scheduler'); 
//       },
//         (error) => {
//           console.error(error);
//         });
//   }
//   // Get all records(in table)
//   GetSchedulerConfiguration() {
//     this.unsubscribe.push(this._SchedulerConfigurationServices.GetSchedulerConfiguration_Service()
//       .subscribe(data => {
//         this.DataSource = data !== null ? new MatTableDataSource(data) : new MatTableDataSource<any>();
//         this.DataSource.paginator = this.Paginator;
//         this.DataSource.sort = this.sort;
//         if (!this.chRef['destroyed']) {
//           this.chRef.detectChanges();
//         }
//       },
//       ));
//   }
//    // add/update
//   SubmitSchedulerConfigurationMaster(){
//                     this.isSave =true;
//     if (this._SchedulerConfigurationModel.Key != "" && this._SchedulerConfigurationModel.Value != "" && this._SchedulerConfigurationModel.Info != "") {
//           if (this.ActiveFlag === "ADD") {
//             // add code
//             this._SchedulerConfigurationModel.Action = this.ActiveFlag;
//             this.unsubscribe.push(this._SchedulerConfigurationServices.AddSchedulerConfigurationMaster_Service
//               (this._SchedulerConfigurationModel).subscribe((data: any) => {
//               debugger;
//               if (data === -1) {
//                 this.toastr.warning('Record Already Exists.', 'Scheduler Configuration Master');
//                 this.chRef.detectChanges();
//               } else if (data === 1) {
//                 this.toastr.success('Record Added Successfully.', 'Scheduler Configuration Master');
//                 this.ClearSchedulerConfiguration();
//                 this.chRef.detectChanges();
//                 this.GetSchedulerConfiguration();
//               } else {
//                 this.toastr.error('Record Added Failed.', 'Scheduler Configuration Master');
//                 this.chRef.detectChanges();
//               }
//             }));
//           } else {
//             // update code
//             this._SchedulerConfigurationModel.Action = this.ActiveFlag;
//             this.unsubscribe.push(this._SchedulerConfigurationServices.AddSchedulerConfigurationMaster_Service
//               (this._SchedulerConfigurationModel).subscribe((data: any) => {
//               debugger;
//               if (data === 1) {
//                 this.toastr.success('Record Updated Successfully.', 'Scheduler Configuration Master');
//                 this.ClearSchedulerConfiguration();
//                 this.chRef.detectChanges();
//                 this.GetSchedulerConfiguration();
//               } else {
//                 this.toastr.error('Record Updated Failed.', 'Scheduler Configuration Master');
//                 this.chRef.detectChanges();
//               }
//             }));
//           }
//         }
//   }
// // Edit and Update (row wise)
//   EditSchedulerConfiguration(Model) {
//     this.isSave = false;
//     //this.isUpdate = true;
//     if (Model != null) {
//       this._SchedulerConfigurationModel.Id = Model.Id;
//       this._SchedulerConfigurationModel.Key = Model.Key;
//       this._SchedulerConfigurationModel.Value = Model.Value;
//       this._SchedulerConfigurationModel.Info = Model.Info;
//       this.UpdateFlag = true;
//       this.ActiveFlag = 'UPDATE';
//     }
//   }

//   // Hide Menu after click Scheduler Configuration
//   ngAfterViewInit() {
//     this._SchedulerConfigurationServices.Toggler = new KTToggle('kt_aside_toggler', this._SchedulerConfigurationServices.toggleOptions);
//     this._SchedulerConfigurationServices.DivToggleWidth = '100%';
//     this._SchedulerConfigurationServices.IsModelOn = false;
//     this._SchedulerConfigurationServices.displayValue = false;
//     this._SchedulerConfigurationServices.Toggler.toggleOn();
//     $('#kt_aside_close_btn').click();
//     setTimeout(() => {
//       this._SchedulerConfigurationServices.OpenToggle = true;
//       this._SchedulerConfigurationServices.Toggler.toggleOn();
//       $('#kt_aside_close_btn').click();
//     }, 500);
//   }

//   ClearSchedulerConfiguration() {
//     this.isSave = true;
//    // this.isUpdate = false;
//     this._SchedulerConfigurationModel.Id = 0;
//     this._SchedulerConfigurationModel.Key = "";
//     this._SchedulerConfigurationModel.Value = "";
//     this._SchedulerConfigurationModel.Info = "";
//     this._SchedulerConfigurationModel.Action = "";
//     this.UpdateFlag = false;
//     this.ActiveFlag = 'Submit';
//   }

//   ngOnDestroy() {
//     this.unsubscribe.forEach(sb => sb.unsubscribe());
//   }
}
