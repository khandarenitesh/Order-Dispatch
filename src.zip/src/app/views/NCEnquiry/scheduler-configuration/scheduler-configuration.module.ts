import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SchedulerConfigurationComponent } from './scheduler-configuration.component';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../../../core/auth';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PartialsModule } from '../../partials/partials.module';

import {
	MatButtonModule, MatInputModule, MatTableModule, MatStepperModule, MatProgressSpinnerModule, MatAutocompleteModule,
	MatRippleModule, MatFormFieldModule, MatSelectModule, MatDatepickerModule, MatCheckboxModule,MatListModule, 
	MatPaginatorModule, MatSortModule, MatRadioModule, MatIconModule
} from '@angular/material';


const schedulerconfigurationComponentRoutes: Routes = [
	{
		path: '',
		children: [
			{ path: 'SchedulerConfiguration', component: SchedulerConfigurationComponent, canActivate: [AuthGuard], data: { roles: ['1'] } }
		]
	}
];
const modules = [
	MatButtonModule, MatFormFieldModule, MatInputModule, MatRippleModule, MatTableModule, 
    MatAutocompleteModule, MatSelectModule, MatDatepickerModule, MatStepperModule, MatProgressSpinnerModule, MatSortModule, 
    MatPaginatorModule, MatIconModule, MatCheckboxModule, MatRadioModule,MatListModule
];

@NgModule({
  declarations: [SchedulerConfigurationComponent],
  imports: [
    CommonModule,modules,
    RouterModule.forChild(schedulerconfigurationComponentRoutes),
	FormsModule, ReactiveFormsModule, PartialsModule
  ]
})

export class SchedulerConfigurationModule { }
