import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeconCylenderUploadComponent } from './secon-cylender-upload.component';

describe('SeconCylenderUploadComponent', () => {
  let component: SeconCylenderUploadComponent;
  let fixture: ComponentFixture<SeconCylenderUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeconCylenderUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeconCylenderUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
