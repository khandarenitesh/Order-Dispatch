import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subscription } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { DistributorModel } from '../../../../models/DBCCampaignUpload/dbc-campaign-upload.model';
import { DBCCampaignUploadService } from '../../../../services/DBCCampaignUpload/dbc-campaign-upload.service';

@Component({
  selector: 'kt-secon-cylender-upload',
  templateUrl: './secon-cylender-upload.component.html',
  styleUrls: ['./secon-cylender-upload.component.scss']
})
export class SeconCylenderUploadComponent implements OnInit {
  
  @ViewChild('fileInput') fileInput: ElementRef;
  isLoading: boolean = false;
  private unsubscribe: Subscription[] = [];
  SelectedDistributor: DistributorModel = new DistributorModel();
  filteredDistributorOptions: Observable<DistributorModel[]>;
  DistributorList: DistributorModel[];
  DistributorControl = new FormControl();

  constructor(private chRef: ChangeDetectorRef, private dbcCampaignUploadService: DBCCampaignUploadService, private toastr: ToastrService) { }

  ngOnInit() {
    this.clearFile();
    this.GetDistributorList();
  }

  GetDistributorList() {
    let Modal = {
      'DistributorId': 0
    };
    this.unsubscribe.push(this.dbcCampaignUploadService.GetDistDetails(Modal)
      .subscribe((data) => {
        this.DistributorList = data.DistributorList;
        this.filteredDistributorOptions = this.DistributorControl.valueChanges
            .pipe(
            map(value => typeof value === 'string' ? value : value !== null ? value.DistributorName : null),
            map(DistributorName => DistributorName ? this.filterDistributor(DistributorName) : this.DistributorList.slice()));
        this.chRef.detectChanges();
      }, () => {
      }));
  }

  filterDistributor(name: string): DistributorModel[] {
    const filterDistributorValue = name.toLowerCase();
    return this.DistributorList.filter((option) => option.DistributorName.toLowerCase().includes(filterDistributorValue) ||
    option.JDEDistributorCode.toLocaleLowerCase().includes(filterDistributorValue));
  }

  displayFnDistributor(user?: DistributorModel): string | undefined {
    return user ? user.DistributorName + "( " + user.JDEDistributorCode + " ) " : undefined;
  }

  // DBC Campaign Upload Excel File
  uploadExcelFile() {
    debugger;
    this.isLoading = true;
    let distributorId = 0;
    if (this.SelectedDistributor != null && this.SelectedDistributor != undefined && this.SelectedDistributor.DistributorId > 0) {
      distributorId = this.SelectedDistributor.DistributorId;
    }
      let formData = new FormData(); 
      let file = this.fileInput.nativeElement.files[0];
      if(file === undefined) {
        this.toastr.error('Please Select File');
        this.isLoading = false;
      } else if (file != undefined && (file.name.split('.').pop() === "xls" || file.name.split('.').pop()  === "xlsx")) { 
        formData.append('upload', file);
        this.dbcCampaignUploadService.UploadSecondCylenderExcel(distributorId, formData).subscribe((data: any) => {
           if (data.length > 0) {
            this.toastr.success("Uploaded SuccessFully", "DBC Campaign");
            this.clearFile();
          } 
          else {
            this.toastr.error("Uploaded Failed", "DBC Campaign");
            this.clearFile();
          }
        });
      } else {
        this.toastr.warning('File is Invalid (Accepts only xls or .xlsx)');
        this.clearFile();
      }
    // } else {
    //   this.toastr.error('Please Select Distributor');
    //   this.isLoading = false;
    //   this.chRef.detectChanges();
    // }
  }

   // Clear File
   clearFile() {
    this.SelectedDistributor = null;
    this.fileInput.nativeElement.value = null;
    this.isLoading = false;
    this.chRef.detectChanges();
  }
}
