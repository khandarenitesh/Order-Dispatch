import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SeconCylenderUploadComponent } from './secon-cylender-upload/secon-cylender-upload.component';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../../../../app/core/auth';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PartialsModule } from '../../partials/partials.module';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';
import { MatAutocompleteModule, MatFormFieldModule, MatInputModule, MatProgressSpinnerModule, MatRippleModule } from '@angular/material';

const UploadSecondCylenderComponentRoutes: Routes = [
	{
		path: '',
		children: [
			{ path: 'SecondCylinderUpload', component: SeconCylenderUploadComponent, canActivate: [AuthGuard], data: { roles: ['1'] } }
		]
	}
];

const modules = [
	             MatProgressSpinnerModule, FormsModule, ReactiveFormsModule, PartialsModule, DataTablesModule, MatFormFieldModule, MatAutocompleteModule, MatFormFieldModule,
	             MatInputModule, MatRippleModule
				];

@NgModule({
  declarations: [SeconCylenderUploadComponent],
  imports: [
    CommonModule,
    modules,
		// NgbModule,
    RouterModule.forChild(UploadSecondCylenderComponentRoutes)
  ]
})
export class SecondSylenderUploadModule { }
