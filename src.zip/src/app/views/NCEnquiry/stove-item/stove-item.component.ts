import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { StoveItemService } from '../../../services/StoveItem/stove-item.service';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { StoveItem } from '../../../models/StoveItem/stove-item.model';
import { Subscription } from 'rxjs';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'kt-stove-item',
  templateUrl: './stove-item.component.html',
  styleUrls: ['./stove-item.component.scss']
})
export class StoveItemComponent implements OnInit {

  postModal: any;
  Temp: any;
  _stoveItemLst: StoveItem[];
  _stoveTypeLst: StoveItem[];
  _stoveItemDtls: StoveItem;
  displayedColumns = ['SrNo', 'StoveType', 'ItemName', 'Price', 'ActiveStatus', 'Actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public StoveItemSource = new MatTableDataSource<any>();
  Operation: string;
  WarningMessage: string;
  private updateSubscription: Subscription;

  constructor(private _stoveItemService: StoveItemService,
    private chRef: ChangeDetectorRef,
    public datepipe: DatePipe,
    private toastr: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private modalService: NgbModal) { }

  ngOnInit() {
    this._stoveItemDtls = new StoveItem();
    this.resetForm();
    this.GetStoveTypeLst();
    this.GetStoveItemDetails();
    this.Operation = 'ADD';
    this._stoveItemDtls.Operation = 'ADD';

  }
  ResetFormCall() {
    this.resetForm();
    this.GetStoveItemDetails();
  }


  resetForm() {
    this._stoveItemDtls = {
      Id: 0,
      DistributorId: this.GetLoginDetails(),
      StoveId: 0,
      ItemName: '',
      Price: '',
      ActiveStatus: '',
      LastUpdateDateTime: '',
      StoveType: '',
      Operation: 'ADD'
    };
    this.Operation = 'ADD';
  }
  OnEdit(data: StoveItem) {
    this.resetForm();
    this.Operation = 'EDIT';
    this._stoveItemDtls.Operation = 'EDIT';
    this._stoveItemDtls = data;
    if (!this.chRef['destroyed']) {
      this.chRef.detectChanges();
    }
  }
  GetStoveTypeLst() {
    this._stoveItemService.getStoveTypeDetails(this.Temp)
      .subscribe(data => {
        this._stoveTypeLst = data.stoveItemList;
        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      },
        (error) => {
          console.error(error);
        });
  }
  GetStoveItemDetails() {
    this.postModal = {
      'DistributorId': this.GetLoginDetails(), // 8131,
      'Id': 0,
      'StoveId': 0,
      'Operation': 'WebMASTER'
    };
    this._stoveItemService.getStoveItemDetails(this.postModal)
      .subscribe(data => {
        this._stoveItemLst = data.stoveItemList;
        this.StoveItemSource = new MatTableDataSource(data.stoveItemList);
        this.StoveItemSource.paginator = this.paginator;
        this.StoveItemSource.sort = this.sort;
        // table
        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      },
        (error) => {
          console.error(error);
        });
  }
  GetLoginDetails() {
    let item = JSON.parse(sessionStorage.getItem('LoginData'));
    return item.refNo;

  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.StoveItemSource.filter = filterValue;
  }
  onDelete(id: number, Status: string) {
    if (Status === 'N') {
      this.WarningMessage = 'Are you sure to Deactivate this record?';
    } else {
      this.WarningMessage = 'Are you sure to Activate this record?';
    }
    if (confirm(this.WarningMessage) === true) {
      this.postModal = {
        'Id': id,
        'ActiveStatus': Status,
        'Operation': 'DELETE'
      };
      this._stoveItemService.saveStoveItemDetails(this.postModal)
        .subscribe(data => {

          if (data.Status === 'Success') {

            if (Status === 'N') {
              this.toastr.success('Record Deactivated Successfully.', 'Stove Item Master', { timeOut: 2000 });
            } else {
              this.toastr.success('Record Activated Successfully.', 'Stove Item Master', { timeOut: 2000 });
            }
          } else if (data < 0) {
            this.toastr.error('Something Went Wrong.', 'Stove Item Master', { timeOut: 2000 });
          }
          this.GetStoveItemDetails();
          if (!this.chRef['destroyed']) {
            this.chRef.detectChanges();
          }
        });
    }
  }
  onSubmit(StoveItemForm: StoveItem) {
    // Converting all date format

    StoveItemForm.DistributorId = this.GetLoginDetails();
    StoveItemForm.Operation = this.Operation;

    this._stoveItemService.saveStoveItemDetails(StoveItemForm).subscribe(data => {
      if (data.Status === 'Success') {
        if (data.StaffRefNo === -1) {
          this.toastr.error('Stove Item already exists.', 'Stove Item Master', { timeOut: 2000 });
        } else if (data.StaffRefNo === -2) {
          // this.toastr.error("Phone No already exists.", "Stove Item Master", {timeOut: 2000});
        } else if (data.StaffRefNo > 0 && this.Operation === 'EDIT') {
          this.resetForm();
          this.GetStoveItemDetails();
          this.toastr.success('Record Updated Successfully.', 'Stove Item Master', { timeOut: 2000 });
        } else if (data.StaffRefNo > 0) {
          this.resetForm();
          this.toastr.success('Record Inserted Successfully.', 'Stove Item Master', { timeOut: 2000 });
          this.GetStoveItemDetails();
        }
      }
    });
  }

}
