import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurakshaCampaignUploadComponent } from './suraksha-campaign-upload.component';

describe('SurakshaCampaignUploadComponent', () => {
  let component: SurakshaCampaignUploadComponent;
  let fixture: ComponentFixture<SurakshaCampaignUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurakshaCampaignUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurakshaCampaignUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
