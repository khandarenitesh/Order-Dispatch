import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, ChangeDetectorRef, OnDestroy } from '@angular/core';

import { FormControl } from '@angular/forms';

// Models
import { DistributorModel } from '../../../models/DBCCampaignUpload/dbc-campaign-upload.model';

// Services
import { DBCCampaignUploadService } from '../../../services/DBCCampaignUpload/dbc-campaign-upload.service';
import { ToastrService } from 'ngx-toastr';
import { Subscription, Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';

@Component({
  selector: 'kt-suraksha-campaign-upload',
  templateUrl: './suraksha-campaign-upload.component.html',
  styleUrls: ['./suraksha-campaign-upload.component.scss']
})
export class SurakshaCampaignUploadComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('fileInput') fileInput: ElementRef;
  isLoading: boolean = false;
  private unsubscribe: Subscription[] = [];
  SelectedDistributor: DistributorModel = new DistributorModel();
  filteredDistributorOptions: Observable<DistributorModel[]>;
  myControlDistributor = new FormControl();
  DDLDistributorList: DistributorModel[];
  postDistributorModal: any;

  constructor(private surakshaCampaignUploadService: DBCCampaignUploadService, private toastr: ToastrService, private chRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.clearFile();
    this.BindAllDDLDistributorList();
  }

  // Get Distributor List
  BindAllDDLDistributorList() {
    this.postDistributorModal = {
      'DistributorId': 0
    };
    this.unsubscribe.push(this.surakshaCampaignUploadService.GetDistDetails(this.postDistributorModal)
      .subscribe((data) => {
        this.DDLDistributorList = data.DistributorList;
        this.filteredDistributorOptions = this.myControlDistributor.valueChanges
          .pipe(startWith<string | DistributorModel>(''),
            map(value => typeof value === 'string' ? value : value !== null ? value.DistributorName : null),
            map(DistributorName => DistributorName ? this.filterDistributor(DistributorName) : this.DDLDistributorList.slice()));
        this.chRef.detectChanges();
      }, () => {
      }));
  }

  private filterDistributor(name: string): DistributorModel[] {
    const filterDistributorValue = name.toLowerCase();
    return this.DDLDistributorList.filter((option) => option.DistributorName.toLowerCase().includes(filterDistributorValue) ||
      option.JDEDistributorCode.toLocaleLowerCase().includes(filterDistributorValue));
  }

  displayFnDistributor(user?: DistributorModel): string | undefined {
    return user ? user.DistributorName + "( " + user.JDEDistributorCode + " ) " : undefined;
  }

  onChange() {
    let file = this.fileInput.nativeElement.files[0];
    if (file.name.split('.').pop() !== "xls" || file.name.split('.').pop() !== "xlsx" || file.name.split('.').pop() !== "csv") {

    } else {
      this.toastr.error("Accepts only xls or .xlsx or .csv");
      this.fileInput.nativeElement.value = null;
    }
  }

  // DBC Campaign Upload Excel File
  uploadExcelFile() {
    this.isLoading = true;
    if (this.SelectedDistributor != null && this.SelectedDistributor != undefined && this.SelectedDistributor.DistributorId > 0) {
      let formData = new FormData();
      let file = this.fileInput.nativeElement.files[0];
      if (file === undefined) {
        this.toastr.error('Please Select File');
        this.isLoading = false;
      } else if (file != undefined && (file.name.split('.').pop() === "xls" || file.name.split('.').pop() === "xlsx" || file.name.split('.').pop() === "csv")) {
        formData.append('upload', file);
        this.surakshaCampaignUploadService.SurakshaUploadExcel(this.SelectedDistributor.DistributorId, formData).subscribe((data: any) => {
          if (data === "-1") {
            this.toastr.error("Distributor Data Already Exists.", "Suraksha Campaign");
            this.clearFile();
          } else if (data.length > 0) {
            this.toastr.success("Uploaded SuccessFully", "Suraksha Campaign");
            this.clearFile();
          } else {
            this.toastr.error("Uploaded Failed", "Suraksha Campaign");
            this.clearFile();
          }
        });
      } else {
        this.toastr.warning('File is Invalid (Accepts only xls or .xlsx)');
        this.clearFile();
      }
    } else {
      this.toastr.error('Please Select Distributor');
      this.isLoading = false;
      this.chRef.detectChanges();
    }
  }

  // Clear File
  clearFile() {
    this.SelectedDistributor = null;
    this.fileInput.nativeElement.value = null;
    this.isLoading = false;
    this.chRef.detectChanges();
  }

  // Set side menu close
  ngAfterViewInit() {
    this.surakshaCampaignUploadService.Toggler = new KTToggle('kt_aside_toggler', this.surakshaCampaignUploadService.toggleOptions);
    this.surakshaCampaignUploadService.DivToggleWidth = '100%';
    this.surakshaCampaignUploadService.IsModelOn = false;
    this.surakshaCampaignUploadService.displayValue = false;
    this.surakshaCampaignUploadService.Toggler.toggleOn();
    $('#kt_aside_close_btn').click();
    setTimeout(() => {
      this.surakshaCampaignUploadService.OpenToggle = true;
      this.surakshaCampaignUploadService.Toggler.toggleOn();
      $('#kt_aside_close_btn').click();
    }, 500);
  }

  ngOnDestroy() {
    this.unsubscribe.forEach(sb => sb.unsubscribe());
  }

}
