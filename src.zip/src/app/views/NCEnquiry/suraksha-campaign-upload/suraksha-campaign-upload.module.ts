import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SurakshaCampaignUploadComponent } from './suraksha-campaign-upload.component';
import { AuthGuard } from '../../../core/auth';
import { GetSessionService } from '../../../services/globalsession.service';
import { ToastrService } from 'ngx-toastr';
import {
  MatButtonModule, MatInputModule, MatTableModule, MatStepperModule, MatProgressSpinnerModule, MatAutocompleteModule,
  MatRippleModule, MatFormFieldModule, MatSelectModule, MatDatepickerModule, MatCheckboxModule, MatIconModule, MatPaginatorModule, MatSortModule, MatRadioModule, MatTooltipModule
} from '@angular/material';
import { MatTableExporterModule } from 'mat-table-exporter';
import { PartialsModule } from '../../partials/partials.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '../../../../../src/app/core/core.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';


const SurakshaCampaignUploadComponentRoutes: Routes = [
  {
    path: '',
    children: [
      { path: 'SurakshaCampaignUpload', component: SurakshaCampaignUploadComponent, canActivate: [AuthGuard], data: { roles: ['1'] } }
    ]
  }
];
const modules = [
  MatButtonModule, MatFormFieldModule, MatInputModule, MatRippleModule, MatTableModule,
  MatAutocompleteModule, MatSelectModule, MatDatepickerModule, MatStepperModule, MatProgressSpinnerModule, MatSortModule,
  MatPaginatorModule, MatIconModule, MatTableExporterModule, MatCheckboxModule, MatRadioModule
];
@NgModule({
  declarations: [SurakshaCampaignUploadComponent],
  providers: [GetSessionService, ToastrService],
  imports: [
    modules,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    PartialsModule,
    CoreModule,
    NgbModule,
    MatTooltipModule,
    DataTablesModule,
    RouterModule.forChild(SurakshaCampaignUploadComponentRoutes)
  ]
})
export class SurakshaCampaignUploadModule { }
