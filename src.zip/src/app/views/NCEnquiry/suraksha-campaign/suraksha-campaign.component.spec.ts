import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurakshaCampaignComponent } from './suraksha-campaign.component';

describe('SurakshaCampaignComponent', () => {
  let component: SurakshaCampaignComponent;
  let fixture: ComponentFixture<SurakshaCampaignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurakshaCampaignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurakshaCampaignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
