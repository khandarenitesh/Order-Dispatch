import { Component, OnInit, OnDestroy, ChangeDetectorRef, ViewChild, AfterViewInit } from '@angular/core';
import { Subscription, Observable, timer } from 'rxjs';
import { FormControl } from '@angular/forms';
import { switchMap, startWith, map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import moment = require('moment');
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { MatPaginator, MatSort, MatTableDataSource, MatCheckboxChange } from '@angular/material';
import { AdminDbcService } from '../../../services/adminDBCCampaign/admin-dbc.service';
import { GetSessionService } from '../../../services/globalsession.service';
import { ConfigurationDetailsService } from '../../../services/ConfigurationDetails/configuration-details.service';
// Models
import {
	ConfigurationDetailsMasterModel, DistributorModel, TemplateModel, SBCConfigDetailsModel, SBCConfigDetailsListModel,
	GroupModel
}
	from '../../../models/ConfigurationDetails/configuration-details.model';

@Component({
	selector: 'kt-suraksha-configuration-details',
	templateUrl: './suraksha-configuration-details.component.html',
	styleUrls: ['./suraksha-configuration-details.component.scss']
})
export class SurakshaConfigurationDetailsComponent implements OnInit, AfterViewInit, OnDestroy {
	private unsubscribe: Subscription[] = [];
	SAList = [];
	postModal: any;
	model: any;
	SelectedSA: any;
	@ViewChild('paginator') paginator: MatPaginator;
	@ViewChild('Sort') Sort: MatSort;
	filteredSelectDistributorOptions: Observable<DistributorModel[]>;
	myControlDistributor = new FormControl();
	DDLDistributorList: DistributorModel[];
	myControlSelectDistributors = new FormControl();
	filteredDistributorOptions: Observable<DistributorModel[]>;
	myControlGroup = new FormControl();
	DDLGroupList: GroupModel[];
	filteredGroupOptions: Observable<GroupModel[]>;
	isEdit: boolean = false;
	subscription: Subscription;
	tooltipMsgResult: string = "";
	SelectedGroup: GroupModel = new GroupModel();
	myControlTemplate = new FormControl();
	public _SBCConfigDetailsModel: SBCConfigDetailsModel = new SBCConfigDetailsModel();
	ScheduleDateResult: Date = new Date();
	ScheduleDaily: string = "";
	checked: boolean = false;
	public _ConfigurationDetailsMasterModel: ConfigurationDetailsMasterModel = new ConfigurationDetailsMasterModel();
	SelectedDistributors: DistributorModel[] = new Array<DistributorModel>();
	postSBCDistributorGroupMappingAddEditModal: any;
	postSBCConfigDetailsAddUpdateModal: any;
	SelectedDistributor: DistributorModel[] = new Array<DistributorModel>();
	public DataSource = new MatTableDataSource<SBCConfigDetailsListModel>();
	displayedColumnsForApi = ['SrNo', 'GroupName', 'DistributorName', 'TemplateName', 'TotalConsumer', 'NonWhatsAppNo', 'TotalSend', 'Balanced', 'ScheduleQty', 'Status', 'Actions'];
	isLoading: boolean = false;
	isQueued: boolean = false;
	DDLTemplateList: TemplateModel[];
	Distributors: DistributorModel[] = new Array<DistributorModel>();
	modalReference: NgbModalRef;
	GroupName: string = "";
	SelectTemplate: string = "";
	TemplateFor: string = 'SURAKSHA';
	TemplateId: string = "";

	constructor(private adminDbcService: AdminDbcService, private chRef: ChangeDetectorRef, private getSession: GetSessionService,
		private _ConfigurationDetailsService: ConfigurationDetailsService, private toastr: ToastrService, private modalService: NgbModal) { }

	ngOnInit() {
		this._SBCConfigDetailsModel = {
			ScheduleDate: this.ConvertStringToDateObj(this.ScheduleDateResult)
		};
		this.postModal = {
			'Id': this.GetLoginDetails()
		};
		this.GetSAList(this.postModal);
		this.refreshData();
	}

	refreshData() {
		this.isLoading = true;
		this.subscription = timer(0, 120000)
			.pipe(switchMap(() => this._ConfigurationDetailsService.GetSurakshaConfigDetailsList("0")))
			.subscribe((data) => {
				if (data.length > 0 && data != null && data != "" && data != undefined) {
					this.DataSource.data = data;
					this.DataSource.paginator = this.paginator;
					this.DataSource.sort = this.Sort;
					this.isLoading = false;
					let data1 = this.DataSource.data.filter(x => x.CurrentStatus === 'QUEUED')
					if (data1.length > 0) {
						this.isQueued = false;
					} else {
						this.isQueued = true;
					}
					this.chRef.detectChanges();
				} else {
					this.DataSource.data = [];
					this.isLoading = false;
					this.chRef.detectChanges();
				}
			});
	}

	GetLoginDetails() {
		let item = this.getSession.GetSessionData();
		return item.refNo;
	}

	GetSAList(postModel) {
		this.unsubscribe.push(this.adminDbcService.GetSAByRoCode(postModel.Id)
			.subscribe((data) => {
				this.SAList = data;
				this.SAList = this.SAList.sort((a: any, b: any) => a.SAName.localeCompare(b.SAName));
				if (!this.chRef['destroyed']) {
					this.chRef.detectChanges();
				}
			}, (error) => {
				console.error(error);
			}));
	}

	onChangeBindDistributorList() {
		this.model = {
			'DistributorId': 0,
			'SACode': this.SelectedSA
		}
		this.unsubscribe.push(this._ConfigurationDetailsService.GetSAListDetails(this.model)
			.subscribe((data) => {
				this.DDLDistributorList = data;
				this.filteredSelectDistributorOptions = this.myControlSelectDistributors.valueChanges
					.pipe(startWith<string | DistributorModel>(''),
						map(value => typeof value === 'string' ? value : value !== null ? value.DistributorName : null),
						map(DistributorName => DistributorName ? this.filterDistributor(DistributorName) : this.DDLDistributorList.slice()));
				this.chRef.detectChanges();
			}, () => { }));
		this.BindAllDDLGroupList();
	}
	// Get Suraksha Distributor Group Mapping List
	BindAllDDLGroupList() {
		this.unsubscribe.push(this._ConfigurationDetailsService.GetSurakshaDistributorGroupMappingList(this.SelectedSA)
			.subscribe((data: any) => {
				if (data.length > 0) {
					this.myControlGroup.reset();
					this.DDLGroupList = [];
					this.DDLGroupList = data;
					this.filteredGroupOptions = this.myControlGroup.valueChanges
						.pipe(startWith<string | GroupModel>(''),
							map(value => typeof value === 'string' ? value : value !== null ? value.GroupName : null),
							map(GroupName => GroupName ? this.filterGroup(GroupName) : this.DDLGroupList.slice()));
					this.chRef.detectChanges();
				} else {
					this.NotSelectedGroup();
				}
			}, () => { }));
	}

	NotSelectedGroup() {
		this.isEdit = false;
		this.tooltipMsgResult = "";
		this.SelectedGroup = null;
		this.myControlGroup.reset();
		this.DDLGroupList = [];
		this.filteredGroupOptions = this.myControlGroup.valueChanges
			.pipe(startWith<string | GroupModel>(''),
				map(value => typeof value === 'string' ? value : value !== null ? value.GroupName : null),
				map(GroupName => GroupName ? this.filterGroup(GroupName) : this.DDLGroupList.slice()));
		this.myControlDistributor.reset();
		this.myControlTemplate.reset();
		this.chRef.detectChanges();
	}

	displayFnGroup(user?: GroupModel): string | undefined {
		return user ? user.GroupName : undefined;
	}

	private filterDistributor(name: string): DistributorModel[] {
		const filterDistributorValue = name.toLowerCase();
		return this.DDLDistributorList.filter((option) => option.DistributorName.toLowerCase().includes(filterDistributorValue) ||
			option.JDEDistributorCode.toLocaleLowerCase().includes(filterDistributorValue));
	}

	displayFnDistributor(value: DistributorModel[] | string): string | undefined {
		let displayValue: string;
		if (Array.isArray(value)) {
			value.forEach((user, index) => {
				if (index === 0) {
					displayValue = user.DistributorName;
				} else {
					displayValue += ', ' + user.DistributorName;
				}
			});
		} else {
			displayValue = value;
		}
		return displayValue;
	}

	private filterGroup(name: string): GroupModel[] {
		const filterGroupValue = name.toLowerCase();
		return this.DDLGroupList.filter(option => option.GroupName.toLowerCase().includes(filterGroupValue));
	}

	// On Change Group By Distributor List
	onChangeBindGroupByDistributorList() {
		if (this.SelectedSA != null && this.SelectedSA != undefined &&
			(this.SelectedGroup != null && this.SelectedGroup.GroupName != null && this.SelectedGroup.GroupName != "" && this.SelectedGroup.GroupName != undefined)) {
			this.unsubscribe.push(this._ConfigurationDetailsService.GetSurakshaDistributorListByGroup(this.SelectedSA, this.SelectedGroup.GroupName)
				.subscribe((data: any) => {
					this.isEdit = true;
					this.SelectedDistributor = new Array<DistributorModel>();
					this.tooltipMsgResult = "";
					for (let res of data) {
						if (res.selected === 1) {
							this.SelectedDistributor.push(res);
							this.tooltipMsgResult += res.DistributorName + ", ";
							this.SelectedDistributor.findIndex(value => value.DistributorName === res.DistributorName);
							this.myControlDistributor.setValue(this.SelectedDistributor);
							this.myControlTemplate.setValue(res.TemplateName);
							this.TemplateId = res.TemplateId;
						}
					}
					this.tooltipMsgResult = this.tooltipMsgResult.replace(/,(?=[^,]*$)/, '');
					this.DDLDistributorList = this.SelectedDistributor;
					this.DDLDistributorList = this.DDLDistributorList.sort((a: any, b: any) => a.DistributorName.localeCompare(b.DistributorName));
					this.filteredDistributorOptions = this.myControlDistributor.valueChanges
						.pipe(startWith<string | DistributorModel>(''),
							map(value => typeof value === 'string' ? value : value !== null ? value.DistributorName : null),
							map(DistributorName => DistributorName ? this.filterDistributor(DistributorName) : this.DDLDistributorList.slice()));
					this.chRef.detectChanges();
				}, () => { }));
		} else {
			this.onChangeUnSelectedGroup();
		}
	}

	onChangeUnSelectedGroup() {
		this.isEdit = false;
		this.tooltipMsgResult = "";
		this.SelectedDistributor = new Array<DistributorModel>();
		this.myControlDistributor.reset();
		this.DDLDistributorList = [];
		this.DDLDistributorList = this.SelectedDistributor;
		this.DDLDistributorList = this.DDLDistributorList.sort((a: any, b: any) => a.DistributorName.localeCompare(b.DistributorName));
		this.filteredDistributorOptions = this.myControlDistributor.valueChanges
			.pipe(startWith<string | DistributorModel>(''),
				map(value => typeof value === 'string' ? value : value !== null ? value.DistributorName : null),
				map(DistributorName => DistributorName ? this.filterDistributor(DistributorName) : this.DDLDistributorList.slice()));
		this.myControlTemplate.reset();
		this.chRef.detectChanges();
	}

	// Get Suraksha ConfigDetails List
	GetSurakshaConfigDetailsList() {
		this.isLoading = true;
		this.unsubscribe.push(this._ConfigurationDetailsService.GetSurakshaConfigDetailsList("0")
			.subscribe((data: any) => {
				if (data.length > 0) {
					this.DataSource.data = data;
					this.DataSource.paginator = this.paginator;
					this.DataSource.sort = this.Sort;
					this.isLoading = false;
					let data1 = this.DataSource.data.filter(x => x.CurrentStatus === 'QUEUED')
					if (data1.length > 0) {
						this.isQueued = false;
					} else {
						this.isQueued = true;
					}
					this.chRef.detectChanges();
				} else {
					this.DataSource.data = [];
					this.isLoading = false;
					this.chRef.detectChanges();
				}
			}, () => {
				this.isLoading = false;
			}));
	}
	optionClicked(event: MatCheckboxChange, user: DistributorModel) {
		let res = 0;
		if (event.checked === false) {
			res = 0;
			this.toggleSelection(user, res);
		}
		else {
			res = 1;
			this.toggleSelection(user, res);
		}
		this.chRef.detectChanges();
	}

	toggleSelection(user: DistributorModel, res) {
		if (res == 1) {
			this.Distributors.push(user);
			this.myControlSelectDistributors.setValue(this.Distributors);
		} else {
			const i = this.Distributors.findIndex(value => value.DistributorName === user.DistributorName);
			this.Distributors.splice(i, 1);
			this.myControlSelectDistributors.setValue(this.Distributors);
			this.chRef.detectChanges();
		}
	}
	// Get Template List
	BindAllDDLTemplateList() {
		this.unsubscribe.push(this._ConfigurationDetailsService.GetTemplateDetails(this.TemplateFor)
			.subscribe((data: any) => {
				this.DDLTemplateList = data;
				this.chRef.detectChanges();
			}, () => { }));
	}

	numberOnly(event): boolean {
		const charCode = (event.which) ? event.which : event.keyCode;
		if (charCode > 31 && (charCode < 48 || charCode > 57)) {
			return false;
		}
		return true;
	}

	// Save Configuration Details
	SaveConfigurationDetails() {
		var arrDistributor = [];
		var tempDistributor: any;
		tempDistributor = "";
		this.ScheduleDaily = (this.checked === true ? "Y" : "N");
		if (this.SelectedSA === null || this.SelectedSA === undefined) {
			this.toastr.error('Please Select Sales Area(SA)');
		} else if ((this.SelectedGroup === null || (this.SelectedGroup.GroupName === null || this.SelectedGroup.GroupName === "" || this.SelectedGroup.GroupName === undefined)) &&
			(this.myControlDistributor.value === "" || this.myControlDistributor.value === null || this.myControlDistributor.value === undefined) &&
			(this.myControlTemplate.value === "" || this.myControlTemplate.value === null || this.myControlTemplate.value === undefined)) {
			this.toastr.error('Please Select Group');
		} else if (this._ConfigurationDetailsMasterModel.SendMessageValue <= 0) {
			this.toastr.error('Message Qty cannot be zero or less than zero');
		} else {
			arrDistributor.push(this.SelectedDistributor);
			arrDistributor.forEach((element: any) => {
				for (var i = 0; i < element.length; i++) {
					tempDistributor += element[i].DistributorId + ",";
				}
			});
			this.postSBCConfigDetailsAddUpdateModal = {
				'SACode': this.SelectedSA,
				'ScheduleDate': this.ConvertDateFormat(this._SBCConfigDetailsModel.ScheduleDate),
				'GroupName': this.SelectedGroup.GroupName,
				'DistributorIdarray': tempDistributor,
				'DistributorMobNo': "",
				'EmergencyNo': "",
				'IsWithRefillCost': "",
				'RSP': "",
				'TemplateId': this.TemplateId,
				'MsgQty': this._ConfigurationDetailsMasterModel.SendMessageValue,
				'CurrentStatus': "QUEUED",
				'Action': "ADD",
				'Retvalue': "",
				'ScheduleDaily': this.ScheduleDaily
			};
			this.unsubscribe.push(this._ConfigurationDetailsService.SurakshaConfigDetailsAddUpdate(this.postSBCConfigDetailsAddUpdateModal)
				.subscribe((data: any) => {
					if (data === 1) {
						this.toastr.success('Record Added Successfully!!!', 'Suraksha Configuration Details');
					} else if (data === -1) {
						this.toastr.error('Distributors Already Exists', 'Suraksha Configuration Details');
					}
					this.GetSurakshaConfigDetailsList();
					this.ClearConfigurationDetails();
					this.chRef.detectChanges();
				}, () => {
					this.toastr.error('Error', 'Suraksha Configuration Details');
					this.chRef.detectChanges();
				}));
		}
	}
	// Send Message Configuration Details
	SendMessageConfigurationDetails(row: SBCConfigDetailsListModel) {
		row.CurrentStatus = 'In-Progress';
		this.unsubscribe.push(this._ConfigurationDetailsService.SendMessageSurakshaConfigurationDetails(row)
			.subscribe(() => {
				this.GetSurakshaConfigDetailsList();
			}, () => { }));
	}

	// Send Message All Configuration Details
	SendMessageAllConfigurationDetails() {
		this.isLoading = true;
		this.unsubscribe.push(this._ConfigurationDetailsService.SendMessageSurakshaAllConfigurationDetails()
			.subscribe(() => {
				setTimeout(async () => {
					await this.GetSurakshaConfigDetailsList();
					this.isLoading = false;
				}, 60000); // 1 min.
			}, () => { }));
	}
	// Open Modal
	openModal(content) {
		if (this.SelectedSA != null || this.SelectedSA != undefined) {
			this.modalReference = this.modalService.open(content, {
				centered: true,
				size: 'lg',
				backdrop: 'static'
			});
			// Get Distributor List By Group
			if (this.SelectedGroup != null && (this.SelectedGroup.GroupName != null && this.SelectedGroup.GroupName != "" && this.SelectedGroup.GroupName != undefined)) {
				this.unsubscribe.push(this._ConfigurationDetailsService.GetSurakshaDistributorListByGroup(this.SelectedSA, this.SelectedGroup.GroupName)
					.subscribe((data: any) => {
						this.isEdit = true;
						this.SelectedDistributors = new Array<DistributorModel>();
						this.Distributors = [];
						this.myControlSelectDistributors.reset();
						this.DDLTemplateList = [];
						this.SelectedDistributors = this.SelectedDistributors.sort((a: any, b: any) => a.DistributorName.localeCompare(b.DistributorName));
						for (let res of data) {
							if (res.selected === 1) {
								this.GroupName = res.GroupName;
								this.SelectedDistributors.push(res);
								this.Distributors.push(res);
								this.DDLDistributorList.findIndex(value => value.DistributorName === res.DistributorName);
								this.myControlSelectDistributors.setValue(this.Distributors);
								this.DDLTemplateList.push(res);
								this.SelectTemplate = res.TemplateId;
							} else {
								this.SelectedDistributors.push(res);
								this.DDLTemplateList.push(res);
							}
						}
						this.DDLDistributorList = this.SelectedDistributors;
						this.filteredSelectDistributorOptions = this.myControlSelectDistributors.valueChanges
							.pipe(startWith<string | DistributorModel>(''),
								map(value => typeof value === 'string' ? value : value !== null ? value.DistributorName : null),
								map(DistributorName => DistributorName ? this.filterDistributor(DistributorName) : this.DDLDistributorList.slice()));
						this.chRef.detectChanges();
						this.BindAllDDLTemplateList();
					}));
			} else {
				this.onClear();
				this.isEdit = false;
			}
		} else {
			this.toastr.error('Please Select Sales Area(SA)');
		}
	}
	onChangeSelectDistributors() {
		if (this.myControlSelectDistributors.value === "") {
			this.myControlSelectDistributors.reset();
			this.SelectedDistributors = [];
			this.Distributors = [];
			this.onChangeBindDistributorList(); // Get SA wise Distributors List
		}
	}

	// Suraksha Distributor Group Mapping -> Add/Update
	onSaveSurakshaDistributorGroupMappingAddEdit() {
		var arrDistributor = [];
		var tempDistributor: any;
		tempDistributor = "";
		if (this.GroupName === null || this.GroupName === "" || this.GroupName === undefined) {
			this.toastr.error('Please Enter Group Name');
		} else if (this.Distributors.length === 0 || this.Distributors === null || this.Distributors === undefined) {
			this.toastr.error('Please Select Distributors');
		} else if (this.SelectTemplate === null || this.SelectTemplate === "" || this.SelectTemplate === undefined) {
			this.toastr.error('Please Select Template');
		} else {
			arrDistributor.push(this.Distributors);
			arrDistributor.forEach((element: any) => {
				for (var i = 0; i < element.length; i++) {
					tempDistributor += element[i].DistributorId + ",";
				}
			});
			// Add
			if (this.isEdit === false) {
				this.postSBCDistributorGroupMappingAddEditModal = {
					'GroupId': 0,
					'GroupName': this.GroupName,
					'SACode': this.SelectedSA,
					'DistributorIdArray': tempDistributor,
					'TemplateId': this.SelectTemplate,
					'IsActive': "Y",
					'Action': "ADD",
					'Retvalue': ""
				};
				this.unsubscribe.push(this._ConfigurationDetailsService.SurakshaDistributorGroupMappingAddEdit(this.postSBCDistributorGroupMappingAddEditModal)
					.subscribe((data: any) => {
						if (data > 0) {
							this.toastr.success('Added Successfully!!!', 'Group Name');
							this.modalReference.close();
							this.onChangeBindGroupByDistributorList();
							this.BindAllDDLGroupList();
							this.chRef.detectChanges();
						} else {
							this.toastr.error('Distributor Group Mapping Already Exists', 'Group Name');
							this.modalReference.close();
							this.onClear();
							this.chRef.detectChanges();
						}
					}, () => { }));
			} else {
				// Edit/Update
				this.postSBCDistributorGroupMappingAddEditModal = {
					'GroupId': 0,
					'GroupName': this.GroupName,
					'SACode': this.SelectedSA,
					'DistributorIdArray': tempDistributor,
					'TemplateId': this.SelectTemplate,
					'IsActive': "Y",
					'Action': "Edit",
					'Retvalue': ""
				};
				this.unsubscribe.push(this._ConfigurationDetailsService.SurakshaDistributorGroupMappingAddEdit(this.postSBCDistributorGroupMappingAddEditModal)
					.subscribe((data: any) => {
						if (data > 0) {
							this.toastr.success('Update Successfully!!!', 'Group Name');
							this.modalReference.close();
							this.onChangeBindGroupByDistributorList();
							this.BindAllDDLGroupList();
							this.chRef.detectChanges();
						} else {
							this.toastr.error('Distributor Group Mapping Already Exists', 'Group Name');
							this.modalReference.close();
							this.onClear();
							this.chRef.detectChanges();
						}
					}, () => { }));
			}
		}
	}

	onClear() {
		this.GroupName = "";
		this.DDLDistributorList = [];
		this.SelectedDistributors = [];
		this.Distributors = [];
		this.myControlSelectDistributors.reset();
		this.SelectTemplate = "";
		this.BindAllDDLTemplateList();  // Get Template List
		this.onChangeBindDistributorList(); // Get SA wise Distributors List
	}

	//Cancel the update popup
	onCancel() {
		this.modalReference.close();
		this.Distributors = [];
		this.myControlSelectDistributors.reset();
	}

	// Clear ConfigurationDetails
	ClearConfigurationDetails() {
		this.SelectedSA = null;
		this.SelectedGroup = null;
		this.myControlGroup.reset();
		this.DDLGroupList = [];
		this.onChangeBindDistributorList();
		this.SelectedDistributor = null;
		this.myControlDistributor.reset();
		this.DDLDistributorList = [];
		this.DDLTemplateList = [];
		this.myControlTemplate.reset();
		this._ConfigurationDetailsMasterModel.SendMessageValue = 0;
		this.tooltipMsgResult = "";
		this.checked = false;
	}

	// Use to convert string to date obj
	ConvertStringToDateObj(SelDate) {
		let d = new Date(moment(SelDate, 'DD-MM-YYYY hh:mm tt').format('YYYY-MM-DD'));
		return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() };
	}

	// Use to Convert object to  Date Format string
	ConvertDateFormat(condate) {
		let dateInput = new Date(condate.year, condate.month - 1, condate.day);
		return moment(dateInput).format('YYYY-MM-DD');
	}

	// Set side menu close
	ngAfterViewInit() {
		this._ConfigurationDetailsService.Toggler = new KTToggle('kt_aside_toggler', this._ConfigurationDetailsService.toggleOptions);
		this._ConfigurationDetailsService.DivToggleWidth = '100%';
		this._ConfigurationDetailsService.IsModelOn = false;
		this._ConfigurationDetailsService.displayValue = false;
		this._ConfigurationDetailsService.Toggler.toggleOn();
		$('#kt_aside_close_btn').click();
		setTimeout(() => {
			this._ConfigurationDetailsService.OpenToggle = true;
			this._ConfigurationDetailsService.Toggler.toggleOn();
			$('#kt_aside_close_btn').click();
		}, 500);
	}

	ngOnDestroy() {
		this.subscription.unsubscribe();
		this.unsubscribe.forEach(sb => sb.unsubscribe());
	}

}

