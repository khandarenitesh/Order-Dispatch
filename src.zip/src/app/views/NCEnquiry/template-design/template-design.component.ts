import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-template-design',
  templateUrl: './template-design.component.html',
  styleUrls: ['./template-design.component.scss']
})
export class TemplateDesignComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
