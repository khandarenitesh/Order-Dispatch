import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TemplateDesignComponent } from './template-design.component';
import { MatTableExporterModule } from 'mat-table-exporter';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../../../app/core/auth';
import { ToastrService } from 'ngx-toastr';
import { GetSessionService } from '../../../services/globalsession.service';
import { PartialsModule } from '../../partials/partials.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '../../../../../src/app/core/core.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';
import { TemplateFormComponent } from './template-form/template-form.component';
import {
	MatButtonModule, MatInputModule, MatTableModule, MatStepperModule, MatProgressSpinnerModule, MatAutocompleteModule,
	MatRippleModule, MatFormFieldModule, MatSelectModule, MatDatepickerModule, MatCheckboxModule,MatListModule, MatIconModule, MatPaginatorModule, MatSortModule, MatRadioModule, MatTooltipModule
} from '@angular/material';
import { TemplateListComponent } from './template-list/template-list.component';

const modules = [
	MatButtonModule, MatFormFieldModule, MatInputModule, MatRippleModule, MatTableModule,
    MatAutocompleteModule, MatSelectModule, MatDatepickerModule, MatStepperModule, MatProgressSpinnerModule, MatSortModule,
    MatPaginatorModule, MatIconModule, MatTableExporterModule, MatCheckboxModule, MatRadioModule,MatListModule
];

const TemplateDesignRoutes: Routes = [
	{
		path: '',
		children: [
			{ path: 'TemplateForm', component: TemplateFormComponent, canActivate: [AuthGuard], data: { roles: ['1'] } },
			{ path: 'Template-List',component:TemplateListComponent, canActivate:[AuthGuard], data:{ roles:['1'] } }
		]
	}
];

@NgModule({
  declarations: [TemplateDesignComponent,TemplateFormComponent, TemplateListComponent],
  providers: [ GetSessionService, ToastrService ],
	imports: [
		modules,
		FormsModule,
		ReactiveFormsModule,
		CommonModule,
		PartialsModule,
		CoreModule,
		NgbModule,
		MatTooltipModule,
		DataTablesModule,
		RouterModule.forChild(TemplateDesignRoutes)
	],
	exports: [ RouterModule ]
})
export class TemplateDesignModule { }
