import { DynamicTemplateService } from './../../../../services/DynamicTemplate/dynamic-template.service';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';

export class Valuequantities {
	Value: string = '';
	FieldType: string = '';
	IsBold: string = '';
}

@Component({
	selector: 'kt-template-form',
	templateUrl: './template-form.component.html',
	styleUrls: ['./template-form.component.scss']
})
export class TemplateFormComponent implements OnInit {

	templateDetailsForm: FormGroup;
	ValuequantitiesModel: Valuequantities = new Valuequantities();
	TemplateData: Valuequantities[] = []; // Array of json
	response: any;
	submitted = false;
	isLoading: boolean = false;
	IsActive: string;
	Pkid: number;
	TemplateId: string;
	TemplateName: string;
	IsDD: boolean = true;
	TemplateType: any;
	isChecked: boolean = true;
	PageState: string = 'Save';

	constructor(private fb: FormBuilder, private chngf: ChangeDetectorRef, private toaster: ToastrService,
		private _service: DynamicTemplateService, private router: Router) { }

	ngOnInit() {
		if (this._service.Id != 0) {
			this.GetTemplateData(this._service.Id);
			this.PageState = 'Edit';
			//form Loaded
			this.FormInit();
		}
		else {
			//form Loaded
			this.FormInit();
			//Load first formarray row
			this.addQuantity();
			this.isChecked = true;
		}
	}

	//Form Init
	FormInit(): FormGroup {
		return this.templateDetailsForm = this.fb.group({
			TemplateId: ['', Validators.compose([Validators.required])],
			IsActive: [],
			TemplateName: ['', Validators.compose([Validators.required])],
			CampaignId: ['', Validators.compose([Validators.required])],
			CampaignName: ['', Validators.compose([Validators.required])],
			TemplateFor: ['', Validators.compose([Validators.required])],
			FileName: [''],
			Valuequantities: this.fb.array([]),
			MediaTypes: [''],
			IsBold: [''],
		});
	}

	//Get FormArrays
	GetValueinquantities(): FormArray {
		return this.templateDetailsForm.get("Valuequantities") as FormArray
	}

	//New quantity Init
	newQuantity(): FormGroup {
		return this.fb.group({
			DynamicValue: [''],
			IsFieldType: [''],
			IsBold: [''],
		})
	}

	//Add Data dynamically
	addQuantity() {
		this.GetValueinquantities().push(this.newQuantity());
		this.chngf.detectChanges();
	}

	//Remove Dynamic Record row wise
	removeQuantityRow(i: number) {
		this.GetValueinquantities().removeAt(i);
		this.response = i;
		this.chngf.detectChanges();
	}

	onChangeIsDropDownOrText(i) {
		if (this.templateDetailsForm.controls['Valuequantities'].value[i].IsFieldType === "IsDropDown") {
			document.getElementById("txt_" + i).style.display = "none";
			document.getElementById("DD_" + i).style.display = "block";
		}
		else {
			document.getElementById("DD_" + i).style.display = "none";
			document.getElementById("txt_" + i).style.display = "block";
		}
	}

	onChangeIsMediaType() {
		if (this.templateDetailsForm.controls['MediaTypes'].value === "video" || this.templateDetailsForm.controls['MediaTypes'].value === "image"
			|| this.templateDetailsForm.controls['MediaTypes'].value === "pdf") {
			this.IsDD = false;
			this.chngf.detectChanges();
		} else {
			this.IsDD = true;
			this.chngf.detectChanges();
		}
	}

	//Save The Template Data
	onSubmit() {
		this.TemplateData = [];
		// stop here if form is invalid
		this.submitted = true;
		if (this.templateDetailsForm.invalid) {
			this.toaster.warning('Please enter data!', 'Template Form');
			this.submitted = false;
			return;
		}
		else {
			for (let i = 0; i < this.templateDetailsForm.controls['Valuequantities'].value.length; i++) {
				this.ValuequantitiesModel = new Valuequantities();
				this.ValuequantitiesModel.Value = this.templateDetailsForm.controls['Valuequantities'].value[i].DynamicValue;
				this.ValuequantitiesModel.FieldType = this.templateDetailsForm.controls['Valuequantities'].value[i].IsFieldType;
				this.ValuequantitiesModel.IsBold = this.templateDetailsForm.controls['Valuequantities'].value[i].IsBold;
				if (this.templateDetailsForm.controls['Valuequantities'].value[i].IsBold === true) {
					this.ValuequantitiesModel.IsBold = 'Y';
				} else {
					this.ValuequantitiesModel.IsBold = 'N';
				}
				this.TemplateData.push(this.ValuequantitiesModel);
				if (this.ValuequantitiesModel.FieldType === "" || this.ValuequantitiesModel.FieldType === null
					|| this.ValuequantitiesModel.FieldType === undefined || this.ValuequantitiesModel.Value === "" ||
					this.ValuequantitiesModel.Value === null || this.ValuequantitiesModel.Value === undefined) {
					this.toaster.warning('Please Select An Option!');
					return;
				}
			}
			if (this.templateDetailsForm.controls['Valuequantities'].value.length <= 0) {
				this.toaster.warning('Please add at least one input field!');
				return;
			}
			var TemplateId = this.templateDetailsForm.controls['TemplateId'].value;
			var TemplateName = this.templateDetailsForm.controls['TemplateName'].value;
			var MediaTypes = this.templateDetailsForm.controls['MediaTypes'].value;
			var CampaignId = this.templateDetailsForm.controls['CampaignId'].value;
			var CampaignName = this.templateDetailsForm.controls['CampaignName'].value;
			var TemplateFor = this.templateDetailsForm.controls['TemplateFor'].value;
			var FileName = this.templateDetailsForm.controls['FileName'].value;
			if (MediaTypes !== "video" && MediaTypes !== "image" && MediaTypes !== "pdf" && MediaTypes !== "") {
				this.TemplateType = "Text";
				MediaTypes = "";
			} else {
				this.TemplateType = "Media";
			}
			if ((FileName === null || FileName === undefined || FileName === "" && MediaTypes !== "") &&
				(MediaTypes === "video" || MediaTypes === "image" || MediaTypes === "pdf" || MediaTypes === "")) {
				this.toaster.warning('Please enter file name!');
				return
			}
			let model = {
				'CampaignId': CampaignId,
				'CampaignName': CampaignName,
				'TemplateId': TemplateId,
				'TemplateName': TemplateName,
				'TemplateFor': TemplateFor,
				'TemplateType': this.TemplateType,
				'IsActive': "Y",
				'MediaType': MediaTypes,
				'FileName': FileName,
				'TemplateData': this.TemplateData
			}
			if (this.PageState == 'Save') {
				this._service.AddDynamicTemplateKeyValues(model)
					.subscribe((data: any) => {
						if (data > 0) {
							this.toaster.success("Data saved successfully!", "Template Form");
							this.ClearAllArrayControl();
							this.templateDetailsForm.reset();
							this.ClearData();
							this.submitted = false;
							this.chngf.detectChanges();
						}
						if (data === -1) {
							this.toaster.warning('Template already exists', 'Template Form');
							this.chngf.detectChanges();
						}
					}, (error) => {
						console.log(error);
						this.toaster.error('something is wrong!', 'Template Form');
					});
			}
			else {
				this._service.EditTemplateKeyValues(model)
					.subscribe((data: any) => {
						if (data > 0) {
							this.toaster.success("Data saved successfully!", "Template Form");
							this.ClearAllArrayControl();
							this.templateDetailsForm.reset();
							this.ClearData();
							this.submitted = false;
							this.chngf.detectChanges();
						}
						if (data === -1) {
							this.toaster.warning('Template already exists', 'Template Form');
							this.chngf.detectChanges();
						}
					}, (error) => {
						console.log(error);
						this.toaster.error('something is wrong!', 'Template Form');
					});
			}
		}
		this.submitted = false;
		this.chngf.detectChanges();
	}

	//Clear or Remove All Controller After Save
	ClearAllArrayControl() {
		const control = <FormArray>this.templateDetailsForm.controls['Valuequantities'];
		for (let i = control.length - 1; i >= 0; i--) {
			control.removeAt(i);
		}
		this.chngf.detectChanges();
	}

	//Clear Form Data
	ClearData() {
		this.templateDetailsForm.reset();
		this.IsDD = true;
		this.router.navigate(['/default/Template-List']);
		this._service.Id = 0;
		this.chngf.detectChanges();
	}

	GetTemplateData(Id: any) {
		this._service.GetTemplate(Id)
			.subscribe(data => {
				this.Afterdata(data);
			},
				(error: any) => {
					console.log(error);
					this.toaster.error('something is wrong!', 'Template Form');
				});
	}

	Afterdata(data) {
		this.templateDetailsForm.controls['CampaignId'].setValue(data.CampaignId);
		this.templateDetailsForm.controls['CampaignName'].setValue(data.CampaignName);
		this.templateDetailsForm.controls['TemplateId'].setValue(data.TemplateId);
		this.templateDetailsForm.controls['TemplateName'].setValue(data.TemplateName);
		this.templateDetailsForm.controls['TemplateFor'].setValue(data.TemplateFor);
		this.templateDetailsForm.controls['MediaTypes'].setValue(data.MediaType);
		if (data.MediaType !== 'Text') {
			this.IsDD = false;
			this.templateDetailsForm.controls['FileName'].setValue(data.FileName);
		}
		if (data.TemplateData != '' || data.TemplateData != null) {
			for (let i = 0; i < data.TemplateData.length; i++) {
				if (data.TemplateData[i].IsBold == 'Y') {
					this.GetValueinquantities().push(
						this.fb.group({
							DynamicValue: [data.TemplateData[i].Value],
							IsFieldType: [data.TemplateData[i].FieldType],
							IsBold: [true],
						}));
				}
				else {
					this.GetValueinquantities().push(
						this.fb.group({
							DynamicValue: [data.TemplateData[i].Value],
							IsFieldType: [data.TemplateData[i].FieldType],
							IsBold: [false],
						}));
				}
				this.chngf.detectChanges();
				if (data.TemplateData[i].FieldType == 'IsDropDown') {
					document.getElementById("txt_" + i).style.display = "none";
					document.getElementById("DD_" + i).style.display = "block";
				}
				else {
					document.getElementById("DD_" + i).style.display = "none";
					document.getElementById("txt_" + i).style.display = "block";
				}
			}
		}
	}
}
