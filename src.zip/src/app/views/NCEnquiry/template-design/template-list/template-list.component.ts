import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatSort, MatTableDataSource } from '@angular/material';
import { DynamicTemplateService } from '../../../../services/DynamicTemplate/dynamic-template.service';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';

@Component({
	selector: 'kt-template-list',
	templateUrl: './template-list.component.html',
	styleUrls: ['./template-list.component.scss']
})
export class TemplateListComponent implements OnInit {

	constructor(private _service: DynamicTemplateService, private chng: ChangeDetectorRef, private router: Router,
		private modalService: NgbModal, private toaster: ToastrService) { }

	displayedColumnsForAPI = ['SrNo', 'CampaignId', 'CampaignName', 'TemplateId', 'TemplateName', 'TemplateFor', 'Action'];
	@ViewChild('paginator') paginator
	@ViewChild('Sort') Sort: MatSort;
	public DataSource = new MatTableDataSource<any>();
	isLoading: boolean = false; ViewModal: any; TemplateId: string;
	TMPVALUEDATA: [] = [];

	ngOnInit() {
		this.GetAllTemplateList();
	}

	GetAllTemplateList() {
		this.isLoading = true;
		this._service.GetAllTemplateList().subscribe((data: any) => {
			if (data.length > 0) {
				this.DataSource.data = data;
				this.DataSource.paginator = this.paginator;
				this.DataSource.sort = this.Sort;
			} else {
				this.DataSource.data = [];
			}
			this.isLoading = false;
			this.chng.detectChanges();
			(error: any) => {
				console.log(error);
				this.isLoading = false;
				this.chng.detectChanges();
			}
		})
	}

	redirect() {
		this.router.navigate(['/default/TemplateForm']);
		this.chng.detectChanges();
	}

	ViewModalPopup(row: any, content: any) {
		this.isLoading = true;
		this.ViewModal = this.modalService.open(content, {
			centered: true,
			size: 'lg',
			backdrop: 'static'
		})
		if ((row.TemplateId === null) || (row.TemplateId === undefined) || (row.TemplateId === "")) {
			this.toaster.warning('Template Id Is Not Valid!');
			return;
		}
		this.TemplateId = row.TemplateId;
		this._service.GetAllTemplateValuesList(this.TemplateId).subscribe((data: any) => {
			if (data.length > 0) {
				this.TMPVALUEDATA = data;
			}
			this.isLoading = false;
			this.chng.detectChanges();
			(error: any) => {
				console.log(error);
				this.isLoading = false;
				this.chng.detectChanges();
			}
		})
	}

	ClearData() {
		this.TMPVALUEDATA = [];
		this.chng.detectChanges();
	}

	Redirect(Id: any) {
		this._service.Id = Id;
		this.router.navigate(['/default/TemplateForm']);
	}
}
