import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { ConsumerEnquiryService } from '../../../services/ConsumerEnquiry/consumer-enquiry.service';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';
import { GetSessionService } from '../../../services/globalsession.service';
import moment = require('moment');

@Component({
  selector: 'kt-unassign-consumer-enquiry',
  templateUrl: './unassign-consumer-enquiry.component.html',
  styleUrls: ['./unassign-consumer-enquiry.component.scss']
})
export class UnassignConsumerEnquiryComponent implements OnInit {


  myValue: boolean = true;
  postModel: any;
  _UnassignConsumerEnquiryLst: any[];

  IsValidDate: boolean = true;
  displayedColumns = ['SrNo', 'EnquiryDate', 'ConsumerName', 'MobileNo', 'ResidentiaArea', 'Address', 'CompanyName', 'SourceType', 'Action'];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public ConsEnqLstSource = new MatTableDataSource<any>();

  EnquiryDetails: any;
  _TempModel: any;
  FromDate: Date;
  ToDate: Date;
  constructor(private consumerEnquiryService: ConsumerEnquiryService,
    private chRef: ChangeDetectorRef,
    public datepipe: DatePipe,
    private toastr: ToastrService,
    private getSession: GetSessionService) { }

  ngOnInit() {
    let d = new Date();

    // $(".kt-header__topbar").css('display','none');
    // $("#kt_aside_brand").css('display','none');
    // $("#kt_aside_menu_wrapper").css('display','none');
    // $("#kt_aside").css('display','none');
    // $(".kt-header--fixed").css('left','0px');
    // $("#kt_wrapper").css('padding-left','0px');
    this.EnquiryDetails = {
      YesterdayEnquiry: 0,
      ThisMonthEnquiry: 0,
      TotalEnquiry: 0,
      YesterdayPurchase: 0,
      ThisMonthPurchase: 0,
      TotalPurchase: 0
    };

    this._TempModel = {
      CId: 0,
      FromDate: '',
      ToDate: ''
    };

    this.getConsumerDetails(this._TempModel);
  }
  // use to convert string to date obj
  ConvertStringToDateObj(SelDate) {
    let d = new Date(moment(SelDate, 'DD-MM-YYYY hh:mm tt').format('YYYY-MM-DD'));
    return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() };
  }

  // Use to Convert object to  Date Format string
  ConvertDateFormat(condate) {
    let dateInput = new Date(condate.year, condate.month - 1, condate.day);
    return moment(dateInput).format('YYYY-MM-DD');
  }
  GetLoginDetails() {
    let item = this.getSession.GetSessionData();
    return item.refNo;
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.ConsEnqLstSource.filter = filterValue;
  }
  onDateSelect(FromDate: Date, ToDate: Date) {
    if (FromDate > ToDate) {
      this.IsValidDate = false;
    } else {
      this.IsValidDate = true;
    }
  }
  getConsumerDetails(model: any) {


    let datePipe = new DatePipe('en-US');
    this.postModel = {
      CId: model.CId,
      FromDate: model.FromDate === '' ? '' : this.ConvertDateFormat(model.FromDate),
      ToDate: model.ToDate === '' ? '' : this.ConvertDateFormat(model.ToDate)
    };

    this.consumerEnquiryService.getUnassignConsumerEnquiry(this.postModel)
      .subscribe(data => {
        this._UnassignConsumerEnquiryLst = data.unassginConsumers;
        this.EnquiryDetails = data.emailSchedulerModel;
        this.ConsEnqLstSource = new MatTableDataSource(data.unassginConsumers);
        this.ConsEnqLstSource.paginator = this.paginator;
        this.ConsEnqLstSource.sort = this.sort;
        if (data.unassginConsumers.length === 0) {
          this.toastr.warning('Record not found.', 'Unassign Consumer Enquiry', { timeOut: 2000 });
        }
        // table
        // this.chRef.detectChanges();
      },
        (error) => {
          console.error(error);
        });
  }
}
