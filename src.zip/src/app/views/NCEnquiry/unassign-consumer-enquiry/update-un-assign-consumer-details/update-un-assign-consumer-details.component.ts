import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConsumerEnquiryService } from '../../../../services/ConsumerEnquiry/consumer-enquiry.service';
import { NCEnquiry, CustEnquiryDtls, EnquiryQuestion } from '../../../../models/NCEnquiry/nc-enquiry.model';
import { StoveItem } from '../../../../models/StoveItem/stove-item.model';
import { StoveItemService } from '../../../../services/StoveItem/stove-item.service';
import { NCEnquiryService } from '../../../../services/new-enquiry/nc-enquiry.service';
import { GetSessionService } from '../../../../services/globalsession.service';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { NgbDatepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import moment = require('moment');
@Component({
  selector: 'kt-update-un-assign-consumer-details',
  templateUrl: './update-un-assign-consumer-details.component.html',
  styleUrls: ['./update-un-assign-consumer-details.component.scss']
})
export class UpdateUnAssignConsumerDetailsComponent implements OnInit {

  UnassignConsumer: any;
  _NCEnquiryModel: any;
  _CustEnquiryDtls: CustEnquiryDtls;
  _CustEnqArray: CustomerQueAns[];
  _CustEnq: EnquiryQuestion[];
  _CustEnq1: EnquiryQuestion[];
  _CustEnq2: StoveItem[];
  postModal: any;
  postModal1: any;
  Temp: any;
  DataTemp: any;
  minDate: any;
  _DistLst: any[];
  _ConnectionLst: EnquiryQuestion[];
  _ConnectionLstTemp: EnquiryQuestion[];
  _StoveLst: EnquiryQuestion[];
  _stoveItemDtls: StoveItem[];
  _stoveItemDtlsBrand: StoveItem[];
  _stoveItemBrand: StoveItem[];
  // For Add and Edit
  CId: number;
  EmailId: number;
  Operation: string;
  DistributorId: number;
  disabled: boolean;
  ShowSucces: number;
  ShowGrid: number;
  ShowError: number;
  isLoading: boolean = false;
  postModel: any;

  BrandName: any;
  BrandId: any;

  ConnectionType: any;

  displayedColumns = ['ItemName', 'Price'];
  displayed = ['DocumentName'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public StoveItemSource = new MatTableDataSource<any>();
  public DocumentSource = new MatTableDataSource<any>();
  constructor(private _stoveItemService: StoveItemService,
    private toastr: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private _NCEnquiryService: NCEnquiryService,
    private chRef: ChangeDetectorRef,
    private getSession: GetSessionService,
    private config: NgbDatepickerConfig,
    private consumerEnquiryService: ConsumerEnquiryService
  ) { this._CustEnqArray = []; this._CustEnq = [];  }

  ngOnInit() {
    this.disabled = false;
    this.EmailId = 0;
    this.DistributorId = 0;
    this.ShowGrid = 0;
    this.ShowError = 0;
    this._NCEnquiryModel = new NCEnquiry();
    const current = new Date();
    this.minDate = {
      year: current.getFullYear(),
      month: current.getMonth() + 1,
      day: current.getDate()
    };

    this.resetForm();
    this.getDistributorDetails();
    this.GetConnectionType();
    this.GetStoveItemDetails();
    this.GetStoveTypeLst();


    this.route.params.subscribe(params => {
      this.CId = params['CId'];
      if (this.CId > 0) {
        this.postModel = {
          CId: this.CId,
          FromDate: '',
          ToDate: '',
        };
        this.getConsumerDetails(this.postModel);
      }

    });


  }
  // use to convert string to date obj
  ConvertStringToDateObj(SelDate) {

    let d = new Date(moment(SelDate, 'YYYY-MM-DD').format('YYYY-MM-DD'));
    return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() };
  }

  // Use to Convert object to  Date Format string
  ConvertDateFormat(condate) {
    let dateInput = new Date(condate.year, condate.month - 1, condate.day);
    this.minDate = {
      year: dateInput.getFullYear(),
      month: dateInput.getMonth() + 1,
      day: dateInput.getDate()
    };
    return moment(dateInput).format('YYYY-MM-DD');
  }


  getConsumerDetails(model: any) {
    this.postModel = {
      CId: model.CId,
      FromDate: '',
      ToDate: '',
    };

    this.consumerEnquiryService.getUnassignConsumerEnquiry(this.postModel)
      .subscribe(data => {



        this._NCEnquiryModel = data.unassginConsumersDtls;
        this._NCEnquiryModel = {
          CId: data.unassginConsumersDtls.CId,
          EQueId: null,
          DistributorId: data.unassginConsumersDtls.DistributorId,
          DistributorName: '',
          ConsName: data.unassginConsumersDtls.ConsumerName,
          Address: data.unassginConsumersDtls.Address,
          MobileNo: data.unassginConsumersDtls.MobileNo,
          ResidentiaArea: data.unassginConsumersDtls.ResidentiaArea,
          EmailId: data.unassginConsumersDtls.EmailId,
          CompanyName: data.unassginConsumersDtls.CompanyName,
          ActiveStatus: '',
          Operation: '',
          ExpectedDate: data.unassginConsumersDtls.ExpectedDate === '' ? '' : this.ConvertStringToDateObj(data.unassginConsumersDtls.ExpectedDate),
          StoveId: data.unassginConsumersDtls.burnerType,
          ItemName: '',
          TotalAmount: 0,
          BrandId: 0,
          Price: 0,
          CustEnquiryDtls: '',
          SourceType: data.unassginConsumersDtls.SourceType,
          ConnectionType: ''
        };

        this._CustEnquiryDtls = {
          QueId: data.unassginConsumersDtls.ConnectionType,
          DistributorId: 0,
          StaffRefNo: '',
          ConsName: '',
          Address: '',
          MobileNo: '',
          ConsumerNo: '',
          QId: data.unassginConsumersDtls.Stove,
          AnsId: 0,
          Ans: '',
          FromDate: '',
          ToDate: '',
          EnquiryId: 0,
          ResidentiaArea: '',
          EmailId: '',
          CompanyName: '',
        };
        this.BrandName = data.unassginConsumersDtls.Brand;

        this.GetBrandDetails();
        if (!this.chRef['destroyed']) {
          this.chRef.detectChanges();
        }
      },
        (error) => {
          console.error(error);
        });
  }


  resetForm() {
    this.ShowSucces = 0;
    this.ShowGrid = 0;
    this.ShowError = 0;
    this._NCEnquiryModel = {
      CId: this.CId,
      EQueId: null,
      DistributorId: null,
      DistributorName: '',
      ConsName: '',
      Address: '',
      MobileNo: '',
      ResidentiaArea: '',
      PhoneNumber: '',
      EmailId: '',
      CompanyName: '',
      ActiveStatus: '',
      Operation: '',
      ExpectedDate: '',
      StoveId: 0,
      ItemName: '',
      TotalAmount: 0,
      BrandId: 0,
      Price: 0,
      CustEnquiryDtls: '',
      SourceType: 'WhatsApp',
      ConnectionType: ''
    };
    this._CustEnquiryDtls = {
      QueId: 0,
      DistributorId: 0,
      StaffRefNo: '',
      ConsName: '',
      Address: '',
      MobileNo: '',
      ConsumerNo: '',
      QId: 0,
      AnsId: 0,
      Ans: '',
      FromDate: '',
      ToDate: '',
      EnquiryId: 0,
      ResidentiaArea: '',
      EmailId: '',
      CompanyName: '',
    };
  }


  GetStoveItemDetails() {
    if (this._NCEnquiryModel.DistributorId === 0) {
      this.DistributorId = 8131;
    } else {
      this.DistributorId = this._NCEnquiryModel.DistributorId;
    }
    this.postModal = {
      'DistributorId': this.DistributorId, // 8131,
      'Id': 0,
      'StoveId': 0,
      'Operation': 'MASTER'
    };

    this._NCEnquiryService.getStoveItemDetails(this.postModal)
      .subscribe(data => {
          // table
          this.chRef.detectChanges();

      },
        (error) => {
          console.error(error);
        });
  }
  calculation() {
    return this.StoveItemSource.data.reduce((summ, v) => summ += parseInt(v.TotalAmount,10), 0);
  }
  GetConnectionType() {
    this.postModal = {
      'DistributorId': 8131,
      'Operation': 'Y'
    };
    this._NCEnquiryService.GetDistConnTypePriceDtls(this.postModal)
      .subscribe(data => {
        this._ConnectionLstTemp = data.QuestionMaster;
        this._ConnectionLst = this._ConnectionLstTemp.filter(t => t.QuestionType === 1);
        this._StoveLst = this._ConnectionLstTemp.filter(t => t.QuestionType === 2);
        this.chRef.detectChanges();
      },
        (error) => {
          console.error(error);
        });
  }
  changeDist() {

    this._CustEnquiryDtls.QId = null;
    this._NCEnquiryModel.StoveId = null;
    this._NCEnquiryModel.BrandId = '';
  }

  getDistributorDetails() {
    this.postModal = {
      'DistributorId': 0,
      'Operation': 'Y'
    };
    this._NCEnquiryService.getDistDetails(this.postModal)
      .subscribe(data => {
        this._DistLst = data.DistributorList;
      },
        (error) => {
          console.error(error);
        });
  }

  GetStoveTypeLst() {
    this._stoveItemService.getStoveTypeDetails(this.Temp)
      .subscribe(data => {
        this._stoveItemDtls = data.stoveItemList;
        this.chRef.detectChanges();
      },
        (error) => {
          console.error(error);
        });
  }

  GetBrandDetails() {
    return new Promise(resolve => {

      this.Temp = {
        'Id': 0,
        'StoveId': this._NCEnquiryModel.StoveId,
        'DistributorId': this._NCEnquiryModel.DistributorId,
        'Operation': 'WEB',
      };
      this._stoveItemService.getStoveItemDetails(this.Temp)
        .subscribe(data => {

          this._stoveItemDtlsBrand = data.stoveItemList;
          let temp = this._stoveItemDtlsBrand.filter(x => x.ItemName === this.BrandName);
          if (temp.length > 0) {
            this.BrandId = temp[0].Id;
          }
          this._NCEnquiryModel.BrandId = this.BrandId;
          this.chRef.detectChanges();
        },
          (error) => {
            console.error(error);
          });
    });

  }

  GetBrand() {
    this.Temp = {
      'Id': 0,
      'StoveId': this._NCEnquiryModel.StoveId,
      'DistributorId': this._NCEnquiryModel.DistributorId,
      'Operation': 'WEB',
    };
    this._stoveItemService.getStoveItemDetails(this.Temp)
      .subscribe(data => {
        this._stoveItemDtlsBrand = data.stoveItemList;
        this.chRef.detectChanges();
      },
        (error) => {
          console.error(error);
        });
  }


  onSubmit(productForm: any) {
    // Converting all date format

    this.isLoading = true;
    this._CustEnqArray = [];
    if (this._CustEnquiryDtls.QueId > 0) {
      this._CustEnq = this._ConnectionLst.filter(t => t.EQueId === this._CustEnquiryDtls.QueId);
      this._CustEnqArray.push({
        QId: 1,
        AnsId: this._CustEnq[0].EQueId,
        Ans: this._CustEnq[0].EnquiryQue,
      });

      productForm.ConnectionType = this._CustEnq[0].EnquiryQue;
      this._NCEnquiryModel.ConnectionType = this._CustEnq[0].EnquiryQue;
    }
    if (this._CustEnquiryDtls.QId > 0) {
      this._CustEnq1 = this._StoveLst.filter(t => t.EQueId === this._CustEnquiryDtls.QId);
      this._CustEnqArray.push({
        QId: 2,
        AnsId: this._CustEnq1[0].EQueId,
        Ans: this._CustEnq1[0].EnquiryQue,
      });
    }
    if (this._NCEnquiryModel.StoveId > 0) {
      this._CustEnq2 = this._stoveItemDtls.filter(t => t.StoveId === this._NCEnquiryModel.StoveId);
      this._CustEnqArray.push({
        QId: 3,
        AnsId: this._CustEnq2[0].StoveId,
        Ans: this._CustEnq2[0].StoveType,
      });
    }


    if (this._NCEnquiryModel.ExpectedDate !== null) {
      this._CustEnq2 = this._stoveItemDtls.filter(t => t.StoveId === this._NCEnquiryModel.StoveId);
         let TempExpectedDate = this.ConvertDateFormat(this._NCEnquiryModel.ExpectedDate);
         this._CustEnqArray.push({
          QId: 4,
          AnsId: 0,
          Ans: TempExpectedDate,
        });
    }

    if (this._NCEnquiryModel.BrandId > 0) {
      let TempRcd = this._stoveItemDtlsBrand.filter(t => t.Id === this._NCEnquiryModel.BrandId);
      this._CustEnqArray.push({
        QId: 5,
        AnsId: TempRcd[0].Id,
        Ans: TempRcd[0].ItemName,
      });
    }



    if (this._NCEnquiryModel.DistributorId > 0) {
      let DistDetails = this._DistLst.filter(x => x.DistributorId === this._NCEnquiryModel.DistributorId);

      productForm.DistributorName = DistDetails[0].DistributorName;
      this._NCEnquiryModel.DistributorName = DistDetails[0].DistributorName;
    }


    this._NCEnquiryModel.CustEnquiryDtls = JSON.stringify(this._CustEnqArray);
    productForm.Operation = this.Operation;
    this._NCEnquiryService.saveDistStaffDetails(productForm).subscribe(data => {
      this.isLoading = false;
      if (data.Status === 'Success') {

        if (data.StaffRefNo === -1) {
          this.toastr.error('You have already done Enquiry against this mobile number.', 'NC Enquiry', { timeOut: 2000 });
        } else {
          this.toastr.success('Consumer Record Updated Successfully.', 'NC Enquiry', { timeOut: 2000 });
        }
        this.router.navigateByUrl('/default/getUnassignConsumer');
      }
    });
  }

}

export class CustomerQueAns {
  QId: number;
  AnsId: number;
  Ans: string;
}
