import { ConsumerModel } from './../../../../models/VAS/Consumer.model';
import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { VasService } from '../../../../services/VAS/vas.service';
import { ToastrService } from 'ngx-toastr';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { FormControl } from '@angular/forms';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { VASCounts } from '../../../../models/VAS/VASCounts.model';
import { formatDate } from '@angular/common';
import swal from 'sweetalert2';

@Component({
	selector: 'kt-add-service',
	templateUrl: './add-service.component.html',
	styleUrls: ['./add-service.component.scss']
})
export class AddServiceComponent implements OnInit {

	DistributorCode: string = "";
	userId: string = "";
	ConsumerList: ConsumerModel[];
	myControlGroup = new FormControl();
	SelectedConsumer: ConsumerModel = new ConsumerModel();
	filteredGroupOptions: Observable<ConsumerModel[]>;
	ConsumerName: string = "";
	ConsumerContact: string = "";
	SRId: number = 0;
	DistributorId: number = 0;
	UniqueConsumerId: number = 0;
	SReqDate: Date = new Date();
	MechanicName: string = '';
	SRStatus: number = 0;
	Action: string = 'ADD';
	ConsumerNo: string = '';
	message: string = 'Data Saved Successfully!';
	columns = ['SrNo', 'ConsumerNo', 'ConsumerName', 'MobileNo', 'SReqDate', 'AssignTo', 'SRStatus', 'Action'];
	@ViewChild(MatPaginator) paginator: MatPaginator;
	@ViewChild(MatSort) sort: MatSort;
	public DataSource = new MatTableDataSource<any>();
	ServiceDate: Date = new Date();
	SerMechanicName: string = '';
	isLoading: boolean = false;
	AddServiceModal: any;
	pageState: string = 'Save';

	Counts: VASCounts = new VASCounts();
	VASConsumer: number = 0;
	ActiveCount: number = 0;
	ExpConsCount: number = 0;
	PendingBookings: number = 0;
	AssignBookingCnt: number = 0;
	DueBookingCnt: number = 0;
	TotalSRCnt: number = 0;
	PendingSRCnt: number = 0;
	TodayCompSR: number = 0;
	NoServiceDoneCnt: number = 0;
	Service1DoneCnt: number = 0;
	Service2DoneCnt: number = 0;
	DelBookingCnt: number = 0;
	ServiceData: any[] = [];
	ServiceList: any[] = [];
	Edit: boolean = false;
	searchModel: any;
	UserModal: any;
	popupTitle: string = "Add Service";
	CurrentDateTime = new Date;
	formatDatestring: any;
	ListTitle: string = "Service Request List";

	constructor(private chRef: ChangeDetectorRef, private service: VasService, private toastr: ToastrService,
		private modalService: NgbModal) { }

	ngOnInit() {
		let user = JSON.parse(sessionStorage.getItem('LoginData'));
		this.userId = user.UserName;
		this.GetVASConsumerList();
		this.GetServiceReqList();
		this.GetVASCount();
		this.formatDatestring = formatDate(this.CurrentDateTime, 'dd-MM-yyyy', 'en-US');
	}

	//get vas consumer list
	GetVASConsumerList() {
		this.isLoading = true;
		this.service.GetVASConsumerList_Service(this.userId).subscribe((data) => {
			if (data.length > 0 && data != null && data != "" && data != undefined) {
				this.ConsumerList = data;
				this.filteredGroupOptions = this.myControlGroup.valueChanges
					.pipe(startWith<string | ConsumerModel>(''),
						map(value => typeof value === 'string' ? value : value !== null ? value.ConsumerNo : null),
						map(ConsumerNo => ConsumerNo ? this.filterCons(ConsumerNo) : this.ConsumerList.slice()));
				this.isLoading = false;
				this.chRef.detectChanges();
			} else {
				this.chRef.detectChanges();
			}
		})
	}

	//Get Service Req List
	GetServiceReqList() {
		this.isLoading = true;
		this.service.ServiceReqList_Service(this.userId).subscribe((data) => {
			if (data.length > 0 && data != null && data != "" && data != undefined) {
				this.ServiceData = data;
				this.DataSource.data = data;
				this.DataSource.paginator = this.paginator;
				this.DataSource.sort = this.sort;
				this.isLoading = false;
				this.chRef.detectChanges();
			} else {
				this.DataSource.data = [];
				this.chRef.detectChanges();
			}
		})
	}

	// COUNTS API
	GetVASCount() {
		this.isLoading = true;
		this.service.VASCount_Service(this.userId).subscribe((data) => {
			this.afterCount(data);
			this.chRef.detectChanges();
		})
	}

	afterCount(data) {
		this.isLoading = false;
		this.Counts = data;
		if (this.Counts !== null) {
			this.VASConsumer = this.Counts.VASConsumer;
			this.ActiveCount = this.Counts.ActiveCount;
			this.ExpConsCount = this.Counts.ExpConsCount;
			this.PendingBookings = this.Counts.PendingBookings;
			this.AssignBookingCnt = this.Counts.AssignBookingCnt;
			this.DueBookingCnt = this.Counts.DueBookingCnt;
			this.TotalSRCnt = this.Counts.TotalSRCnt;
			this.PendingSRCnt = this.Counts.PendingSRCnt;
			this.TodayCompSR = this.Counts.TodayCompSR;
			this.NoServiceDoneCnt = this.Counts.NoServiceDoneCnt;
			this.Service1DoneCnt = this.Counts.Service1DoneCnt;
			this.Service2DoneCnt = this.Counts.Service2DoneCnt;
			this.DelBookingCnt = this.Counts.DelBookingCnt;
			this.isLoading = false;
			this.chRef.detectChanges();
		}
	}

	// use for filter data consumerNo wise
	private filterCons(name: string): ConsumerModel[] {
		const filterConsValue = name.toLowerCase();
		return this.ConsumerList.filter(option => option.ConsumerNo.toLowerCase().includes(filterConsValue));
	}

	// use for catch values
	displayFnGroup(user?: ConsumerModel): string | undefined {
		return user ? user.ConsumerNo : undefined;
	}

	//On change consumer Number
	onChangeConsumer() {
		if (this.SelectedConsumer !== null) {
			this.ConsumerName = this.SelectedConsumer.ConsumerName;
			this.ConsumerContact = this.SelectedConsumer.MobileNo;
			this.DistributorCode = this.SelectedConsumer.DistributorCode;
			this.UniqueConsumerId = this.SelectedConsumer.UniqueConsumerId;
		}
	}

//Opens the dialog or popup for service add or edit
	AddEditPopupService(content: any) {
		this.UserModal = this.modalService.open(content, {
			centered: true,
			size: "lg",
			backdrop: "static",
		});
	}

	//Save service data
	saveSerReq() {
		swal.fire({
			title: 'Are you sure?',
			text: "Do You want to save?",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes',
			allowOutsideClick: false
		}).then((result) => {
			if (result.value) {
				this.isLoading = true;
				let model = {
					'SRId': this.SRId,
					'DistributorCode': this.DistributorCode,
					'ConsumerNo': this.SelectedConsumer.ConsumerNo,
					'UniqueConsumerId': this.UniqueConsumerId,
					'SRDate': this.SReqDate,
					'AssignTo': this.MechanicName,
					'SRStatus': this.SRStatus,
					'Action': this.Action
				}
				this.saveAPICall(model);
			}
		});
	}

	//API CALL FOR Save, Update, Delete
	saveAPICall(model: any) {
		this.service.AddEditServiceReq_Service(model).subscribe((data) => {
			if (data === -1) {
				this.isLoading = false;
				this.toastr.warning('Consumer Number Already Exist!', 'VAS Activation', { timeOut: 2000 });
			} else if (data > 0) {
				this.clearData();
				this.GetServiceReqList();
				this.GetVASCount();
				this.isLoading = false;
				this.modalService.dismissAll();
				this.toastr.success(this.message, 'VAS Activation', { timeOut: 2000 });
			}
		})
	}

	//Clear Data from service form
	clearData() {
		this.popupTitle = "Add Service"
		this.SelectedConsumer = null;
		this.ConsumerName = '';
		this.ConsumerContact = '';
		this.SReqDate = new Date();
		this.MechanicName = '';
		this.SRId = 0;
		this.ConsumerNo = '';
		this.Action = 'Add';
		this.Edit = false;
		this.pageState = "Save";
		this.chRef.detectChanges();
	}

	//Opens the dialog or popup for service edit
	updateServicePopup(row: any, content: any) {
		this.AddServiceModal = this.modalService.open(content, {
			centered: true,
			size: 'md',
			backdrop: 'static'
		})
		this.SRId = row.SRId;
		this.DistributorCode = row.DistributorCode;
		this.ConsumerNo = row.ConsumerNo;
		this.UniqueConsumerId = row.UniqueConsumerId;
	}


	//Update Service Data operations
	updateServiceReq() {
		this.isLoading = true;
		if (this.SRStatus == 1) {
			if (this.SerMechanicName == '') {
				this.toastr.warning('Please Enter Mechanic Name!', 'VAS Activation', { timeOut: 2000 });
				return;
			}
			this.message = 'Service Request Status Updated Successfully!';
		}
		else {
			this.message = 'Service Request Canceled Successfully!';
		}
		let model = {
			'SRId': this.SRId,
			'DistributorCode': this.DistributorCode,
			'ConsumerNo': this.ConsumerNo,
			'UniqueConsumerId': this.UniqueConsumerId,
			'SRDate': this.ServiceDate,
			'AssignTo': this.SerMechanicName,
			'SRStatus': this.SRStatus,
			'Action': 'DONE'
		}
		this.saveAPICall(model);
	}

	//Set Data for Update operation
	setData(row: any) {
		this.pageState = "Update";
		this.popupTitle = "Update Service"
		this.SRId = row.SRId;
		this.SelectedConsumer = new ConsumerModel();
		this.SelectedConsumer.ConsumerNo = String(row.ConsumerNo);
		this.SelectedConsumer.ConsumerName = row.ConsumerName;
		this.SelectedConsumer.MobileNo = row.MobileNo;
		this.SelectedConsumer.DistributorCode = row.DistributorCode;
		this.ConsumerName = row.ConsumerName;
		this.ConsumerContact = row.MobileNo;
		this.DistributorCode = row.DistributorCode;
		this.UniqueConsumerId = row.UniqueConsumerId;
		this.SReqDate = row.SReqDate;
		this.MechanicName = row.AssignTo;
		this.message = 'Data Updated Successfully!';
		this.Edit = true;
		this.Action = 'EDIT';
		this.chRef.detectChanges();
	}


	//Delete Service Data by row wise
	DeleteSerReq(row: any) {
		this.isLoading = true;
		swal.fire({
			title: 'Are you sure?',
			text: "Do You want to Delete?",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes',
			allowOutsideClick: false
		}).then((result) => {
			if (result.value) {
				let model = {
					'SRId': row.SRId,
					'Action': 'DELETE',
					'SReqDate': this.SReqDate,
				}
				this.SRId = row.SRId;
				this.Action = 'DELETE';
				this.message = 'Record Deleted Successfully!';
				this.saveAPICall(model);
			}
		});
		this.isLoading = false;
	}

	//Filter Data Status wise
	filterData(Flag: any) {
		if (this.DataSource.data !== null || this.DataSource.data !== undefined) {
			if (Flag === 'Pending') {
				this.ListTitle = "Service Request List - Pending" + ' (' + this.PendingSRCnt + ')';
				this.ServiceList = this.ServiceData.filter(x => x.SRStatus === 0)
			}
			else if (Flag === 'Completed') {
				this.ListTitle = "Service Request List - Completed" + ' (' + this.TodayCompSR + ')';
				this.ServiceList = this.ServiceData.filter(x => x.SRCompletedOn === this.formatDatestring && x.SRDoneCount === 1)
			}
			this.DataSource = new MatTableDataSource(this.ServiceList);
			this.DataSource.paginator = this.paginator;
			this.DataSource.sort = this.sort;
			this.chRef.detectChanges();
		}
	}

	//Clear Add service data
	cleardataSerice() {
		this.SerMechanicName = '';
		this.ServiceDate = new Date();
		this.SRStatus = 0;
		this.chRef.detectChanges();
	}

	//Search - Apply Filter
	applyFilter() {
		this.isLoading = true
		this.searchModel = this.searchModel.toLowerCase() //Datasource defaults to lowercase matches
		this.DataSource.filter = this.searchModel
		this.isLoading = false
		this.chRef.detectChanges()
	}
}
