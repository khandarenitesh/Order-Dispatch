import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { VasService } from '../../../../services/VAS/vas.service'
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material'
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { VASCounts } from '../../../../models/VAS/VASCounts.model';


@Component({
	selector: 'kt-booking-details',
	templateUrl: './booking-details.component.html',
	styleUrls: ['./booking-details.component.scss'],
})

export class BookingDetailsComponent implements OnInit {

	displayedColumnsForApi = ['SRNo', 'ConsumerNo', 'ConsumerName', 'MobNo', 'OrderNo', 'OrderDateTime',
		'ActualDelDate', 'AssignTo', 'OrderStatus', 'Action']
	@ViewChild(MatPaginator) paginator: MatPaginator
	@ViewChild('Sort') Sort: MatSort;
	public DataSource = new MatTableDataSource<any>()
	@ViewChild('DelboyAssignForm') DelboyAssignForm: NgForm;
	Counts: VASCounts = new VASCounts();

	maxDate = new Date();
	isLoading: boolean = false
	searchModel: string = ''
	DistributorCode: string = ''
	FromDate: any = null;
	Todate: any = null;
	Flag: string = 'PENDING';
	RefillPendingBookingModal: any;
	pageState: string = '';
	PkOrderId: number = 0;
	DistributorId: number = 0;
	DelBoyName: string = '';
	message: string = 'Assigned Successfully!';
	failed: string = 'Something went Wrong!';
	DistributorCode1: string = "";
	VASConsumer: number = 0;
	ActiveCount: number = 0;
	ExpConsCount: number = 0;
	PendingBookings: number = 0;
	AssignBookingCnt: number = 0;
	DueBookingCnt: number = 0;
	TotalSRCnt: number = 0;
	PendingSRCnt: number = 0;
	TodayCompSR: number = 0;
	NoServiceDoneCnt: number = 0;
	Service1DoneCnt: number = 0;
	Service2DoneCnt: number = 0;
	DelBookingCnt: number = 0;
	RifillPendingData: any[] = [];
	RifillPendingList: any[] = [];
	TodaysDateTime = new Date();
	CurrentDateTime = new Date();
	OrderDate: string = "";
	ListTitle: string = "Refill Pending Booking List";

	constructor(private service: VasService, private chRef: ChangeDetectorRef, private modalService: NgbModal,
		private toastr: ToastrService) { }

	ngOnInit() {
		this.pageState = "Submit";
		let user = JSON.parse(sessionStorage.getItem('LoginData'))
		this.DistributorCode1 = user.refNo;
		this.DistributorCode1 = user.UserName;
		this.RefillPendingList();
		this.GetRefillVASCount();
	}

	//popup function
	DelBoyAssignPopup(row: any, content: any) {
		this.PkOrderId = row.PkOrderId;
		this.DistributorId = row.DistributorId;
		this.DistributorCode = row.DistributorCode;
		this.DelBoyName = "";
		this.RefillPendingBookingModal = this.modalService.open(content, {
			centered: true,
			size: 'sm',
			backdrop: 'static'
		})
	}

	//Save Data Delivery Boy Assign
	SaveDelboyAssign() {
		this.isLoading = true;
		let model = {
			'PkOrderId': this.PkOrderId,
			'DistributorCode': this.DistributorCode,
			'DelBoyName': this.DelBoyName
		}
		this.service.SaveDelboyAssign_Service(model)
			.subscribe((data: any) => {
				if (data > 0) {
					this.toastr.success(this.message, 'Delivery Boy', { timeOut: 2000 });
					this.modalService.dismissAll();
				} else if (data === -1) {
					this.toastr.error(this.failed, 'Delivery Boy Assign', { timeOut: 2000 });
				}
				this.RefillPendingList();
				this.GetRefillVASCount();
			}, (error: any) => {
				console.error(error);
				this.isLoading = false;
				this.chRef.detectChanges();
			});
	}

	//Get Refill Booking List
	RefillPendingList() {
		this.isLoading = true
		this.service.GetRefillPendingList(this.DistributorCode1, this.FromDate, this.Todate, this.Flag).subscribe((data) => {
			if (data.length > 0) {
				this.DataSource.data = data
				this.RifillPendingData = data;
				this.DataSource.paginator = this.paginator
				this.DataSource.sort = this.Sort
				this.isLoading = false
				this.chRef.detectChanges()
			} else {
				this.DataSource.data = []
				this.isLoading = false
				this.chRef.detectChanges()
			}
		})
	}

	//Get Refill Booking Counts
	GetRefillVASCount() {
		this.isLoading = true;
		this.service.VASCount_Service(this.DistributorCode1).subscribe((data) => {
			if (data !== null || data !== undefined) {
				this.afterCount(data);
			}
			this.chRef.detectChanges();
		})
	}

	afterCount(data) {
		this.Counts = data;
		if (this.Counts !== null) {
			this.VASConsumer = this.Counts.VASConsumer;
			this.ActiveCount = this.Counts.ActiveCount;
			this.ExpConsCount = this.Counts.ExpConsCount;
			this.PendingBookings = this.Counts.PendingBookings;
			this.AssignBookingCnt = this.Counts.AssignBookingCnt;
			this.DueBookingCnt = this.Counts.DueBookingCnt;
			this.TotalSRCnt = this.Counts.TotalSRCnt;
			this.PendingSRCnt = this.Counts.PendingSRCnt;
			this.TodayCompSR = this.Counts.TodayCompSR;
			this.NoServiceDoneCnt = this.Counts.NoServiceDoneCnt;
			this.Service1DoneCnt = this.Counts.Service1DoneCnt;
			this.Service2DoneCnt = this.Counts.Service2DoneCnt;
			this.DelBookingCnt = this.Counts.DelBookingCnt;
			this.isLoading = false;
			this.chRef.detectChanges();
		}
	}

	filterData(Flag: any) {
		if (this.DataSource.data !== null || this.DataSource.data !== undefined) {
			if (Flag === 'Pending') {	
				this.ListTitle = "Refill Pending Booking List - Pending" + ' (' + this.PendingBookings + ')';
				this.RifillPendingList = this.RifillPendingData.filter(x => x.OrderStatus !== 'DLVD' &&
					x.OrderStatus !== 'Cancelled' && x.OrderStatus !== 'Delivered');
			}
			else if (Flag === 'Alloted') {
				this.ListTitle = "Refill Pending Booking List - Alloted" + ' (' + this.AssignBookingCnt + ')';
				this.RifillPendingList = this.RifillPendingData.filter((x => (x.OrderStatus !== 'DLVD' &&
					x.OrderStatus !== 'Cancelled' && x.OrderStatus !== 'Delivered') && (x.AssignTo !== null)))
			}
			else if (Flag === 'Due') {
				this.ListTitle = "Refill Pending Booking List - Delayed" + ' (' + this.DueBookingCnt + ')';
				this.TodaysDateTime = new Date();
				this.CurrentDateTime = new Date(this.TodaysDateTime.setHours(this.TodaysDateTime.getHours() - 24));
				this.RifillPendingList = this.RifillPendingData.filter(p => (new Date(p.OrderDateTime)) < this.CurrentDateTime && (p.OrderStatus !== 'DLVD' &&
					p.OrderStatus !== 'Cancelled' && p.OrderStatus !== 'Delivered'));
			}
			else if (Flag === 'Delivered') {
				this.ListTitle = "Refill Pending Booking List - Delivered" + ' (' + this.DelBookingCnt + ')';
				this.RifillPendingList = this.RifillPendingData.filter(x => (x.OrderStatus === 'DLVD') ||
					(x.OrderStatus === 'Cancelled') || (x.OrderStatus === 'Delivered'))
			}
			this.DataSource = new MatTableDataSource(this.RifillPendingList);
			this.DataSource.paginator = this.paginator;
			this.DataSource.sort = this.Sort;
			this.chRef.detectChanges();
		}
	}

	//Search - Apply Filter
	applyFilter() {
		this.isLoading = true
		this.searchModel = this.searchModel.toLowerCase() //Datasource defaults to lowercase matches
		this.DataSource.filter = this.searchModel
		this.isLoading = false
		this.chRef.detectChanges()
	}
}
