import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogForDataFetchingComponent } from './log-for-data-fetching.component';

describe('LogForDataFetchingComponent', () => {
  let component: LogForDataFetchingComponent;
  let fixture: ComponentFixture<LogForDataFetchingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogForDataFetchingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogForDataFetchingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
