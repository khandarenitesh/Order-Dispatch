import { Component,	OnInit,	ChangeDetectorRef,	ViewChild,	ElementRef,} from "@angular/core";
import { FormControl } from "@angular/forms";
import { MatPaginator, MatTableDataSource, MatSort } from "@angular/material";
import { VasLogCounts } from "../../../../models/VAS/VASCounts.model"
import { VasService } from "../../../../services/VAS/vas.service";
import { ToastrService } from "ngx-toastr";
import { formatDate } from "@angular/common";

@Component({
  selector: 'kt-log-for-data-fetching',
  templateUrl: './log-for-data-fetching.component.html',
  styleUrls: ['./log-for-data-fetching.component.scss']
})
export class LogForDataFetchingComponent implements OnInit {

  Counts: VasLogCounts = new VasLogCounts();
	LoginFailCount: number = 0;
	BKGFileFailCount: number = 0;
	SRFileFailCounts: number = 0;
	BkgEmptyExcelCounts: number = 0;
	SREmptyExcelCounts: number = 0;
	LastCycleTime: number = 0;
	OneamshedularExeutedornot: number = 0;
	TotalBkgDownloadFile: number = 0;
	TotalNoofCycle: number = 0;
	isLoading: boolean = false;
	// DistributorCode: string = "";
	// Flag: string = "ALL";
	// FromDate = new FormControl();
	// Todate = new FormControl();
	// logSaveCountList: any[] = [];
	// Flag1: any;
	searchModel: any;
	currentDate = new Date();
	DataSource = new MatTableDataSource<any>();
	LogFeacthDataList: any[] = [];
	LogFeacthDataList1: any[] = [];
	ListTitle : string ="LogIn Fail Count"
	formatDatestring: any;
	ColumnArray = [
		"SrNo",
		"DistributorCode",
		"LoginDateTime",
		"LogFor",
		"LoginStatus",
		"BkgFileAddedOn",
		"SRFileAddedOn",
		"BkgExcelCount",
		"BkgImportedCount",
		"SRExcelCount",
		"SRImportedCount",
	];
	@ViewChild("TABLE") table: ElementRef;
	@ViewChild("paginator") paginator: MatPaginator;
	@ViewChild("sort1") sort1: MatSort;

	constructor(
		private chRef: ChangeDetectorRef,
		private service: VasService,
		private toastr: ToastrService
	) {}

	ngOnInit() {
		this.GetLogDataCounts();
		this.GetLogFeacthing();
		this.GetLogSaveForCountList();
		// this.FromDate = new FormControl(new Date());
		// this.Todate = new FormControl(new Date());
		this.formatDatestring = formatDate(
			this.currentDate,
			"dd/MM/yyyy",
			"en-US"
		);


	}

	// It will Display For PageLoad when Log In Count Fail
	GetLogFeacthing() {
		this.isLoading = true;
		this.service.GetSaveLogList_Service().subscribe((data: any) => {
			if (
				data.length > 0 &&
				data != null &&
				data != "" &&
				data != undefined
			) {
				this.DataSource.data = data.filter(
					(x) =>
						x.LoginDateTime == this.formatDatestring &&
						x.LoginStatus == "0" &&
						x.DistributorCode !== "0"
				);
				this.DataSource.paginator = this.paginator;
				this.DataSource.sort = this.sort1;
			} else {
				this.DataSource.data = [];
			}
			this.isLoading = false;
			this.chRef.detectChanges();
			(error: any) => {
				this.isLoading = false;
				this.chRef.detectChanges;
			};
		});
	}

	// When Click On Count Link It will Call This List
	GetLogSaveForCountList() {
		this.isLoading = true;
		this.service.GetLogFeachDataForCountList().subscribe((data: any) => {
			if (
				data.length > 0 &&
				data != null &&
				data != "" &&
				data != undefined
			) {
				this.LogFeacthDataList = data;
				this.DataSource.paginator = this.paginator;
				this.DataSource.sort = this.sort1;
				this.isLoading = false;
				this.chRef.detectChanges();
			} else {
				this.DataSource.data = [];
				this.isLoading = false;
				this.chRef.detectChanges();
			}
		});
	}

	// All Counts API
	GetLogDataCounts() {
		this.isLoading = true;
		this.service.GetLogCount_Service().subscribe((data) => {
			this.afterCount(data);
			this.chRef.detectChanges();
		});
	}

	// After Counts API
	afterCount(data) {
		this.isLoading = false;
		this.Counts = data;
		if (this.Counts !== null) {
			this.LoginFailCount = this.Counts.LoginFailCount;
			this.BKGFileFailCount = this.Counts.BKGFileFailCount;
			this.SRFileFailCounts = this.Counts.SRFileFailCounts;
			this.BkgEmptyExcelCounts = this.Counts.BkgEmptyExcelCounts;
			this.SREmptyExcelCounts = this.Counts.SREmptyExcelCounts;
			this.LastCycleTime = this.Counts.LastCycleTime;
			this.OneamshedularExeutedornot =
				this.Counts.OneamshedularExeutedornot;
			this.TotalBkgDownloadFile = this.Counts.TotalBkgDownloadFile;
			this.TotalNoofCycle = this.Counts.TotalNoofCycle;
		}
	}

	// Filter Data
	FilterData(Flag: any) {
		if (
			this.DataSource.data !== null ||
			this.DataSource.data !== undefined
		) {
			if (Flag === "BkgFail") {
				this.ListTitle = " Refill Booking Failed List ";
				this.LogFeacthDataList1 = this.LogFeacthDataList.filter(
					(x) => x.BkgFileName == "No File"
				);
			} else if (Flag === "BkgExcelEmpty") {
				this.ListTitle = "Refill Booking Excel Empty List";
				this.LogFeacthDataList1 = this.LogFeacthDataList.filter(
					(x) => x.BkgExcelCount == 0 && x.BkgFileName !== null
				);
			} else if (Flag === "SRFail") {
				this.ListTitle = "Sales Register Failed List";
				this.LogFeacthDataList1 = this.LogFeacthDataList.filter(
					(x) => x.SRFileName == "No File"
				);
			} else if (Flag === "SREmptyExcel") {
				this.ListTitle = "Sales Register Empty Excel List";
				this.LogFeacthDataList1 = this.LogFeacthDataList.filter(
					 (x) => x.SRExcelCount == 0 && x.SRFileName !== null
				);
			} else if (Flag === "LogInFail") {
				this.ListTitle = "LogIn Failed List";
				this.LogFeacthDataList1 = this.LogFeacthDataList.filter(
					(x) =>
						x.LoginDateTime == this.formatDatestring &&
						x.LoginStatus == "0" &&
						x.DistributorCode !== "0"
				);
			} else if (Flag === "ToNoOfCycle") {
				this.ListTitle = "Total No of Cycle List";
				this.LogFeacthDataList1 = this.LogFeacthDataList.filter(
					(x) => x.LogFor == "Cycle End"
				);
			}
			this.DataSource = new MatTableDataSource(this.LogFeacthDataList1);
			this.DataSource.paginator = this.paginator;
			this.DataSource.sort = this.sort1;
			this.chRef.detectChanges();
		}
	}

	// ClearFun() {
	// 	if (this.FromDate.value > this.Todate.value) {
	// 		this.Todate.reset();
	// 		this.toastr.warning("From Date Should Be Less Than To Date!");
	// 		this.chRef.detectChanges();
	// 	}
	// }

	applyFilter() {
		this.isLoading = true;
		this.searchModel = this.searchModel.toLowerCase();
		this.DataSource.filter = this.searchModel;
		this.isLoading = false;
		this.chRef.detectChanges();
	}

}
