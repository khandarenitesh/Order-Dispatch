import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { NgForm } from "@angular/forms";
import { ChangeDetectorRef, Component, OnInit, ViewChild } from "@angular/core";
import { ToastrService } from "ngx-toastr";
import { VasService } from "../../../../services/VAS/vas.service";
import { ConsumerModel } from "../../../../models/VAS/Consumer.model";
import moment = require("moment");
import { MatPaginator, MatSort, MatTableDataSource } from "@angular/material";
import { VASCounts } from "../../../../models/VAS/VASCounts.model";
import swal from 'sweetalert2';

@Component({
	selector: "kt-vas-activation",
	templateUrl: "./vas-activation.component.html",
	styleUrls: ["./vas-activation.component.scss"],
})
export class VASActivationComponent implements OnInit {
	public _ConsumerModel: ConsumerModel = new ConsumerModel();

	SACode: number = 0;
	DistributorId: number = 0;
	DistributorCode: string = "";
	DistributorName: string = "";
	UniqueConsumerId: string = "0";
	ConsumerNo: string = "";
	ConsumerName: string = "";
	ConsumerContact: string = "";
	AreaName: string = "";
	IsRegistered: string = "Y";
	ConsAddr: string = "";
	RegistrationDate: any;
	Status: number = 1;
	IsApprove: string = "1";
	Action: string = "ADD";
	message: string = "Record Added Successfully.";
	disable: boolean = false;
	pageState: string = "";
	isLoading: boolean = false;
	ConsumerList: any[] = [];
	ConsumerData: any[] = [];

	columns = ["SrNo", "ConsumerNo", "ConsumerName", "MobileNo", "RegistrationDate", "Status", "Action"];
	@ViewChild(MatPaginator) paginator: MatPaginator;
	@ViewChild(MatSort) sort: MatSort;
	public DataSource = new MatTableDataSource<any>();
	@ViewChild("AddService") AddService: NgForm;
	Counts: VASCounts = new VASCounts();
	VASConsumer: number = 0;
	ActiveCount: number = 0;
	ExpConsCount: number = 0;
	PendingBookings: number = 0;
	AssignBookingCnt: number = 0;
	DueBookingCnt: number = 0;
	TotalSRCnt: number = 0;
	PendingSRCnt: number = 0;
	TodayCompSR: number = 0;
	NoServiceDoneCnt: number = 0;
	Service1DoneCnt: number = 0;
	Service2DoneCnt: number = 0;
	DelBookingCnt: number = 0;
	UserModal: any;
	searchModel: string = "";
	DataShare: any;
	CurrentDateTime = new Date();
	ListTitle: string = "Value Added Service Activated Consumers List";
	constructor(
		private chRef: ChangeDetectorRef,
		private service: VasService,
		private toastr: ToastrService,
		private modalService: NgbModal
	) { }

	ngOnInit() {
		let user = JSON.parse(sessionStorage.getItem("LoginData"));
		this.DistributorId = user.refNo;
		this.DistributorCode = user.UserName;
		this.DistributorName = user.DisplayName;
		this.RegistrationDate = new Date();
		this.pageState = "Save";
		this.getonloadData();
	}

	getonloadData() {
		this.GetVASConsumerList();
		this.GetVASActiovationCount();
	}

	GetVASConsumerList() {
		this.isLoading = true;
		this.service
			.GetVASConsumerList_Service(this.DistributorCode)
			.subscribe((data) => {
				if (
					data.length > 0 &&
					data != null &&
					data != "" &&
					data != undefined
				) {
					this.ConsumerData = data;
					this.DataSource.data = data;
					this.DataSource.paginator = this.paginator;
					this.DataSource.sort = this.sort;
					this.isLoading = false;
					this.chRef.detectChanges();
				} else {
					this.DataSource.data = [];
					this.chRef.detectChanges();
				}
			});
	}

	numberOnly(event: any) {
		const pattern = /[0-9]/;
		let inputChar = String.fromCharCode(event.charCode);
		if (event.keyCode != 8 && !pattern.test(inputChar)) {
			event.preventDefault();
		}
	}

	Adddata() {
		if (this.ConsumerNo == "" && this.Action !== "STATUS" && this.Action !== "APPROVE"
		) {
			this.toastr.warning("Please Enter Consumer Number", "VAS Activation", { timeOut: 2000 }
			);
		} else if (this.ConsumerName == "" && this.Action !== "STATUS" && this.Action !== "APPROVE"
		) {
			this.toastr.warning("Please Enter Consumer Name", "VAS Activation", { timeOut: 2000 });
		} else if (this.ConsumerContact == "" && this.Action !== "STATUS" && this.Action !== "APPROVE") {
			this.toastr.warning("Please Enter Consumer Name", "VAS Activation", { timeOut: 2000 });
		} else {
			this.isLoading = true;
			let model = {
				SACode: this.SACode,
				DistributorId: this.DistributorId,
				DistributorCode: this.DistributorCode,
				DistributorName: this.DistributorName,
				AddedBy: this.DistributorName,
				UniqueConsumerId: this.UniqueConsumerId,
				ConsumerNo: this.ConsumerNo,
				MobileNo: this.ConsumerContact,
				ConsumerName: this.ConsumerName,
				AreaName: this.AreaName,
				ConsumerAddress: this.ConsAddr,
				IsRegistered: this.IsRegistered,
				RegisterDate: this.RegistrationDate,
				Status: this.Status,
				IsApprove: this.IsApprove,
				Action: this.Action,
			};
			this.DataShare = model;
			this.isLoading = false;
			this.chRef.detectChanges();
		}
	}

	SubmitData() {
		this.isLoading = true;
		let model = this.DataShare;
		this.service.AddEditConsumer(model).subscribe((data) => {
			if (data === -2) {
				this.isLoading = false;
				this.toastr.warning(
					"Consumer Number Already Exist!",
					"VAS Activation",
					{ timeOut: 2000 }
				);
				this.chRef.detectChanges();
			} else if (data > 0) {
				this.clearData();
				this.getonloadData();
				this.isLoading = false;
				this.toastr.success(this.message, "VAS Activation", {
					timeOut: 2000,
				});
				this.chRef.detectChanges();
			} else if (data === -1) {
				this.isLoading = false;
				this.toastr.error(
					"Something went Wrong!",
					"VAS Activation"
				);
				this.chRef.detectChanges();
			}
			this.getonloadData();
			this.message = "Record Added Successfully";
			this.modalService.dismissAll();
		});
	}

	clearData() {
		this.ConsumerNo = "";
		this.ConsumerName = "";
		this.ConsumerContact = "";
		this.RegistrationDate = new Date();
		this.AreaName = "";
		this.ConsAddr = "";
		this.Action = "ADD";
		this.disable = false;
		this.pageState = "Save";
		this.chRef.detectChanges();
	}

	setdata(row: any) {
		this.pageState = "Update";
		this.disable = true;
		this.SACode = row.SACode;
		this.DistributorId = row.DistributorId;
		this.DistributorCode = row.DistributorCode;
		this.DistributorName = row.DistributorName;
		this.UniqueConsumerId = row.UniqueConsumerId;
		this.ConsumerNo = row.ConsumerNo;
		this.ConsumerContact = row.MobileNo;
		this.ConsumerName = row.ConsumerName;
		this.AreaName = row.AreaName;
		this.ConsAddr = row.ConsumerAddress;
		this.IsRegistered = row.IsRegistered;
		this.RegistrationDate = row.RegistrationDate;
		this.Status = row.Status;
		this.Action = "EDIT";
		this.message = "Data Upadated Successfully!";
	}

	changeStatus(row: any) {
		this.isLoading = true;
		swal.fire({
			title: 'Are you sure?',
			text: "Do You want to Change Status?",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes',
			allowOutsideClick: false
		}).then((result) => {
			if (result.value) {
				if (row.Status == 1) {
					this.Status = 0;
				}
				if (row.Status == 0) {
					this.Status = 1;
				}
				this.DistributorCode = row.DistributorCode;
				this.ConsumerNo = row.ConsumerNo;
				this.Action = "STATUS";
				this.message = "Status Changed Successfully!";
				this.Adddata();
				this.SubmitData();
				this.isLoading = false;
			}
		});
		this.isLoading = false;
	}


	ApproveConsumer(row: any) {
		this.isLoading = true;
		this.IsApprove = "1";
		this.DistributorCode = row.DistributorCode;
		this.ConsumerNo = row.ConsumerNo;
		this.Action = "APPROVE";
		this.message = "Consumer Approved Successfully!";
		this.Adddata();
		this.SubmitData();
	}

	GetVASActiovationCount() {
		this.isLoading = true;
		this.service
			.VASCount_Service(this.DistributorCode)
			.subscribe((data) => {
				this.afterCount(data);
				this.chRef.detectChanges();
			});
	}

	afterCount(data) {
		this.isLoading = false;
		this.Counts = data;
		if (this.Counts !== null) {
			this.VASConsumer = this.Counts.VASConsumer;
			this.ActiveCount = this.Counts.ActiveCount;
			this.ExpConsCount = this.Counts.ExpConsCount;
			this.PendingBookings = this.Counts.PendingBookings;
			this.AssignBookingCnt = this.Counts.AssignBookingCnt;
			this.DueBookingCnt = this.Counts.DueBookingCnt;
			this.TotalSRCnt = this.Counts.TotalSRCnt;
			this.PendingSRCnt = this.Counts.PendingSRCnt;
			this.TodayCompSR = this.Counts.TodayCompSR;
			this.NoServiceDoneCnt = this.Counts.NoServiceDoneCnt;
			this.Service1DoneCnt = this.Counts.Service1DoneCnt;
			this.Service2DoneCnt = this.Counts.Service2DoneCnt;
			this.DelBookingCnt = this.Counts.DelBookingCnt;
			this.isLoading = false;
			this.chRef.detectChanges();
		}
	}

	filterData(Flag: any) {
		if (
			this.DataSource.data !== null ||
			this.DataSource.data !== undefined
		) {
			if (Flag === "All") {
				this.ListTitle = "Value Added Service Activated Consumers List - All " + ' (' + this.VASConsumer + ')';
				this.ConsumerList = this.ConsumerData;
			} else if (Flag === "Active") {
				this.ListTitle = "Value Added Service Activated Consumers List - Active" + ' (' + this.ActiveCount + ')';
				this.ConsumerList = this.ConsumerData.filter(
					(x) => x.Status === 1);
			} else if (Flag === "Expired") {
				this.ListTitle = "Value Added Service Activated Consumers List - Expired" + ' (' + this.ExpConsCount + ')';
				this.ConsumerList = this.ConsumerData.filter(p => (new Date(p.ExpiryDate)) < this.CurrentDateTime);
				// this.ConsumerList = this.ConsumerData.filter((x) => x.Status === 2);
			}
			this.DataSource = new MatTableDataSource(this.ConsumerList);
			this.DataSource.paginator = this.paginator;
			this.DataSource.sort = this.sort;
			this.chRef.detectChanges();
		}
	}

	AddEditPopupVas(content: any) {
		this.UserModal = this.modalService.open(content, {
			centered: true,
			size: "lg",
			backdrop: "static",
		});
		this.chRef.detectChanges();
	}

	SetDataPopupVas(content: any) {
		this.UserModal = this.modalService.open(content, {
			centered: true,
			size: "md",
			backdrop: "static",
			keyboard: false,
		});
		this.chRef.detectChanges();
	}

	applyFilter() {
		this.isLoading = true;
		this.searchModel = this.searchModel.toLowerCase();
		this.DataSource.filter = this.searchModel;
		this.isLoading = false;
		this.chRef.detectChanges();
	}

}
