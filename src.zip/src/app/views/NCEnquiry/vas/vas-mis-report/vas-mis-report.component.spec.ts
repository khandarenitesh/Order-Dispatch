import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VasMisReportComponent } from './vas-mis-report.component';

describe('VasMisReportComponent', () => {
  let component: VasMisReportComponent;
  let fixture: ComponentFixture<VasMisReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VasMisReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VasMisReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
