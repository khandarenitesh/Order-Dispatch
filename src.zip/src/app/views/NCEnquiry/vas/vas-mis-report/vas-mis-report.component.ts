import { Subscription } from "rxjs";
import {
	ChangeDetectorRef,
	Component,
	OnInit,
	ViewChild,
	ElementRef,
} from "@angular/core";
import { AdminDbcService } from "../../../../services/adminDBCCampaign/admin-dbc.service";
import { GetSessionService } from "../../../../services/globalsession.service";
import { MatPaginator, MatSort, MatTableDataSource } from "@angular/material";
import { VasService } from "../../../../services/VAS/vas.service";
import * as XLSX from "xlsx";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: 'kt-vas-mis-report',
  templateUrl: './vas-mis-report.component.html',
  styleUrls: ['./vas-mis-report.component.scss']
})
export class VasMisReportComponent implements OnInit {

	private unsubscribe: Subscription[] = [];
	DataSource = new MatTableDataSource<any>();
	@ViewChild(MatPaginator) paginator: MatPaginator;
	@ViewChild(MatSort) sort: MatSort;
	@ViewChild("TABLE") table: ElementRef;

	SelectedSA: string = "0";
	isLoading: boolean = false;
	postModal: any;
	DataModel: any;
	SAList = [];
	SACountList: any;

	displayedColumns = [
		"SAName",
		"JDEDistributorCode",
		"DistributorName",
		"TotalRegConsumer",
		"PendingBooking",
		"YestDelivery",
		"DelDelay",
		"S1",
		"S2",
	];
	dtOption: any;
	constructor(
		private chRef: ChangeDetectorRef,
		private adminDbcService: AdminDbcService,
		private getSession: GetSessionService,
		private service: VasService,
		private toaster: ToastrService
	) {}

	ngOnInit() {
		this.postModal = {
			SACode: this.GetLoginDetails(),
		};
		this.GetSAList(this.postModal);
		this.GetMISInformation(this.DataModel); // Call The list for Page Load
	}

	ngAfterViewInit() {
		this.dtOption = {
			paging: false,
			filter: false,
			sort: false,
			info: false,
			language: {
				zeroRecords: " ",
			},
		};

		$(() => {
			$(".DataTable").DataTable(this.dtOption);
		});
	}

	GetLoginDetails() {
		let item = this.getSession.GetSessionData();
		return item.refNo;
	}

	// Sales Area Dropdown list
	GetSAList(postModel) {
		this.unsubscribe.push(
			this.adminDbcService.GetSAByRoCode(postModel.SACode).subscribe(
				async (data) => {
					this.SAList = [];
					this.SAList = await data;
					if (!this.chRef["destroyed"]) {
						this.chRef.detectChanges();
					}
				},
				(error) => {
					console.error(error);
				}
			)
		);
	}

	// MIS Report List
	GetMISInformation(DataModel) {
		this.isLoading = true;
		this.DataModel = {
			SACode: DataModel,
			Flag: "distwise",
			ROCode: this.postModal.SACode,
		};
		this.unsubscribe.push(
			this.service.VASMISReportList(this.DataModel).subscribe((data) => {
				this.afterMISInformation(data);
			})
		);
	}

	afterMISInformation(data) {
		if (data != null && data != undefined) {
			this.isLoading = false;
			this.SACountList = [];
			this.SACountList = data;
			this.DataSource = new MatTableDataSource();
			this.DataSource.data = data;
			this.DataSource.paginator = this.paginator;
			this.DataSource.sort = this.sort;
			this.chRef.detectChanges();
		} else {
			this.DataSource = new MatTableDataSource();
			this.DataSource.data = null;
		}
	}

	//Export Excel
	exportAsExcel() {
		let data: any[] = [];
		const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(
			this.table.nativeElement
		);
		const wb: XLSX.WorkBook = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet(wb, ws, "All Data Export");
		XLSX.writeFile(wb, "excelFile.xlsx");
	}

	ngOnDestroy() {
		this.unsubscribe.forEach((sb) => sb.unsubscribe());
	}
}
