import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-vas',
  templateUrl: './vas.component.html',
  styleUrls: ['./vas.component.scss']
})
export class VASComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
