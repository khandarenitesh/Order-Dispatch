// Angular
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// RxJS
import { Observable, Subject } from 'rxjs';
import { finalize, takeUntil, tap } from 'rxjs/operators';
// Translate
import { TranslateService } from '@ngx-translate/core';
// Store
import { Store } from '@ngrx/store';
import { AppState } from '../../../../core/reducers';
// Auth
import { AuthNoticeService, AuthService, Login } from '../../../../core/auth';


import { OMCAuthService } from '../../../../services/auth/auth.service';
import { ToastrService } from 'ngx-toastr';
import { GetSessionService } from '../../../../services/globalsession.service';
import { Meta } from '@angular/platform-browser';
import { GlobalVersion } from '../../../../services/common.service';
import { NgbModal, NgbModalRef, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';


/**
 * ! Just example => Should be removed in development
 */
const DEMO_PARAMS = {
	EMAIL: '',
	PASSWORD: ''
};



@Component({
	selector: 'kt-login',
	templateUrl: './login.component.html',
	encapsulation: ViewEncapsulation.None
})
export class LoginComponent implements OnInit, OnDestroy {
	modalReference: NgbModalRef;
	myString: string = "";
	closeResult: string;  
	isLoginFlag: boolean = false;

	/**
	 * Component constructor
	 *
	 * @param router: Router
	 * @param auth: AuthService
	 * @param authNoticeService: AuthNoticeService
	 * @param translate: TranslateService
	 * @param store: Store<AppState>
	 * @param fb: FormBuilder
	 * @param cdr
	 */
	constructor(
		private _OMCAuthService: OMCAuthService,
		private router: Router,
		private auth: AuthService,
		private authNoticeService: AuthNoticeService,
		private translate: TranslateService,
		private store: Store<AppState>,
		private fb: FormBuilder,
		private route: ActivatedRoute,
		private cdr: ChangeDetectorRef,
		private toastr: ToastrService,
		private getSession: GetSessionService,
		private meta: Meta,
		private modalService: NgbModal
	) {
		this.unsubscribe = new Subject();
		this.Version = this.meta.getTag('name=Version');


	}
	static counter = 1;
	// Public params
	loginForm: FormGroup;
	loading = false;
	isLoggedIn$: Observable<boolean>;
	errors: any = [];
	Version: any;
	OldVersion: string = '01';

	SessionData: string;
	private unsubscribe: Subject<any>; // Read more: => https://brianflove.com/2016/12/11/anguar-2-unsubscribe-observables/

	/**
	 * @ Lifecycle sequences => https://angular.io/guide/lifecycle-hooks
	 */

	/**
	 * On init
	 */

	private API_ENDPOINT = GlobalVersion.Version;
	ngOnInit(): void {

		if (this.Version.content !== this.OldVersion) {

			window.location.reload();  // Forcely Refresh page
			sessionStorage.setItem('IsLoaded', 'loaded');
		}

		// this.stepper.selectedIndex = 2;



		this.initLoginForm();
		document.addEventListener('DOMContentLoaded', function() {
			sessionStorage.removeItem('IsLoaded');
		});
	}

	/**
	 * On destroy
	 */
	ngOnDestroy(): void {
		this.authNoticeService.setNotice(null);
		this.unsubscribe.next();
		this.unsubscribe.complete();
		this.loading = false;
	}

	/**
	 * Form initalization
	 * Default params, validators
	 */
	initLoginForm() {
		// demo message to show
		if (!this.authNoticeService.onNoticeChanged$.getValue()) {
			const initialNotice = `Use Username
			<strong>${DEMO_PARAMS.EMAIL}</strong> and password
			<strong>${DEMO_PARAMS.PASSWORD}</strong> to continue.`;
			this.authNoticeService.setNotice(initialNotice, 'info');
		}
		this.isLoginFlag = false;
		this.loginForm = this.fb.group({
			email: [DEMO_PARAMS.EMAIL, Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(320) // https://stackoverflow.com/questions/386294/what-is-the-maximum-length-of-a-valid-email-address
			])
			],
			password: [DEMO_PARAMS.PASSWORD, Validators.compose([
				Validators.required,
				Validators.minLength(3),
				Validators.maxLength(100)
			])
			]
		});
	}

	/**
	 * Form Submit
	 */
	async submit(content) {
		const controls = this.loginForm.controls;
		/** check form */
		if (this.loginForm.invalid) {
			Object.keys(controls).forEach(controlName =>
				controls[controlName].markAsTouched()
			);
			return;
		}
		this.loading = true;
		const authData = {
			email: controls['email'].value,
			password: controls['password'].value
		};
		let a = null;
		
		await this._OMCAuthService.CheckLogin(authData.email, authData.password).then((data) => {
			a = data;
			if (a === "EmailSuccess") {
				this.myString = "Reset Password link has been sent to your registered email id. Kindly check and reset password.";
				// setTimeout(() => {
					this.isLoginFlag = true;
					this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
						this.closeResult = `Closed with: ${result}`;  
						if (result === 'Ok') {  
						  this.modalReference.close(); 
						}  
					  }, (reason) => {
						this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;  
					  });  
				// }, 5000); // 5 seconds
			}
			this.loading = false;
			this.cdr.detectChanges();
		});

		// this._OMCAuthService.login(authData.email, authData.password);

	}

	private getDismissReason(reason: any): string {  
		if (reason === ModalDismissReasons.ESC) {
		  return 'by pressing ESC';  
		} else if (reason === ModalDismissReasons.BACKDROP_CLICK) {  
		  return 'by clicking on a backdrop';  
		} else {  
		  return `with: ${reason}`;  
		}  
	  }  

	shortAfterLongFunc(x) {
		alert('short func completed with value: ' + x);
		return {
			a: x
		};
	}

	/**
	 * Checking control validation
	 *
	 * @param controlName: string => Equals to formControlName
	 * @param validationType: string => Equals to valitors name
	 */
	isControlHasError(controlName: string, validationType: string): boolean {
		const control = this.loginForm.controls[controlName];
		if (!control) {
			return false;
		}

		const result = control.hasError(validationType) && (control.dirty || control.touched);
		return result;
	}
}
