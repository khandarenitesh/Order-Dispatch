import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OMCAuthService } from '../../../../services/auth/auth.service';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
@Component({
  selector: 'kt-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss']
})
export class TestComponent implements OnInit {
  SessionData: string;
  constructor(private route: ActivatedRoute,
    private _OMCAuthService: OMCAuthService,
    private router: Router) { }

  ngOnInit() {

    this.route.params.subscribe(params => {
		  this.SessionData = params['SessionData'];
    });
    if (this.SessionData !== '') {
      this.submit();
    } else {
      this.router.navigateByUrl('/auth/login');
    }

  }

  async submit() {


		let a = null;
		await this._OMCAuthService.CheckLoginAnotherWeb( this.SessionData,  this.SessionData).then(data => {

      if (data !== null ) {
        a = data;
      } else {
        this.router.navigateByUrl('/auth/login');
      }


			// this.cdr.detectChanges();
		});

		// this._OMCAuthService.login(authData.email, authData.password);

	}

}
