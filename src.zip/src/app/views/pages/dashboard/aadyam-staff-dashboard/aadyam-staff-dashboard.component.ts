import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-aadyam-staff-dashboard',
  templateUrl: './aadyam-staff-dashboard.component.html',
  styleUrls: ['./aadyam-staff-dashboard.component.scss']
})
export class AadyamStaffDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
