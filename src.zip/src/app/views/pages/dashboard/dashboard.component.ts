// Angular
import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
// Lodash
import { shuffle } from 'lodash';
// Services
import { LayoutConfigService } from '../../../core/_base/layout';
// Widgets model
import { SparklineChartOptions } from '../../../core/_base/metronic';
import { Widget4Data } from '../../partials/content/widgets/widget4/widget4.component';
import { DistributorConnTypePrice } from '../../../models/DistributorConn/distributor-conn-type-price.model';
import { DistributorConnTypeService } from '../../../services/DistributorConn/distributor-conn-type.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { DistributorDashboardService } from '../../../services/Dashboard/dashboard.service';
import { DistDashboard, InterestedConsumerCount, MessageSentConsumerCount, Staffwisecount } from '../../../models/Dashboard/dist-dashboard.model';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { GetSessionService } from '../../../services/globalsession.service';

import { LocationStrategy } from "@angular/common";

@Component({
	selector: 'kt-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['dashboard.component.scss'],
	providers: [DistributorDashboardService]
})
export class DashboardComponent implements OnInit {


	postModal: any;
	_ConnTypeLst: DistributorConnTypePrice;
	RoleId: Number;
	loadingTitle = '';
	closeResult: string;
	today: any;
	RSP: number;
	DistLanguage: string;

	DistCount: DistDashboard;
	staffLst: Staffwisecount;
	_messageSentConsumerCount: MessageSentConsumerCount;
	_interestedConsumerCount: InterestedConsumerCount;
	_ContctDtls: DistributorConnTypePrice;
	displayedColumns = ['SrNo', 'StaffName',  'TodayNcEnquiry','TotalNcEnquiry','TodayPurchase','TotalPurchase'];
	@ViewChild(MatPaginator) paginator: MatPaginator;
	@ViewChild(MatSort) sort: MatSort;
	public DistStaffSource = new MatTableDataSource<any>();

	LanguageMst: any[];
	_DistLangaugeModel: any;

	ContactNo: string;

	constructor(private layoutConfigService: LayoutConfigService,
		private distDashboardService: DistributorDashboardService,
		private distributorConnTypeService: DistributorConnTypeService,
		private chRef: ChangeDetectorRef,
		private toastr: ToastrService,
		private modalService: NgbModal,
		private getSession: GetSessionService,
		private Location: LocationStrategy) {
	}

	ngOnInit(): void {

		// hide back button
		history.pushState(null, null, window.location.href);

		this.Location.onPopState(() => {
			history.pushState(null, null, window.location.href);
		});

		this.LanguageMst = [];
		this._DistLangaugeModel = {
			DistributorId: this.GetLoginDetails(),
			LanguageId: 0,
			LanguageName: '',
			ActiveStatus: 'Y',
		  };

		$('.custom_Test').css('display', 'block');
		this.DistCount = new DistDashboard();
		this._messageSentConsumerCount = new MessageSentConsumerCount();
		this._interestedConsumerCount = new InterestedConsumerCount();
		this._ConnTypeLst = new DistributorConnTypePrice();
		this._ContctDtls = new DistributorConnTypePrice();
		let item = JSON.parse(sessionStorage.getItem('LoginData'));
		if (item !== null) {
			this.RoleId = item.RoleId;
		}
		this.postModal = {
			'DistributorId': this.GetLoginDetails()
		};
		this.GetdistributorConnTypeDetails(this.postModal);
		this.GetDashboardCount(this.postModal);
		this.DistLanguage = '';
		// Update Language
		this.GetLanguageMaster();

	}


	GetDashboardCount(postModel) {
		this.distDashboardService.GetDistDashboardCount(postModel)
			.subscribe(data => {
				// (data);
				//
				this.DistCount = data.getDashboardCount;
				this._messageSentConsumerCount = data.messageSentConsumerCount;
				this._interestedConsumerCount = data.interestedConsumerCount;
				this.DistStaffSource = new MatTableDataSource(data.Staffwisecount);
				this.DistStaffSource.paginator = this.paginator;
				this.DistStaffSource.sort = this.sort;

				if (!this.chRef['destroyed']) {
					this.chRef.detectChanges();
				  }
			},
				(error) => {
					console.error(error);
				});
	}
	applyFilter(filterValue: string) {
		filterValue = filterValue.trim(); // Remove whitespace
		filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
		this.DistStaffSource.filter = filterValue;
	  }

	GetdistributorConnTypeDetails(postdata) {
		this.distributorConnTypeService.GetDistConnTypePriceDtls(postdata)
			.subscribe(data => {

				this._ConnTypeLst = data.GetDistConnType;
				this._ContctDtls  = data.GetDistConnType;
				this.RSP = data.GetDistConnType.RSP;
				this.DistLanguage = data.GetDistConnType.LanguageName;
				this._DistLangaugeModel.LanguageId = data.GetDistConnType.LanguageId;
				this.ContactNo = data.GetDistConnType.ContactNo;
				// table
				if (!this.chRef['destroyed']) {
					this.chRef.detectChanges();
				  }
			},
				(error) => {
					console.error(error);
				});
	}
	GetLoginDetails() {
		let item = this.getSession.GetSessionData();
		return item.refNo;
	}

	// Update RSP Amount
	// Update Purchase Date
	open(content) {

		this.loadingTitle = 'Update RSP Amount';
		this.modalService.open(content, { centered: true }).result.then((result) => {
			this.closeResult = `Closed with: ${result}`;
		}, (reason) => {
			this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
		});
	}
	private getDismissReason(reason: any): string {
		if (reason === ModalDismissReasons.ESC) {
			return 'by pressing ESC';
		} else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
			return 'by clicking on a backdrop';
		} else {
			return `with: ${reason}`;
		}
	}
	_UpdateRSPAmount(UpdateRspDetails: DistributorConnTypePrice) {
		UpdateRspDetails.ActiveStatus = '';
		UpdateRspDetails.Flag = 'RSP';
		this.distributorConnTypeService.saveDistConnTypePriceDtls(UpdateRspDetails).subscribe(data => {
			if (data.Status === 'Success') {
				if (data.StaffRefNo === -1) {
					this.toastr.error('RSP Amount not exists.', 'RSP Amount', {timeOut: 2000});
				} else if (data.StaffRefNo > 0) {

					// this.router.navigateByUrl("/default/getConsumerEnquiry");
					this.toastr.success('RSP Amount Updated Successfully.', 'RSP Amount', {timeOut: 2000});
				} else {
					this.toastr.error('Network error', 'RSP Amount', {timeOut: 2000});
				}
			}
			this.modalService.dismissAll();
			this.GetdistributorConnTypeDetails(this.postModal);
		});
	}

	// Update Contact Details
	openUpdateContact(content) {

		this.loadingTitle = 'Update Contact Details';

		this.modalService.open(content, { centered: true, size: 'lg' }).result.then((result) => {
			this.closeResult = `Closed with: ${result}`;

		}, (reason) => {
			this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
		});
	}

	// Update WhatsApps Language Details
	openUpdateLanguage(content) {

		this.loadingTitle = 'Update Language Details';
		this.GetLanguageMaster();

		this.modalService.open(content, { centered: true, size: 'lg' }).result.then((result) => {
			this.closeResult = `Closed with: ${result}`;

		}, (reason) => {
			this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
		});
	}



	_UpdateContactDetailsAmount(UpdateRspDetails: DistributorConnTypePrice) {
		UpdateRspDetails.ActiveStatus = '';
		UpdateRspDetails.DistributorId = this.GetLoginDetails();
		UpdateRspDetails.Flag = 'CONTACTNO';
		this.distributorConnTypeService.saveDistConnTypePriceDtls(UpdateRspDetails).subscribe(data => {
			if (data.Status === 'Success') {
				if (data.StaffRefNo === -1) {
					this.toastr.error('CONTACT number not exists.', 'CONTACT Details', {timeOut: 2000});
				} else if (data.StaffRefNo > 0) {

					// this.router.navigateByUrl("/default/getConsumerEnquiry");
					this.toastr.success('CONTACT number Updated Successfully.', 'CONTACT Details', {timeOut: 2000});
				} else {
					this.toastr.error('Network error', 'CONTACT Details', {timeOut: 2000});
				}
			}
			this.modalService.dismissAll();
			this.GetdistributorConnTypeDetails(this.postModal);
		});
	}

	// Distributor Language

	// Get Language Master
	GetLanguageMaster() {
		this.distDashboardService.GetLanguageMaster(this.postModal)
		  .subscribe(data => {
			this.LanguageMst = data.LangList;
			if (!this.chRef['destroyed']) {
			  this.chRef.detectChanges();
			}
		  },
			(error) => {
			  console.error(error);
			});
	}
	_SaveDistributorLanguage(LangModel: any) {

		this.distDashboardService.SaveDistributorLanguageDtls(LangModel)
		  .subscribe(data => {
			if (data.Status === 'Success') {
			  if (data.ResultId === -1) {
				this.toastr.error('Distributor Language not Save', 'Distributor Language', { timeOut: 2000 });
			  } else if (data.ResultId > 0) {
				this.toastr.success('Distributor Language Saved Successfully.', 'Distributor Language', { timeOut: 2000 });
			  }

			  if (!this.chRef['destroyed']) {
				this.chRef.detectChanges();
			  }
			}
			this.modalService.dismissAll();
			this.GetdistributorConnTypeDetails(this.postModal);
		  },
			(error) => {
			  console.error(error);
			});
	  }

}
