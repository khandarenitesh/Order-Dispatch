
import { MatInputModule, MatFormFieldModule, MatTableModule, MatSortModule, MatPaginatorModule, MatTooltipModule, MatIconModule, MatRadioModule } from '@angular/material';
// Angular
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
// NgBootstrap
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from 'angular-datatables';


// Core Module
import { CoreModule } from '../../../core/core.module';
import { PartialsModule } from '../../partials/partials.module';
import { DashboardComponent } from './dashboard.component';
import {MatSelectModule} from '@angular/material/select';
import { RODashboardComponent } from './rodashboard/rodashboard.component';
import { ExcelService } from '../../../services/Excel.service';
import { AadyamStaffDashboardComponent } from './aadyam-staff-dashboard/aadyam-staff-dashboard.component';

@NgModule({
	imports: [
		FormsModule,
		ReactiveFormsModule,
		MatSelectModule,
		MatInputModule,
	MatFormFieldModule,
		CommonModule,
		PartialsModule,
		CoreModule,
		NgbModule,
		MatTableModule,
		MatSortModule,
		MatPaginatorModule ,
		MatTooltipModule,
		DataTablesModule,
		MatIconModule,
		MatRadioModule,
		RouterModule.forChild([
			{
				path: '',
				component: DashboardComponent
			},
		]),
	],
	providers: [ExcelService],
	declarations: [
		DashboardComponent,RODashboardComponent, AadyamStaffDashboardComponent
	],
	bootstrap: [RODashboardComponent]
})
export class DashboardModule {
}
