import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RODashboardComponent } from './rodashboard.component';

describe('RODashboardComponent', () => {
  let component: RODashboardComponent;
  let fixture: ComponentFixture<RODashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RODashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RODashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
