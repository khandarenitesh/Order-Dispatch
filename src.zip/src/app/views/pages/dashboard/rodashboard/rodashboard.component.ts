import { Component, OnInit, ViewChild, ChangeDetectorRef, ElementRef, Directive } from '@angular/core';
import { GetSessionService } from '../../../../services/globalsession.service';
import { DistributorDashboardService } from '../../../../services/Dashboard/dashboard.service';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { DatePipe } from '@angular/common';
import { ExcelService } from '../../../../services/Excel.service';
import { ToastrService } from 'ngx-toastr';

@Component({
	selector: 'kt-rodashboard',
	templateUrl: './rodashboard.component.html',
	styleUrls: ['./rodashboard.component.scss']
})
export class RODashboardComponent implements OnInit {
	constructor(private _GetSessionService: GetSessionService,
		private distDashboardService: DistributorDashboardService,
		private _ChangeDetectorRef: ChangeDetectorRef,
		private datepipe: DatePipe,
		private excelService: ExcelService,
		private _ToastrService: ToastrService) {
		this.MultipleSAList = new TempModel;
	}
	@ViewChild('TABLE') table: ElementRef;
	postModal: any;
	GetRODashboardCountList: any;
	GetRODashboardDistwiseCountList: any;
	public MultipleSAData = Array<any>();
	public MultipleSAList: TempModel;
	dtOption: any;
	// Table 1
	displayedColumns = ['SrNo', 'SAName', 'TotalDist', 'ActiveDist', 'Enquiry', 'ConnectionRels', 'InActiveDist',];
	@ViewChild('MatPaginator', { read: MatPaginator }) paginator: MatPaginator;
	@ViewChild('MatSort', { read: MatSort }) sort: MatSort;
	public RODashboardDataSource = new MatTableDataSource<any>();

	TotalDistributors: number = 0;
	ActiveDistributors: number = 0;
	YestEnquiries: number = 0;
	TotalEnquiries: number = 0;
	ConnectionRelease: number = 0;
	InActiveDistributors: number = 0;

	SACount: number = 0;
	SANameCount: number = 20;
	Key: string;

	ngOnInit(): void {
		this.postModal = {
			'ROCode': this._GetSessionService.GetLoginDetails()
		};
		this.GetRODashboardCount(this.postModal).then(res =>
			this.GetRODashboardDistwiseCount(this.postModal)
		);
		// this.GetRODashboardDistwiseCount(this.postModal);
		this.dtOption = {
			paging: false,
			filter: false
		};
	}
	GetRODashboardCount(postModel) {
		return this.distDashboardService.GetRODashboardCount(postModel)
		.toPromise()
		.then(data => {
				this.GetRODashboardCountList = data.rODashboardCounts;
				for (let q = 0; q < data.rODashboardCounts.length; q++) {
					this.TotalDistributors = this.TotalDistributors + data.rODashboardCounts[q].TotalDist;
					this.ActiveDistributors = this.ActiveDistributors + data.rODashboardCounts[q].ActiveDist;
					this.YestEnquiries = this.YestEnquiries + data.rODashboardCounts[q].YestEnquiry;
					this.TotalEnquiries = this.TotalEnquiries + data.rODashboardCounts[q].Enquiry;
					this.ConnectionRelease = this.ConnectionRelease + data.rODashboardCounts[q].ConnectionRels;
					this.InActiveDistributors = this.InActiveDistributors + data.rODashboardCounts[q].InActiveDist;
				}
				this.RODashboardDataSource = new MatTableDataSource(data.rODashboardCounts);
				this.RODashboardDataSource.paginator = this.paginator;
				this.RODashboardDataSource.sort = this.sort;
				this._ChangeDetectorRef.detectChanges();
				$(() => {
					$('.displayFirst').DataTable(this.dtOption);
				});
			},
				(error) => {
					console.error(error);
				});
	}

	calculation() {
		return this.GetRODashboardCountList.map(t => t.TotalDist).reduce((acc, value) => acc + value, 0);
	}

	applyFilter2(filterValue: string) {
		filterValue = filterValue.trim(); // Remove whitespace
		filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
		this.RODashboardDataSource.filter = filterValue;
	}
	GetRODashboardDistwiseCount(postModel) {
		let SortedData = [];
		let sa1;
		let sa2;
		this.distDashboardService.GetRODashboardDistwiseCount(postModel)
			.subscribe(data => {
				this.GetRODashboardDistwiseCountList = data;
				for (let i = 0; i < data.length; i++) {
					if (data[i].SACode !== null) {
						if (i < (data.length - 1)) {
							 sa1 = data[i].SACode;
							 sa2 = data[i + 1].SACode;
						} else {
							sa2 = 0;
						}
						if (sa1 === sa2) {
							SortedData.push({
								'DistributorName': data[i].DistributorName,
								'ConnectionRels': data[i].ConnectionRels,
								'YestEnquiry': data[i].YestEnquiry,
								'Enquiry': data[i].Enquiry,
								'ActiveUsers': data[i].ActiveUsers
							});
						} else {
							SortedData.push({
								'DistributorName': data[i].DistributorName,
								'ConnectionRels': data[i].ConnectionRels,
								'YestEnquiry': data[i].YestEnquiry,
								'Enquiry': data[i].Enquiry,
								'ActiveUsers': data[i].ActiveUsers
							});
							this.GetRODashboardDistwiseCountList = SortedData;
							this.MultipleSAData[this.SACount] = this.GetRODashboardDistwiseCountList;
							this.MultipleSAList[this.SACount] = data[i].SAName;
							this._ChangeDetectorRef.detectChanges();
							SortedData = [];
							this.SACount = this.SACount + 1;
							this.SANameCount = this.SANameCount + 1;
						}
					}
				}

				this._ChangeDetectorRef.detectChanges();
				$(() => {
					$('.display').DataTable();
				});
			},
				(error) => {
					console.error(error);
				});

	}

	applyFilter(filterValue: string, Count: number) {
		filterValue = filterValue.trim(); // Remove whitespace
		filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
		this.MultipleSAData[Count].RODashboardCount = this.MultipleSAData[Count].RODashboardCount;
		this.MultipleSAData[Count].RODashboardCount.filter = filterValue;
	}


	// use to export data to excel
	exportAsXLSX(data, FileName): void {
		let ExcelData = [];
		if (data !== null && data !== undefined) {
			for (let i = 0; i < data.length; i++) {
				ExcelData.push({
					'Distributor Name': data[i].DistributorName,
					'Active Users': data[i].ActiveUsers,
					'Yesterday\'s Enquiries': data[i].YestEnquiry,
					'Total Enquiries': data[i].Enquiry,
					'Connection Release': data[i].ConnectionRels
				});
			}
			this.excelService.exportAsExcelFile(ExcelData, FileName);
		} else {
			this._ToastrService.success('Data Not Available.');
		}
	}
}

export class TempModel {
	MultipleSAWiseDataList: any;
}
