import { Component, OnInit, Input, forwardRef, Output, EventEmitter } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

const noop = () => {
};
export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => SdsDatepickerComponent),
  multi: true
};

@Component({
  selector: 'sds-datepicker',
  templateUrl: './sds-datepicker.component.html',
  styleUrls: ['./sds-datepicker.component.scss'],
  providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR]
})
export class SdsDatepickerComponent implements ControlValueAccessor {
  @Input() required: boolean;
  /**
     * Holds the current value of the date
     */
  @Input() ngModel: any;

  /**
   * Invoked when the model has been changed
   */
  @Output() ngModelChange: EventEmitter<any> = new EventEmitter<any>();
  @Input() placeholder: string;
  @Input() minDate: any;
  @Input() maxDate: any;
  DateValue: any;
  // The internal data model
  private innerValue: any = '';

  // Placeholders for the callbacks which are later providesd
  // by the Control Value Accessor
  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;
  constructor() { }

  ngOnInit() {
    if (this.required === undefined || this.required === null) {
      this.required = false;
    }
  }
  // Focus Event function for input component
  public focusIn(target: HTMLElement): void {
    target.parentElement.classList.add('e-input-focus');
  }

  // FocusOut Event function for input component
  public focusOut(target: HTMLElement): void {
    target.parentElement.classList.remove('e-input-focus');
  }
  // MouseDown Event function for input component
  public onMouseDown(target: HTMLElement): void {
    target.classList.add('e-input-btn-ripple');
  }

  // MouseUp Event function for input component
  public onMouseUp(target: HTMLElement): void {
    let ele: HTMLElement = target;
    setTimeout(
      () => { ele.classList.remove('e-input-btn-ripple'); },
      500);
  }

  // get accessor
  get value(): any {
    return this.innerValue;
  }

  // set accessor including call the onchange callback
  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = v;
      this.onChangeCallback(v);
    }
  }

  // Set touched on blur
  onBlur() {
    this.onTouchedCallback();
  }

  // From ControlValueAccessor interface
  writeValue(value: any) {
    if (value !== this.innerValue) {
      this.innerValue = value;
    }
  }

  // From ControlValueAccessor interface
  registerOnChange(fn: any) {
    this.onChangeCallback = fn;
  }

  // From ControlValueAccessor interface
  registerOnTouched(fn: any) {
    this.onTouchedCallback = fn;
  }
}
